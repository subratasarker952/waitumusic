import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Brain, 
  TrendingUp, 
  Target, 
  Clock, 
  Star, 
  ChevronDown, 
  ChevronRight,
  Lightbulb,
  BarChart3,
  Award,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Zap
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CareerRecommendation {
  id: string;
  title: string;
  category: 'immediate' | 'short_term' | 'long_term';
  priority: 'low' | 'medium' | 'high';
  description: string;
  actionItems: string[];
  expectedImpact: string;
  timeframe: string;
  difficulty: 'easy' | 'medium' | 'hard';
  resources?: string[];
}

interface IndustryInsight {
  trend: string;
  impact: 'positive' | 'negative' | 'neutral';
  relevance: number;
  description: string;
  timeframe: string;
}

interface UserAnalysis {
  role: string;
  experience: number;
  recentActivity: number;
  engagementLevel: 'low' | 'medium' | 'high';
  growthTrend: 'declining' | 'stable' | 'growing';
  strengths: string[];
  weaknesses: string[];
}

interface AIRecommendationsResponse {
  recommendations: CareerRecommendation[];
  insights: IndustryInsight[];
  analysis: UserAnalysis;
}

const AICareerWidget: React.FC = () => {
  const [expandedRecommendations, setExpandedRecommendations] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const { data, isLoading, error, refetch } = useQuery<AIRecommendationsResponse>({
    queryKey: ['/api/ai-recommendations'],
    retry: 1,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const toggleRecommendation = (id: string) => {
    setExpandedRecommendations(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'default';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'immediate': return <Zap className="h-4 w-4" />;
      case 'short_term': return <Target className="h-4 w-4" />;
      case 'long_term': return <TrendingUp className="h-4 w-4" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'hard': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const getEngagementLevelColor = (level: string) => {
    switch (level) {
      case 'high': return 'text-green-600 dark:text-green-400';
      case 'medium': return 'text-yellow-600 dark:text-yellow-400';
      case 'low': return 'text-red-600 dark:text-red-400';
      default: return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getGrowthTrendIcon = (trend: string) => {
    switch (trend) {
      case 'growing': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'stable': return <BarChart3 className="h-4 w-4 text-yellow-600" />;
      case 'declining': return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default: return <BarChart3 className="h-4 w-4 text-gray-600" />;
    }
  };

  const getImpactIcon = (impact: string) => {
    switch (impact) {
      case 'positive': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'negative': return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'neutral': return <BarChart3 className="h-4 w-4 text-gray-600" />;
      default: return <BarChart3 className="h-4 w-4 text-gray-600" />;
    }
  };

  const refreshRecommendations = () => {
    refetch();
    toast({
      title: "Refreshing Recommendations",
      description: "Getting the latest career insights for you...",
    });
  };

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Career Recommendations
          </CardTitle>
          <CardDescription>
            Analyzing your career data and generating personalized insights...
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="h-20 bg-gray-100 dark:bg-gray-800 rounded animate-pulse" />
            <div className="h-32 bg-gray-100 dark:bg-gray-800 rounded animate-pulse" />
            <div className="h-24 bg-gray-100 dark:bg-gray-800 rounded animate-pulse" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Career Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Unable to load career recommendations at this time.
            </p>
            <Button onClick={refreshRecommendations} variant="outline">
              <RefreshCw className="h-4 w-4 mr-2" />
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data) return null;

  const { recommendations, insights, analysis } = data;

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              AI Career Recommendations
            </CardTitle>
            <CardDescription>
              Personalized insights based on your profile and industry trends
            </CardDescription>
          </div>
          <Button onClick={refreshRecommendations} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="insights">Insights</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Career Health Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Progress value={analysis.experience} className="flex-1" />
                    <span className="text-sm font-medium">{analysis.experience}%</span>
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                    Based on profile completion and activity
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Growth Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    {getGrowthTrendIcon(analysis.growthTrend)}
                    <span className="capitalize font-medium">{analysis.growthTrend}</span>
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                    Recent activity: {analysis.recentActivity} actions
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Engagement Level</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${
                      analysis.engagementLevel === 'high' ? 'bg-green-500' :
                      analysis.engagementLevel === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                    }`} />
                    <span className={`capitalize font-medium ${getEngagementLevelColor(analysis.engagementLevel)}`}>
                      {analysis.engagementLevel}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Top Priority</CardTitle>
                </CardHeader>
                <CardContent>
                  {recommendations.length > 0 ? (
                    <div>
                      <p className="font-medium text-sm">{recommendations[0].title}</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                        {recommendations[0].timeframe}
                      </p>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-600 dark:text-gray-400">No recommendations available</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Quick Strengths & Weaknesses */}
            <div className="grid gap-4 md:grid-cols-2 mt-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    Strengths
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    {analysis.strengths.slice(0, 3).map((strength, index) => (
                      <div key={index} className="text-sm text-green-700 dark:text-green-400">
                        • {strength}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                    Areas for Growth
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    {analysis.weaknesses.slice(0, 3).map((weakness, index) => (
                      <div key={index} className="text-sm text-amber-700 dark:text-amber-400">
                        • {weakness}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="recommendations" className="mt-4">
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {recommendations.map((rec) => (
                  <Card key={rec.id} className="border-l-4 border-l-blue-500">
                    <Collapsible 
                      open={expandedRecommendations.has(rec.id)}
                      onOpenChange={() => toggleRecommendation(rec.id)}
                    >
                      <CollapsibleTrigger asChild>
                        <CardHeader className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800/50">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              {getCategoryIcon(rec.category)}
                              <div>
                                <CardTitle className="text-base">{rec.title}</CardTitle>
                                <div className="flex items-center gap-2 mt-1">
                                  <Badge variant={getPriorityColor(rec.priority)} className="text-xs">
                                    {rec.priority} priority
                                  </Badge>
                                  <Badge variant="outline" className="text-xs capitalize">
                                    {rec.category.replace('_', ' ')}
                                  </Badge>
                                  <span className={`text-xs px-2 py-1 rounded-full ${getDifficultyColor(rec.difficulty)}`}>
                                    {rec.difficulty}
                                  </span>
                                </div>
                              </div>
                            </div>
                            {expandedRecommendations.has(rec.id) ? 
                              <ChevronDown className="h-4 w-4" /> : 
                              <ChevronRight className="h-4 w-4" />
                            }
                          </div>
                        </CardHeader>
                      </CollapsibleTrigger>
                      
                      <CollapsibleContent>
                        <CardContent>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                            {rec.description}
                          </p>
                          
                          <div className="space-y-3">
                            <div>
                              <h4 className="font-medium text-sm mb-2">Action Items:</h4>
                              <ul className="space-y-1">
                                {rec.actionItems.map((action, index) => (
                                  <li key={index} className="text-sm text-gray-600 dark:text-gray-400 flex items-start gap-2">
                                    <CheckCircle2 className="h-3 w-3 mt-0.5 text-green-600 flex-shrink-0" />
                                    {action}
                                  </li>
                                ))}
                              </ul>
                            </div>
                            
                            <div className="grid gap-2 md:grid-cols-2">
                              <div>
                                <span className="font-medium text-sm">Expected Impact:</span>
                                <p className="text-sm text-gray-600 dark:text-gray-400">{rec.expectedImpact}</p>
                              </div>
                              <div>
                                <span className="font-medium text-sm">Timeframe:</span>
                                <p className="text-sm text-gray-600 dark:text-gray-400">{rec.timeframe}</p>
                              </div>
                            </div>
                            
                            {rec.resources && rec.resources.length > 0 && (
                              <div>
                                <h4 className="font-medium text-sm mb-2">Resources:</h4>
                                <div className="flex flex-wrap gap-1">
                                  {rec.resources.map((resource, index) => (
                                    <Badge key={index} variant="secondary" className="text-xs">
                                      {resource}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </CollapsibleContent>
                    </Collapsible>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="insights" className="mt-4">
            <div className="space-y-4">
              {insights.map((insight, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        {getImpactIcon(insight.impact)}
                        {insight.trend}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {Math.round(insight.relevance * 100)}% relevant
                        </Badge>
                        <Badge variant={insight.impact === 'positive' ? 'default' : 
                                       insight.impact === 'negative' ? 'destructive' : 'secondary'}>
                          {insight.impact}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      {insight.description}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Clock className="h-3 w-3" />
                      {insight.timeframe}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="mt-4">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Profile Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <span className="font-medium text-sm">Role:</span>
                      <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">{analysis.role.replace('_', ' ')}</p>
                    </div>
                    <div>
                      <span className="font-medium text-sm">Experience Level:</span>
                      <div className="flex items-center gap-2">
                        <Progress value={analysis.experience} className="flex-1" />
                        <span className="text-sm">{analysis.experience}%</span>
                      </div>
                    </div>
                    <div>
                      <span className="font-medium text-sm">Recent Activity:</span>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{analysis.recentActivity} recent actions</p>
                    </div>
                    <div>
                      <span className="font-medium text-sm">Growth Trend:</span>
                      <div className="flex items-center gap-2">
                        {getGrowthTrendIcon(analysis.growthTrend)}
                        <span className="text-sm capitalize">{analysis.growthTrend}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Award className="h-4 w-4 text-green-600" />
                      Strengths
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {analysis.strengths.map((strength, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                          <span className="text-sm">{strength}</span>
                        </div>
                      ))}
                      {analysis.strengths.length === 0 && (
                        <p className="text-sm text-gray-600 dark:text-gray-400">No specific strengths identified yet</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Lightbulb className="h-4 w-4 text-amber-600" />
                      Growth Areas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {analysis.weaknesses.map((weakness, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-600" />
                          <span className="text-sm">{weakness}</span>
                        </div>
                      ))}
                      {analysis.weaknesses.length === 0 && (
                        <p className="text-sm text-gray-600 dark:text-gray-400">No specific growth areas identified</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AICareerWidget;