import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, Wifi, WifiOff, Clock, FileText, Shield, Eye } from 'lucide-react';

interface OfflineDocument {
  id: string;
  bookingId: number;
  title: string;
  type: 'technical-rider' | 'attachment' | 'message' | 'contract';
  cachedAt: string;
  size: string;
  lastModified: string;
  isAvailable: boolean;
}

export default function OfflineBookingAccess() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [cachedDocuments, setCachedDocuments] = useState<OfflineDocument[]>([]);
  const [cacheStatus, setCacheStatus] = useState<{
    totalDocuments: number;
    totalSize: string;
    lastSync: string;
  }>({
    totalDocuments: 0,
    totalSize: '0 MB',
    lastSync: 'Never'
  });

  // Monitor online/offline status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load cached documents from service worker
  useEffect(() => {
    loadCacheStatus();
    loadCachedDocuments();
  }, []);

  const loadCacheStatus = async () => {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      const messageChannel = new MessageChannel();
      
      messageChannel.port1.onmessage = (event) => {
        if (event.data.type === 'CACHE_STATUS') {
          setCacheStatus({
            totalDocuments: event.data.cachedDocuments,
            totalSize: `${(event.data.cachedDocuments * 0.5).toFixed(1)} MB`, // Estimate
            lastSync: new Date().toLocaleString()
          });
        }
      };

      navigator.serviceWorker.controller.postMessage(
        { type: 'GET_CACHE_STATUS' },
        [messageChannel.port2]
      );
    }
  };

  const loadCachedDocuments = async () => {
    // In a real implementation, this would query the service worker cache
    // For now, showing example cached documents
    const mockCachedDocs: OfflineDocument[] = [
      {
        id: '1',
        bookingId: 123,
        title: 'Technical Rider - Lí-Lí Octave Performance',
        type: 'technical-rider',
        cachedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
        size: '245 KB',
        lastModified: new Date(Date.now() - 4 * 60 * 60 * 1000).toLocaleDateString(),
        isAvailable: true
      },
      {
        id: '2',
        bookingId: 124,
        title: 'Flight Itinerary - JCro Tour',
        type: 'attachment',
        cachedAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(), // 1 hour ago
        size: '1.2 MB',
        lastModified: new Date(Date.now() - 6 * 60 * 60 * 1000).toLocaleDateString(),
        isAvailable: true
      },
      {
        id: '3',
        bookingId: 125,
        title: 'Performance Contract - Princess Trinidad',
        type: 'contract',
        cachedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
        size: '890 KB',
        lastModified: new Date().toLocaleDateString(),
        isAvailable: true
      }
    ];

    setCachedDocuments(mockCachedDocs);
  };

  const downloadForOffline = async (bookingId: number) => {
    try {
      // Cache technical rider
      const riderResponse = await fetch(`/api/technical-rider/${bookingId}`);
      if (riderResponse.ok) {
        const riderData = await riderResponse.json();
        await cacheDocument(`/api/technical-rider/${bookingId}`, riderData);
      }

      // Cache attachments
      const attachmentsResponse = await fetch(`/api/booking-attachments?bookingId=${bookingId}`);
      if (attachmentsResponse.ok) {
        const attachmentsData = await attachmentsResponse.json();
        await cacheDocument(`/api/booking-attachments?bookingId=${bookingId}`, attachmentsData);
      }

      // Cache messages
      const messagesResponse = await fetch(`/api/booking-messages?bookingId=${bookingId}`);
      if (messagesResponse.ok) {
        const messagesData = await messagesResponse.json();
        await cacheDocument(`/api/booking-messages?bookingId=${bookingId}`, messagesData);
      }

      // Refresh cache status
      loadCacheStatus();
      loadCachedDocuments();

    } catch (error) {
      console.error('Error downloading for offline:', error);
    }
  };

  const cacheDocument = async (url: string, data: any) => {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'CACHE_BOOKING_DOCUMENT',
        url,
        data,
        timestamp: new Date().toISOString()
      });
    }
  };

  const viewOfflineDocument = async (doc: OfflineDocument) => {
    if (!doc.isAvailable) return;

    try {
      // Attempt to load from cache
      const response = await fetch(`/api/booking-documents/${doc.id}`);
      if (response.ok) {
        const data = await response.json();
        
        // Create blob and download
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${doc.title.replace(/[^a-zA-Z0-9]/g, '_')}.json`;
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Error viewing offline document:', error);
    }
  };

  const getDocumentTypeIcon = (type: string) => {
    switch (type) {
      case 'technical-rider': return <Shield className="w-4 h-4" />;
      case 'attachment': return <FileText className="w-4 h-4" />;
      case 'contract': return <FileText className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getDocumentTypeBadge = (type: string) => {
    const colors = {
      'technical-rider': 'bg-blue-100 text-blue-800',
      'attachment': 'bg-green-100 text-green-800',
      'message': 'bg-purple-100 text-purple-800',
      'contract': 'bg-orange-100 text-orange-800'
    };
    
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const cached = new Date(timestamp);
    const diffMs = now.getTime() - cached.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor(diffMs / (1000 * 60));

    if (diffHours > 0) return `${diffHours}h ago`;
    if (diffMinutes > 0) return `${diffMinutes}m ago`;
    return 'Just now';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-gray-900">
            Offline Booking Access
          </h1>
          <p className="text-xl text-gray-600">
            Access your booking documents, technical riders, and communications offline
          </p>

          {/* Connection Status */}
          <div className="flex justify-center">
            <Badge 
              className={`flex items-center space-x-2 px-4 py-2 ${
                isOnline 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}
            >
              {isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
              <span>{isOnline ? 'Online' : 'Offline'}</span>
            </Badge>
          </div>
        </div>

        {/* Cache Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Download className="w-5 h-5 mr-2" />
              Offline Cache Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{cacheStatus.totalDocuments}</p>
                <p className="text-sm text-gray-600">Cached Documents</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{cacheStatus.totalSize}</p>
                <p className="text-sm text-gray-600">Storage Used</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">
                  {isOnline ? 'Available' : 'Offline Mode'}
                </p>
                <p className="text-sm text-gray-600">Sync Status</p>
              </div>
            </div>

            {isOnline && (
              <div className="mt-4 text-center">
                <Button 
                  onClick={() => loadCacheStatus()}
                  variant="outline"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Refresh Cache Status
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Download Section */}
        {isOnline && (
          <Card>
            <CardHeader>
              <CardTitle>Download Booking for Offline Access</CardTitle>
              <p className="text-sm text-gray-600">
                Download complete booking documentation for offline viewing
              </p>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <input
                  type="number"
                  placeholder="Booking ID"
                  className="flex-1 p-2 border rounded"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      const input = e.target as HTMLInputElement;
                      if (input.value) {
                        downloadForOffline(parseInt(input.value));
                        input.value = '';
                      }
                    }
                  }}
                />
                <Button
                  onClick={(e) => {
                    const input = (e.target as HTMLElement).parentElement?.querySelector('input') as HTMLInputElement;
                    if (input?.value) {
                      downloadForOffline(parseInt(input.value));
                      input.value = '';
                    }
                  }}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Cached Documents */}
        <Card>
          <CardHeader>
            <CardTitle>Cached Documents</CardTitle>
            <p className="text-sm text-gray-600">
              Documents available for offline viewing with timestamps
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {cachedDocuments.map((doc) => (
                <Card key={doc.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="flex-shrink-0">
                        {getDocumentTypeIcon(doc.type)}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{doc.title}</p>
                        <div className="flex items-center space-x-2 text-xs text-gray-500">
                          <span>Booking #{doc.bookingId}</span>
                          <span>•</span>
                          <span>{doc.size}</span>
                          <span>•</span>
                          <Clock className="w-3 h-3" />
                          <span>Cached {formatTimeAgo(doc.cachedAt)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Badge className={getDocumentTypeBadge(doc.type)}>
                        {doc.type.replace('-', ' ')}
                      </Badge>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => viewOfflineDocument(doc)}
                        disabled={!doc.isAvailable}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}

              {cachedDocuments.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Download className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No documents cached for offline access.</p>
                  <p className="text-sm">Download bookings to view them offline.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* PWA Information */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900 mb-1">PWA Offline Features</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Technical riders cached with date stamps for offline viewing</li>
                  <li>• Booking attachments and communications stored locally</li>
                  <li>• Automatic synchronization when connection is restored</li>
                  <li>• Contract documents and payment vouchers available offline</li>
                  <li>• Real-time cache status monitoring and management</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}