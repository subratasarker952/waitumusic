import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

// UI Components
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

// Icons
import {
  Users, Calendar, DollarSign, TrendingUp, Music, Star,
  Settings, Shield, Activity, FileText, Heart, Download,
  Mic, Headphones, Briefcase, Check, AlertTriangle,
  BarChart3, Clock, MapPin, Play, ShoppingCart, Award,
  Globe, Wrench, Database, UserCheck, BookOpen,
  CreditCard, Camera, Video, Image, FolderOpen, Trash2, Music2, Crown
} from 'lucide-react';

// Modal Components
import ProfileEditModal from '@/components/modals/ProfileEditModal';
import MusicUploadModal from '@/components/modals/MusicUploadModal';
import CalendarModal from '@/components/modals/CalendarModal';
import EquipmentModal from '@/components/modals/EquipmentModal';
import BookingResponseModal from '@/components/modals/BookingResponseModal';
import MerchandiseModal from '@/components/modals/MerchandiseModal';
import ServiceManagementModal from '@/components/modals/ServiceManagementModal';
import UserManagementModal from '@/components/modals/UserManagementModal';
import KnowledgeBaseModal from '@/components/modals/KnowledgeBaseModal';
import StoreBrowserModal from '@/components/modals/StoreBrowserModal';
import { VideoUploadModal } from './VideoUploadModal';
import UploadAlbumButton from '@/components/UploadAlbumButton';

// Specialized Components
import SuperadminDashboard from '@/components/dashboards/SuperadminDashboard';
import AdminDashboard from '@/components/dashboards/AdminDashboard';
import AICompanion from '@/pages/AICompanion';
import { PRORegistration } from '@/components/PRORegistration';
import SplitsheetServiceDashboard from '@/components/SplitsheetServiceDashboard';
import { RevenueAnalyticsDashboard } from '@/components/analytics/RevenueAnalyticsDashboard';

// Helper function to get role display names
const getRoleDisplayName = (roleId: number): string => {
  const roleNames = {
    1: 'Superadmin',
    2: 'Admin', 
    3: 'Managed Artist',
    4: 'Artist',
    5: 'Managed Musician',
    6: 'Musician',
    7: 'Managed Professional',
    8: 'Professional',
    9: 'Fan'
  };
  return roleNames[roleId as keyof typeof roleNames] || `Role ${roleId}`;
};

interface UnifiedDashboardProps {
  stats: any;
  bookings: any[];
  user: any;
}

export default function UnifiedDashboard({ stats, bookings, user }: UnifiedDashboardProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Modal states
  const [profileEditOpen, setProfileEditOpen] = useState(false);
  const [musicUploadOpen, setMusicUploadOpen] = useState(false);
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [equipmentOpen, setEquipmentOpen] = useState(false);
  const [bookingResponseOpen, setBookingResponseOpen] = useState(false);
  const [merchandiseOpen, setMerchandiseOpen] = useState(false);
  const [serviceManagementOpen, setServiceManagementOpen] = useState(false);
  const [userManagementOpen, setUserManagementOpen] = useState(false);
  const [videoUploadOpen, setVideoUploadOpen] = useState(false);
  const [knowledgeBaseOpen, setKnowledgeBaseOpen] = useState(false);
  const [storeBrowserOpen, setStoreBrowserOpen] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [selectedUserId, setSelectedUserId] = useState<string | undefined>();
  const [userModalMode, setUserModalMode] = useState<'create' | 'edit' | 'view'>('view');
  const [activeTab, setActiveTab] = useState("overview");

  // Data queries
  const { data: songs } = useQuery({
    queryKey: ['/api/songs'],
    queryFn: async () => {
      const response = await apiRequest('/api/songs');
      return await response.json();
    },
  });

  const { data: artists } = useQuery({
    queryKey: ['/api/artists'],
    queryFn: async () => {
      const response = await apiRequest('/api/artists');
      return await response.json();
    },
  });

  // Error boundary protection
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Authentication Required</h2>
          <p className="text-gray-600">Please log in to access your dashboard.</p>
        </div>
      </div>
    );
  }

  // Get user role information
  const userRole = user.roleId;
  const isAdmin = [1, 2].includes(userRole);
  const isSuperadmin = userRole === 1;
  const isManaged = [3, 5, 7].includes(userRole);
  const isArtist = [3, 4].includes(userRole);
  const isMusicianProfile = [5, 6].includes(userRole);
  const isManagedMusician = userRole === 5;
  const isProfessional = [7, 8].includes(userRole);
  const isFan = userRole === 9;
  
  // PRO registration eligibility: Artists, Musicians, and Music-related Professionals
  const musicProfessionalTypes = [
    'background_vocalist', 'producer', 'arranger', 'composer', 'songwriter', 
    'dj', 'music_director', 'sound_engineer', 'mixing_engineer', 'mastering_engineer',
    'music_producer', 'beat_maker', 'orchestrator', 'lyricist', 'jingle_writer'
  ];
  const isPROEligible = isArtist || isMusicianProfile || 
    (isProfessional && user.roleData?.specializations?.some((spec: string) => 
      musicProfessionalTypes.includes(spec.toLowerCase().replace(/\s+/g, '_'))
    ));

  // Filter data based on user
  const userSongs = songs?.filter((song: any) => song.artistUserId === user?.id) || [];
  const userBookings = bookings?.filter((b: any) => 
    b.musician_user_id === user?.id || 
    b.professional_user_id === user?.id || 
    b.booker_user_id === user?.id ||
    b.artist_user_id === user?.id
  ) || [];

  // Event handlers
  const handleEditProfile = () => setProfileEditOpen(true);
  const handleUploadMusic = () => setMusicUploadOpen(true);
  const handleUploadAlbum = () => {
    toast({
      title: "Album Upload",
      description: "Opening album upload form with multi-track support...",
    });
    setMusicUploadOpen(true);
  };
  const handleBlockDate = () => setCalendarOpen(true);
  const handleUpdateEquipment = () => setEquipmentOpen(true);
  const handleMerchandiseManagement = () => setMerchandiseOpen(true);
  const handleManageMerchandiseCategories = () => {
    // Open merchandise management modal for category management
    setMerchandiseOpen(true);
    toast({
      title: "Merchandise Categories",
      description: "Use the Add Merchandise form to create category-specific items",
    });
  };
  const handleUpdateRates = () => setServiceManagementOpen(true);

  const handleDeleteSong = async (songId: string, songTitle: string) => {
    const confirmed = window.confirm(`Are you sure you want to delete "${songTitle}"? This action cannot be undone.`);
    if (!confirmed) return;

    try {
      await apiRequest(`/api/songs/${songId}`, { method: 'DELETE' });
      queryClient.invalidateQueries({ queryKey: ['/api/songs'] });
      toast({
        title: "Song Deleted",
        description: `"${songTitle}" has been successfully deleted.`,
      });
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: "Unable to delete the song. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleBookingResponse = (bookingId: string, action: 'accept' | 'decline', message?: string) => {
    toast({
      title: `Booking ${action === 'accept' ? 'Accepted' : 'Declined'}`,
      description: `Booking ${bookingId} has been ${action}ed.`,
    });
    setBookingResponseOpen(false);
    setSelectedBooking(null);
  };

  const handleViewBooking = (booking: any) => {
    setSelectedBooking(booking);
    setBookingResponseOpen(true);
  };

  const handleManageKnowledgeBase = () => {
    // Open knowledge base management modal
    setKnowledgeBaseOpen(true);
  };

  const handleBrowseStore = () => {
    // Open dashboard-contained store browser
    setStoreBrowserOpen(true);
    toast({
      title: "Store Browser",
      description: "Browse merchandise from your favorite artists",
    });
  };

  const handleBrowseArtists = () => {
    // Open dashboard-contained artist browser
    toast({
      title: "Artist Browser",
      description: "Browse your favorite artists within dashboard",
    });
    // This could open an artist browser modal in the future
  };

  const handleViewPurchases = () => {
    // Open dashboard-contained purchase history
    toast({
      title: "Purchase History",
      description: "View your purchase history within dashboard",
    });
    // This could open a purchase history modal in the future
  };

  const handleCreateUser = () => {
    setSelectedUserId(undefined);
    setUserModalMode('create');
    setUserManagementOpen(true);
  };

  const handleEditUser = (userId: string) => {
    setSelectedUserId(userId);
    setUserModalMode('edit');
    setUserManagementOpen(true);
  };

  const handleViewUser = (userId: string) => {
    setSelectedUserId(userId);
    setUserModalMode('view');
    setUserManagementOpen(true);
  };

  // Dashboard containment - prevent external navigation
  const handleDashboardAction = (actionName: string, action: () => void) => {
    // Execute action within dashboard context
    action();
    toast({
      title: "Dashboard Action",
      description: `${actionName} opened within dashboard`,
    });
  };

  // Render role-specific dashboard content
  const renderDashboardContent = () => {
    if (isSuperadmin) {
      return <SuperadminDashboard stats={stats} bookings={bookings} user={user} />;
    }

    if (userRole === 2) { // Admin
      return <AdminDashboard stats={stats} bookings={bookings} user={user} />;
    }

    // For all other roles, render unified dashboard with role-specific sections
    return (
      <div className="space-y-4 sm:space-y-6 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Header - Mobile Optimized */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex-1">
            <h1 className="text-2xl sm:text-3xl font-bold">
              {isFan ? 'Welcome Back!' : 
               isArtist ? 'Artist Dashboard' :
               isMusicianProfile ? 'Musician Dashboard' :
               isProfessional ? 'Professional Dashboard' : 'Dashboard'}
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground mt-1">
              {isFan ? 'Discover music, follow artists, and book experiences' :
               isArtist ? 'Manage your music career and bookings' :
               isMusicianProfile ? 'Manage your session work and bookings' :
               isProfessional ? 'Manage your consulting services and clients' : 'Manage your account'}
            </p>
          </div>
          <Badge variant="outline" className={`
            flex-shrink-0 ${
            isManaged ? "text-green-600 border-green-600" :
            isArtist ? "text-purple-600 border-purple-600" :
            isMusicianProfile ? "text-blue-600 border-blue-600" :
            isProfessional ? "text-orange-600 border-orange-600" :
            "text-pink-600 border-pink-600"
          }`}>
            {isManaged && <Check className="h-3 w-3 mr-1" />}
            {isArtist && <Music className="h-3 w-3 mr-1" />}
            {isMusicianProfile && <Headphones className="h-3 w-3 mr-1" />}
            {isProfessional && <Briefcase className="h-3 w-3 mr-1" />}
            {isFan && <Heart className="h-3 w-3 mr-1" />}
            <span className="hidden sm:inline">{getRoleDisplayName(userRole)}</span>
            <span className="sm:hidden">{getRoleDisplayName(userRole).split(' ')[0]}</span>
          </Badge>
        </div>

        {/* AI Insights for Managed Users */}
        {isManaged && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="w-5 h-5 mr-2" />
                OppHub
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AICompanion />
            </CardContent>
          </Card>
        )}

        {/* Mobile Dropdown Navigation - Musical Organization */}
        <div className="block sm:hidden mb-6">
          <Select value={activeTab} onValueChange={setActiveTab}>
            <SelectTrigger className="w-full h-12 text-base">
              <SelectValue placeholder={
                isArtist ? "🎨 Creative Studio" :
                isMusicianProfile ? "🎧 Session Workshop" :
                isProfessional ? "💼 Professional Suite" :
                isFan ? "💖 Fan Experience" : "🎵 Dashboard"
              } />
            </SelectTrigger>
            <SelectContent>
              {/* Creative Studio/Session Workshop */}
              <SelectItem value="overview">🏰 Overview ({isArtist ? 'Studio' : isMusicianProfile ? 'Workshop' : 'Dashboard'})</SelectItem>
              <SelectItem value="profile">⭐ Profile ({isArtist ? 'Studio' : isMusicianProfile ? 'Workshop' : 'Profile'})</SelectItem>
              
              {/* Performance & Production */}
              {!isFan && <SelectItem value="calendar">📅 Calendar (Schedule)</SelectItem>}
              {(isArtist || isManagedMusician) && <SelectItem value="music">🎵 Music (Production)</SelectItem>}
              {isMusicianProfile && <SelectItem value="equipment">🎧 Instruments (Equipment)</SelectItem>}
              
              {/* Business & Opportunities */}
              {isProfessional && <SelectItem value="services">💼 Services (Business)</SelectItem>}
              {!isProfessional && <SelectItem value="bookings">📋 Bookings (Business)</SelectItem>}
              
              {/* Commercial & Legal */}
              {isArtist && !isFan && <SelectItem value="merchandise">🛒 Merchandise (Commercial)</SelectItem>}
              {isPROEligible && <SelectItem value="pro-registration">📝 PRO Registration (Legal)</SelectItem>}
              {isManaged && (isArtist || isManagedMusician) && <SelectItem value="splitsheets">📄 Splitsheets (Legal)</SelectItem>}
              
              {/* Fan Experience */}
              {isFan && <SelectItem value="favorites">❤️ Favorites (Fan)</SelectItem>}
              {isFan && <SelectItem value="purchases">🛒 Purchases (Fan)</SelectItem>}
              
              {/* Knowledge Center */}
              {isProfessional && <SelectItem value="knowledge">📚 Knowledge Base (Resources)</SelectItem>}
            </SelectContent>
          </Select>
        </div>

        {/* Desktop Tab Navigation - Musical Organization */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="hidden sm:block">
            <div className="space-y-4 mb-6">
              
              {/* Artist/Musician Creative Hub */}
              {(isArtist || isMusicianProfile) && (
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 rounded-lg p-3">
                  <h3 className="text-sm font-medium text-purple-700 dark:text-purple-300 mb-2 flex items-center gap-2">
                    <Music className="h-4 w-4" />
                    {isArtist ? 'Creative Studio' : 'Session Workshop'}
                  </h3>
                  <TabsList className="grid w-full grid-cols-3 gap-1">
                    <TabsTrigger value="overview" className="text-xs flex items-center gap-1">
                      <Crown className="h-3 w-3" />
                      Overview
                    </TabsTrigger>
                    <TabsTrigger value="profile" className="text-xs flex items-center gap-1">
                      <Star className="h-3 w-3" />
                      Profile
                    </TabsTrigger>
                    {!isFan && (
                      <TabsTrigger value="calendar" className="text-xs flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        Calendar
                      </TabsTrigger>
                    )}
                  </TabsList>
                </div>
              )}

              {/* Performance & Production Hub */}
              {(isArtist || isMusicianProfile) && (
                <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20 rounded-lg p-3">
                  <h3 className="text-sm font-medium text-emerald-700 dark:text-emerald-300 mb-2 flex items-center gap-2">
                    <Mic className="h-4 w-4" />
                    Performance & Production
                  </h3>
                  <div className="grid grid-cols-2 gap-1">
                    {(isArtist || isManagedMusician) && (
                      <TabsList className="grid w-full grid-cols-1">
                        <TabsTrigger value="music" className="text-xs flex items-center gap-1">
                          <Music className="h-3 w-3" />
                          Music
                        </TabsTrigger>
                      </TabsList>
                    )}
                    {isMusicianProfile && (
                      <TabsList className="grid w-full grid-cols-1">
                        <TabsTrigger value="equipment" className="text-xs flex items-center gap-1">
                          <Headphones className="h-3 w-3" />
                          Instruments
                        </TabsTrigger>
                      </TabsList>
                    )}
                  </div>
                </div>
              )}

              {/* Business & Booking Suite */}
              {(isArtist || isMusicianProfile || isProfessional) && (
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 rounded-lg p-3">
                  <h3 className="text-sm font-medium text-blue-700 dark:text-blue-300 mb-2 flex items-center gap-2">
                    <Briefcase className="h-4 w-4" />
                    Business & Opportunities
                  </h3>
                  <div className="grid grid-cols-2 gap-1">
                    {!isProfessional && (
                      <TabsList className="grid w-full grid-cols-1">
                        <TabsTrigger value="bookings" className="text-xs flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          Bookings
                        </TabsTrigger>
                      </TabsList>
                    )}
                    {isProfessional && (
                      <TabsList className="grid w-full grid-cols-1">
                        <TabsTrigger value="services" className="text-xs flex items-center gap-1">
                          <Briefcase className="h-3 w-3" />
                          Services
                        </TabsTrigger>
                      </TabsList>
                    )}
                  </div>
                </div>
              )}

              {/* Commercial & Legal Hub */}
              {(isArtist || isManagedMusician || isPROEligible) && (
                <div className="bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20 rounded-lg p-3">
                  <h3 className="text-sm font-medium text-orange-700 dark:text-orange-300 mb-2 flex items-center gap-2">
                    <ShoppingCart className="h-4 w-4" />
                    Commercial & Legal
                  </h3>
                  <div className="grid grid-cols-3 gap-1">
                    {isArtist && !isFan && (
                      <TabsList className="grid w-full grid-cols-1">
                        <TabsTrigger value="merchandise" className="text-xs flex items-center gap-1">
                          <ShoppingCart className="h-3 w-3" />
                          Merch
                        </TabsTrigger>
                      </TabsList>
                    )}
                    {isPROEligible && (
                      <TabsList className="grid w-full grid-cols-1">
                        <TabsTrigger value="pro-registration" className="text-xs flex items-center gap-1">
                          <FileText className="h-3 w-3" />
                          PRO
                        </TabsTrigger>
                      </TabsList>
                    )}
                    {isManaged && (isArtist || isManagedMusician) && (
                      <TabsList className="grid w-full grid-cols-1">
                        <TabsTrigger value="splitsheets" className="text-xs flex items-center gap-1">
                          <FileText className="h-3 w-3" />
                          Splits
                        </TabsTrigger>
                      </TabsList>
                    )}
                  </div>
                </div>
              )}

              {/* Fan Experience Hub */}
              {isFan && (
                <div className="bg-gradient-to-r from-pink-50 to-rose-50 dark:from-pink-950/20 dark:to-rose-950/20 rounded-lg p-3">
                  <h3 className="text-sm font-medium text-pink-700 dark:text-pink-300 mb-2 flex items-center gap-2">
                    <Heart className="h-4 w-4" />
                    Fan Experience
                  </h3>
                  <TabsList className="grid w-full grid-cols-4 gap-1">
                    <TabsTrigger value="overview" className="text-xs flex items-center gap-1">
                      <Crown className="h-3 w-3" />
                      Overview
                    </TabsTrigger>
                    <TabsTrigger value="profile" className="text-xs flex items-center gap-1">
                      <Star className="h-3 w-3" />
                      Profile
                    </TabsTrigger>
                    <TabsTrigger value="favorites" className="text-xs flex items-center gap-1">
                      <Heart className="h-3 w-3" />
                      Favorites
                    </TabsTrigger>
                    <TabsTrigger value="purchases" className="text-xs flex items-center gap-1">
                      <ShoppingCart className="h-3 w-3" />
                      Purchases
                    </TabsTrigger>
                  </TabsList>
                </div>
              )}

              {/* Professional Knowledge Center */}
              {isProfessional && (
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 rounded-lg p-3">
                  <h3 className="text-sm font-medium text-green-700 dark:text-green-300 mb-2 flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Knowledge Center
                  </h3>
                  <TabsList className="grid w-full grid-cols-1 gap-1">
                    <TabsTrigger value="knowledge" className="text-xs flex items-center gap-1">
                      <BookOpen className="h-3 w-3" />
                      Knowledge Base
                    </TabsTrigger>
                  </TabsList>
                </div>
              )}

            </div>
          </div>

          {/* Overview Tab - Mobile Optimized */}
          <TabsContent value="overview" className="space-y-4 sm:space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {/* Role-specific metrics */}
              {isArtist && (
                <>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Monthly Bookings</CardTitle>
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{userBookings.length}</div>
                      <p className="text-xs text-muted-foreground">
                        +12% from last month
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Songs</CardTitle>
                      <Music className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{userSongs.length}</div>
                      <p className="text-xs text-muted-foreground">
                        Released tracks
                      </p>
                    </CardContent>
                  </Card>
                </>
              )}

              {isMusicianProfile && (
                <>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Monthly Sessions</CardTitle>
                      <Headphones className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{userBookings.length}</div>
                      <p className="text-xs text-muted-foreground">
                        +8% from last month
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Session Revenue</CardTitle>
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$2,450</div>
                      <p className="text-xs text-muted-foreground">
                        +15% from last month
                      </p>
                    </CardContent>
                  </Card>
                </>
              )}

              {isProfessional && (
                <>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Monthly Consultations</CardTitle>
                      <Briefcase className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{userBookings.length}</div>
                      <p className="text-xs text-muted-foreground">
                        +20% from last month
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Active Clients</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">18</div>
                      <p className="text-xs text-muted-foreground">
                        +3 new this month
                      </p>
                    </CardContent>
                  </Card>
                </>
              )}

              {isFan && (
                <>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Following</CardTitle>
                      <Heart className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">12</div>
                      <p className="text-xs text-muted-foreground">
                        Artists followed
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Purchases</CardTitle>
                      <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">24</div>
                      <p className="text-xs text-muted-foreground">
                        Songs purchased
                      </p>
                    </CardContent>
                  </Card>
                </>
              )}

              {/* Common metrics */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {isProfessional ? 'Revenue' : isArtist ? 'Earnings' : isMusicianProfile ? 'Ratings' : 'Downloads'}
                  </CardTitle>
                  {isProfessional || isArtist ? (
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  ) : isMusicianProfile ? (
                    <Star className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Download className="h-4 w-4 text-muted-foreground" />
                  )}
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isProfessional ? '$5,200' : isArtist ? '$3,400' : isMusicianProfile ? '4.9' : '156'}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {isProfessional ? '+25% from last month' : 
                     isArtist ? '+18% from last month' : 
                     isMusicianProfile ? 'Average rating' : 'Total downloads'}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userBookings.slice(0, 3).map((booking: any, index) => (
                    <div key={booking.id || index} className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                      <div className="flex-1">
                        <p className="font-medium">
                          {isArtist ? `Performance booked for ${booking.eventName || 'Event'}` :
                           isMusicianProfile ? `Session scheduled for ${booking.eventName || 'Session'}` :
                           isProfessional ? `Consultation scheduled with ${booking.clientName || 'Client'}` :
                           `Booking: ${booking.eventName || 'Event'}`}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {booking.eventDate ? new Date(booking.eventDate).toLocaleDateString() : 'Date TBD'}
                        </p>
                      </div>
                    </div>
                  ))}
                  {userBookings.length === 0 && (
                    <p className="text-muted-foreground text-center py-4">No recent activity</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab - Mobile Optimized */}
          <TabsContent value="profile" className="space-y-4 sm:space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg sm:text-xl">Profile Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button onClick={handleEditProfile} className="w-full h-12 text-base">
                  <Settings className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Calendar Tab - Mobile Optimized */}
          <TabsContent value="calendar" className="space-y-4 sm:space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg sm:text-xl">Calendar Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button onClick={handleBlockDate} className="w-full h-12 text-base">
                  <Calendar className="w-4 h-4 mr-2" />
                  Manage Availability
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Role-specific tabs */}
          {(isArtist || isManagedMusician) && (
            <TabsContent value="music" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Music Catalog</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    All uploads require ISRC code and 3000x3000px minimum cover art
                    {isManagedMusician && " • Managed musicians have full upload privileges"}
                  </p>
                  {isManaged && (
                    <p className="text-sm text-emerald-600 dark:text-emerald-400 mt-2">
                      💡 Managed users can also embed YouTube videos (playlists encouraged)
                    </p>
                  )}
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    <Button onClick={handleUploadMusic} className="w-full h-12 text-base">
                      <Music className="w-4 h-4 mr-2" />
                      Upload Music
                    </Button>
                    <UploadAlbumButton 
                      variant="outline"
                      className="w-full h-12 text-base"
                      onSuccess={() => {
                        toast({
                          title: "Album uploaded successfully",
                          description: "Your album has been uploaded and is now available."
                        });
                        queryClient.invalidateQueries({ queryKey: ['/api/songs'] });
                      }}
                    />
                  </div>
                  
                  {isManaged && (
                    <div className="border-t pt-4">
                      <h4 className="font-medium mb-2 text-emerald-700 dark:text-emerald-300">YouTube Video Integration</h4>
                      <Button 
                        onClick={() => setVideoUploadOpen(true)} 
                        className="w-full h-12 text-base bg-red-600 hover:bg-red-700 text-white"
                      >
                        <Video className="w-4 h-4 mr-2" />
                        Add YouTube Video
                      </Button>
                      <p className="text-xs text-muted-foreground mt-2">
                        Add YouTube videos to your profile and all-links page. Playlists are encouraged for better organization.
                      </p>
                    </div>
                  )}
                  
                  <div className="space-y-4">
                    <h4 className="font-medium">Your Songs</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                      {userSongs.map((song: any) => (
                        <Card key={song.id}>
                          <CardContent className="p-3 sm:p-4">
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex-1 min-w-0">
                                <h4 className="font-medium truncate text-sm sm:text-base">{song.title}</h4>
                                <p className="text-xs sm:text-sm text-muted-foreground truncate">{song.genre || 'No genre'}</p>
                                <p className="text-xs sm:text-sm text-muted-foreground">
                                  Preview: {isManaged ? '15s-full' : '30s fixed'}
                                </p>
                                {song.price && (
                                  <p className="text-sm font-medium text-green-600">
                                    ${parseFloat(song.price).toFixed(2)}
                                  </p>
                                )}
                              </div>
                              <Button
                                size="sm"
                                variant="destructive"
                                className="flex-shrink-0"
                                onClick={() => handleDeleteSong(song.id, song.title)}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                      {userSongs.length === 0 && (
                        <p className="text-muted-foreground text-center py-6 sm:py-4 col-span-1 sm:col-span-2">
                          No songs uploaded yet
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {(isArtist || isFan) && (
            <TabsContent value="merchandise" className="space-y-4 sm:space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg sm:text-xl">
                    {isArtist ? 'Merchandise Management' : 'Merchandise'}
                  </CardTitle>
                  {isArtist && (
                    <p className="text-sm text-muted-foreground">
                      Manage your merchandise inventory and categories
                    </p>
                  )}
                </CardHeader>
                <CardContent className="space-y-4">
                  {isArtist && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                      <Button onClick={handleMerchandiseManagement} className="w-full h-12 text-base">
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        Add Merchandise
                      </Button>
                      <Button onClick={handleManageMerchandiseCategories} className="w-full h-12 text-base" variant="outline">
                        <FolderOpen className="w-4 h-4 mr-2" />
                        Manage Categories
                      </Button>
                    </div>
                  )}
                  {isFan && (
                    <Button onClick={handleBrowseStore} className="w-full h-12 text-base">
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Browse Store
                    </Button>
                  )}
                  {isArtist && (
                    <div className="space-y-4">
                      <h4 className="font-medium">Your Merchandise</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                        <div className="text-center text-muted-foreground py-6 sm:py-8 col-span-1 sm:col-span-2">
                          No merchandise items yet. Start by adding some merchandise!
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {isMusicianProfile && (
            <TabsContent value="equipment" className="space-y-4 sm:space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg sm:text-xl">Instrument Management</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button onClick={handleUpdateEquipment} className="w-full h-12 text-base">
                    <Wrench className="w-4 h-4 mr-2" />
                    Manage Instruments
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {isProfessional && (
            <>
              <TabsContent value="services" className="space-y-4 sm:space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg sm:text-xl">Service Management</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button onClick={handleUpdateRates} className="w-full h-12 text-base">
                      <DollarSign className="w-4 h-4 mr-2" />
                      Manage Services & Rates
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="knowledge" className="space-y-4 sm:space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg sm:text-xl">Knowledge Base</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button onClick={handleManageKnowledgeBase} className="w-full h-12 text-base">
                      <BookOpen className="w-4 h-4 mr-2" />
                      Manage Resources
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </>
          )}

          {!isProfessional && (
            <TabsContent value="bookings" className="space-y-4 sm:space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg sm:text-xl">
                    {isArtist ? 'Performance Bookings' : 
                     isMusicianProfile ? 'Session Bookings' : 
                     'Event Bookings'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 sm:space-y-4">
                    {userBookings.map((booking: any) => (
                      <Card key={booking.id}>
                        <CardContent className="p-3 sm:p-4">
                          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-sm sm:text-base truncate">{booking.eventName || 'Event'}</h4>
                              <p className="text-xs sm:text-sm text-muted-foreground">
                                {booking.eventDate ? new Date(booking.eventDate).toLocaleDateString() : 'Date TBD'}
                              </p>
                            </div>
                            <Button 
                              size="sm" 
                              className="w-full sm:w-auto flex-shrink-0"
                              onClick={() => handleViewBooking(booking)}
                            >
                              View Details
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    {userBookings.length === 0 && (
                      <p className="text-muted-foreground text-center py-6 sm:py-8">No bookings yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {isFan && (
            <>
              <TabsContent value="favorites" className="space-y-4 sm:space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg sm:text-xl">Favorite Artists</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={handleBrowseArtists} className="w-full h-12 text-base">
                      <Heart className="w-4 h-4 mr-2" />
                      Browse Artists
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="purchases" className="space-y-4 sm:space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg sm:text-xl">Purchase History</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={handleViewPurchases} className="w-full h-12 text-base">
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      View Purchases
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </>
          )}

          {/* PRO Registration Tab - Available for Artists, Musicians, and Music Professionals */}
          {isPROEligible && (
            <TabsContent value="pro-registration" className="space-y-4 sm:space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                    <FileText className="h-5 w-5 flex-shrink-0" />
                    <span className="text-base sm:text-lg leading-tight">Performance Rights Organization Registration</span>
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Register with a PRO to collect royalties for your musical works and performances
                  </p>
                </CardHeader>
                <CardContent>
                  <PRORegistration userId={user.id} />
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {/* Splitsheet Service Tab - Available for Managed Artists and Musicians */}
          {isManaged && (isArtist || isManagedMusician) && (
            <TabsContent value="splitsheets" className="space-y-4 sm:space-y-6">
              <SplitsheetServiceDashboard user={user} />
            </TabsContent>
          )}
        </Tabs>
      </div>
    );
  };

  return (
    <>
      {renderDashboardContent()}

      {/* Modals */}
      {profileEditOpen && (
        <ProfileEditModal 
          open={profileEditOpen} 
          onOpenChange={setProfileEditOpen}
        />
      )}
      
      {musicUploadOpen && (
        <MusicUploadModal 
          open={musicUploadOpen} 
          onOpenChange={setMusicUploadOpen}
        />
      )}
      
      {calendarOpen && (
        <CalendarModal 
          open={calendarOpen} 
          onOpenChange={setCalendarOpen}
          mode="schedule"
        />
      )}
      
      {equipmentOpen && (
        <EquipmentModal 
          open={equipmentOpen} 
          onOpenChange={setEquipmentOpen}
        />
      )}
      
      {bookingResponseOpen && selectedBooking && (
        <BookingResponseModal 
          open={bookingResponseOpen} 
          onOpenChange={setBookingResponseOpen}
          booking={selectedBooking}
          onResponse={handleBookingResponse}
        />
      )}
      
      {merchandiseOpen && (
        <MerchandiseModal 
          open={merchandiseOpen} 
          onOpenChange={setMerchandiseOpen}
        />
      )}
      
      {serviceManagementOpen && (
        <ServiceManagementModal 
          open={serviceManagementOpen} 
          onOpenChange={setServiceManagementOpen}
        />
      )}
      
      {userManagementOpen && (
        <UserManagementModal 
          open={userManagementOpen} 
          onOpenChange={setUserManagementOpen}
          userId={selectedUserId}
          mode={userModalMode}
        />
      )}

      {videoUploadOpen && (
        <VideoUploadModal 
          isOpen={videoUploadOpen} 
          onOpenChange={setVideoUploadOpen}
          userId={user.id}
        />
      )}

      {knowledgeBaseOpen && (
        <KnowledgeBaseModal 
          open={knowledgeBaseOpen} 
          onOpenChange={setKnowledgeBaseOpen}
        />
      )}

      {storeBrowserOpen && (
        <StoreBrowserModal 
          isOpen={storeBrowserOpen} 
          onClose={() => setStoreBrowserOpen(false)}
          user={user}
        />
      )}
    </>
  );
}