import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Mail, Send, Users, BarChart3, TestTube, Calendar, User, Globe } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';

interface NewsletterStats {
  totalSubscribers: number;
  totalNewsletters: number;
  recentNewsletters: Array<{
    id: number;
    title: string;
    sentAt: string;
    sentCount: number;
    openCount: number;
    clickCount: number;
  }>;
}

interface Artist {
  userId: number;
  stageNames: string[];
  isManaged: boolean;
  fullName?: string;
}

export default function NewsletterManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [newsletterData, setNewsletterData] = useState({
    title: '',
    content: '',
    type: 'general',
    targetArtistId: '',
    scheduledFor: ''
  });
  
  const [testEmail, setTestEmail] = useState('');
  const [isScheduled, setIsScheduled] = useState(false);

  // Query newsletter statistics
  const { data: stats, isLoading: statsLoading } = useQuery<NewsletterStats>({
    queryKey: ['/api/newsletter/stats'],
    queryFn: () => apiRequest('/api/newsletter/stats').then(res => res.json())
  });

  // Query managed artists for targeting
  const { data: artists = [] } = useQuery<Artist[]>({
    queryKey: ['/api/artists'],
    queryFn: () => apiRequest('/api/artists').then(res => res.json())
  });

  // Create newsletter mutation
  const createNewsletterMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/newsletter/create', {
      method: 'POST',
      body: JSON.stringify(data)
    }).then(res => res.json()),
    onSuccess: (data) => {
      toast({
        title: "Newsletter Success",
        description: data.message || "Newsletter created and sent successfully!",
      });
      setNewsletterData({
        title: '',
        content: '',
        type: 'general',
        targetArtistId: '',
        scheduledFor: ''
      });
      setIsScheduled(false);
      queryClient.invalidateQueries({ queryKey: ['/api/newsletter/stats'] });
    },
    onError: (error: any) => {
      toast({
        title: "Newsletter Error",
        description: error.message || "Failed to create newsletter",
        variant: "destructive",
      });
    }
  });

  // Test email mutation
  const testEmailMutation = useMutation({
    mutationFn: (email: string) => apiRequest('/api/newsletter/test', {
      method: 'POST',
      body: JSON.stringify({ email })
    }).then(res => res.json()),
    onSuccess: (data) => {
      toast({
        title: "Test Email Success",
        description: data.message,
      });
      setTestEmail('');
    },
    onError: (error: any) => {
      toast({
        title: "Test Email Failed",
        description: error.message || "Failed to send test email",
        variant: "destructive",
      });
    }
  });

  const handleCreateNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newsletterData.title || !newsletterData.content) {
      toast({
        title: "Validation Error",
        description: "Title and content are required",
        variant: "destructive",
      });
      return;
    }

    const payload = {
      ...newsletterData,
      targetArtistId: newsletterData.targetArtistId ? parseInt(newsletterData.targetArtistId) : undefined,
      scheduledFor: newsletterData.scheduledFor || undefined
    };

    createNewsletterMutation.mutate(payload);
  };

  const handleTestEmail = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!testEmail) {
      toast({
        title: "Validation Error",
        description: "Test email address is required",
        variant: "destructive",
      });
      return;
    }

    testEmailMutation.mutate(testEmail);
  };

  const managedArtists = artists.filter(artist => artist.isManaged);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Mail className="h-6 w-6 text-emerald-600" />
        <h2 className="text-2xl font-bold text-gray-900">Newsletter Management</h2>
      </div>

      <Tabs defaultValue="create" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="create">Create Newsletter</TabsTrigger>
          <TabsTrigger value="stats">Analytics</TabsTrigger>
          <TabsTrigger value="test">Test Email</TabsTrigger>
          <TabsTrigger value="subscribers">Subscribers</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="h-5 w-5" />
                Create & Send Newsletter
              </CardTitle>
              <CardDescription>
                Create newsletters for general audience or specific managed artists
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateNewsletter} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Newsletter Title</Label>
                    <Input
                      id="title"
                      value={newsletterData.title}
                      onChange={(e) => setNewsletterData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter newsletter title"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="type">Newsletter Type</Label>
                    <Select 
                      value={newsletterData.type} 
                      onValueChange={(value) => setNewsletterData(prev => ({ ...prev, type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">
                          <div className="flex items-center gap-2">
                            <Globe className="h-4 w-4" />
                            General Newsletter
                          </div>
                        </SelectItem>
                        <SelectItem value="artist-specific">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4" />
                            Artist-Specific
                          </div>
                        </SelectItem>
                        <SelectItem value="release-announcement">
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4" />
                            Release Announcement
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {newsletterData.type === 'artist-specific' && (
                  <div className="space-y-2">
                    <Label htmlFor="targetArtist">Target Artist</Label>
                    <Select 
                      value={newsletterData.targetArtistId} 
                      onValueChange={(value) => setNewsletterData(prev => ({ ...prev, targetArtistId: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select managed artist" />
                      </SelectTrigger>
                      <SelectContent>
                        {managedArtists.map((artist) => (
                          <SelectItem key={artist.userId} value={artist.userId.toString()}>
                            {artist.stageNames?.[0] || artist.fullName || `Artist ${artist.userId}`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="content">Newsletter Content (HTML supported)</Label>
                  <Textarea
                    id="content"
                    value={newsletterData.content}
                    onChange={(e) => setNewsletterData(prev => ({ ...prev, content: e.target.value }))}
                    placeholder="Enter newsletter content... You can use HTML tags for formatting."
                    rows={10}
                    required
                  />
                  <p className="text-sm text-gray-500">
                    You can use HTML for formatting. Available placeholders: {'{{firstName}}'}, {'{{lastName}}'}, {'{{unsubscribeUrl}}'}
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="schedule"
                    checked={isScheduled}
                    onCheckedChange={setIsScheduled}
                  />
                  <Label htmlFor="schedule">Schedule for later</Label>
                </div>

                {isScheduled && (
                  <div className="space-y-2">
                    <Label htmlFor="scheduledFor">Scheduled Date & Time</Label>
                    <Input
                      id="scheduledFor"
                      type="datetime-local"
                      value={newsletterData.scheduledFor}
                      onChange={(e) => setNewsletterData(prev => ({ ...prev, scheduledFor: e.target.value }))}
                      min={new Date().toISOString().slice(0, 16)}
                    />
                  </div>
                )}

                <Button 
                  type="submit" 
                  disabled={createNewsletterMutation.isPending}
                  className="w-full"
                >
                  {createNewsletterMutation.isPending ? (
                    'Processing...'
                  ) : isScheduled ? (
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Schedule Newsletter
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Send className="h-4 w-4" />
                      Create & Send Now
                    </div>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Subscribers</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {statsLoading ? '...' : stats?.totalSubscribers || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Active newsletter subscriptions
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Newsletters</CardTitle>
                <Mail className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {statsLoading ? '...' : stats?.totalNewsletters || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Newsletters sent successfully
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Email Server</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-emerald-600">
                  Connected
                </div>
                <p className="text-xs text-muted-foreground">
                  mail.comeseetv.com active
                </p>
              </CardContent>
            </Card>
          </div>

          {stats?.recentNewsletters && stats.recentNewsletters.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Recent Newsletters</CardTitle>
                <CardDescription>Latest newsletters sent to subscribers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats.recentNewsletters.map((newsletter) => (
                    <div key={newsletter.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h4 className="font-medium">{newsletter.title}</h4>
                        <p className="text-sm text-gray-500">
                          Sent {new Date(newsletter.sentAt).toLocaleDateString()} to {newsletter.sentCount} subscribers
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Badge variant="outline">{newsletter.openCount} opens</Badge>
                        <Badge variant="outline">{newsletter.clickCount} clicks</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="test" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TestTube className="h-5 w-5" />
                Test Email Functionality
              </CardTitle>
              <CardDescription>
                Send a test newsletter to verify email server connectivity and templates
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleTestEmail} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="testEmail">Test Email Address</Label>
                  <Input
                    id="testEmail"
                    type="email"
                    value={testEmail}
                    onChange={(e) => setTestEmail(e.target.value)}
                    placeholder="Enter email address to receive test newsletter"
                    required
                  />
                </div>
                
                <Button 
                  type="submit" 
                  disabled={testEmailMutation.isPending}
                  className="w-full"
                >
                  {testEmailMutation.isPending ? (
                    'Sending Test Email...'
                  ) : (
                    <div className="flex items-center gap-2">
                      <TestTube className="h-4 w-4" />
                      Send Test Newsletter
                    </div>
                  )}
                </Button>
              </form>
              
              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Test Email Information</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Tests mail.comeseetv.com server connectivity</li>
                  <li>• Sends welcome newsletter template</li>
                  <li>• Includes unsubscribe functionality</li>
                  <li>• Verifies email delivery and formatting</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subscribers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Subscriber Management
              </CardTitle>
              <CardDescription>
                View and manage newsletter subscribers by artist interests
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {managedArtists.map((artist) => (
                  <div key={artist.userId} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">
                          {artist.stageNames?.[0] || artist.fullName || `Artist ${artist.userId}`}
                        </h4>
                        <p className="text-sm text-gray-500">Managed Artist</p>
                      </div>
                      <Badge variant="secondary">
                        Subscribers: Loading...
                      </Badge>
                    </div>
                  </div>
                ))}
                
                {managedArtists.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No managed artists found. Only managed artists can have dedicated subscriber lists.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}