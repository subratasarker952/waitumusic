import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  TrendingUp, 
  Target, 
  Star, 
  Users, 
  Music, 
  Calendar,
  Brain,
  Zap,
  Award,
  ChevronRight,
  BarChart3,
  PieChart,
  LineChart,
  Activity,
  Milestone,
  AlertCircle,
  CheckCircle2,
  Clock
} from 'lucide-react';

interface ArtistAnalysis {
  artistId: number;
  artistName: string;
  currentStage: 'emerging' | 'developing' | 'established' | 'veteran';
  careerScore: number;
  growthTrajectory: 'ascending' | 'stable' | 'declining';
  breakoutProbability: number;
  nextMilestones: Milestone[];
  strengthAreas: string[];
  improvementAreas: string[];
  marketPosition: string;
  projectedRevenue: number;
  recommendations: string[];
  similarArtists: string[];
  lastUpdated: string;
}

interface Milestone {
  id: string;
  title: string;
  description: string;
  targetDate: string;
  probability: number;
  impact: 'high' | 'medium' | 'low';
  status: 'pending' | 'in_progress' | 'completed' | 'missed';
  requirements: string[];
}

interface DevelopmentPlan {
  artistId: number;
  phase: string;
  duration: string;
  objectives: string[];
  strategies: string[];
  resources: string[];
  timeline: TimelineItem[];
  successMetrics: string[];
}

interface TimelineItem {
  month: number;
  milestones: string[];
  focus: string;
  expectedOutcome: string;
}

export default function PredictiveArtistDevelopment() {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedArtist, setSelectedArtist] = useState<number | null>(null);
  const [timeframe, setTimeframe] = useState('6months');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch artist analyses with ML predictions
  const { data: artistAnalyses, isLoading } = useQuery({
    queryKey: ['/api/intelligence/artist-development'],
    queryFn: async () => {
      const response = await apiRequest('/api/intelligence/artist-development');
      if (!response.ok) throw new Error('Failed to fetch artist analyses');
      return response.json();
    }
  });

  // Fetch development plans
  const { data: developmentPlans } = useQuery({
    queryKey: ['/api/intelligence/development-plans', selectedArtist],
    queryFn: async () => {
      if (!selectedArtist) return null;
      const response = await apiRequest(`/api/intelligence/development-plans/${selectedArtist}`);
      if (!response.ok) throw new Error('Failed to fetch development plans');
      return response.json();
    },
    enabled: !!selectedArtist
  });

  // Generate development plan mutation
  const generatePlan = useMutation({
    mutationFn: async ({ artistId, timeframe }: { artistId: number; timeframe: string }) => {
      const response = await apiRequest('/api/intelligence/generate-development-plan', {
        method: 'POST',
        body: JSON.stringify({ artistId, timeframe })
      });
      if (!response.ok) throw new Error('Failed to generate development plan');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/development-plans'] });
      toast({ title: "Success", description: "Development plan generated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to generate development plan", variant: "destructive" });
    }
  });

  const getStageColor = (stage: string) => {
    const colors = {
      emerging: 'bg-blue-500',
      developing: 'bg-purple-500',
      established: 'bg-green-500',
      veteran: 'bg-gold-500'
    };
    return colors[stage as keyof typeof colors] || 'bg-gray-500';
  };

  const getTrajectoryIcon = (trajectory: string) => {
    switch (trajectory) {
      case 'ascending': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'stable': return <Activity className="h-4 w-4 text-blue-600" />;
      case 'declining': return <TrendingUp className="h-4 w-4 text-red-600 rotate-180" />;
      default: return <Activity className="h-4 w-4 text-gray-600" />;
    }
  };

  const getMilestoneIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="h-4 w-4 text-green-600" />;
      case 'in_progress': return <Clock className="h-4 w-4 text-blue-600" />;
      case 'missed': return <AlertCircle className="h-4 w-4 text-red-600" />;
      default: return <Milestone className="h-4 w-4 text-gray-600" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Brain className="h-6 w-6 text-purple-600" />
            Predictive Artist Development
          </h2>
          <p className="text-muted-foreground">AI-powered career trajectory analysis and milestone prediction</p>
        </div>
        <div className="flex gap-2">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3months">3 Months</SelectItem>
              <SelectItem value="6months">6 Months</SelectItem>
              <SelectItem value="1year">1 Year</SelectItem>
              <SelectItem value="2years">2 Years</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
          <TabsTrigger value="plans">Development Plans</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {artistAnalyses?.map((analysis: ArtistAnalysis) => (
              <Card key={analysis.artistId} className="hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setSelectedArtist(analysis.artistId)}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{analysis.artistName}</CardTitle>
                      <Badge className={`${getStageColor(analysis.currentStage)} text-white mt-2`}>
                        {analysis.currentStage}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1">
                      {getTrajectoryIcon(analysis.growthTrajectory)}
                      <span className="text-sm font-medium">{analysis.careerScore}/100</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Breakout Probability:</span>
                      <span className="font-medium">{analysis.breakoutProbability}%</span>
                    </div>
                    <Progress value={analysis.breakoutProbability} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Career Score:</span>
                      <span className="font-medium">{analysis.careerScore}/100</span>
                    </div>
                    <Progress value={analysis.careerScore} className="h-2" />
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Projected Revenue (12mo):</p>
                    <p className="text-lg font-bold text-green-600">
                      ${analysis.projectedRevenue.toLocaleString()}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Next Milestones:</p>
                    <div className="space-y-1">
                      {analysis.nextMilestones.slice(0, 2).map((milestone) => (
                        <div key={milestone.id} className="flex items-center gap-2 text-xs">
                          {getMilestoneIcon(milestone.status)}
                          <span className="truncate">{milestone.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    size="sm"
                    className="w-full"
                    onClick={(e) => {
                      e.stopPropagation();
                      generatePlan.mutate({ artistId: analysis.artistId, timeframe });
                    }}
                    disabled={generatePlan.isPending}
                  >
                    {generatePlan.isPending ? (
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                    ) : (
                      <>
                        <Brain className="h-4 w-4 mr-1" />
                        Generate Plan
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Predictions Tab */}
        <TabsContent value="predictions" className="space-y-4">
          {selectedArtist && artistAnalyses?.find((a: ArtistAnalysis) => a.artistId === selectedArtist) ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {(() => {
                const analysis = artistAnalyses.find((a: ArtistAnalysis) => a.artistId === selectedArtist);
                return (
                  <>
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Target className="h-5 w-5 text-blue-600" />
                          Career Predictions
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-sm">Breakout Probability</span>
                            <span className="font-medium">{analysis.breakoutProbability}%</span>
                          </div>
                          <Progress value={analysis.breakoutProbability} className="h-3" />
                        </div>

                        <div className="space-y-2">
                          <h4 className="font-medium text-sm">Strength Areas:</h4>
                          <div className="flex flex-wrap gap-1">
                            {analysis.strengthAreas.map((area: string, index: number) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {area}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <h4 className="font-medium text-sm">Improvement Areas:</h4>
                          <div className="flex flex-wrap gap-1">
                            {analysis.improvementAreas.map((area: string, index: number) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {area}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="p-3 bg-blue-50 rounded-lg">
                          <p className="text-sm font-medium">Market Position</p>
                          <p className="text-xs text-muted-foreground">{analysis.marketPosition}</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Milestone className="h-5 w-5 text-purple-600" />
                          Upcoming Milestones
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {analysis.nextMilestones.map((milestone: Milestone) => (
                          <div key={milestone.id} className="p-3 border rounded-lg">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex items-center gap-2">
                                {getMilestoneIcon(milestone.status)}
                                <h4 className="font-medium text-sm">{milestone.title}</h4>
                              </div>
                              <Badge variant={milestone.impact === 'high' ? 'default' : 'secondary'}>
                                {milestone.impact}
                              </Badge>
                            </div>
                            
                            <p className="text-xs text-muted-foreground mb-2">
                              {milestone.description}
                            </p>

                            <div className="flex items-center justify-between text-xs">
                              <span className="text-muted-foreground">
                                Target: {new Date(milestone.targetDate).toLocaleDateString()}
                              </span>
                              <span className="font-medium">{milestone.probability}% likely</span>
                            </div>

                            <Progress value={milestone.probability} className="h-1 mt-2" />
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  </>
                );
              })()}
            </div>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center h-64">
                <div className="text-center">
                  <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Select an artist to view predictions</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Development Plans Tab */}
        <TabsContent value="plans" className="space-y-4">
          {developmentPlans ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-green-600" />
                    Development Timeline
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {developmentPlans.timeline?.map((item: TimelineItem) => (
                      <div key={item.month} className="flex gap-4 p-4 border rounded-lg">
                        <div className="flex-shrink-0">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <span className="text-sm font-medium text-blue-600">M{item.month}</span>
                          </div>
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-sm mb-1">{item.focus}</h4>
                          <p className="text-xs text-muted-foreground mb-2">{item.expectedOutcome}</p>
                          <div className="space-y-1">
                            {item.milestones.map((milestone, index) => (
                              <div key={index} className="flex items-center gap-2 text-xs">
                                <ChevronRight className="h-3 w-3 text-muted-foreground" />
                                <span>{milestone}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Objectives</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {developmentPlans.objectives?.map((objective: string, index: number) => (
                        <div key={index} className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{objective}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Success Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {developmentPlans.successMetrics?.map((metric: string, index: number) => (
                        <div key={index} className="flex items-start gap-2">
                          <BarChart3 className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{metric}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center h-64">
                <div className="text-center">
                  <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No development plan generated yet</p>
                  <p className="text-sm text-muted-foreground mt-1">Select an artist and generate a plan</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Artists</p>
                    <p className="text-2xl font-bold">{artistAnalyses?.length || 0}</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Career Score</p>
                    <p className="text-2xl font-bold">
                      {Math.round(artistAnalyses?.reduce((sum: number, artist: ArtistAnalysis) => sum + artist.careerScore, 0) / (artistAnalyses?.length || 1)) || 0}
                    </p>
                  </div>
                  <Star className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">High Potential</p>
                    <p className="text-2xl font-bold">
                      {artistAnalyses?.filter((a: ArtistAnalysis) => a.breakoutProbability > 70).length || 0}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Projected Revenue</p>
                    <p className="text-2xl font-bold">
                      ${artistAnalyses?.reduce((sum: number, artist: ArtistAnalysis) => sum + artist.projectedRevenue, 0).toLocaleString() || '0'}
                    </p>
                  </div>
                  <PieChart className="h-8 w-8" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}