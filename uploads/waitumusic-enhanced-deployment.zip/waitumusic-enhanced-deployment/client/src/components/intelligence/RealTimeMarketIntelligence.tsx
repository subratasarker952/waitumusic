import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp, 
  BarChart3, 
  Globe,
  DollarSign,
  Users,
  Music,
  Zap,
  AlertTriangle,
  CheckCircle,
  Clock,
  Star,
  Target
} from 'lucide-react';

interface MarketTrend {
  id: number;
  category: string;
  trend: string;
  growth: number;
  confidence: number;
  timeframe: string;
  region: string;
  platforms: string[];
  impact: 'low' | 'medium' | 'high' | 'critical';
  opportunities: string[];
  threats: string[];
}

interface GenreAnalysis {
  genre: string;
  popularity: number;
  growth: number;
  marketShare: number;
  topArtists: string[];
  keyPlatforms: string[];
  demographics: {
    primaryAge: string;
    regions: string[];
    streamingBehavior: string;
  };
  revenue: {
    streaming: number;
    live: number;
    merchandise: number;
    sync: number;
  };
}

interface CompetitorInsight {
  artistName: string;
  genre: string;
  followers: number;
  monthlyListeners: number;
  engagementRate: number;
  recentReleases: number;
  averageStreams: number;
  strategies: string[];
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
}

const RealTimeMarketIntelligence: React.FC = () => {
  const [selectedRegion, setSelectedRegion] = useState('global');
  const [selectedTimeframe, setSelectedTimeframe] = useState('30d');

  // Fetch market trends
  const { data: marketTrends, isLoading: trendsLoading } = useQuery({
    queryKey: ['/api/intelligence/market/trends', selectedRegion, selectedTimeframe],
    queryFn: () => apiRequest(`/api/intelligence/market/trends?region=${selectedRegion}&timeframe=${selectedTimeframe}`).then(res => res.json())
  });

  // Fetch genre analysis
  const { data: genreAnalysis, isLoading: genreLoading } = useQuery({
    queryKey: ['/api/intelligence/market/genres', selectedRegion],
    queryFn: () => apiRequest(`/api/intelligence/market/genres?region=${selectedRegion}`).then(res => res.json())
  });

  // Fetch competitor insights
  const { data: competitorInsights } = useQuery({
    queryKey: ['/api/intelligence/market/competitors'],
    queryFn: () => apiRequest('/api/intelligence/market/competitors').then(res => res.json())
  });

  // Fetch market analytics
  const { data: analytics } = useQuery({
    queryKey: ['/api/intelligence/market/analytics'],
    queryFn: () => apiRequest('/api/intelligence/market/analytics').then(res => res.json())
  });

  const regions = [
    { id: 'global', name: 'Global' },
    { id: 'north_america', name: 'North America' },
    { id: 'europe', name: 'Europe' },
    { id: 'caribbean', name: 'Caribbean' },
    { id: 'latin_america', name: 'Latin America' },
    { id: 'asia_pacific', name: 'Asia Pacific' }
  ];

  const timeframes = [
    { id: '7d', name: 'Last 7 Days' },
    { id: '30d', name: 'Last 30 Days' },
    { id: '90d', name: 'Last 3 Months' },
    { id: '1y', name: 'Last Year' }
  ];

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-blue-500';
    }
  };

  const getGrowthColor = (growth: number) => {
    if (growth > 20) return 'text-green-600';
    if (growth > 0) return 'text-blue-600';
    return 'text-red-600';
  };

  if (trendsLoading || genreLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="trends" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="trends">Market Trends</TabsTrigger>
          <TabsTrigger value="genres">Genre Analysis</TabsTrigger>
          <TabsTrigger value="competitors">Competitors</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        {/* Market Trends Tab */}
        <TabsContent value="trends" className="space-y-4">
          {/* Filters */}
          <div className="flex gap-4 mb-6">
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Region" />
              </SelectTrigger>
              <SelectContent>
                {regions.map(region => (
                  <SelectItem key={region.id} value={region.id}>
                    {region.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Timeframe" />
              </SelectTrigger>
              <SelectContent>
                {timeframes.map(timeframe => (
                  <SelectItem key={timeframe.id} value={timeframe.id}>
                    {timeframe.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Trends</p>
                    <p className="text-2xl font-bold">{marketTrends?.length || 0}</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Market Growth</p>
                    <p className="text-2xl font-bold">{analytics?.marketGrowth || 0}%</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">High Impact</p>
                    <p className="text-2xl font-bold">
                      {marketTrends?.filter((t: MarketTrend) => t.impact === 'high' || t.impact === 'critical').length || 0}
                    </p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Opportunities</p>
                    <p className="text-2xl font-bold">{analytics?.totalOpportunities || 0}</p>
                  </div>
                  <Target className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Trends Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {marketTrends?.map((trend: MarketTrend) => (
              <Card key={trend.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{trend.trend}</CardTitle>
                      <p className="text-sm text-muted-foreground">{trend.category}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`${getImpactColor(trend.impact)} text-white`}>
                        {trend.impact}
                      </Badge>
                      <Badge variant="outline">
                        {trend.confidence}% confidence
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Growth Rate</span>
                      <span className={`font-medium ${getGrowthColor(trend.growth)}`}>
                        {trend.growth > 0 ? '+' : ''}{trend.growth}%
                      </span>
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Market Penetration</span>
                        <span>{trend.confidence}%</span>
                      </div>
                      <Progress value={trend.confidence} className="h-2" />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium mb-2">Region</p>
                        <Badge variant="outline">{trend.region}</Badge>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-2">Timeframe</p>
                        <Badge variant="outline">{trend.timeframe}</Badge>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Key Platforms</p>
                      <div className="flex flex-wrap gap-1">
                        {trend.platforms.map(platform => (
                          <Badge key={platform} variant="outline" className="text-xs">
                            {platform}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium mb-2 text-green-600">Opportunities</p>
                        <ul className="text-xs space-y-1">
                          {trend.opportunities.slice(0, 3).map((opp, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <CheckCircle className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                              <span>{opp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-2 text-red-600">Threats</p>
                        <ul className="text-xs space-y-1">
                          {trend.threats.slice(0, 3).map((threat, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <AlertTriangle className="h-3 w-3 text-red-500 mt-0.5 flex-shrink-0" />
                              <span>{threat}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Genre Analysis Tab */}
        <TabsContent value="genres" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {genreAnalysis?.map((genre: GenreAnalysis, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Music className="h-5 w-5" />
                    {genre.genre}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Popularity</p>
                        <div className="flex items-center gap-2">
                          <Progress value={genre.popularity} className="flex-1 h-2" />
                          <span className="text-sm font-medium">{genre.popularity}%</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Growth</p>
                        <p className={`text-lg font-medium ${getGrowthColor(genre.growth)}`}>
                          {genre.growth > 0 ? '+' : ''}{genre.growth}%
                        </p>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm text-muted-foreground">Market Share</p>
                      <div className="flex items-center gap-2">
                        <Progress value={genre.marketShare} className="flex-1 h-2" />
                        <span className="text-sm font-medium">{genre.marketShare}%</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Demographics</p>
                      <div className="space-y-1 text-xs">
                        <div>Age: {genre.demographics.primaryAge}</div>
                        <div>Regions: {genre.demographics.regions.join(', ')}</div>
                        <div>Behavior: {genre.demographics.streamingBehavior}</div>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Revenue Sources</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span>Streaming</span>
                          <span>${genre.revenue.streaming.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span>Live</span>
                          <span>${genre.revenue.live.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span>Merchandise</span>
                          <span>${genre.revenue.merchandise.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span>Sync</span>
                          <span>${genre.revenue.sync.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Top Artists</p>
                      <div className="flex flex-wrap gap-1">
                        {genre.topArtists.slice(0, 3).map(artist => (
                          <Badge key={artist} variant="outline" className="text-xs">
                            {artist}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Key Platforms</p>
                      <div className="flex flex-wrap gap-1">
                        {genre.keyPlatforms.map(platform => (
                          <Badge key={platform} variant="outline" className="text-xs">
                            {platform}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Competitor Analysis Tab */}
        <TabsContent value="competitors" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {competitorInsights?.map((competitor: CompetitorInsight, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{competitor.artistName}</CardTitle>
                      <p className="text-sm text-muted-foreground">{competitor.genre}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">{competitor.engagementRate}%</div>
                      <div className="text-xs text-muted-foreground">Engagement</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Followers</p>
                        <p className="text-lg font-medium">{competitor.followers.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Monthly Listeners</p>
                        <p className="text-lg font-medium">{competitor.monthlyListeners.toLocaleString()}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Recent Releases</p>
                        <p className="text-lg font-medium">{competitor.recentReleases}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Avg Streams</p>
                        <p className="text-lg font-medium">{competitor.averageStreams.toLocaleString()}</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Key Strategies</p>
                      <ul className="text-xs space-y-1">
                        {competitor.strategies.slice(0, 3).map((strategy, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <Zap className="h-3 w-3 text-blue-500 mt-0.5 flex-shrink-0" />
                            <span>{strategy}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium mb-2 text-green-600">Strengths</p>
                        <ul className="text-xs space-y-1">
                          {competitor.strengths.slice(0, 2).map((strength, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <CheckCircle className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                              <span>{strength}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-2 text-red-600">Weaknesses</p>
                        <ul className="text-xs space-y-1">
                          {competitor.weaknesses.slice(0, 2).map((weakness, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <AlertTriangle className="h-3 w-3 text-red-500 mt-0.5 flex-shrink-0" />
                              <span>{weakness}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2 text-purple-600">Market Opportunities</p>
                      <ul className="text-xs space-y-1">
                        {competitor.opportunities.slice(0, 2).map((opp, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <Target className="h-3 w-3 text-purple-500 mt-0.5 flex-shrink-0" />
                            <span>{opp}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Market Insights Tab */}
        <TabsContent value="insights" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Market Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Total Market Size</span>
                    <span className="font-medium">${analytics?.marketSize?.toLocaleString() || 0}M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Growth Rate</span>
                    <span className={`font-medium ${getGrowthColor(analytics?.growthRate || 0)}`}>
                      {analytics?.growthRate || 0}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Active Artists</span>
                    <span className="font-medium">{analytics?.activeArtists?.toLocaleString() || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Streaming Revenue</span>
                    <span className="font-medium">${analytics?.streamingRevenue?.toLocaleString() || 0}M</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Key Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analytics?.recommendations?.map((rec: string, index: number) => (
                    <div key={index} className="flex items-start gap-2">
                      <Star className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{rec}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RealTimeMarketIntelligence;