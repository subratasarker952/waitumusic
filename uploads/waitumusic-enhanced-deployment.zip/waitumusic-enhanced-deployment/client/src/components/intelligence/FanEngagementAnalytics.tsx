import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  Users, 
  Heart, 
  MessageCircle, 
  Share2,
  TrendingUp,
  BarChart3,
  Clock,
  MapPin,
  Calendar,
  Star,
  Music,
  Video,
  Headphones,
  UserPlus,
  Activity,
  Target,
  Award,
  Globe,
  Zap
} from 'lucide-react';

interface FanSegment {
  id: number;
  name: string;
  size: number;
  demographics: {
    ageRange: string;
    primaryLocation: string;
    musicGenres: string[];
    platforms: string[];
  };
  engagementLevel: 'low' | 'medium' | 'high' | 'super_fan';
  averageSpend: number;
  loyaltyScore: number;
  growthRate: number;
  recentActivity: string[];
}

interface EngagementMetrics {
  platform: string;
  followers: number;
  engagement: {
    likes: number;
    comments: number;
    shares: number;
    saves: number;
    rate: number;
  };
  reach: number;
  impressions: number;
  growth: {
    followers: number;
    engagement: number;
  };
  topContent: Array<{
    id: number;
    type: string;
    title: string;
    engagement: number;
  }>;
}

interface FanJourney {
  stage: string;
  fanCount: number;
  conversionRate: number;
  averageTime: string;
  touchpoints: string[];
  dropoffRate: number;
  recommendations: string[];
}

interface CommunityInsight {
  topic: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  mentions: number;
  engagement: number;
  influence: number;
  keyContributors: string[];
  trendingtags: string[];
}

const FanEngagementAnalytics: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPlatform, setSelectedPlatform] = useState('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState('30d');

  // Fetch fan segments
  const { data: fanSegments, isLoading: segmentsLoading } = useQuery({
    queryKey: ['/api/intelligence/fan-analytics/segments'],
    queryFn: () => apiRequest('/api/intelligence/fan-analytics/segments').then(res => res.json())
  });

  // Fetch engagement metrics
  const { data: engagementMetrics, isLoading: metricsLoading } = useQuery({
    queryKey: ['/api/intelligence/fan-analytics/engagement', selectedPlatform, selectedTimeframe],
    queryFn: () => apiRequest(`/api/intelligence/fan-analytics/engagement?platform=${selectedPlatform}&timeframe=${selectedTimeframe}`).then(res => res.json())
  });

  // Fetch fan journey data
  const { data: fanJourney } = useQuery({
    queryKey: ['/api/intelligence/fan-analytics/journey'],
    queryFn: () => apiRequest('/api/intelligence/fan-analytics/journey').then(res => res.json())
  });

  // Fetch community insights
  const { data: communityInsights } = useQuery({
    queryKey: ['/api/intelligence/fan-analytics/community'],
    queryFn: () => apiRequest('/api/intelligence/fan-analytics/community').then(res => res.json())
  });

  // Fetch analytics summary
  const { data: analytics } = useQuery({
    queryKey: ['/api/intelligence/fan-analytics/summary'],
    queryFn: () => apiRequest('/api/intelligence/fan-analytics/summary').then(res => res.json())
  });

  // Create fan campaign
  const createCampaign = useMutation({
    mutationFn: (campaignData: any) => apiRequest('/api/intelligence/fan-analytics/campaigns', {
      method: 'POST',
      body: JSON.stringify(campaignData)
    }),
    onSuccess: () => {
      toast({ title: "Campaign Created", description: "Fan engagement campaign created successfully" });
    }
  });

  const platforms = [
    { id: 'all', name: 'All Platforms' },
    { id: 'instagram', name: 'Instagram' },
    { id: 'tiktok', name: 'TikTok' },
    { id: 'youtube', name: 'YouTube' },
    { id: 'twitter', name: 'Twitter' },
    { id: 'spotify', name: 'Spotify' },
    { id: 'soundcloud', name: 'SoundCloud' }
  ];

  const timeframes = [
    { id: '7d', name: 'Last 7 Days' },
    { id: '30d', name: 'Last 30 Days' },
    { id: '90d', name: 'Last 3 Months' },
    { id: '1y', name: 'Last Year' }
  ];

  const getEngagementLevelColor = (level: string) => {
    switch (level) {
      case 'super_fan': return 'bg-purple-500';
      case 'high': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getEngagementLevelLabel = (level: string) => {
    switch (level) {
      case 'super_fan': return 'Super Fan';
      case 'high': return 'High';
      case 'medium': return 'Medium';
      default: return 'Low';
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600';
      case 'negative': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return '😊';
      case 'negative': return '😞';
      default: return '😐';
    }
  };

  if (segmentsLoading || metricsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="segments">Segments</TabsTrigger>
          <TabsTrigger value="journey">Journey</TabsTrigger>
          <TabsTrigger value="community">Community</TabsTrigger>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          {/* Filter Controls */}
          <div className="flex gap-4 mb-6">
            <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Platform" />
              </SelectTrigger>
              <SelectContent>
                {platforms.map(platform => (
                  <SelectItem key={platform.id} value={platform.id}>
                    {platform.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Timeframe" />
              </SelectTrigger>
              <SelectContent>
                {timeframes.map(timeframe => (
                  <SelectItem key={timeframe.id} value={timeframe.id}>
                    {timeframe.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Fans</p>
                    <p className="text-2xl font-bold">{analytics?.totalFans?.toLocaleString() || 0}</p>
                    <p className="text-xs text-green-600">+{analytics?.fanGrowth || 0}% this month</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Engagement Rate</p>
                    <p className="text-2xl font-bold">{analytics?.engagementRate || 0}%</p>
                    <p className="text-xs text-green-600">+{analytics?.engagementGrowth || 0}% vs last period</p>
                  </div>
                  <Heart className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Super Fans</p>
                    <p className="text-2xl font-bold">{analytics?.superFans || 0}</p>
                    <p className="text-xs text-purple-600">{analytics?.superFanPercentage || 0}% of total</p>
                  </div>
                  <Star className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Fan Value</p>
                    <p className="text-2xl font-bold">${analytics?.averageFanValue || 0}</p>
                    <p className="text-xs text-green-600">Avg lifetime value</p>
                  </div>
                  <Award className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Platform Metrics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {engagementMetrics?.map((platform: EngagementMetrics) => (
              <Card key={platform.platform}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5" />
                    {platform.platform}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Followers</p>
                      <p className="text-xl font-bold">{platform.followers.toLocaleString()}</p>
                      <p className={`text-xs ${platform.growth.followers >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {platform.growth.followers >= 0 ? '+' : ''}{platform.growth.followers}%
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Engagement Rate</p>
                      <p className="text-xl font-bold">{platform.engagement.rate}%</p>
                      <p className={`text-xs ${platform.growth.engagement >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {platform.growth.engagement >= 0 ? '+' : ''}{platform.growth.engagement}%
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Likes</span>
                      <span>{platform.engagement.likes.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Comments</span>
                      <span>{platform.engagement.comments.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Shares</span>
                      <span>{platform.engagement.shares.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Reach</span>
                      <span>{platform.reach.toLocaleString()}</span>
                    </div>
                  </div>

                  {platform.topContent.length > 0 && (
                    <div className="mt-4 pt-4 border-t">
                      <p className="text-sm font-medium mb-2">Top Content</p>
                      <div className="space-y-1">
                        {platform.topContent.slice(0, 3).map(content => (
                          <div key={content.id} className="flex justify-between text-xs">
                            <span className="truncate">{content.title}</span>
                            <span>{content.engagement.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Fan Segments Tab */}
        <TabsContent value="segments" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {fanSegments?.map((segment: FanSegment) => (
              <Card key={segment.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{segment.name}</CardTitle>
                    <Badge className={`${getEngagementLevelColor(segment.engagementLevel)} text-white`}>
                      {getEngagementLevelLabel(segment.engagementLevel)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Size</span>
                      <span className="font-medium">{segment.size.toLocaleString()} fans</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Avg Spend</span>
                      <span className="font-medium">${segment.averageSpend}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Loyalty Score</span>
                      <div className="flex items-center gap-2">
                        <Progress value={segment.loyaltyScore} className="w-20 h-2" />
                        <span className="text-sm">{segment.loyaltyScore}%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Growth Rate</span>
                      <span className={`font-medium ${segment.growthRate >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {segment.growthRate >= 0 ? '+' : ''}{segment.growthRate}%
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t">
                    <p className="text-sm font-medium mb-2">Demographics</p>
                    <div className="space-y-1 text-xs">
                      <div className="flex items-center gap-2">
                        <Clock className="h-3 w-3" />
                        <span>{segment.demographics.ageRange}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3 w-3" />
                        <span>{segment.demographics.primaryLocation}</span>
                      </div>
                    </div>
                    <div className="mt-2">
                      <p className="text-xs font-medium mb-1">Top Genres:</p>
                      <div className="flex flex-wrap gap-1">
                        {segment.demographics.musicGenres.slice(0, 3).map(genre => (
                          <Badge key={genre} variant="outline" className="text-xs">
                            {genre}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="mt-2">
                      <p className="text-xs font-medium mb-1">Active Platforms:</p>
                      <div className="flex flex-wrap gap-1">
                        {segment.demographics.platforms.slice(0, 3).map(platform => (
                          <Badge key={platform} variant="outline" className="text-xs">
                            {platform}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  <Button size="sm" variant="outline" className="w-full mt-4">
                    <Target className="h-3 w-3 mr-1" />
                    Target Segment
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Fan Journey Tab */}
        <TabsContent value="journey" className="space-y-4">
          <div className="space-y-6">
            {fanJourney?.map((stage: FanJourney, index: number) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                      </div>
                      <div>
                        <h3 className="font-medium text-lg">{stage.stage}</h3>
                        <p className="text-sm text-muted-foreground">
                          {stage.fanCount.toLocaleString()} fans • Avg time: {stage.averageTime}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-medium">{stage.conversionRate}%</div>
                      <div className="text-xs text-muted-foreground">Conversion rate</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm font-medium mb-2">Key Touchpoints</p>
                      <ul className="space-y-1">
                        {stage.touchpoints.map((touchpoint, i) => (
                          <li key={i} className="text-sm flex items-start gap-2">
                            <div className="w-1 h-1 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                            <span>{touchpoint}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-2">Optimization Recommendations</p>
                      <ul className="space-y-1">
                        {stage.recommendations.map((rec, i) => (
                          <li key={i} className="text-sm flex items-start gap-2">
                            <Zap className="h-3 w-3 text-yellow-600 mt-0.5 flex-shrink-0" />
                            <span>{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t">
                    <div className="flex items-center gap-4">
                      <div className="text-sm">
                        <span className="font-medium">Drop-off Rate:</span>
                        <span className={`ml-2 ${stage.dropoffRate > 30 ? 'text-red-600' : 'text-green-600'}`}>
                          {stage.dropoffRate}%
                        </span>
                      </div>
                      <Progress value={100 - stage.dropoffRate} className="flex-1 h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Community Insights Tab */}
        <TabsContent value="community" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {communityInsights?.map((insight: CommunityInsight, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{insight.topic}</CardTitle>
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{getSentimentIcon(insight.sentiment)}</span>
                      <span className={`text-sm font-medium ${getSentimentColor(insight.sentiment)}`}>
                        {insight.sentiment}
                      </span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Mentions</p>
                      <p className="text-xl font-bold">{insight.mentions.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Engagement</p>
                      <p className="text-xl font-bold">{insight.engagement.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">Influence Score</span>
                      <span className="text-sm font-medium">{insight.influence}/100</span>
                    </div>
                    <Progress value={insight.influence} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium mb-1">Key Contributors</p>
                      <p className="text-xs text-muted-foreground">
                        {insight.keyContributors.join(', ')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-1">Trending Tags</p>
                      <div className="flex flex-wrap gap-1">
                        {insight.trendingtags.map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  <Button size="sm" variant="outline" className="w-full mt-4">
                    <MessageCircle className="h-3 w-3 mr-1" />
                    Engage Community
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Fan Campaigns Tab */}
        <TabsContent value="campaigns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Create Fan Engagement Campaign</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-lg font-medium mb-2">Launch Targeted Fan Campaigns</p>
                <p className="text-muted-foreground mb-4">
                  Create personalized campaigns based on fan segments and engagement analytics
                </p>
                <Button>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Create Campaign
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FanEngagementAnalytics;