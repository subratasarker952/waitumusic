import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Target, 
  TrendingUp, 
  Users,
  Star,
  MapPin,
  Calendar,
  Award,
  Zap,
  CheckCircle,
  Clock,
  Compass,
  Lightbulb,
  Route
} from 'lucide-react';

interface CareerPath {
  id: number;
  title: string;
  description: string;
  stages: CareerStage[];
  estimatedDuration: string;
  successProbability: number;
  potentialEarnings: {
    current: number;
    year1: number;
    year3: number;
    year5: number;
  };
  requiredSkills: string[];
  keyMilestones: string[];
  industryConnections: string[];
  recommendation: 'highly_recommended' | 'recommended' | 'consider' | 'not_recommended';
}

interface CareerStage {
  id: number;
  name: string;
  description: string;
  duration: string;
  objectives: string[];
  skills: string[];
  connections: string[];
  milestones: string[];
  completed: boolean;
  progress: number;
}

interface SkillAssessment {
  skill: string;
  currentLevel: number;
  targetLevel: number;
  importance: number;
  developmentPath: string[];
  resources: string[];
  timeToMaster: string;
}

const AICareerPathOptimizer: React.FC = () => {
  const [selectedPath, setSelectedPath] = useState<number | null>(null);

  // Fetch career paths
  const { data: careerPaths, isLoading: pathsLoading } = useQuery({
    queryKey: ['/api/intelligence/career/paths'],
    queryFn: () => apiRequest('/api/intelligence/career/paths').then(res => res.json())
  });

  // Fetch skill assessment
  const { data: skillAssessment } = useQuery({
    queryKey: ['/api/intelligence/career/skills'],
    queryFn: () => apiRequest('/api/intelligence/career/skills').then(res => res.json())
  });

  // Fetch analytics
  const { data: analytics } = useQuery({
    queryKey: ['/api/intelligence/career/analytics'],
    queryFn: () => apiRequest('/api/intelligence/career/analytics').then(res => res.json())
  });

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case 'highly_recommended': return 'bg-green-500';
      case 'recommended': return 'bg-blue-500';
      case 'consider': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getRecommendationLabel = (recommendation: string) => {
    switch (recommendation) {
      case 'highly_recommended': return 'Highly Recommended';
      case 'recommended': return 'Recommended';
      case 'consider': return 'Consider';
      default: return 'Not Recommended';
    }
  };

  if (pathsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="paths" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="paths">Career Paths</TabsTrigger>
          <TabsTrigger value="skills">Skill Development</TabsTrigger>
          <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
        </TabsList>

        {/* Career Paths Tab */}
        <TabsContent value="paths" className="space-y-4">
          {/* Analytics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Available Paths</p>
                    <p className="text-2xl font-bold">{careerPaths?.length || 0}</p>
                  </div>
                  <Route className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                    <p className="text-2xl font-bold">{analytics?.averageSuccessRate || 0}%</p>
                  </div>
                  <Target className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Career Stage</p>
                    <p className="text-2xl font-bold">{analytics?.currentStage || 'N/A'}</p>
                  </div>
                  <Compass className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Earning Potential</p>
                    <p className="text-2xl font-bold">${analytics?.maxEarningPotential?.toLocaleString() || 0}</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Career Paths Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {careerPaths?.map((path: CareerPath) => (
              <Card key={path.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{path.title}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">{path.description}</p>
                    </div>
                    <Badge className={`${getRecommendationColor(path.recommendation)} text-white`}>
                      {getRecommendationLabel(path.recommendation)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Duration</p>
                        <p className="font-medium">{path.estimatedDuration}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Success Rate</p>
                        <div className="flex items-center gap-2">
                          <Progress value={path.successProbability} className="flex-1 h-2" />
                          <span className="text-sm font-medium">{path.successProbability}%</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Earning Progression</p>
                      <div className="grid grid-cols-4 gap-2 text-xs">
                        <div className="text-center">
                          <div className="font-medium">${path.potentialEarnings.current.toLocaleString()}</div>
                          <div className="text-muted-foreground">Current</div>
                        </div>
                        <div className="text-center">
                          <div className="font-medium">${path.potentialEarnings.year1.toLocaleString()}</div>
                          <div className="text-muted-foreground">Year 1</div>
                        </div>
                        <div className="text-center">
                          <div className="font-medium">${path.potentialEarnings.year3.toLocaleString()}</div>
                          <div className="text-muted-foreground">Year 3</div>
                        </div>
                        <div className="text-center">
                          <div className="font-medium">${path.potentialEarnings.year5.toLocaleString()}</div>
                          <div className="text-muted-foreground">Year 5</div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Required Skills</p>
                      <div className="flex flex-wrap gap-1">
                        {path.requiredSkills.slice(0, 4).map(skill => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {path.requiredSkills.length > 4 && (
                          <Badge variant="outline" className="text-xs">
                            +{path.requiredSkills.length - 4} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Key Milestones</p>
                      <ul className="text-xs space-y-1">
                        {path.keyMilestones.slice(0, 3).map((milestone, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <CheckCircle className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>{milestone}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Industry Connections</p>
                      <div className="flex items-center gap-1">
                        <Users className="h-3 w-3 text-muted-foreground" />
                        <span className="text-xs">{path.industryConnections.length} key connections</span>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-3 border-t">
                      <button
                        className="flex-1 px-3 py-2 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                        onClick={() => setSelectedPath(path.id)}
                      >
                        <Route className="h-3 w-3 inline mr-1" />
                        View Path Details
                      </button>
                      <button className="px-3 py-2 text-sm border rounded hover:bg-gray-50 transition-colors">
                        <Star className="h-3 w-3 inline mr-1" />
                        Save
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Selected Path Details */}
          {selectedPath && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Career Path Details</CardTitle>
              </CardHeader>
              <CardContent>
                {(() => {
                  const path = careerPaths.find((p: CareerPath) => p.id === selectedPath);
                  if (!path) return null;
                  
                  return (
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium text-lg mb-2">{path.title}</h3>
                        <p className="text-muted-foreground">{path.description}</p>
                      </div>

                      <div>
                        <h4 className="font-medium mb-3">Career Stages</h4>
                        <div className="space-y-4">
                          {path.stages.map((stage: CareerStage, index: number) => (
                            <div key={stage.id} className="border rounded-lg p-4">
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                    <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                                  </div>
                                  <div>
                                    <h5 className="font-medium">{stage.name}</h5>
                                    <p className="text-sm text-muted-foreground">{stage.description}</p>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="text-sm font-medium">{stage.duration}</div>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Progress value={stage.progress} className="w-16 h-1" />
                                    <span className="text-xs">{stage.progress}%</span>
                                  </div>
                                </div>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                  <p className="text-sm font-medium mb-2">Objectives</p>
                                  <ul className="text-xs space-y-1">
                                    {stage.objectives.map((obj, i) => (
                                      <li key={i} className="flex items-start gap-2">
                                        <Target className="h-3 w-3 text-blue-500 mt-0.5 flex-shrink-0" />
                                        <span>{obj}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                                <div>
                                  <p className="text-sm font-medium mb-2">Skills</p>
                                  <div className="flex flex-wrap gap-1">
                                    {stage.skills.map(skill => (
                                      <Badge key={skill} variant="outline" className="text-xs">
                                        {skill}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                                <div>
                                  <p className="text-sm font-medium mb-2">Key Connections</p>
                                  <ul className="text-xs space-y-1">
                                    {stage.connections.slice(0, 2).map((connection, i) => (
                                      <li key={i} className="flex items-start gap-2">
                                        <Users className="h-3 w-3 text-purple-500 mt-0.5 flex-shrink-0" />
                                        <span>{connection}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Skill Development Tab */}
        <TabsContent value="skills" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {skillAssessment?.map((skill: SkillAssessment, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-lg">{skill.skill}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Current Level</p>
                        <div className="flex items-center gap-2">
                          <Progress value={skill.currentLevel * 20} className="flex-1 h-2" />
                          <span className="text-sm font-medium">{skill.currentLevel}/5</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Target Level</p>
                        <div className="flex items-center gap-2">
                          <Progress value={skill.targetLevel * 20} className="flex-1 h-2" />
                          <span className="text-sm font-medium">{skill.targetLevel}/5</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm">Importance</span>
                        <span className="text-sm font-medium">{skill.importance}/10</span>
                      </div>
                      <Progress value={skill.importance * 10} className="h-2" />
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Development Path</p>
                      <ul className="text-xs space-y-1">
                        {skill.developmentPath.slice(0, 3).map((step, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <Lightbulb className="h-3 w-3 text-yellow-500 mt-0.5 flex-shrink-0" />
                            <span>{step}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Resources</p>
                      <div className="flex flex-wrap gap-1">
                        {skill.resources.slice(0, 3).map(resource => (
                          <Badge key={resource} variant="outline" className="text-xs">
                            {resource}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t">
                      <div className="text-sm">
                        <Clock className="h-3 w-3 inline mr-1" />
                        Time to master: {skill.timeToMaster}
                      </div>
                      <button className="text-sm text-blue-600 hover:text-blue-700">
                        Start Learning
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Progress Tracking Tab */}
        <TabsContent value="progress" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Career Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Overall Progress</span>
                    <span className="font-medium">{analytics?.overallProgress || 0}%</span>
                  </div>
                  <Progress value={analytics?.overallProgress || 0} className="h-3" />
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Skills Development</span>
                      <span className="font-medium">{analytics?.skillsProgress || 0}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Network Building</span>
                      <span className="font-medium">{analytics?.networkProgress || 0}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Experience Gained</span>
                      <span className="font-medium">{analytics?.experienceProgress || 0}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Income Growth</span>
                      <span className="font-medium">{analytics?.incomeProgress || 0}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Upcoming Milestones</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analytics?.upcomingMilestones?.map((milestone: any, index: number) => (
                    <div key={index} className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{milestone.title}</p>
                        <p className="text-xs text-muted-foreground">{milestone.description}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Calendar className="h-3 w-3 text-muted-foreground" />
                          <span className="text-xs">{milestone.targetDate}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AICareerPathOptimizer;