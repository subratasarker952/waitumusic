import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp, 
  BarChart3, 
  Target, 
  Zap,
  Clock,
  Users,
  Heart,
  Share,
  Eye,
  DollarSign,
  Calendar,
  Music,
  Video,
  Image,
  FileText,
  Sparkles,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

interface ContentPrediction {
  id: number;
  contentType: string;
  title: string;
  description: string;
  platform: string;
  predictedPerformance: {
    viewsPrediction: number;
    engagementRate: number;
    sharesPrediction: number;
    conversionRate: number;
    viralPotential: number;
  };
  confidenceScore: number;
  optimizationSuggestions: string[];
  bestPostingTime: string;
  targetAudience: string[];
  hashtags: string[];
  status: 'draft' | 'analyzed' | 'optimized' | 'published';
  createdAt: string;
}

interface PerformanceMetrics {
  contentId: number;
  actualViews: number;
  actualEngagement: number;
  actualShares: number;
  actualConversions: number;
  predictionAccuracy: number;
  performanceGrade: 'A' | 'B' | 'C' | 'D' | 'F';
}

interface ContentTrend {
  topic: string;
  trendScore: number;
  growth: number;
  platforms: string[];
  peakTime: string;
  duration: string;
  audienceInterest: number;
}

const ContentPerformancePredictor: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newContent, setNewContent] = useState({
    contentType: '',
    title: '',
    description: '',
    platform: '',
    targetAudience: [] as string[]
  });

  // Fetch content predictions
  const { data: predictions, isLoading: predictionsLoading } = useQuery({
    queryKey: ['/api/intelligence/content/predictions'],
    queryFn: () => apiRequest('/api/intelligence/content/predictions').then(res => res.json())
  });

  // Fetch performance metrics
  const { data: metrics } = useQuery({
    queryKey: ['/api/intelligence/content/metrics'],
    queryFn: () => apiRequest('/api/intelligence/content/metrics').then(res => res.json())
  });

  // Fetch trending topics
  const { data: trends } = useQuery({
    queryKey: ['/api/intelligence/content/trends'],
    queryFn: () => apiRequest('/api/intelligence/content/trends').then(res => res.json())
  });

  // Fetch analytics
  const { data: analytics } = useQuery({
    queryKey: ['/api/intelligence/content/analytics'],
    queryFn: () => apiRequest('/api/intelligence/content/analytics').then(res => res.json())
  });

  // Create content prediction mutation
  const createPrediction = useMutation({
    mutationFn: (contentData: any) => apiRequest('/api/intelligence/content/predictions', {
      method: 'POST',
      body: JSON.stringify(contentData)
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/content/predictions'] });
      toast({ title: "Content Analyzed", description: "Performance prediction generated successfully" });
      setNewContent({ contentType: '', title: '', description: '', platform: '', targetAudience: [] });
    }
  });

  // Optimize content mutation
  const optimizeContent = useMutation({
    mutationFn: (contentId: number) => apiRequest(`/api/intelligence/content/optimize/${contentId}`, {
      method: 'POST'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/content/predictions'] });
      toast({ title: "Content Optimized", description: "Content has been optimized based on AI recommendations" });
    }
  });

  const contentTypes = [
    { id: 'music', name: 'Music Track', icon: Music },
    { id: 'video', name: 'Music Video', icon: Video },
    { id: 'image', name: 'Album Artwork', icon: Image },
    { id: 'post', name: 'Social Post', icon: FileText }
  ];

  const platforms = [
    'Instagram', 'TikTok', 'YouTube', 'Twitter', 'Facebook', 'Spotify', 'SoundCloud'
  ];

  const audienceTypes = [
    'Gen Z (18-24)', 'Millennials (25-40)', 'Gen X (41-56)', 'Hip-Hop Fans',
    'Pop Music Lovers', 'Indie Music Fans', 'Electronic Music Enthusiasts',
    'R&B/Soul Listeners', 'Caribbean Music Fans', 'Music Producers'
  ];

  const getPerformanceColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getPerformanceGrade = (score: number) => {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  };

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'bg-green-500';
      case 'B': return 'bg-green-400';
      case 'C': return 'bg-yellow-500';
      case 'D': return 'bg-orange-500';
      default: return 'bg-red-500';
    }
  };

  const handleCreatePrediction = () => {
    if (!newContent.title || !newContent.contentType || !newContent.platform) {
      toast({ 
        title: "Validation Error", 
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    createPrediction.mutate(newContent);
  };

  if (predictionsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="predictions" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
          <TabsTrigger value="create">Analyze Content</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        {/* Content Predictions Tab */}
        <TabsContent value="predictions" className="space-y-4">
          {/* Analytics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Predictions</p>
                    <p className="text-2xl font-bold">{predictions?.length || 0}</p>
                  </div>
                  <Target className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Confidence</p>
                    <p className="text-2xl font-bold">{analytics?.averageConfidence || 0}%</p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">High Potential</p>
                    <p className="text-2xl font-bold">
                      {predictions?.filter((p: ContentPrediction) => p.predictedPerformance.viralPotential >= 80).length || 0}
                    </p>
                  </div>
                  <Sparkles className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Prediction Accuracy</p>
                    <p className="text-2xl font-bold">{analytics?.predictionAccuracy || 0}%</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Content Predictions Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {predictions?.map((prediction: ContentPrediction) => (
              <Card key={prediction.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{prediction.title}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">
                        {prediction.contentType} • {prediction.platform}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge 
                        className={`${prediction.confidenceScore >= 80 ? 'bg-green-500' : 
                          prediction.confidenceScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'} text-white`}
                      >
                        {prediction.confidenceScore}% confidence
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {prediction.description}
                  </p>

                  {/* Performance Predictions */}
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Eye className="h-4 w-4 text-blue-600" />
                        <span className="text-sm">Views</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {prediction.predictedPerformance.viewsPrediction.toLocaleString()}
                        </div>
                        <Progress 
                          value={Math.min(100, prediction.predictedPerformance.viewsPrediction / 10000 * 100)} 
                          className="w-20 h-2 mt-1"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Heart className="h-4 w-4 text-red-600" />
                        <span className="text-sm">Engagement</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {prediction.predictedPerformance.engagementRate}%
                        </div>
                        <Progress 
                          value={prediction.predictedPerformance.engagementRate} 
                          className="w-20 h-2 mt-1"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4 text-purple-600" />
                        <span className="text-sm">Viral Potential</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {prediction.predictedPerformance.viralPotential}%
                        </div>
                        <Progress 
                          value={prediction.predictedPerformance.viralPotential} 
                          className="w-20 h-2 mt-1"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Best Posting Time */}
                  <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-medium">Optimal Posting Time</span>
                    </div>
                    <p className="text-sm text-blue-700">{prediction.bestPostingTime}</p>
                  </div>

                  {/* Optimization Suggestions */}
                  {prediction.optimizationSuggestions.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-sm font-medium mb-2">Optimization Suggestions</h4>
                      <ul className="text-xs space-y-1">
                        {prediction.optimizationSuggestions.slice(0, 3).map((suggestion, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <div className="w-1 h-1 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                            <span>{suggestion}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Hashtags */}
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-1">
                      {prediction.hashtags.slice(0, 5).map(hashtag => (
                        <Badge key={hashtag} variant="outline" className="text-xs">
                          #{hashtag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-3 border-t">
                    <Button 
                      size="sm" 
                      onClick={() => optimizeContent.mutate(prediction.id)}
                      disabled={optimizeContent.isPending}
                    >
                      <Sparkles className="h-3 w-3 mr-1" />
                      Optimize
                    </Button>
                    <Button size="sm" variant="outline">
                      Schedule
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Create/Analyze Content Tab */}
        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Analyze New Content</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Content Type</label>
                  <Select 
                    value={newContent.contentType} 
                    onValueChange={(value) => setNewContent(prev => ({ ...prev, contentType: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select content type" />
                    </SelectTrigger>
                    <SelectContent>
                      {contentTypes.map(type => (
                        <SelectItem key={type.id} value={type.id}>
                          <div className="flex items-center gap-2">
                            <type.icon className="h-4 w-4" />
                            {type.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Platform</label>
                  <Select 
                    value={newContent.platform} 
                    onValueChange={(value) => setNewContent(prev => ({ ...prev, platform: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select platform" />
                    </SelectTrigger>
                    <SelectContent>
                      {platforms.map(platform => (
                        <SelectItem key={platform} value={platform}>
                          {platform}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Title</label>
                <Input
                  value={newContent.title}
                  onChange={(e) => setNewContent(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter content title"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Description</label>
                <Textarea
                  rows={3}
                  value={newContent.description}
                  onChange={(e) => setNewContent(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe your content..."
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Target Audience</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {audienceTypes.map(audience => (
                    <div key={audience} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={audience}
                        checked={newContent.targetAudience.includes(audience)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewContent(prev => ({ 
                              ...prev, 
                              targetAudience: [...prev.targetAudience, audience] 
                            }));
                          } else {
                            setNewContent(prev => ({ 
                              ...prev, 
                              targetAudience: prev.targetAudience.filter(a => a !== audience) 
                            }));
                          }
                        }}
                        className="rounded"
                      />
                      <label htmlFor={audience} className="text-sm">{audience}</label>
                    </div>
                  ))}
                </div>
              </div>

              <Button 
                onClick={handleCreatePrediction}
                disabled={createPrediction.isPending}
                className="w-full"
              >
                <BarChart3 className="h-4 w-4 mr-2" />
                Analyze Content Performance
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trending Topics Tab */}
        <TabsContent value="trends" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {trends?.map((trend: ContentTrend, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-lg">{trend.topic}</CardTitle>
                    <Badge className={`${trend.trendScore >= 80 ? 'bg-green-500' : 
                      trend.trendScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'} text-white`}>
                      {trend.trendScore}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Growth</span>
                      <span className={`text-sm font-medium ${trend.growth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {trend.growth >= 0 ? '+' : ''}{trend.growth}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Interest</span>
                      <Progress value={trend.audienceInterest} className="w-20 h-2" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Peak Time</span>
                      <span className="text-sm">{trend.peakTime}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Duration</span>
                      <span className="text-sm">{trend.duration}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <p className="text-xs font-medium text-muted-foreground mb-2">Platforms:</p>
                    <div className="flex flex-wrap gap-1">
                      {trend.platforms.map(platform => (
                        <Badge key={platform} variant="outline" className="text-xs">
                          {platform}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button size="sm" variant="outline" className="w-full mt-4">
                    Create Content
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Performance Tracking Tab */}
        <TabsContent value="performance" className="space-y-4">
          <div className="space-y-4">
            {metrics?.map((metric: PerformanceMetrics) => {
              const prediction = predictions?.find((p: ContentPrediction) => p.id === metric.contentId);
              return (
                <Card key={metric.contentId}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-medium">{prediction?.title || 'Content'}</h4>
                        <p className="text-sm text-muted-foreground">
                          {prediction?.platform} • {prediction?.contentType}
                        </p>
                      </div>
                      <Badge className={`${getGradeColor(metric.performanceGrade)} text-white`}>
                        Grade {metric.performanceGrade}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-lg font-medium">{metric.actualViews.toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">Views</div>
                        <div className="text-xs">
                          vs {prediction?.predictedPerformance.viewsPrediction.toLocaleString()} predicted
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-medium">{metric.actualEngagement}%</div>
                        <div className="text-xs text-muted-foreground">Engagement</div>
                        <div className="text-xs">
                          vs {prediction?.predictedPerformance.engagementRate}% predicted
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-medium">{metric.actualShares.toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">Shares</div>
                        <div className="text-xs">
                          vs {prediction?.predictedPerformance.sharesPrediction.toLocaleString()} predicted
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-medium">{metric.actualConversions}</div>
                        <div className="text-xs text-muted-foreground">Conversions</div>
                        <div className="text-xs">
                          {(prediction?.predictedPerformance.conversionRate || 0)}% rate predicted
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t">
                      <div className="text-sm">
                        <span className="font-medium">Prediction Accuracy:</span>
                        <span className={`ml-2 ${getPerformanceColor(metric.predictionAccuracy)}`}>
                          {metric.predictionAccuracy}%
                        </span>
                      </div>
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ContentPerformancePredictor;