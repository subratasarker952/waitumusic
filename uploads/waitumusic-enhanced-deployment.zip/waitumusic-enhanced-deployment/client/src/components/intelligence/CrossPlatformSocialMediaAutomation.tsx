import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Share2, 
  Calendar, 
  BarChart3, 
  Settings, 
  Play, 
  Pause, 
  Clock,
  Users,
  TrendingUp,
  Zap,
  Plus,
  Edit,
  Trash2
} from 'lucide-react';

interface SocialMediaCampaign {
  id: number;
  name: string;
  platforms: string[];
  content: string;
  status: 'draft' | 'scheduled' | 'active' | 'paused' | 'completed';
  scheduledDate?: string;
  targetAudience: string;
  objectives: string[];
  metrics: {
    reach: number;
    engagement: number;
    clicks: number;
    conversions: number;
  };
  createdAt: string;
}

interface ContentTemplate {
  id: number;
  name: string;
  content: string;
  platform: string;
  category: string;
  variables: string[];
}

interface AutomationRule {
  id: number;
  name: string;
  trigger: string;
  action: string;
  platforms: string[];
  isActive: boolean;
}

const CrossPlatformSocialMediaAutomation: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [newCampaign, setNewCampaign] = useState({
    name: '',
    content: '',
    targetAudience: '',
    objectives: [] as string[]
  });

  // Fetch campaigns
  const { data: campaigns, isLoading: campaignsLoading } = useQuery({
    queryKey: ['/api/intelligence/social-media/campaigns'],
    queryFn: () => apiRequest('/api/intelligence/social-media/campaigns').then(res => res.json())
  });

  // Fetch content templates
  const { data: templates, isLoading: templatesLoading } = useQuery({
    queryKey: ['/api/intelligence/social-media/templates'],
    queryFn: () => apiRequest('/api/intelligence/social-media/templates').then(res => res.json())
  });

  // Fetch automation rules
  const { data: automationRules, isLoading: rulesLoading } = useQuery({
    queryKey: ['/api/intelligence/social-media/automation-rules'],
    queryFn: () => apiRequest('/api/intelligence/social-media/automation-rules').then(res => res.json())
  });

  // Fetch analytics
  const { data: analytics } = useQuery({
    queryKey: ['/api/intelligence/social-media/analytics'],
    queryFn: () => apiRequest('/api/intelligence/social-media/analytics').then(res => res.json())
  });

  // Create campaign mutation
  const createCampaign = useMutation({
    mutationFn: (campaignData: any) => apiRequest('/api/intelligence/social-media/campaigns', {
      method: 'POST',
      body: JSON.stringify(campaignData)
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/social-media/campaigns'] });
      toast({ title: "Campaign Created", description: "Social media campaign created successfully" });
      setNewCampaign({ name: '', content: '', targetAudience: '', objectives: [] });
      setSelectedPlatforms([]);
    }
  });

  // Update campaign status mutation
  const updateCampaignStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => 
      apiRequest(`/api/intelligence/social-media/campaigns/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/social-media/campaigns'] });
      toast({ title: "Campaign Updated", description: "Campaign status updated successfully" });
    }
  });

  // Generate content mutation
  const generateContent = useMutation({
    mutationFn: (prompt: any) => apiRequest('/api/intelligence/social-media/generate-content', {
      method: 'POST',
      body: JSON.stringify(prompt)
    }),
    onSuccess: async (response) => {
      const data = await response.json();
      setNewCampaign(prev => ({ ...prev, content: data.content }));
      toast({ title: "Content Generated", description: "AI-generated content is ready for review" });
    }
  });

  const platforms = [
    { id: 'instagram', name: 'Instagram', color: 'bg-pink-500' },
    { id: 'twitter', name: 'Twitter/X', color: 'bg-blue-500' },
    { id: 'facebook', name: 'Facebook', color: 'bg-blue-600' },
    { id: 'tiktok', name: 'TikTok', color: 'bg-black' },
    { id: 'youtube', name: 'YouTube', color: 'bg-red-500' },
    { id: 'linkedin', name: 'LinkedIn', color: 'bg-blue-700' }
  ];

  const objectives = [
    'Brand Awareness',
    'Engagement',
    'Lead Generation',
    'Sales Conversion',
    'Community Building',
    'Event Promotion',
    'Music Promotion'
  ];

  const handleCreateCampaign = () => {
    if (!newCampaign.name || !newCampaign.content || selectedPlatforms.length === 0) {
      toast({ 
        title: "Validation Error", 
        description: "Please fill in all required fields and select at least one platform",
        variant: "destructive"
      });
      return;
    }

    createCampaign.mutate({
      ...newCampaign,
      platforms: selectedPlatforms,
      status: 'draft'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'paused': return 'bg-yellow-500';
      case 'completed': return 'bg-blue-500';
      case 'scheduled': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  if (campaignsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="campaigns" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="create">Create</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
        </TabsList>

        {/* Active Campaigns Tab */}
        <TabsContent value="campaigns" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Campaigns</p>
                    <p className="text-2xl font-bold">{campaigns?.filter((c: SocialMediaCampaign) => c.status === 'active').length || 0}</p>
                  </div>
                  <Play className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Reach</p>
                    <p className="text-2xl font-bold">{analytics?.totalReach?.toLocaleString() || '0'}</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Engagement Rate</p>
                    <p className="text-2xl font-bold">{analytics?.engagementRate || '0'}%</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {campaigns?.map((campaign: SocialMediaCampaign) => (
              <Card key={campaign.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{campaign.name}</CardTitle>
                    <Badge className={`${getStatusColor(campaign.status)} text-white`}>
                      {campaign.status}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {campaign.platforms.map(platform => (
                      <Badge key={platform} variant="outline" className="text-xs">
                        {platform}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                    {campaign.content}
                  </p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-medium">Reach:</span> {campaign.metrics.reach.toLocaleString()}
                    </div>
                    <div>
                      <span className="font-medium">Engagement:</span> {campaign.metrics.engagement.toLocaleString()}
                    </div>
                    <div>
                      <span className="font-medium">Clicks:</span> {campaign.metrics.clicks.toLocaleString()}
                    </div>
                    <div>
                      <span className="font-medium">Conversions:</span> {campaign.metrics.conversions}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    {campaign.status === 'active' ? (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => updateCampaignStatus.mutate({ id: campaign.id, status: 'paused' })}
                      >
                        <Pause className="h-3 w-3 mr-1" />
                        Pause
                      </Button>
                    ) : (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => updateCampaignStatus.mutate({ id: campaign.id, status: 'active' })}
                      >
                        <Play className="h-3 w-3 mr-1" />
                        Resume
                      </Button>
                    )}
                    <Button size="sm" variant="outline">
                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Create Campaign Tab */}
        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Create New Campaign</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Campaign Name</label>
                  <Input
                    value={newCampaign.name}
                    onChange={(e) => setNewCampaign(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter campaign name"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Target Audience</label>
                  <Input
                    value={newCampaign.targetAudience}
                    onChange={(e) => setNewCampaign(prev => ({ ...prev, targetAudience: e.target.value }))}
                    placeholder="e.g., Music lovers, 18-35"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Select Platforms</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {platforms.map(platform => (
                    <div key={platform.id} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={platform.id}
                        checked={selectedPlatforms.includes(platform.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedPlatforms(prev => [...prev, platform.id]);
                          } else {
                            setSelectedPlatforms(prev => prev.filter(p => p !== platform.id));
                          }
                        }}
                        className="rounded"
                      />
                      <label htmlFor={platform.id} className="text-sm">{platform.name}</label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Campaign Objectives</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {objectives.map(objective => (
                    <div key={objective} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={objective}
                        checked={newCampaign.objectives.includes(objective)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewCampaign(prev => ({ 
                              ...prev, 
                              objectives: [...prev.objectives, objective] 
                            }));
                          } else {
                            setNewCampaign(prev => ({ 
                              ...prev, 
                              objectives: prev.objectives.filter(o => o !== objective) 
                            }));
                          }
                        }}
                        className="rounded"
                      />
                      <label htmlFor={objective} className="text-sm">{objective}</label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium">Content</label>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => generateContent.mutate({
                      platforms: selectedPlatforms,
                      objectives: newCampaign.objectives,
                      targetAudience: newCampaign.targetAudience
                    })}
                    disabled={generateContent.isPending || selectedPlatforms.length === 0}
                  >
                    <Zap className="h-3 w-3 mr-1" />
                    Generate with AI
                  </Button>
                </div>
                <Textarea
                  rows={4}
                  value={newCampaign.content}
                  onChange={(e) => setNewCampaign(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Enter your campaign content or use AI generation"
                />
              </div>

              <Button 
                onClick={handleCreateCampaign}
                disabled={createCampaign.isPending}
                className="w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Campaign
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Content Templates Tab */}
        <TabsContent value="templates" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates?.map((template: ContentTemplate) => (
              <Card key={template.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">{template.name}</CardTitle>
                    <Badge variant="outline">{template.platform}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-muted-foreground mb-2">{template.category}</p>
                  <p className="text-sm line-clamp-3">{template.content}</p>
                  <Button size="sm" variant="outline" className="w-full mt-3">
                    Use Template
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Automation Rules Tab */}
        <TabsContent value="automation" className="space-y-4">
          <div className="space-y-4">
            {automationRules?.map((rule: AutomationRule) => (
              <Card key={rule.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium">{rule.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        When <span className="font-medium">{rule.trigger}</span> → {rule.action}
                      </p>
                      <div className="flex gap-1 mt-2">
                        {rule.platforms.map(platform => (
                          <Badge key={platform} variant="outline" className="text-xs">
                            {platform}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={rule.isActive ? 'bg-green-500' : 'bg-gray-500'}>
                        {rule.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                      <Button size="sm" variant="outline">
                        <Settings className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CrossPlatformSocialMediaAutomation;