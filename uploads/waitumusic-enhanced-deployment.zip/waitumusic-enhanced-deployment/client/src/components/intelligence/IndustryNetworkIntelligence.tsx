import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Network, 
  Users, 
  Building, 
  MapPin, 
  Calendar,
  Mail,
  Phone,
  Star,
  TrendingUp,
  Search,
  Filter,
  Plus,
  MessageCircle,
  Handshake,
  Award,
  Globe
} from 'lucide-react';

interface NetworkContact {
  id: number;
  name: string;
  title: string;
  company: string;
  industry: string;
  location: string;
  email: string;
  phone?: string;
  connectionStrength: number;
  lastContact: string;
  tags: string[];
  socialProfiles: {
    linkedin?: string;
    twitter?: string;
    instagram?: string;
  };
  notes: string;
  opportunities: number;
  collaborations: number;
}

interface IndustryEvent {
  id: number;
  name: string;
  type: string;
  date: string;
  location: string;
  attendees: number;
  relevanceScore: number;
  keyPersons: string[];
  topics: string[];
  networkingPotential: 'low' | 'medium' | 'high';
  cost: number;
  currency: string;
}

interface NetworkOpportunity {
  id: number;
  title: string;
  type: string;
  contactId: number;
  contactName: string;
  company: string;
  description: string;
  potentialValue: number;
  probability: number;
  status: 'identified' | 'contacted' | 'in_progress' | 'closed_won' | 'closed_lost';
  nextAction: string;
  deadline?: string;
}

const IndustryNetworkIntelligence: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [industryFilter, setIndustryFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');

  // Fetch network contacts
  const { data: contacts, isLoading: contactsLoading } = useQuery({
    queryKey: ['/api/intelligence/network/contacts'],
    queryFn: () => apiRequest('/api/intelligence/network/contacts').then(res => res.json())
  });

  // Fetch industry events
  const { data: events, isLoading: eventsLoading } = useQuery({
    queryKey: ['/api/intelligence/network/events'],
    queryFn: () => apiRequest('/api/intelligence/network/events').then(res => res.json())
  });

  // Fetch network opportunities
  const { data: opportunities, isLoading: opportunitiesLoading } = useQuery({
    queryKey: ['/api/intelligence/network/opportunities'],
    queryFn: () => apiRequest('/api/intelligence/network/opportunities').then(res => res.json())
  });

  // Fetch analytics
  const { data: analytics } = useQuery({
    queryKey: ['/api/intelligence/network/analytics'],
    queryFn: () => apiRequest('/api/intelligence/network/analytics').then(res => res.json())
  });

  // Add contact mutation
  const addContact = useMutation({
    mutationFn: (contactData: any) => apiRequest('/api/intelligence/network/contacts', {
      method: 'POST',
      body: JSON.stringify(contactData)
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/network/contacts'] });
      toast({ title: "Contact Added", description: "New industry contact added successfully" });
    }
  });

  // Update opportunity status
  const updateOpportunity = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => 
      apiRequest(`/api/intelligence/network/opportunities/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/network/opportunities'] });
      toast({ title: "Opportunity Updated", description: "Opportunity status updated successfully" });
    }
  });

  const industries = [
    'Music Production', 'Record Labels', 'Publishing', 'Live Events', 
    'Music Technology', 'Streaming', 'Media & PR', 'Management', 'Legal'
  ];

  const locations = [
    'New York', 'Los Angeles', 'Nashville', 'Atlanta', 'Miami', 
    'London', 'Toronto', 'Austin', 'Chicago', 'Remote'
  ];

  const getConnectionStrengthColor = (strength: number) => {
    if (strength >= 80) return 'text-green-600';
    if (strength >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getConnectionStrengthLabel = (strength: number) => {
    if (strength >= 80) return 'Strong';
    if (strength >= 60) return 'Moderate';
    return 'Weak';
  };

  const getPotentialColor = (potential: string) => {
    switch (potential) {
      case 'high': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'closed_won': return 'bg-green-500';
      case 'in_progress': return 'bg-blue-500';
      case 'contacted': return 'bg-yellow-500';
      case 'closed_lost': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const filteredContacts = contacts?.filter((contact: NetworkContact) => {
    const matchesSearch = contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contact.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contact.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesIndustry = industryFilter === 'all' || contact.industry === industryFilter;
    const matchesLocation = locationFilter === 'all' || contact.location === locationFilter;
    
    return matchesSearch && matchesIndustry && matchesLocation;
  });

  if (contactsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="network" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="network">Network</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Network Contacts Tab */}
        <TabsContent value="network" className="space-y-4">
          {/* Analytics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Contacts</p>
                    <p className="text-2xl font-bold">{contacts?.length || 0}</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Strong Connections</p>
                    <p className="text-2xl font-bold">
                      {contacts?.filter((c: NetworkContact) => c.connectionStrength >= 80).length || 0}
                    </p>
                  </div>
                  <Network className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Opportunities</p>
                    <p className="text-2xl font-bold">
                      {opportunities?.filter((o: NetworkOpportunity) => 
                        ['identified', 'contacted', 'in_progress'].includes(o.status)
                      ).length || 0}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Network Value</p>
                    <p className="text-2xl font-bold">${analytics?.networkValue?.toLocaleString() || '0'}</p>
                  </div>
                  <Award className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="flex-1 min-w-[200px]">
              <Input
                placeholder="Search contacts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <Select value={industryFilter} onValueChange={setIndustryFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Industries</SelectItem>
                {industries.map(industry => (
                  <SelectItem key={industry} value={industry}>{industry}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={locationFilter} onValueChange={setLocationFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                {locations.map(location => (
                  <SelectItem key={location} value={location}>{location}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Plus className="h-4 w-4 mr-2" />
              Add Contact
            </Button>
          </div>

          {/* Contacts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredContacts?.map((contact: NetworkContact) => (
              <Card key={contact.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{contact.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">{contact.title}</p>
                      <p className="text-sm font-medium">{contact.company}</p>
                    </div>
                    <div className="text-right">
                      <div className={`text-sm font-medium ${getConnectionStrengthColor(contact.connectionStrength)}`}>
                        {getConnectionStrengthLabel(contact.connectionStrength)}
                      </div>
                      <div className="flex gap-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3 w-3 ${
                              i < Math.floor(contact.connectionStrength / 20) 
                                ? 'fill-yellow-400 text-yellow-400' 
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Building className="h-3 w-3 text-muted-foreground" />
                      <span>{contact.industry}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-3 w-3 text-muted-foreground" />
                      <span>{contact.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-3 w-3 text-muted-foreground" />
                      <span>Last contact: {new Date(contact.lastContact).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mt-3">
                    {contact.tags.slice(0, 3).map(tag => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {contact.tags.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{contact.tags.length - 3}
                      </Badge>
                    )}
                  </div>

                  <div className="flex gap-1 mt-3 pt-3 border-t">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Mail className="h-3 w-3 mr-1" />
                      Email
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <MessageCircle className="h-3 w-3 mr-1" />
                      Message
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Industry Events Tab */}
        <TabsContent value="events" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {events?.map((event: IndustryEvent) => (
              <Card key={event.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{event.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">{event.type}</p>
                    </div>
                    <Badge className={`${getPotentialColor(event.networkingPotential)} text-white`}>
                      {event.networkingPotential} potential
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-3 w-3 text-muted-foreground" />
                      <span>{new Date(event.date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-3 w-3 text-muted-foreground" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-3 w-3 text-muted-foreground" />
                      <span>{event.attendees.toLocaleString()} attendees</span>
                    </div>
                  </div>

                  <div className="mb-3">
                    <p className="text-xs font-medium text-muted-foreground mb-1">Key Topics:</p>
                    <div className="flex flex-wrap gap-1">
                      {event.topics.slice(0, 3).map(topic => (
                        <Badge key={topic} variant="outline" className="text-xs">
                          {topic}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="mb-3">
                    <p className="text-xs font-medium text-muted-foreground mb-1">Key Persons:</p>
                    <p className="text-sm">{event.keyPersons.join(', ')}</p>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t">
                    <div className="text-sm">
                      <span className="font-medium">{event.cost} {event.currency}</span>
                      <span className="text-muted-foreground"> • Score: {event.relevanceScore}/100</span>
                    </div>
                    <Button size="sm">
                      Register
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Network Opportunities Tab */}
        <TabsContent value="opportunities" className="space-y-4">
          <div className="space-y-4">
            {opportunities?.map((opportunity: NetworkOpportunity) => (
              <Card key={opportunity.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-medium text-lg">{opportunity.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        {opportunity.contactName} • {opportunity.company}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge className={`${getStatusColor(opportunity.status)} text-white mb-2`}>
                        {opportunity.status.replace('_', ' ')}
                      </Badge>
                      <div className="text-sm">
                        <div className="font-medium">${opportunity.potentialValue.toLocaleString()}</div>
                        <div className="text-muted-foreground">{opportunity.probability}% probability</div>
                      </div>
                    </div>
                  </div>

                  <p className="text-sm mb-3">{opportunity.description}</p>

                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="font-medium">Next:</span> {opportunity.nextAction}
                      {opportunity.deadline && (
                        <span className="text-muted-foreground ml-2">
                          Due: {new Date(opportunity.deadline).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => updateOpportunity.mutate({ id: opportunity.id, status: 'contacted' })}
                      >
                        Contact
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => updateOpportunity.mutate({ id: opportunity.id, status: 'in_progress' })}
                      >
                        Progress
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Network Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>This Month</span>
                    <span className="font-medium">+{analytics?.growthThisMonth || 0} contacts</span>
                  </div>
                  <div className="flex justify-between">
                    <span>This Quarter</span>
                    <span className="font-medium">+{analytics?.growthThisQuarter || 0} contacts</span>
                  </div>
                  <div className="flex justify-between">
                    <span>This Year</span>
                    <span className="font-medium">+{analytics?.growthThisYear || 0} contacts</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Industry Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {analytics?.industryDistribution?.map((item: any) => (
                    <div key={item.industry} className="flex justify-between">
                      <span>{item.industry}</span>
                      <span className="font-medium">{item.count}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default IndustryNetworkIntelligence;