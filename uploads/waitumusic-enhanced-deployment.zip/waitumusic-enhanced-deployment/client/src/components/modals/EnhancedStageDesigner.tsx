import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Music, Mic, Volume2, Guitar, Piano, 
  Square, Circle, Monitor, Lightbulb, Wrench,
  Move, RotateCcw, Save, Download, Users, Plus, Trash2
} from 'lucide-react';

interface StagePlotItem {
  id: string;
  type: 'drums' | 'bass' | 'guitar' | 'keyboard' | 'vocals' | 'monitor' | 'equipment';
  x: number;
  y: number;
  name: string;
  assignedTo: string;
  talentRole?: string;
  equipmentList?: string[];
  monitorMixRequired?: boolean;
}

interface TalentProfile {
  id: number;
  name: string;
  role: string;
  stageNames?: string[];
  equipmentOwned?: string[];
  equipmentNeeded?: string[];
  monitorPreferences?: {
    preferredMixStyle: string;
    instrumentsInMix: string[];
    effectsPreferences: string[];
  };
  technicalRequirements?: {
    instruments: string[];
    amplification: string[];
    effects: string[];
    specialRequests: string[];
  };
}

interface MonitorMix {
  id: string;
  name: string;
  assignedTo: string;
  talentRole: string;
  channels: number[];
  preferences: string[];
  position: { x: number; y: number };
}

interface EnhancedStageDesignerProps {
  isOpen: boolean;
  onClose: () => void;
  bookingId?: number;
  assignedTalent?: TalentProfile[];
  onSave?: (stagePlot: StagePlotItem[], monitorMixes: MonitorMix[]) => void;
  onLoad?: (data: any) => void;
}

const STAGE_ICONS = {
  drums: { icon: Circle, color: 'bg-red-500', label: 'Drums' },
  bass: { icon: Music, color: 'bg-blue-500', label: 'Bass' },
  guitar: { icon: Guitar, color: 'bg-green-500', label: 'Guitar' },
  keyboard: { icon: Piano, color: 'bg-purple-500', label: 'Keyboard' },
  vocals: { icon: Mic, color: 'bg-yellow-500', label: 'Vocals' },
  monitor: { icon: Monitor, color: 'bg-gray-500', label: 'Monitor' },
  equipment: { icon: Wrench, color: 'bg-orange-500', label: 'Equipment' }
};

export default function EnhancedStageDesigner({ 
  isOpen, 
  onClose, 
  bookingId, 
  assignedTalent = [], 
  onSave,
  onLoad 
}: EnhancedStageDesignerProps) {
  const { toast } = useToast();
  const [stagePlot, setStagePlot] = useState<StagePlotItem[]>([]);
  const [monitorMixes, setMonitorMixes] = useState<MonitorMix[]>([]);
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [showTalentProfiles, setShowTalentProfiles] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  // Fetch talent profiles with equipment and technical requirements
  const { data: talentProfiles } = useQuery({
    queryKey: ['/api/talent-profiles', assignedTalent.map(t => t.id)],
    queryFn: async () => {
      if (assignedTalent.length === 0) return [];
      const response = await apiRequest('/api/talent-profiles', {
        method: 'POST',
        body: JSON.stringify({ talentIds: assignedTalent.map(t => t.id) })
      });
      return await response.json();
    },
    enabled: assignedTalent.length > 0
  });

  // Initialize stage plot based on assigned talent and their equipment
  useEffect(() => {
    if (assignedTalent.length > 0 && stagePlot.length === 0) {
      initializeStagePlotFromTalent();
    }
  }, [assignedTalent, talentProfiles]);

  const initializeStagePlotFromTalent = () => {
    const newStagePlot: StagePlotItem[] = [];
    const newMonitorMixes: MonitorMix[] = [];
    let positionIndex = 0;

    assignedTalent.forEach((talent, index) => {
      const profile = talentProfiles?.find(p => p.id === talent.id);
      const instruments = profile?.technicalRequirements?.instruments || ['vocals'];
      
      instruments.forEach((instrument) => {
        const position = getPositionForInstrument(instrument, positionIndex);
        const stageItem: StagePlotItem = {
          id: `${talent.id}-${instrument}-${positionIndex}`,
          type: mapInstrumentToType(instrument),
          x: position.x,
          y: position.y,
          name: `${talent.name} - ${instrument}`,
          assignedTo: talent.name,
          talentRole: talent.role,
          equipmentList: profile?.equipmentOwned?.filter(eq => 
            eq.toLowerCase().includes(instrument.toLowerCase())
          ) || [],
          monitorMixRequired: true
        };
        newStagePlot.push(stageItem);
        positionIndex++;

        // Create monitor mix for each talent position
        if (stageItem.monitorMixRequired) {
          const monitorMix: MonitorMix = {
            id: `monitor-${talent.id}-${positionIndex}`,
            name: `${talent.name} Monitor`,
            assignedTo: talent.name,
            talentRole: talent.role,
            channels: [], // Will be populated from mixer
            preferences: profile?.monitorPreferences?.instrumentsInMix || [],
            position: { x: position.x, y: position.y + 60 }
          };
          newMonitorMixes.push(monitorMix);
        }
      });
    });

    setStagePlot(newStagePlot);
    setMonitorMixes(newMonitorMixes);
  };

  const getPositionForInstrument = (instrument: string, index: number) => {
    const basePositions = {
      drums: { x: 300, y: 200 },
      bass: { x: 200, y: 250 },
      guitar: { x: 400, y: 250 },
      keyboard: { x: 150, y: 200 },
      vocals: { x: 300, y: 300 },
      saxophone: { x: 350, y: 220 },
      trumpet: { x: 250, y: 220 },
      violin: { x: 450, y: 200 }
    };

    const position = basePositions[instrument.toLowerCase()] || { x: 300 + (index * 50), y: 250 };
    return { x: position.x + (index * 20), y: position.y + (index * 10) };
  };

  const mapInstrumentToType = (instrument: string): StagePlotItem['type'] => {
    const mapping = {
      drums: 'drums',
      bass: 'bass',
      guitar: 'guitar',
      keyboard: 'keyboard',
      vocals: 'vocals',
      piano: 'keyboard'
    };
    return mapping[instrument.toLowerCase()] || 'equipment';
  };

  const handleMouseDown = (e: React.MouseEvent, itemId: string) => {
    e.preventDefault();
    const item = stagePlot.find(i => i.id === itemId) || monitorMixes.find(m => m.id === itemId);
    if (!item) return;

    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    setDraggedItem(itemId);
    setSelectedItem(itemId);
    
    const itemX = 'x' in item ? item.x : item.position.x;
    const itemY = 'y' in item ? item.y : item.position.y;
    
    setDragOffset({
      x: e.clientX - rect.left - itemX,
      y: e.clientY - rect.top - itemY
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggedItem || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const newX = e.clientX - rect.left - dragOffset.x;
    const newY = e.clientY - rect.top - dragOffset.y;

    // Keep items within canvas bounds
    const boundedX = Math.max(20, Math.min(newX, rect.width - 40));
    const boundedY = Math.max(20, Math.min(newY, rect.height - 40));

    // Update stage plot items
    setStagePlot(prev => prev.map(item => 
      item.id === draggedItem 
        ? { ...item, x: boundedX, y: boundedY }
        : item
    ));

    // Update monitor mix positions
    setMonitorMixes(prev => prev.map(mix => 
      mix.id === draggedItem 
        ? { ...mix, position: { x: boundedX, y: boundedY } }
        : mix
    ));
  };

  const handleMouseUp = () => {
    setDraggedItem(null);
    setDragOffset({ x: 0, y: 0 });
  };

  const assignTalentToPosition = (itemId: string, talentName: string) => {
    const talent = assignedTalent.find(t => t.name === talentName);
    if (!talent) return;

    setStagePlot(prev => prev.map(item => 
      item.id === itemId 
        ? { 
            ...item, 
            assignedTo: talentName,
            talentRole: talent.role,
            equipmentList: talentProfiles?.find(p => p.id === talent.id)?.equipmentOwned || []
          }
        : item
    ));
  };

  const addNewStageItem = (type: StagePlotItem['type']) => {
    const newItem: StagePlotItem = {
      id: `item-${Date.now()}`,
      type,
      x: 300,
      y: 200,
      name: `New ${STAGE_ICONS[type].label}`,
      assignedTo: '',
      monitorMixRequired: type !== 'monitor' && type !== 'equipment'
    };
    setStagePlot(prev => [...prev, newItem]);
  };

  const removeStageItem = (itemId: string) => {
    setStagePlot(prev => prev.filter(item => item.id !== itemId));
    setMonitorMixes(prev => prev.filter(mix => mix.id !== itemId));
  };

  const generateDynamicMonitorMixes = () => {
    const newMonitorMixes: MonitorMix[] = [];
    
    stagePlot.forEach((item) => {
      if (item.monitorMixRequired && item.assignedTo) {
        const talent = assignedTalent.find(t => t.name === item.assignedTo);
        const profile = talentProfiles?.find(p => p.id === talent?.id);
        
        const monitorMix: MonitorMix = {
          id: `monitor-${item.id}`,
          name: `${item.assignedTo} Monitor`,
          assignedTo: item.assignedTo,
          talentRole: item.talentRole || '',
          channels: [], // Will be populated from mixer configuration
          preferences: profile?.monitorPreferences?.instrumentsInMix || [],
          position: { x: item.x, y: item.y + 60 }
        };
        newMonitorMixes.push(monitorMix);
      }
    });

    setMonitorMixes(newMonitorMixes);
    toast({
      title: "Monitor Mixes Generated",
      description: `Created ${newMonitorMixes.length} dynamic monitor configurations`
    });
  };

  const saveStagePlot = async () => {
    try {
      if (bookingId) {
        const response = await apiRequest(`/api/bookings/${bookingId}/stage-plot`, {
          method: 'POST',
          body: JSON.stringify({ 
            stagePlot, 
            monitorMixes,
            assignedTalent: assignedTalent.map(t => ({
              ...t,
              profile: talentProfiles?.find(p => p.id === t.id)
            }))
          })
        });
        
        if (response.ok) {
          toast({
            title: "Stage Plot Saved",
            description: "Stage plot and monitor configurations saved successfully"
          });
        }
      }
      
      if (onSave) {
        onSave(stagePlot, monitorMixes);
      }
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Failed to save stage plot configuration",
        variant: "destructive"
      });
    }
  };

  const exportStagePlot = () => {
    const exportData = {
      booking_id: bookingId,
      stage_plot: stagePlot,
      monitor_mixes: monitorMixes,
      talent_assignments: assignedTalent.map(talent => ({
        ...talent,
        profile: talentProfiles?.find(p => p.id === talent.id),
        stage_positions: stagePlot.filter(item => item.assignedTo === talent.name)
      })),
      generated_at: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `enhanced-stage-plot-booking-${bookingId}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Stage Plot Exported",
      description: "Complete stage plot and talent assignments exported"
    });
  };

  const renderStageItem = (item: StagePlotItem) => {
    const IconComponent = STAGE_ICONS[item.type].icon;
    const isSelected = selectedItem === item.id;
    const isDragging = draggedItem === item.id;
    
    return (
      <div
        key={item.id}
        className={`absolute cursor-move transition-all select-none ${
          isSelected ? 'ring-2 ring-blue-500 scale-110' : 'hover:scale-105'
        } ${isDragging ? 'z-50 opacity-90' : 'z-10'}`}
        style={{ 
          left: item.x, 
          top: item.y, 
          transform: 'translate(-50%, -50%)',
          userSelect: 'none'
        }}
        onMouseDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          handleMouseDown(e, item.id);
        }}
        onClick={(e) => {
          e.stopPropagation();
          setSelectedItem(item.id);
        }}
      >
        <div className={`w-12 h-12 rounded-full ${STAGE_ICONS[item.type].color} flex items-center justify-center text-white shadow-lg hover:shadow-xl`}>
          <IconComponent size={20} />
        </div>
        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-1 text-xs bg-black text-white px-2 py-1 rounded whitespace-nowrap pointer-events-none">
          {item.name}
          {item.assignedTo && (
            <div className="text-yellow-300">{item.assignedTo}</div>
          )}
        </div>
      </div>
    );
  };

  const renderMonitorMix = (mix: MonitorMix) => {
    const isSelected = selectedItem === mix.id;
    const isDragging = draggedItem === mix.id;
    
    return (
      <div
        key={mix.id}
        className={`absolute cursor-move transition-all select-none ${
          isSelected ? 'ring-2 ring-green-500 scale-110' : 'hover:scale-105'
        } ${isDragging ? 'z-50 opacity-90' : 'z-10'}`}
        style={{ 
          left: mix.position.x, 
          top: mix.position.y, 
          transform: 'translate(-50%, -50%)',
          userSelect: 'none'
        }}
        onMouseDown={(e) => {
          e.preventDefault();
          e.stopPropagation();
          handleMouseDown(e, mix.id);
        }}
        onClick={(e) => {
          e.stopPropagation();
          setSelectedItem(mix.id);
        }}
      >
        <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center text-white shadow-lg hover:shadow-xl">
          <Monitor size={16} />
        </div>
        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-1 text-xs bg-green-800 text-white px-2 py-1 rounded whitespace-nowrap pointer-events-none">
          {mix.name}
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Square className="h-5 w-5" />
            Enhanced Stage Plot Designer
            {bookingId && <Badge variant="outline">Booking #{bookingId}</Badge>}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Stage Canvas */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Interactive Stage Plot</CardTitle>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(STAGE_ICONS).map(([type, config]) => (
                    <Button
                      key={type}
                      size="sm"
                      variant="outline"
                      onClick={() => addNewStageItem(type as StagePlotItem['type'])}
                      className="flex items-center gap-1"
                    >
                      <config.icon size={16} />
                      Add {config.label}
                    </Button>
                  ))}
                  <Button size="sm" onClick={generateDynamicMonitorMixes} className="bg-green-600">
                    <Monitor className="w-4 h-4 mr-1" />
                    Generate Monitors
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div
                  ref={canvasRef}
                  className="relative w-full h-96 bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg overflow-hidden"
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  onMouseLeave={handleMouseUp}
                >
                  {/* Stage Outline */}
                  <div className="absolute inset-4 border-2 border-gray-400 rounded-lg bg-gray-50">
                    <div className="absolute top-2 left-1/2 transform -translate-x-1/2 text-sm font-medium text-gray-600">
                      STAGE
                    </div>
                  </div>
                  
                  {/* Audience Area */}
                  <div className="absolute bottom-4 left-4 right-4 h-16 bg-blue-50 border border-blue-200 rounded flex items-center justify-center">
                    <span className="text-blue-600 font-medium">AUDIENCE</span>
                  </div>

                  {/* Stage Items */}
                  {stagePlot.map(renderStageItem)}
                  
                  {/* Monitor Mixes */}
                  {monitorMixes.map(renderMonitorMix)}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Controls Panel */}
          <div className="space-y-4">
            {/* Assigned Talent */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Assigned Talent ({assignedTalent.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {assignedTalent.map((talent) => (
                  <div key={talent.id} className="p-2 border rounded">
                    <div className="font-medium text-sm">{talent.name}</div>
                    <div className="text-xs text-gray-500">{talent.role}</div>
                    {talent.stageNames && (
                      <div className="text-xs text-blue-600">
                        Stage: {talent.stageNames.join(', ')}
                      </div>
                    )}
                  </div>
                ))}
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => setShowTalentProfiles(!showTalentProfiles)}
                  className="w-full"
                >
                  {showTalentProfiles ? 'Hide' : 'Show'} Equipment Profiles
                </Button>
              </CardContent>
            </Card>

            {/* Selected Item Details */}
            {selectedItem && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Item Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {(() => {
                    const item = stagePlot.find(i => i.id === selectedItem);
                    const mix = monitorMixes.find(m => m.id === selectedItem);
                    const currentItem = item || mix;
                    
                    if (!currentItem) return null;
                    
                    return (
                      <>
                        <div>
                          <Label className="text-xs">Name</Label>
                          <Input
                            value={'name' in currentItem ? currentItem.name : currentItem.name}
                            onChange={(e) => {
                              if (item) {
                                setStagePlot(prev => prev.map(i => 
                                  i.id === selectedItem ? { ...i, name: e.target.value } : i
                                ));
                              } else if (mix) {
                                setMonitorMixes(prev => prev.map(m => 
                                  m.id === selectedItem ? { ...m, name: e.target.value } : m
                                ));
                              }
                            }}
                            className="h-8"
                          />
                        </div>
                        
                        <div>
                          <Label className="text-xs">Assign Talent</Label>
                          <Select
                            value={'assignedTo' in currentItem ? currentItem.assignedTo : ''}
                            onValueChange={(value) => assignTalentToPosition(selectedItem, value)}
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue placeholder="Select talent" />
                            </SelectTrigger>
                            <SelectContent>
                              {assignedTalent.map((talent) => (
                                <SelectItem key={talent.id} value={talent.name}>
                                  {talent.name} ({talent.role})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        {item && item.equipmentList && item.equipmentList.length > 0 && (
                          <div>
                            <Label className="text-xs">Equipment from Profile</Label>
                            <div className="space-y-1">
                              {item.equipmentList.map((equipment, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">
                                  {equipment}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => removeStageItem(selectedItem)}
                          className="w-full"
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Remove Item
                        </Button>
                      </>
                    );
                  })()}
                </CardContent>
              </Card>
            )}

            {/* Monitor Mix Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Monitor Mixes ({monitorMixes.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {monitorMixes.map((mix) => (
                    <div key={mix.id} className="p-2 border rounded text-xs">
                      <div className="font-medium">{mix.name}</div>
                      <div className="text-gray-500">{mix.assignedTo} ({mix.talentRole})</div>
                      {mix.preferences.length > 0 && (
                        <div className="text-blue-600">
                          Prefers: {mix.preferences.join(', ')}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button onClick={saveStagePlot} className="w-full" size="sm">
                  <Save className="w-4 h-4 mr-1" />
                  Save Stage Plot
                </Button>
                <Button onClick={exportStagePlot} variant="outline" className="w-full" size="sm">
                  <Download className="w-4 h-4 mr-1" />
                  Export Configuration
                </Button>
                <Button 
                  onClick={() => setStagePlot([])} 
                  variant="outline" 
                  className="w-full" 
                  size="sm"
                >
                  <RotateCcw className="w-4 h-4 mr-1" />
                  Reset Plot
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Talent Equipment Profiles */}
        {showTalentProfiles && (
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-lg">Talent Equipment Profiles</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {talentProfiles?.map((profile) => (
                  <Card key={profile.id}>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">{profile.name}</CardTitle>
                      <Badge variant="outline" className="w-fit">{profile.role}</Badge>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {profile.equipmentOwned && profile.equipmentOwned.length > 0 && (
                        <div>
                          <Label className="text-xs font-medium">Equipment Owned</Label>
                          <div className="flex flex-wrap gap-1">
                            {profile.equipmentOwned.map((item, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {item}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {profile.equipmentNeeded && profile.equipmentNeeded.length > 0 && (
                        <div>
                          <Label className="text-xs font-medium">Equipment Needed</Label>
                          <div className="flex flex-wrap gap-1">
                            {profile.equipmentNeeded.map((item, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs text-red-600">
                                {item}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {profile.technicalRequirements && (
                        <div>
                          <Label className="text-xs font-medium">Instruments</Label>
                          <div className="flex flex-wrap gap-1">
                            {profile.technicalRequirements.instruments?.map((inst, idx) => (
                              <Badge key={idx} variant="default" className="text-xs">
                                {inst}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </DialogContent>
    </Dialog>
  );
}