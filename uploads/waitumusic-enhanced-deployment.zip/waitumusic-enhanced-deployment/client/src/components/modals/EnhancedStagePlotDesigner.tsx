import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Save, Download, Upload, RotateCcw, RotateCw, Trash2, Grid3X3, Music, Users, Move } from 'lucide-react';

interface MovableStageItem {
  id: string;
  type: 'instrument' | 'equipment' | 'performer';
  name: string;
  displayName?: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  color: string;
  icon: string;
  assignedTo?: string;
  talentRole?: string;
  equipmentList?: string[];
  isDragging?: boolean;
}

interface AssignedTalent {
  id: number;
  name: string;
  role: string;
  instruments?: string[];
  specialization?: string;
}

interface EnhancedStagePlotDesignerProps {
  isOpen: boolean;
  onClose: () => void;
  bookingId?: number;
  assignedTalent?: AssignedTalent[];
  onSave?: (data: any) => void;
}

const STAGE_ITEMS = {
  instruments: [
    { name: 'Grand Piano', width: 120, height: 80, color: '#8B4513', icon: '🎹', equipmentList: ['Grand Piano', 'Piano Bench'] },
    { name: 'Drum Kit', width: 100, height: 100, color: '#2C5F2D', icon: '🥁', equipmentList: ['Kick Drum', 'Snare', 'Hi-Hat', 'Toms', 'Cymbals'] },
    { name: 'Bass Amp', width: 40, height: 60, color: '#1E40AF', icon: '🔊', equipmentList: ['Bass Amplifier Head', 'Bass Cabinet'] },
    { name: 'Guitar Amp', width: 35, height: 55, color: '#DC2626', icon: '🔊', equipmentList: ['Guitar Amplifier', 'Effects Pedals'] },
    { name: 'Keyboard Setup', width: 50, height: 30, color: '#6B7280', icon: '🎹', equipmentList: ['Keyboard', 'Stand', 'Sustain Pedal'] },
    { name: 'Mic Stand', width: 15, height: 15, color: '#374151', icon: '🎤', equipmentList: ['Microphone', 'Mic Stand', 'Pop Filter'] }
  ],
  equipment: [
    { name: 'Monitor Speaker', width: 30, height: 25, color: '#111827', icon: '🔊', equipmentList: ['Floor Monitor', 'Monitor Cable'] },
    { name: 'Main Speaker', width: 40, height: 60, color: '#111827', icon: '🔊', equipmentList: ['PA Speaker', 'Speaker Stand'] },
    { name: 'Lighting Rig', width: 60, height: 40, color: '#FCD34D', icon: '💡', equipmentList: ['LED Lights', 'Light Stand', 'DMX Controller'] },
    { name: 'Camera Position', width: 25, height: 25, color: '#9CA3AF', icon: '📹', equipmentList: ['Camera', 'Tripod', 'Memory Card'] }
  ],
  performers: [
    { name: 'Lead Vocalist', width: 30, height: 30, color: '#DC2626', icon: '👤', equipmentList: ['Vocal Mic', 'Mic Stand'] },
    { name: 'Guitarist', width: 30, height: 30, color: '#059669', icon: '👤', equipmentList: ['Guitar', 'Guitar Cable', 'Picks'] },
    { name: 'Bassist', width: 30, height: 30, color: '#1E40AF', icon: '👤', equipmentList: ['Bass Guitar', 'Bass Cable'] },
    { name: 'Drummer', width: 30, height: 30, color: '#7C2D12', icon: '👤', equipmentList: ['Drum Sticks', 'Kick Pedal'] },
    { name: 'Keyboardist', width: 30, height: 30, color: '#7C3AED', icon: '👤', equipmentList: ['Keyboard', 'Sustain Pedal'] }
  ]
};

export default function EnhancedStagePlotDesigner({
  isOpen,
  onClose,
  bookingId,
  assignedTalent = [],
  onSave
}: EnhancedStagePlotDesignerProps) {
  const { toast } = useToast();
  const canvasRef = useRef<HTMLDivElement>(null);
  const [stageItems, setStageItems] = useState<MovableStageItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<MovableStageItem | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [stageWidth, setStageWidth] = useState(600);
  const [stageHeight, setStageHeight] = useState(400);
  const [gridSnap, setGridSnap] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [talentInstruments, setTalentInstruments] = useState<{[key: string]: string[]}>({});

  // Load talent instrument profiles when component opens
  useEffect(() => {
    if (isOpen && assignedTalent.length > 0) {
      loadTalentInstruments();
    }
  }, [isOpen, assignedTalent]);

  const loadTalentInstruments = async () => {
    const instrumentMap: {[key: string]: string[]} = {};
    
    for (const talent of assignedTalent) {
      try {
        const response = await fetch(`/api/talent/${talent.id}/instruments`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        if (response.ok) {
          const instruments = await response.json();
          instrumentMap[talent.name] = instruments.length > 0 ? instruments : talent.instruments || [];
        } else {
          // Fallback to provided instruments array
          instrumentMap[talent.name] = talent.instruments || [];
        }
      } catch (error) {
        // Use fallback instruments
        instrumentMap[talent.name] = talent.instruments || [];
      }
    }
    
    setTalentInstruments(instrumentMap);
  };

  const snapToGrid = useCallback((value: number) => {
    if (!gridSnap) return value;
    const gridSize = 10;
    return Math.round(value / gridSize) * gridSize;
  }, [gridSnap]);

  const addStageItem = (itemType: keyof typeof STAGE_ITEMS, itemName: string) => {
    const itemTemplate = STAGE_ITEMS[itemType].find(item => item.name === itemName);
    if (!itemTemplate) return;

    const newItem: MovableStageItem = {
      id: `${itemType}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: itemType === 'performers' ? 'performer' : itemType === 'instruments' ? 'instrument' : 'equipment',
      name: itemTemplate.name,
      displayName: itemTemplate.name,
      x: snapToGrid(50),
      y: snapToGrid(50),
      width: itemTemplate.width,
      height: itemTemplate.height,
      rotation: 0,
      color: itemTemplate.color,
      icon: itemTemplate.icon,
      equipmentList: itemTemplate.equipmentList || [],
      assignedTo: '',
      talentRole: ''
    };

    setStageItems(prev => [...prev, newItem]);
    setSelectedItem(newItem);
    
    toast({
      title: "Item Added",
      description: `${itemTemplate.name} added to stage plot`
    });
  };

  const handleMouseDown = useCallback((e: React.MouseEvent, item: MovableStageItem) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const offsetX = e.clientX - rect.left - item.x;
    const offsetY = e.clientY - rect.top - item.y;
    
    setSelectedItem(item);
    setDragOffset({ x: offsetX, y: offsetY });
    
    // Mark item as dragging
    setStageItems(prev => prev.map(stageItem => 
      stageItem.id === item.id 
        ? { ...stageItem, isDragging: true }
        : { ...stageItem, isDragging: false }
    ));
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!selectedItem?.isDragging || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const newX = snapToGrid(e.clientX - rect.left - dragOffset.x);
    const newY = snapToGrid(e.clientY - rect.top - dragOffset.y);
    
    // Boundary checking
    const boundedX = Math.max(0, Math.min(newX, stageWidth - selectedItem.width));
    const boundedY = Math.max(0, Math.min(newY, stageHeight - selectedItem.height));
    
    setStageItems(prev => prev.map(item => 
      item.id === selectedItem.id 
        ? { ...item, x: boundedX, y: boundedY }
        : item
    ));
  }, [selectedItem, dragOffset, snapToGrid, stageWidth, stageHeight]);

  const handleMouseUp = useCallback(() => {
    setStageItems(prev => prev.map(item => ({ ...item, isDragging: false })));
  }, []);

  const deleteItem = (itemId: string) => {
    setStageItems(prev => prev.filter(item => item.id !== itemId));
    if (selectedItem?.id === itemId) {
      setSelectedItem(null);
    }
    toast({
      title: "Item Removed",
      description: "Stage item has been removed from the plot"
    });
  };

  const rotateItem = (itemId: string, direction: 'left' | 'right') => {
    const rotationDelta = direction === 'left' ? -15 : 15;
    setStageItems(prev => prev.map(item => 
      item.id === itemId 
        ? { ...item, rotation: (item.rotation + rotationDelta) % 360 }
        : item
    ));
  };

  const assignTalentToItem = (itemId: string, talentName: string, talentRole: string) => {
    setStageItems(prev => prev.map(item => 
      item.id === itemId 
        ? { ...item, assignedTo: talentName, talentRole }
        : item
    ));
    toast({
      title: "Talent Assigned",
      description: `${talentName} assigned to stage position`
    });
  };

  // Auto-assign instruments based on talent profiles
  const autoAssignInstruments = () => {
    if (Object.keys(talentInstruments).length === 0) {
      toast({
        title: "No Instrument Data",
        description: "Load talent profiles first for auto-assignment",
        variant: "destructive"
      });
      return;
    }

    const updatedItems = [...stageItems];
    let assignmentCount = 0;

    assignedTalent.forEach(talent => {
      const instruments = talentInstruments[talent.name] || [];
      
      instruments.forEach(instrument => {
        // Find matching stage items for this instrument
        const matchingItems = updatedItems.filter(item => 
          !item.assignedTo && 
          (item.name.toLowerCase().includes(instrument.toLowerCase()) ||
           instrument.toLowerCase().includes(item.name.toLowerCase().split(' ')[0]))
        );

        if (matchingItems.length > 0) {
          const itemToAssign = matchingItems[0];
          itemToAssign.assignedTo = talent.name;
          itemToAssign.talentRole = talent.role;
          assignmentCount++;
        }
      });
    });

    setStageItems(updatedItems);
    
    toast({
      title: "Auto-Assignment Complete",
      description: `${assignmentCount} items assigned based on talent instruments`
    });
  };

  // Add instrument based on talent profile
  const addTalentInstrument = (talentName: string, instrument: string) => {
    // Find appropriate stage item for this instrument
    let itemTemplate = null;
    let itemCategory: keyof typeof STAGE_ITEMS = 'instruments';

    // Search through all categories for matching instrument
    for (const [category, items] of Object.entries(STAGE_ITEMS)) {
      const found = items.find(item => 
        item.name.toLowerCase().includes(instrument.toLowerCase()) ||
        instrument.toLowerCase().includes(item.name.toLowerCase().split(' ')[0])
      );
      if (found) {
        itemTemplate = found;
        itemCategory = category as keyof typeof STAGE_ITEMS;
        break;
      }
    }

    // Default to a generic instrument if no match found
    if (!itemTemplate) {
      itemTemplate = {
        name: instrument,
        width: 40,
        height: 40,
        color: '#6B7280',
        icon: '🎵',
        equipmentList: [instrument]
      };
    }

    const newItem: MovableStageItem = {
      id: `talent-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'instrument',
      name: itemTemplate.name,
      displayName: `${instrument} (${talentName})`,
      x: snapToGrid(100 + stageItems.length * 60),
      y: snapToGrid(100),
      width: itemTemplate.width,
      height: itemTemplate.height,
      rotation: 0,
      color: itemTemplate.color,
      icon: itemTemplate.icon,
      equipmentList: itemTemplate.equipmentList || [instrument],
      assignedTo: talentName,
      talentRole: assignedTalent.find(t => t.name === talentName)?.role || 'performer'
    };

    setStageItems(prev => [...prev, newItem]);
    
    toast({
      title: "Instrument Added",
      description: `${instrument} added and assigned to ${talentName}`
    });
  };

  const saveStagePlot = () => {
    const stagePlotData = {
      stageWidth,
      stageHeight,
      items: stageItems,
      bookingId,
      createdAt: new Date().toISOString()
    };
    
    onSave?.(stagePlotData);
    toast({
      title: "Stage Plot Saved",
      description: "Enhanced stage plot configuration saved successfully"
    });
  };

  const clearStage = () => {
    setStageItems([]);
    setSelectedItem(null);
    toast({
      title: "Stage Cleared",
      description: "All items removed from stage plot"
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Move className="h-5 w-5" />
            Enhanced Stage Plot Designer - Movable Icons
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Stage Canvas */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <CardTitle className="text-lg">Stage Canvas</CardTitle>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowGrid(!showGrid)}
                    >
                      <Grid3X3 className="h-4 w-4 mr-1" />
                      {showGrid ? 'Hide' : 'Show'} Grid
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setGridSnap(!gridSnap)}
                    >
                      Grid Snap: {gridSnap ? 'On' : 'Off'}
                    </Button>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="stage-width">Width:</Label>
                    <Input
                      id="stage-width"
                      type="number"
                      value={stageWidth}
                      onChange={(e) => setStageWidth(Number(e.target.value))}
                      className="w-20 h-8"
                      min="300"
                      max="1200"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Label htmlFor="stage-height">Height:</Label>
                    <Input
                      id="stage-height"
                      type="number"
                      value={stageHeight}
                      onChange={(e) => setStageHeight(Number(e.target.value))}
                      className="w-20 h-8"
                      min="200"
                      max="800"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div 
                  ref={canvasRef}
                  className="relative border-2 border-dashed border-gray-300 bg-gray-50 dark:bg-gray-900 overflow-hidden cursor-crosshair"
                  style={{ 
                    width: stageWidth, 
                    height: stageHeight,
                    backgroundImage: showGrid ? `
                      linear-gradient(to right, #ccc 1px, transparent 1px),
                      linear-gradient(to bottom, #ccc 1px, transparent 1px)
                    ` : 'none',
                    backgroundSize: '10px 10px'
                  }}
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  onMouseLeave={handleMouseUp}
                >
                  {/* Render stage items */}
                  {stageItems.map((item) => (
                    <div
                      key={item.id}
                      className={`absolute cursor-move select-none ${
                        selectedItem?.id === item.id ? 'ring-2 ring-blue-500' : ''
                      } ${item.isDragging ? 'z-50' : 'z-10'}`}
                      style={{
                        left: item.x,
                        top: item.y,
                        width: item.width,
                        height: item.height,
                        backgroundColor: item.color,
                        transform: `rotate(${item.rotation}deg)`,
                        borderRadius: '4px',
                        opacity: item.isDragging ? 0.8 : 1
                      }}
                      onMouseDown={(e) => handleMouseDown(e, item)}
                      onClick={() => setSelectedItem(item)}
                    >
                      <div className="flex flex-col items-center justify-center h-full text-white text-xs font-medium">
                        <span className="text-lg">{item.icon}</span>
                        <span className="text-center leading-tight px-1">
                          {item.displayName}
                        </span>
                        {item.assignedTo && (
                          <span className="text-xs bg-black bg-opacity-50 px-1 rounded">
                            {item.assignedTo}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  {/* Canvas info overlay */}
                  <div className="absolute bottom-2 left-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                    {stageItems.length} items • {stageWidth}×{stageHeight}px
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Control Panel */}
          <div className="space-y-6">
            {/* Add Items */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Add Items</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="instruments" className="space-y-4">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="instruments">🎼</TabsTrigger>
                    <TabsTrigger value="equipment">🎚️</TabsTrigger>
                    <TabsTrigger value="performers">👥</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="instruments" className="space-y-2">
                    {STAGE_ITEMS.instruments.map((item) => (
                      <Button
                        key={item.name}
                        variant="outline"
                        size="sm"
                        className="w-full justify-start h-auto py-2"
                        onClick={() => addStageItem('instruments', item.name)}
                      >
                        <span className="text-lg mr-2">{item.icon}</span>
                        <span className="text-xs">{item.name}</span>
                      </Button>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="equipment" className="space-y-2">
                    {STAGE_ITEMS.equipment.map((item) => (
                      <Button
                        key={item.name}
                        variant="outline"
                        size="sm"
                        className="w-full justify-start h-auto py-2"
                        onClick={() => addStageItem('equipment', item.name)}
                      >
                        <span className="text-lg mr-2">{item.icon}</span>
                        <span className="text-xs">{item.name}</span>
                      </Button>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="performers" className="space-y-2">
                    {STAGE_ITEMS.performers.map((item) => (
                      <Button
                        key={item.name}
                        variant="outline"
                        size="sm"
                        className="w-full justify-start h-auto py-2"
                        onClick={() => addStageItem('performers', item.name)}
                      >
                        <span className="text-lg mr-2">{item.icon}</span>
                        <span className="text-xs">{item.name}</span>
                      </Button>
                    ))}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Talent Instruments & Auto-Assignment */}
            {assignedTalent.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Talent Instruments
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button
                    onClick={autoAssignInstruments}
                    className="w-full"
                    variant="default"
                    disabled={stageItems.length === 0}
                  >
                    <Music className="h-4 w-4 mr-2" />
                    Auto-Assign Instruments
                  </Button>
                  
                  <div className="space-y-3">
                    {assignedTalent.map((talent) => (
                      <div key={talent.id} className="border rounded p-3 space-y-2">
                        <div className="font-medium text-sm">{talent.name}</div>
                        <Badge variant="secondary" className="text-xs">
                          {talent.role}
                        </Badge>
                        
                        {talentInstruments[talent.name] && talentInstruments[talent.name].length > 0 ? (
                          <div className="space-y-1">
                            <div className="text-xs text-muted-foreground">Instruments:</div>
                            <div className="flex flex-wrap gap-1">
                              {talentInstruments[talent.name].map((instrument, idx) => (
                                <Button
                                  key={idx}
                                  variant="outline"
                                  size="sm"
                                  className="h-6 px-2 text-xs"
                                  onClick={() => addTalentInstrument(talent.name, instrument)}
                                >
                                  + {instrument}
                                </Button>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <div className="text-xs text-muted-foreground">
                            No instruments loaded from profile
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Selected Item Controls */}
            {selectedItem && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Item Controls</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="item-name">Display Name</Label>
                    <Input
                      id="item-name"
                      value={selectedItem.displayName || ''}
                      onChange={(e) => {
                        const newName = e.target.value;
                        setStageItems(prev => prev.map(item => 
                          item.id === selectedItem.id 
                            ? { ...item, displayName: newName }
                            : item
                        ));
                        setSelectedItem({ ...selectedItem, displayName: newName });
                      }}
                      className="h-8"
                    />
                  </div>

                  {assignedTalent.length > 0 && (
                    <div>
                      <Label>Assign Talent</Label>
                      <Select
                        value={selectedItem.assignedTo}
                        onValueChange={(value) => {
                          const talent = assignedTalent.find(t => t.name === value);
                          if (talent) {
                            assignTalentToItem(selectedItem.id, talent.name, talent.role);
                            setSelectedItem({ ...selectedItem, assignedTo: talent.name, talentRole: talent.role });
                          }
                        }}
                      >
                        <SelectTrigger className="h-8">
                          <SelectValue placeholder="Select talent" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">No Assignment</SelectItem>
                          {assignedTalent.map((talent) => (
                            <SelectItem key={talent.id} value={talent.name}>
                              {talent.name} ({talent.role})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => rotateItem(selectedItem.id, 'left')}
                      className="flex-1"
                    >
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => rotateItem(selectedItem.id, 'right')}
                      className="flex-1"
                    >
                      <RotateCw className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteItem(selectedItem.id)}
                      className="flex-1"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  {selectedItem.equipmentList && selectedItem.equipmentList.length > 0 && (
                    <div>
                      <Label>Equipment List</Label>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedItem.equipmentList.map((equipment, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {equipment}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Actions */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button onClick={saveStagePlot} className="w-full" size="sm">
                  <Save className="h-4 w-4 mr-2" />
                  Save Stage Plot
                </Button>
                <Button variant="outline" onClick={clearStage} className="w-full" size="sm">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear Stage
                </Button>
                <Button variant="secondary" onClick={onClose} className="w-full" size="sm">
                  Close Designer
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}