import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Edit, Save, X, FileText } from 'lucide-react';

interface ProfileEditModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userType?: 'artist' | 'musician' | 'professional' | 'fan';
  userSpecializations?: string[];
}

export default function ProfileEditModal({ open, onOpenChange, userType = 'artist', userSpecializations = [] }: ProfileEditModalProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  
  // PRO registration eligibility: Artists, Musicians, and Music-related Professionals
  const musicProfessionalTypes = [
    'background_vocalist', 'producer', 'arranger', 'composer', 'songwriter', 
    'dj', 'music_director', 'sound_engineer', 'mixing_engineer', 'mastering_engineer',
    'music_producer', 'beat_maker', 'orchestrator', 'lyricist', 'jingle_writer'
  ];
  const isPROEligible = userType === 'artist' || userType === 'musician' || 
    (userType === 'professional' && userSpecializations.some(spec => 
      musicProfessionalTypes.includes(spec.toLowerCase().replace(/\s+/g, '_'))
    ));
  const [formData, setFormData] = useState({
    fullName: user?.fullName || '',
    bio: '',
    stageName: userType === 'artist' ? '' : '',
    genre: userType === 'artist' ? '' : '',
    instruments: userType === 'musician' ? '' : '',
    services: userType === 'professional' ? '' : '',
    websiteUrl: '',
    phoneNumber: '',
    // PRO Registration fields
    isRegisteredWithPRO: false,
    performingRightsOrganization: '',
    ipiNumber: '',
    socialLinks: {
      instagram: '',
      twitter: '',
      youtube: '',
      spotify: ''
    }
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSocialLinkChange = (platform: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      socialLinks: {
        ...prev.socialLinks,
        [platform]: value
      }
    }));
  };

  const handleSave = async () => {
    try {
      // Here you would make an API call to update the profile
      toast({
        title: "Profile Updated",
        description: "Your profile has been successfully updated.",
      });
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Edit className="h-5 w-5" />
            Edit Profile
          </DialogTitle>
          <DialogDescription>
            Update your {userType} profile information and settings.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Basic Information</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>

              {userType === 'artist' && (
                <div className="space-y-2">
                  <Label htmlFor="stageName">Stage Name</Label>
                  <Input
                    id="stageName"
                    value={formData.stageName}
                    onChange={(e) => handleInputChange('stageName', e.target.value)}
                    placeholder="Your stage/artist name"
                  />
                </div>
              )}

              {userType === 'artist' && (
                <div className="space-y-2">
                  <Label htmlFor="genre">Genre</Label>
                  <Input
                    id="genre"
                    value={formData.genre}
                    onChange={(e) => handleInputChange('genre', e.target.value)}
                    placeholder="e.g., Pop, Rock, Jazz"
                  />
                </div>
              )}

              {userType === 'musician' && (
                <div className="space-y-2">
                  <Label htmlFor="instruments">Instruments</Label>
                  <Input
                    id="instruments"
                    value={formData.instruments}
                    onChange={(e) => handleInputChange('instruments', e.target.value)}
                    placeholder="e.g., Guitar, Piano, Drums"
                  />
                </div>
              )}

              {userType === 'professional' && (
                <div className="space-y-2">
                  <Label htmlFor="services">Specialization</Label>
                  <Input
                    id="services"
                    value={formData.services}
                    onChange={(e) => handleInputChange('services', e.target.value)}
                    placeholder="e.g., Music Production, Consulting"
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="phoneNumber">Phone Number</Label>
                <Input
                  id="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={(e) => handleInputChange('phoneNumber', e.target.value)}
                  placeholder="Your phone number"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="websiteUrl">Website URL</Label>
                <Input
                  id="websiteUrl"
                  value={formData.websiteUrl}
                  onChange={(e) => handleInputChange('websiteUrl', e.target.value)}
                  placeholder="https://your-website.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={formData.bio}
                onChange={(e) => handleInputChange('bio', e.target.value)}
                placeholder="Tell us about yourself..."
                rows={4}
              />
            </div>
          </div>

          {/* Social Media Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Social Media</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="instagram">Instagram</Label>
                <Input
                  id="instagram"
                  value={formData.socialLinks.instagram}
                  onChange={(e) => handleSocialLinkChange('instagram', e.target.value)}
                  placeholder="@your_instagram"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="twitter">Twitter</Label>
                <Input
                  id="twitter"
                  value={formData.socialLinks.twitter}
                  onChange={(e) => handleSocialLinkChange('twitter', e.target.value)}
                  placeholder="@your_twitter"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="youtube">YouTube</Label>
                <Input
                  id="youtube"
                  value={formData.socialLinks.youtube}
                  onChange={(e) => handleSocialLinkChange('youtube', e.target.value)}
                  placeholder="YouTube channel URL"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="spotify">Spotify</Label>
                <Input
                  id="spotify"
                  value={formData.socialLinks.spotify}
                  onChange={(e) => handleSocialLinkChange('spotify', e.target.value)}
                  placeholder="Spotify artist URL"
                />
              </div>
            </div>
          </div>

          {/* PRO Registration Section - Only for eligible users */}
          {isPROEligible && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Performance Rights Organization (PRO)
              </h3>
              <p className="text-sm text-muted-foreground">
                Register with a PRO to collect royalties for your musical works and performances. 
                PROs are open to creators worldwide.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="pro-registered"
                    checked={formData.isRegisteredWithPRO}
                    onCheckedChange={(checked) => handleInputChange('isRegisteredWithPRO', checked)}
                  />
                  <Label htmlFor="pro-registered">I am registered with a PRO</Label>
                </div>

                {formData.isRegisteredWithPRO && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-6">
                    <div className="space-y-2">
                      <Label htmlFor="pro-org">PRO Organization</Label>
                      <Select
                        value={formData.performingRightsOrganization}
                        onValueChange={(value) => handleInputChange('performingRightsOrganization', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select PRO" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ascap">ASCAP (USA)</SelectItem>
                          <SelectItem value="bmi">BMI (USA)</SelectItem>
                          <SelectItem value="sesac">SESAC (USA)</SelectItem>
                          <SelectItem value="socan">SOCAN (Canada)</SelectItem>
                          <SelectItem value="prs">PRS for Music (UK)</SelectItem>
                          <SelectItem value="gema">GEMA (Germany)</SelectItem>
                          <SelectItem value="sacem">SACEM (France)</SelectItem>
                          <SelectItem value="siae">SIAE (Italy)</SelectItem>
                          <SelectItem value="sgae">SGAE (Spain)</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="ipi-number">IPI Number (Optional)</Label>
                      <Input
                        id="ipi-number"
                        value={formData.ipiNumber}
                        onChange={(e) => handleInputChange('ipiNumber', e.target.value)}
                        placeholder="e.g., 00123456789"
                      />
                      <p className="text-xs text-muted-foreground">
                        International Publisher Identifier (if you have one)
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            <X className="h-4 w-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleSave}>
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}