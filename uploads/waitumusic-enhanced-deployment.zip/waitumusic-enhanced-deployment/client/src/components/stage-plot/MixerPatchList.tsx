import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Plus, Trash2, Save, Upload, Volume2, Music4, Eraser } from 'lucide-react';

interface MixerPatchRow {
  id: string;
  channel: number;
  instrument: string;
  microphone: string;
  diBox: boolean;
  position: string;
  notes: string;
  assignedMusician?: string;
  isActive: boolean;
}

interface MixerPatchList {
  id?: string;
  name: string;
  rows: MixerPatchRow[];
  bookingId?: number;
  createdAt?: string;
  modifiedAt?: string;
}

// Industry-standard equipment lists
const INSTRUMENTS = [
  // Most common first
  'Lead Vocals', 'Background Vocals', 'Acoustic Guitar', 'Electric Guitar', 'Bass Guitar',
  'Drum Kit - Kick', 'Drum Kit - Snare', 'Drum Kit - Hi-Hat', 'Drum Kit - Tom 1', 'Drum Kit - Tom 2',
  'Drum Kit - Floor Tom', 'Drum Kit - Overhead L', 'Drum Kit - Overhead R', 'Piano/Keyboard',
  'Electric Piano', 'Synthesizer', 'Organ', 'Saxophone', 'Trumpet', 'Trombone',
  // Extended instruments
  'Violin', 'Cello', 'Double Bass', 'Flute', 'Clarinet', 'Oboe', 'Bassoon', 'French Horn',
  'Tuba', 'Harmonica', 'Accordion', 'Mandolin', 'Banjo', 'Ukulele', 'Steel Guitar',
  'Lap Steel', 'Pedal Steel', 'Dobro', 'Resonator Guitar', 'Classical Guitar',
  'Percussions - Congas', 'Percussions - Bongos', 'Percussions - Timbales', 'Percussions - Cowbell',
  'Percussions - Shaker', 'Percussions - Tambourine', 'Percussions - Cajon', 'Djembe',
  'Tabla', 'Steel Drums', 'Xylophone', 'Marimba', 'Vibraphone', 'Timpani',
  'Harp', 'Bagpipes', 'Didgeridoo', 'Kalimba', 'Hang Drum', 'Theremin',
  'Talk Box', 'Vocoder', 'Sampler', 'Drum Machine', 'Loop Station', 'Click Track',
  'Playback Track', 'Monitor Send', 'Auxiliary Input', 'Spare Channel', 'None'
];

const MICROPHONES = [
  // Most common first
  'SM58', 'SM57', 'Beta 58A', 'Beta 57A', 'SM7B', 'RE20', 'MD421',
  'AKG D112', 'Sennheiser e609', 'Shure Beta 52A', 'Audio-Technica AT2020',
  'Neumann U87', 'AKG C414', 'Rode NTK', 'Electro-Voice RE16',
  // Extended mics
  'AKG C451', 'Shure KSM32', 'Audio-Technica AT4040', 'Neumann TLM103',
  'Coles 4038', 'RCA 44', 'AKG C12', 'Sony C-37A', 'Neumann U47',
  'AKG C28', 'Schoeps CMC6', 'DPA 4006', 'Earthworks QTC40',
  'Josephson C42', 'Royer R-121', 'AEA R84', 'Coles 4040',
  'Oktava MK-012', 'CAD E100S', 'Peluso P-87', 'Warm Audio WA-87',
  'Golden Age Project R1', 'sE Electronics sE2200a', 'Aston Origin',
  'Lauten Audio LA-220', 'Mojave Audio MA-50', 'Bock Audio 151',
  'Cloud Microphones JRS-34', 'Lewitt LCT 640 TS', 'Austrian Audio OC18',
  'DI Box', 'Wireless Pack', 'Headset Mic', 'Lavalier Mic', 'Shotgun Mic',
  'Boundary Mic', 'Instrument Mic', 'Contact Mic', 'None'
];

const POSITIONS = [
  'Center Stage', 'Stage Left', 'Stage Right', 'Upstage Center', 'Upstage Left', 'Upstage Right',
  'Downstage Center', 'Downstage Left', 'Downstage Right', 'Drum Riser', 'Piano Position',
  'Bass Position', 'Guitar Position', 'Keyboard Position', 'Vocal Position', 'Horn Section',
  'String Section', 'Percussion Section', 'Monitor Position', 'FOH', 'Side Fill',
  'Fly Gallery', 'Orchestra Pit', 'Balcony', 'Booth', 'Mobile', 'Offstage', 'Custom'
];

interface MixerPatchListProps {
  bookingId?: number;
  assignedMusicians?: Array<{ id: number; name: string; instruments?: string[] }>;
  onSave?: (patchList: MixerPatchList) => void;
  onLoad?: (patchList: MixerPatchList) => void;
  initialPatchList?: MixerPatchList;
  userRole?: string;
  canEdit?: boolean;
}

export default function MixerPatchList({
  bookingId,
  assignedMusicians = [],
  onSave,
  onLoad,
  initialPatchList,
  userRole = 'fan',
  canEdit = true
}: MixerPatchListProps) {
  const [patchList, setPatchList] = useState<MixerPatchList>(
    initialPatchList || {
      name: 'New Mixer Patch List',
      rows: Array.from({ length: 32 }, (_, i) => ({
        id: `channel-${i + 1}`,
        channel: i + 1,
        instrument: 'None',
        microphone: 'None',
        diBox: false,
        position: '',
        notes: '',
        isActive: false
      })),
      bookingId
    }
  );
  const [templateName, setTemplateName] = useState('');
  const [savedPatchLists, setSavedPatchLists] = useState<MixerPatchList[]>([]);
  
  const { toast } = useToast();

  const canManage = canEdit && (userRole === 'superadmin' || userRole === 'admin' || 
    userRole === 'managed_artist' || userRole === 'managed_musician');

  // Load saved patch lists
  useEffect(() => {
    const loadSavedPatchLists = async () => {
      try {
        // Loading mixer patch lists
        
        // Check localStorage first
        const savedLists = localStorage.getItem('mixerPatchLists');
        if (savedLists) {
          const parsed = JSON.parse(savedLists);
          setSavedPatchLists(parsed);
          // Loaded mixer patch lists successfully
          return;
        }
        
        // Skip token check for now
        
        const response = await apiRequest('/api/mixer-patch-lists');
        
        if (response.ok) {
          const lists = await response.json();
          // Applied loaded mixer patch lists
          setSavedPatchLists(lists);
        } else {
          console.error('Failed to load patch lists:', response.status, response.statusText);
        }
      } catch (error) {
        console.error('Failed to load patch lists:', error);
      }
    };
    
    if (canManage) {
      loadSavedPatchLists();
    }
  }, [canManage]);

  // Auto-populate from assigned musicians
  useEffect(() => {
    if (assignedMusicians.length > 0 && !initialPatchList) {
      populateFromMusicians();
    }
  }, [assignedMusicians]);

  const populateFromMusicians = () => {
    if (!canManage) return;

    const newRows = [...patchList.rows];
    let channelIndex = 0;

    // Lead vocals first (primary artist)
    if (assignedMusicians.length > 0) {
      newRows[channelIndex] = {
        ...newRows[channelIndex],
        instrument: 'Lead Vocals',
        microphone: 'SM58',
        position: 'Center Stage',
        assignedMusician: assignedMusicians[0].name,
        isActive: true,
        notes: 'Primary artist lead vocals'
      };
      channelIndex++;
    }

    // Assign instruments based on musician profiles
    assignedMusicians.forEach((musician, index) => {
      if (index === 0) return; // Skip primary artist (already assigned vocals)
      
      const instruments = musician.instruments || ['Background Vocals'];
      
      instruments.forEach(instrument => {
        if (channelIndex < newRows.length) {
          // Map musician instruments to mixer channels
          let mixerInstrument = instrument;
          let suggestedMic = 'SM57';
          let position = 'Stage Left';

          // Instrument-specific mic and position suggestions
          if (instrument.toLowerCase().includes('vocal')) {
            mixerInstrument = 'Background Vocals';
            suggestedMic = 'SM58';
            position = 'Upstage Center';
          } else if (instrument.toLowerCase().includes('guitar')) {
            mixerInstrument = 'Electric Guitar';
            suggestedMic = 'SM57';
            position = 'Stage Right';
          } else if (instrument.toLowerCase().includes('bass')) {
            mixerInstrument = 'Bass Guitar';
            suggestedMic = 'Beta 52A';
            position = 'Stage Left';
          } else if (instrument.toLowerCase().includes('drum')) {
            mixerInstrument = 'Drum Kit - Kick';
            suggestedMic = 'Beta 52A';
            position = 'Drum Riser';
          } else if (instrument.toLowerCase().includes('piano') || instrument.toLowerCase().includes('keyboard')) {
            mixerInstrument = 'Piano/Keyboard';
            suggestedMic = 'DI Box';
            position = 'Piano Position';
          }

          newRows[channelIndex] = {
            ...newRows[channelIndex],
            instrument: mixerInstrument,
            microphone: suggestedMic,
            position: position,
            assignedMusician: musician.name,
            isActive: true,
            diBox: mixerInstrument === 'Piano/Keyboard' || mixerInstrument === 'Bass Guitar',
            notes: `${musician.name} - ${instrument}`
          };
          channelIndex++;
        }
      });
    });

    setPatchList(prev => ({ ...prev, rows: newRows }));
    
    toast({
      title: "Channels Auto-Populated",
      description: `Assigned ${channelIndex} channels based on musician assignments`
    });
  };

  const updateRow = (channelId: string, field: keyof MixerPatchRow, value: any) => {
    if (!canManage) return;

    setPatchList(prev => ({
      ...prev,
      rows: prev.rows.map(row =>
        row.id === channelId
          ? {
              ...row,
              [field]: value,
              isActive: field === 'instrument' ? value !== 'None' : row.isActive
            }
          : row
      )
    }));
  };

  const addRow = () => {
    if (!canManage) return;

    const newChannel = patchList.rows.length + 1;
    const newRow: MixerPatchRow = {
      id: `channel-${newChannel}`,
      channel: newChannel,
      instrument: 'None',
      microphone: 'None',
      diBox: false,
      position: '',
      notes: '',
      isActive: false
    };

    setPatchList(prev => ({
      ...prev,
      rows: [...prev.rows, newRow]
    }));
  };

  const removeRow = (channelId: string) => {
    if (!canManage || patchList.rows.length <= 1) return;

    const row = patchList.rows.find(r => r.id === channelId);
    const channelInfo = row ? `Channel ${row.channel}${row.instrument !== 'None' ? ` (${row.instrument})` : ''}` : 'this channel';
    
    if (confirm(`Are you sure you want to remove ${channelInfo} from the mixer patch list?`)) {
      setPatchList(prev => ({
        ...prev,
        rows: prev.rows.filter(row => row.id !== channelId)
          .map((row, index) => ({ ...row, channel: index + 1 }))
      }));
      
      toast({
        title: "Channel Removed",
        description: `${channelInfo} has been removed from the patch list`
      });
    }
  };

  const savePatchList = async () => {
    if (!canManage || !templateName.trim()) {
      toast({
        title: "Save Failed",
        description: "Please enter a template name",
        variant: "destructive"
      });
      return;
    }

    try {

      const listToSave = {
        ...patchList,
        name: templateName,
        modifiedAt: new Date().toISOString()
      };

      // Check if name already exists and append number
      let finalName = templateName;
      let counter = 1;
      while (savedPatchLists.some(list => list.name === finalName)) {
        finalName = `${templateName}-${counter}`;
        counter++;
      }
      listToSave.name = finalName;

      const response = await apiRequest('/api/mixer-patch-lists', {
        method: 'POST',
        body: JSON.stringify(listToSave)
      });

      if (response.ok) {
        const saved = await response.json();
        setSavedPatchLists(prev => [...prev, saved]);
        setTemplateName('');
        toast({
          title: "Patch List Saved",
          description: `Template saved as "${finalName}"`
        });
        
        if (onSave) {
          onSave(saved);
        }
      } else {
        const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
        toast({
          title: "Save Failed",
          description: errorData.message || "Failed to save mixer patch list",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Save error:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save mixer patch list",
        variant: "destructive"
      });
    }
  };

  const loadPatchList = (list: MixerPatchList) => {
    const loadedList = {
      ...list,
      id: undefined,
      bookingId: bookingId
    };
    setPatchList(loadedList);
    
    // Notify parent about load action
    if (onLoad) {
      onLoad(loadedList);
    }
    
    toast({
      title: "Template Loaded",
      description: `Loaded "${list.name}" - modify and save with new name`
    });
  };

  const clearPatchList = () => {
    if (window.confirm('Are you sure you want to clear all channels? This will reset all channels to inactive state and cannot be undone.')) {
      setPatchList(prev => ({
        ...prev,
        rows: prev.rows.map(row => ({
          ...row,
          instrument: 'None',
          microphone: 'None',
          diBox: false,
          position: '',
          notes: '',
          assignedMusician: '',
          isActive: false
        }))
      }));
      
      toast({
        title: "Channels Cleared",
        description: "All channels have been reset to inactive state"
      });
    }
  };

  const deletePatchList = async (list: any) => {
    const confirmed = window.confirm(
      `Are you sure you want to delete the mixer patch list template "${list.name}"? This action cannot be undone.`
    );
    
    if (!confirmed) return;

    try {
      const response = await apiRequest(`/api/mixer-patch-lists/${list.id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setSavedPatchLists(prev => prev.filter(p => p.id !== list.id));
        toast({
          title: "Template Deleted",
          description: `Mixer patch list template "${list.name}" has been deleted`
        });
      } else {
        throw new Error('Failed to delete template');
      }
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: "Failed to delete mixer patch list template",
        variant: "destructive"
      });
    }
  };

  const activeChannels = patchList.rows.filter(row => row.isActive).length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Volume2 className="h-5 w-5" />
              Mixer Patch List
            </div>
            <Badge variant="outline">{activeChannels} Active Channels</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Left Column - Templates & Controls */}
            <div className="space-y-4">
              {/* Template Management */}
              {canManage && (
                <div>
                  <Label className="text-sm font-semibold">Save Template</Label>
                  <div className="space-y-2 mt-2">
                    <Input
                      value={templateName}
                      onChange={(e) => setTemplateName(e.target.value)}
                      placeholder="Template name"
                    />
                    <Button
                      onClick={savePatchList}
                      disabled={!templateName.trim()}
                      className="w-full"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save Template
                    </Button>
                  </div>
                </div>
              )}

              <div>
                <Label className="text-sm font-semibold">Load Template</Label>
                <div className="space-y-2 mt-2">
                  {savedPatchLists.map(list => (
                    <div key={list.id} className="flex gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 justify-start"
                        onClick={() => loadPatchList(list)}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        {list.name}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deletePatchList(list)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                  {savedPatchLists.length === 0 && (
                    <p className="text-sm text-gray-500">No saved templates</p>
                  )}
                </div>
              </div>

              {/* Channel Actions */}
              {canManage && (
                <div>
                  <Label className="text-sm font-semibold">Channel Actions</Label>
                  <div className="space-y-2 mt-2">
                    {assignedMusicians.length > 0 && (
                      <Button 
                        onClick={populateFromMusicians} 
                        variant="outline"
                        className="w-full"
                      >
                        <Music4 className="h-4 w-4 mr-2" />
                        Auto-Populate
                      </Button>
                    )}
                    <Button onClick={addRow} variant="outline" className="w-full">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Channel
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - Patch List Table */}
            <div className="lg:col-span-3 space-y-4">

              {/* Patch List Table */}
              <div className="border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="p-2 text-left font-medium">Ch</th>
                      <th className="p-2 text-left font-medium">Instrument</th>
                      <th className="p-2 text-left font-medium">Mic</th>
                      <th className="p-2 text-left font-medium">DI</th>
                      <th className="p-2 text-left font-medium">Position</th>
                      <th className="p-2 text-left font-medium">Musician</th>
                      <th className="p-2 text-left font-medium">Notes</th>
                      {canManage && <th className="p-2 text-left font-medium">Action</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {patchList.rows.map((row, index) => (
                      <tr
                        key={row.id}
                        className={`border-t ${
                          row.isActive ? 'bg-blue-50' : index % 2 === 0 ? 'bg-white' : 'bg-gray-50'
                        }`}
                      >
                        <td className="p-2 font-mono text-center">
                          <Badge variant={row.isActive ? 'default' : 'secondary'} className="text-xs px-1 py-0">
                            {row.channel}
                          </Badge>
                        </td>
                        <td className="p-2">
                          {canManage ? (
                            <Select
                              value={row.instrument}
                              onValueChange={(value) => updateRow(row.id, 'instrument', value)}
                            >
                              <SelectTrigger className="w-full">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {INSTRUMENTS.map(instrument => (
                                  <SelectItem key={instrument} value={instrument}>
                                    {instrument}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className={row.instrument === 'None' ? 'text-gray-400' : ''}>
                              {row.instrument}
                            </span>
                          )}
                        </td>
                        <td className="p-2">
                          {canManage ? (
                            <Select
                              value={row.microphone}
                              onValueChange={(value) => updateRow(row.id, 'microphone', value)}
                              disabled={row.instrument === 'None'}
                            >
                              <SelectTrigger className="w-full h-7 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {MICROPHONES.map(mic => (
                                  <SelectItem key={mic} value={mic}>
                                    {mic}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className={row.microphone === 'None' ? 'text-gray-400' : ''}>
                              {row.microphone}
                            </span>
                          )}
                        </td>
                        <td className="p-2 text-center">
                          {canManage ? (
                            <input
                              type="checkbox"
                              checked={row.diBox}
                              onChange={(e) => updateRow(row.id, 'diBox', e.target.checked)}
                              disabled={row.instrument === 'None'}
                              className="w-3 h-3"
                            />
                          ) : (
                            <span>{row.diBox ? '✓' : '—'}</span>
                          )}
                        </td>
                        <td className="p-2">
                          {canManage ? (
                            <Select
                              value={row.position}
                              onValueChange={(value) => updateRow(row.id, 'position', value)}
                              disabled={row.instrument === 'None'}
                            >
                              <SelectTrigger className="w-full h-7 text-xs">
                                <SelectValue placeholder="Select position" />
                              </SelectTrigger>
                              <SelectContent>
                                {POSITIONS.map(position => (
                                  <SelectItem key={position} value={position}>
                                    {position}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="text-sm">{row.position || '—'}</span>
                          )}
                        </td>
                        <td className="p-2">
                          <span className="text-xs font-medium text-blue-600">
                            {row.assignedMusician || '—'}
                          </span>
                        </td>
                        <td className="p-2">
                          {canManage ? (
                            <Input
                              value={row.notes}
                              onChange={(e) => updateRow(row.id, 'notes', e.target.value)}
                              placeholder="Notes"
                              className="w-full text-xs h-7"
                              disabled={row.instrument === 'None'}
                            />
                          ) : (
                            <span className="text-xs">{row.notes || '—'}</span>
                          )}
                        </td>
                        {canManage && (
                          <td className="p-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeRow(row.id)}
                              disabled={patchList.rows.length <= 1}
                              className="h-7 w-7 p-0"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

              {/* Clear Patch List Button - Right below patch list */}
              {canManage && patchList.rows.some(row => row.isActive) && (
                <div className="mt-4">
                  <Button
                    onClick={clearPatchList}
                    variant="destructive"
                    size="sm"
                  >
                    <Eraser className="h-4 w-4 mr-2" />
                    Clear All Channels
                  </Button>
                </div>
              )}

              {/* Summary */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center text-sm">
                  <span>
                    <strong>Total Channels:</strong> {patchList.rows.length} | 
                    <strong className="ml-2">Active:</strong> {activeChannels} |
                    <strong className="ml-2">Available:</strong> {patchList.rows.length - activeChannels}
                  </span>
                  <span>
                    <strong>Musicians Assigned:</strong> {assignedMusicians.length}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}