// This file has been replaced with FixedAdminPanel.tsx to resolve TypeScript errors
export { default } from './FixedAdminPanel';