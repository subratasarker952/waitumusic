import RecommendationsComponent from '@/components/Recommendations';

export default function RecommendationsPage() {
  return <RecommendationsComponent />;
}