export { default } from "./FixedAdminPanel";
