import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import MinimalApp from "./MinimalApp";
import "./index.css";

// Use minimal app for debugging
const USE_MINIMAL_APP = false;

// Enhanced error handling for React app initialization
try {
  const rootElement = document.getElementById("root");
  if (!rootElement) {
    throw new Error("Root element not found");
  }
  
  const root = createRoot(rootElement);
  
  if (USE_MINIMAL_APP) {
    console.log("🔧 Using minimal app for debugging");
    root.render(<MinimalApp />);
  } else {
    root.render(<App />);
  }
  
  console.log("✅ React app mounted successfully");
} catch (error) {
  console.error("❌ React app failed to mount:", error);
  
  // Fallback error display
  const rootElement = document.getElementById("root");
  if (rootElement) {
    rootElement.innerHTML = `
      <div style="padding: 20px; color: red; font-family: Arial;">
        <h2>React App Failed to Mount</h2>
        <p>Error: ${error instanceof Error ? error.message : 'Unknown error'}</p>
        <p>Check the browser console for more details.</p>
        <pre>${error instanceof Error ? error.stack : ''}</pre>
      </div>
    `;
  }
}
