/**
 * Minimal App Component - For debugging React mounting issues
 */
import React from 'react';
import { Switch, Route } from "wouter";
import TestComponent from "@/components/TestComponent";

function MinimalRouter() {
  return (
    <div>
      <h1>Minimal WaituMusic App</h1>
      <Switch>
        <Route path="/test-react" component={TestComponent} />
        <Route>
          {() => (
            <div>
              <h2>React is Working!</h2>
              <p>This is a minimal React app without complex providers.</p>
              <a href="/test-react">Test React Route</a>
            </div>
          )}
        </Route>
      </Switch>
    </div>
  );
}

export default MinimalRouter;