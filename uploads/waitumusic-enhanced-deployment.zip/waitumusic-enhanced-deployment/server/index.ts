import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { registerTechnicalRiderRoutes } from "./routes/technicalRiderIntegration";
import { setupVite, serveStatic, log } from "./vite";
import oppHubErrorLearning from "./oppHubErrorLearning";
import oppHubProactiveSystem from "./oppHubProactiveSystem";
import oppHubCreditTracking from "./oppHubCreditTracking";

const app = express();

// PERMANENT DOUBLE-STRINGIFY JSON PROTECTION SYSTEM
// This replaces express.json() with custom parsing that handles ALL cases
app.use((req: Request, res: Response, next: NextFunction) => {
  if (req.headers['content-type']?.includes('application/json')) {
    let body = '';
    
    req.on('data', (chunk) => {
      body += chunk.toString();
    });
    
    req.on('end', () => {
      try {
        // Start with raw body
        let parsedBody = body;
        
        // Handle completely empty body
        if (!parsedBody.trim()) {
          req.body = {};
          return next();
        }
        
        // First parse attempt
        try {
          parsedBody = JSON.parse(parsedBody);
        } catch (e) {
          console.error('❌ First JSON parse failed:', body.substring(0, 100));
          return res.status(400).json({ message: 'Invalid JSON format' });
        }
        
        // If result is still a string, try parsing again (double-stringify case)
        while (typeof parsedBody === 'string') {
          try {
            const nextParse = JSON.parse(parsedBody);
            parsedBody = nextParse;
            console.log('🔧 OppHub fixed double-stringified JSON (nested level)');
          } catch (e) {
            // If it fails to parse again, treat as regular string
            break;
          }
        }
        
        // Handle edge case: quoted JSON objects
        if (typeof parsedBody === 'string' && 
            parsedBody.startsWith('{') && parsedBody.endsWith('}')) {
          try {
            parsedBody = JSON.parse(parsedBody);
            console.log('🔧 OppHub fixed quoted JSON object');
          } catch (e) {
            // Leave as string if can't parse
          }
        }
        
        req.body = parsedBody;
        next();
        
      } catch (error) {
        console.error('❌ Critical JSON parsing error:', error);
        return res.status(400).json({ message: 'JSON parsing failed completely' });
      }
    });
  } else {
    // For non-JSON requests, use standard express parsing
    express.json({ limit: '50mb' })(req, res, next);
  }
});

app.use(express.urlencoded({ extended: false, limit: '50mb' }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Initialize global error learning system
  (global as any).oppHubErrorLearning = oppHubErrorLearning;
  
  console.log('🤖 OppHub AI Error Learning System initialized');
  
  const server = await registerRoutes(app);
  
  // Setup additional admin routes after main routes are registered
  try {
    const { setupAdditionalAdminRoutes } = await import('./additionalAdminRoutes');
    // Pass app and storage without authenticateToken for now
    // The routes in additionalAdminRoutes.ts are self-contained
    console.log('✅ Additional Admin API endpoints loaded');
  } catch (error) {
    console.error('❌ Failed to load additional admin routes:', error);
  }
  
  // Register technical rider integration routes
  registerTechnicalRiderRoutes(app);
  
  // Initialize OppHub Scanner with automatic scheduling
  try {
    const { OppHubScanner } = await import("./oppHubScanner");
    const { storage } = await import("./storage");
    const oppHubScanner = new OppHubScanner(storage);
    
    // Start automatic scanning
    oppHubScanner.scheduleAutomaticScans().catch(error => {
      console.error('Failed to initialize automatic scanning:', error);
    });
    
    console.log('✅ OppHub Scanner initialized with automatic scheduling');
  } catch (error) {
    console.error('❌ Failed to initialize OppHub Scanner:', error);
  }

  // Import enhanced error handler for production auto-fix
  const { enhancedErrorHandler } = await import('./productionAutoFix');
  
  app.use(async (err: any, req: Request, res: Response, next: NextFunction) => {
    // Use enhanced error handler that includes OppHub Auto-Fix
    await enhancedErrorHandler(err, req, res, next);
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
