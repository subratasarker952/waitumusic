import type { Express, Request, Response } from "express";
import { storage } from "../storage";
import jwt from "jsonwebtoken";
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

interface StagePlotItem {
  id: string;
  type: 'drums' | 'bass' | 'guitar' | 'keyboard' | 'vocals' | 'monitor' | 'equipment';
  x: number;
  y: number;
  name: string;
  assignedTo: string;
  talentRole?: string;
  equipmentList?: string[];
  monitorMixRequired?: boolean;
}

interface MonitorMix {
  id: string;
  name: string;
  assignedTo: string;
  talentRole: string;
  channels: number[];
  preferences: string[];
  position: { x: number; y: number };
}

interface MixerChannel {
  channel: number;
  inputSource: string;
  equipment: string;
  stageLocation: string;
  notes: string;
  assignedTo: string;
  talentRole: string;
  gain: number;
  eq: { low: number; mid: number; high: number };
  aux1: number; aux2: number; aux3: number; aux4: number;
  aux5: number; aux6: number; aux7: number; aux8: number;
  phantom: boolean;
  lowCut: boolean;
  gate: { enabled: boolean; threshold: number };
  compressor: { enabled: boolean; ratio: number; threshold: number };
}

interface SetlistSong {
  id: string;
  title: string;
  artist: string;
  duration: number;
  key: string;
  bpm: number;
  energy: 'low' | 'medium' | 'high';
  source: 'uploaded' | 'youtube' | 'manual';
  sourceUrl?: string;
  chordChart?: string;
  notes: string;
  position: number;
}

interface TechnicalRiderData {
  bookingId: number;
  stagePlot: StagePlotItem[];
  monitorMixes: MonitorMix[];
  mixerChannels: MixerChannel[];
  setlist: SetlistSong[];
  talentAssignments: any[];
  eventInfo: any;
  createdAt: Date;
  updatedAt: Date;
}

export function registerTechnicalRiderRoutes(app: Express) {
  
  // Save complete technical rider configuration
  app.post('/api/bookings/:id/technical-rider/complete', authenticateToken, async (req: Request, res: Response) => {
    try {
      const bookingId = parseInt(req.params.id);
      const { stagePlot, monitorMixes, mixerChannels, setlist, eventInfo } = req.body;

      const technicalRiderData: TechnicalRiderData = {
        bookingId,
        stagePlot: stagePlot || [],
        monitorMixes: monitorMixes || [],
        mixerChannels: mixerChannels || [],
        setlist: setlist || [],
        talentAssignments: [],
        eventInfo: eventInfo || {},
        createdAt: new Date(),
        updatedAt: new Date()
      };

      // Store technical rider data (would save to database in real implementation)
      
      res.json({ 
        success: true, 
        message: 'Complete technical rider saved successfully',
        technicalRiderId: `TR-${bookingId}-${Date.now()}`
      });
    } catch (error) {
      console.error('Error saving complete technical rider:', error);
      res.status(500).json({ message: 'Failed to save technical rider' });
    }
  });

  // Get complete technical rider for booking
  app.get('/api/bookings/:id/technical-rider/complete', authenticateToken, async (req: Request, res: Response) => {
    try {
      const bookingId = parseInt(req.params.id);
      
      // Mock technical rider data for demonstration
      const technicalRider: TechnicalRiderData = {
        bookingId,
        stagePlot: [
          {
            id: 'stage-1',
            type: 'drums',
            x: 300,
            y: 200,
            name: 'Drum Kit',
            assignedTo: 'Drummer',
            talentRole: 'musician',
            equipmentList: ['DW Performance Series', 'Meinl Byzance Cymbals'],
            monitorMixRequired: true
          },
          {
            id: 'stage-2',
            type: 'vocals',
            x: 300,
            y: 300,
            name: 'Lead Vocals',
            assignedTo: 'Lead Singer',
            talentRole: 'artist',
            equipmentList: ['Shure SM58', 'Wireless Pack'],
            monitorMixRequired: true
          }
        ],
        monitorMixes: [
          {
            id: 'monitor-1',
            name: 'Drummer Monitor',
            assignedTo: 'Drummer',
            talentRole: 'musician',
            channels: [1, 2, 9, 10],
            preferences: ['kick heavy', 'snare prominent'],
            position: { x: 280, y: 180 }
          }
        ],
        mixerChannels: [],
        setlist: [],
        talentAssignments: [],
        eventInfo: {},
        createdAt: new Date(),
        updatedAt: new Date()
      };

      res.json(technicalRider);
    } catch (error) {
      console.error('Error fetching technical rider:', error);
      res.status(500).json({ message: 'Failed to fetch technical rider' });
    }
  });

  // Stage plot specific endpoints
  app.post('/api/bookings/:id/stage-plot', authenticateToken, async (req: Request, res: Response) => {
    try {
      const bookingId = parseInt(req.params.id);
      const { stagePlot, monitorMixes, assignedTalent } = req.body;

      // Validate stage plot data
      if (!Array.isArray(stagePlot)) {
        return res.status(400).json({ message: 'Invalid stage plot data' });
      }

      // Process talent assignments and generate equipment lists
      const processedStagePlot = stagePlot.map((item: StagePlotItem) => ({
        ...item,
        equipmentList: item.equipmentList || [],
        monitorMixRequired: item.monitorMixRequired !== false
      }));

      res.json({ 
        success: true, 
        message: 'Stage plot saved successfully',
        stagePlotId: `SP-${bookingId}-${Date.now()}`,
        itemCount: processedStagePlot.length,
        monitorMixCount: monitorMixes?.length || 0
      });
    } catch (error) {
      console.error('Error saving stage plot:', error);
      res.status(500).json({ message: 'Failed to save stage plot' });
    }
  });

  // Mixer configuration endpoints
  app.post('/api/bookings/:id/mixer-config', authenticateToken, async (req: Request, res: Response) => {
    try {
      const bookingId = parseInt(req.params.id);
      const { mixerChannels, monitorMixes, stagePlotData } = req.body;

      // Validate mixer configuration
      if (!Array.isArray(mixerChannels) || mixerChannels.length > 32) {
        return res.status(400).json({ message: 'Invalid mixer configuration' });
      }

      // Process mixer channels and monitor assignments
      const processedChannels = mixerChannels.map((channel: MixerChannel, index: number) => ({
        ...channel,
        channel: index + 1,
        eq: channel.eq || { low: 0, mid: 0, high: 0 },
        gate: channel.gate || { enabled: false, threshold: -40 },
        compressor: channel.compressor || { enabled: false, ratio: 3, threshold: -20 }
      }));

      res.json({ 
        success: true, 
        message: 'Mixer configuration saved successfully',
        mixerConfigId: `MC-${bookingId}-${Date.now()}`,
        channelsConfigured: processedChannels.filter(c => c.inputSource).length,
        totalChannels: 32
      });
    } catch (error) {
      console.error('Error saving mixer configuration:', error);
      res.status(500).json({ message: 'Failed to save mixer configuration' });
    }
  });

  // Setlist management endpoints
  app.post('/api/bookings/:id/setlist', authenticateToken, async (req: Request, res: Response) => {
    try {
      const bookingId = parseInt(req.params.id);
      const { setlist, eventInfo, aiOptimization } = req.body;

      // Validate setlist data
      if (!Array.isArray(setlist)) {
        return res.status(400).json({ message: 'Invalid setlist data' });
      }

      // Process setlist songs with position ordering
      const processedSetlist = setlist.map((song: SetlistSong, index: number) => ({
        ...song,
        position: index + 1,
        duration: song.duration || 180,
        energy: song.energy || 'medium'
      }));

      const totalDuration = processedSetlist.reduce((sum, song) => sum + song.duration, 0);

      res.json({ 
        success: true, 
        message: 'Setlist saved successfully',
        setlistId: `SL-${bookingId}-${Date.now()}`,
        songCount: processedSetlist.length,
        totalDuration: Math.round(totalDuration / 60),
        aiOptimized: !!aiOptimization
      });
    } catch (error) {
      console.error('Error saving setlist:', error);
      res.status(500).json({ message: 'Failed to save setlist' });
    }
  });

  // Get existing setlist for booking
  app.get('/api/bookings/:id/setlist', authenticateToken, async (req: Request, res: Response) => {
    try {
      const bookingId = parseInt(req.params.id);
      
      // Mock setlist data
      const setlistData = {
        songs: [
          {
            id: 'song-1',
            title: 'Opening Song',
            artist: 'Artist Name',
            duration: 240,
            key: 'C',
            bpm: 120,
            energy: 'medium' as const,
            source: 'uploaded' as const,
            notes: 'Opening number - build energy',
            position: 1
          }
        ],
        eventInfo: {
          eventType: 'concert',
          duration: 60,
          audienceType: 'general',
          expectedAttendance: 200
        },
        totalDuration: 240,
        createdAt: new Date(),
        updatedAt: new Date()
      };

      res.json(setlistData);
    } catch (error) {
      console.error('Error fetching setlist:', error);
      res.status(500).json({ message: 'Failed to fetch setlist' });
    }
  });

  // Integration status endpoint
  app.get('/api/bookings/:id/technical-rider/status', authenticateToken, async (req: Request, res: Response) => {
    try {
      const bookingId = parseInt(req.params.id);
      
      const status = {
        bookingId,
        componentsCompleted: {
          stagePlot: true,
          mixerConfig: true,
          setlist: true,
          talentAssignments: true
        },
        lastUpdated: new Date(),
        readyForExport: true,
        integrationHealth: 'excellent',
        interconnections: {
          stagePlotToMixer: true,
          mixerToSetlist: true,
          talentAssignments: true
        }
      };

      res.json(status);
    } catch (error) {
      console.error('Error checking technical rider status:', error);
      res.status(500).json({ message: 'Failed to check status' });
    }
  });
}