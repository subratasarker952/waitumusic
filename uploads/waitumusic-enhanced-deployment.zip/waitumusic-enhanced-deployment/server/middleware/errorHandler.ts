import { Request, Response, NextFunction } from 'express';
import { oppHubProductionFixer } from '../oppHubProductionErrorFixer';

export interface CustomError extends Error {
  statusCode?: number;
  code?: string;
}

export const errorHandler = async (
  error: CustomError,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.error('Error occurred:', error.message);
  console.error('Stack trace:', error.stack);
  
  // OppHub Auto-Fix: Attempt to resolve database errors immediately
  if (process.env.NODE_ENV === 'production' && isDatabaseError(error)) {
    console.log('🤖 OppHub detecting database error, attempting auto-fix...');
    
    try {
      const fixResult = await oppHubProductionFixer.detectAndFixDatabaseErrors();
      
      if (fixResult.fixed && fixResult.solutions.length > 0) {
        console.log('🔧 OppHub Auto-Fix successful:', fixResult.solutions);
        
        // Log the auto-fix for audit
        await oppHubProductionFixer.logProductionIssue(error, `Auto-fixed: ${req.method} ${req.path}`);
        
        // Attempt to retry the original request after fix
        if (canRetryRequest(req)) {
          return res.status(200).json({
            success: true,
            message: 'Database issue detected and automatically resolved',
            autoFixApplied: fixResult.solutions,
            retryAdvised: true
          });
        }
      }
    } catch (autoFixError) {
      console.error('🚫 OppHub Auto-Fix failed:', autoFixError);
    }
  }
  
  // Standard error response
  const statusCode = error.statusCode || 500;
  const message = process.env.NODE_ENV === 'production' 
    ? 'Internal server error' 
    : error.message;
  
  res.status(statusCode).json({
    success: false,
    error: message,
    ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
  });
};

function isDatabaseError(error: CustomError): boolean {
  const dbErrorPatterns = [
    'column does not exist',
    'relation does not exist',
    'table does not exist',
    'foreign key violation',
    'invalid input syntax',
    'connection failed',
    'connection terminated',
    'database connection',
    'ECONNREFUSED',
    'ENOTFOUND'
  ];
  
  return dbErrorPatterns.some(pattern => 
    error.message.toLowerCase().includes(pattern.toLowerCase())
  );
}

function canRetryRequest(req: Request): boolean {
  // Only retry safe methods and specific endpoints
  const safeMethods = ['GET', 'HEAD', 'OPTIONS'];
  const retryableEndpoints = ['/api/demo-mode', '/api/artists', '/api/songs', '/api/opportunities'];
  
  return safeMethods.includes(req.method) || 
         retryableEndpoints.some(endpoint => req.path.startsWith(endpoint));
}

// Request timeout handler
export const requestTimeout = (timeoutMs: number = 30000) => {
  return (req: Request, res: Response, next: NextFunction) => {
    res.setTimeout(timeoutMs, () => {
      const error = new Error('Request timeout') as CustomError;
      error.statusCode = 408;
      next(error);
    });
    next();
  };
};

// Database connection retry middleware
export const retryDatabaseOperation = async <T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delayMs: number = 1000
): Promise<T> => {
  let lastError: Error;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      console.log(`Database operation failed (attempt ${attempt}/${maxRetries}):`, error);
      
      if (attempt < maxRetries) {
        // Apply auto-fix before retry
        if (process.env.NODE_ENV === 'production') {
          try {
            const fixResult = await oppHubProductionFixer.detectAndFixDatabaseErrors();
            if (fixResult.fixed) {
              console.log('🔧 Applied auto-fix before retry:', fixResult.solutions);
            }
          } catch (fixError) {
            console.error('Auto-fix failed during retry:', fixError);
          }
        }
        
        // Exponential backoff
        await new Promise(resolve => setTimeout(resolve, delayMs * Math.pow(2, attempt - 1)));
      }
    }
  }
  
  throw lastError!;
};