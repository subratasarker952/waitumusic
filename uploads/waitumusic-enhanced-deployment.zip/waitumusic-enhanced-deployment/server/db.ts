import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

// Configure Neon for serverless environment with SSL handling
neonConfig.webSocketConstructor = ws;

// Handle SSL/WebSocket issues for all environments to prevent certificate errors
neonConfig.subtls = undefined; // Disable subtls to avoid certificate issues
neonConfig.pipelineConnect = false; // Disable pipeline connect for better compatibility
neonConfig.pipelineTLS = false; // Disable TLS pipeline to avoid certificate hostname issues

// Force Neon to use HTTP instead of WebSocket to avoid SSL hostname issues
neonConfig.forceDisableWebSocket = true;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Configure connection pool with retry logic and SSL handling
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
  // Complete SSL bypass for certificate hostname issues
  ssl: false  // Disable SSL completely to avoid all certificate issues
});

// Add connection error handling
pool.on('error', (err: any) => {
  console.error('Database pool error:', err);
});

export const db = drizzle({ client: pool, schema });