#!/bin/bash

# WaituMusic Production Installation Script for AlmaLinux 9 with CyberPanel
# Run this script as root after extracting deploywaitumusic.zip

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                 WaituMusic Production Installer              ║"
echo "║            AlmaLinux 9 + CyberPanel + PM2 Setup             ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root"
   exit 1
fi

# Variables
DOMAIN="waitumusic.com"
APP_DIR="/home/${DOMAIN}/public_html"
LOG_DIR="/home/${DOMAIN}/logs"
UPLOAD_DIR="/home/${DOMAIN}/uploads"
SSL_DIR="/home/${DOMAIN}/ssl"
BACKUP_DIR="/home/${DOMAIN}/backups"

print_info "Starting WaituMusic production installation..."

# 1. Update system
print_info "Updating AlmaLinux system packages..."
dnf update -y
print_status "System updated"

# 2. Install Node.js 20.x
print_info "Installing Node.js 20.x..."
dnf module reset nodejs -y
dnf module install nodejs:20 -y
dnf install npm -y
node --version
npm --version
print_status "Node.js installed"

# 3. Install PM2 globally
print_info "Installing PM2 process manager..."
npm install -g pm2
pm2 startup systemd -u root --hp /root
systemctl enable pm2-root
print_status "PM2 installed and configured"

# 4. Install PostgreSQL client (if not already installed)
print_info "Installing PostgreSQL client..."
dnf install postgresql postgresql-contrib -y
print_status "PostgreSQL client installed"

# 5. Create directory structure
print_info "Creating directory structure..."
mkdir -p ${APP_DIR}
mkdir -p ${LOG_DIR}
mkdir -p ${UPLOAD_DIR}
mkdir -p ${SSL_DIR}
mkdir -p ${BACKUP_DIR}
print_status "Directories created"

# 6. Set proper ownership
print_info "Setting directory ownership..."
chown -R ${DOMAIN}:${DOMAIN} /home/${DOMAIN}
chmod 755 /home/${DOMAIN}
chmod 755 ${APP_DIR}
chmod 755 ${LOG_DIR}
chmod 755 ${UPLOAD_DIR}
chmod 700 ${SSL_DIR}
print_status "Ownership configured"

# 7. Copy application files
print_info "Copying WaituMusic application files..."
cp -r ./* ${APP_DIR}/
cd ${APP_DIR}

# 8. Install dependencies
print_info "Installing Node.js dependencies..."
npm install --production
print_status "Dependencies installed"

# 9. Build application
print_info "Building production application..."
npm run build
print_status "Application built"

# 10. Configure environment
print_info "Setting up environment configuration..."
if [[ -f ".env.production" ]]; then
    cp .env.production .env
    print_warning "Please edit .env file with your production values"
else
    print_error ".env.production file not found"
fi

# 11. Create log files
print_info "Creating log files..."
touch ${LOG_DIR}/combined.log
touch ${LOG_DIR}/out.log
touch ${LOG_DIR}/error.log
touch ${LOG_DIR}/access.log
touch ${LOG_DIR}/app.log
chown ${DOMAIN}:${DOMAIN} ${LOG_DIR}/*
print_status "Log files created"

# 12. Install and configure Nginx (if not using OpenLiteSpeed)
if ! command -v nginx &> /dev/null; then
    print_info "Installing Nginx..."
    dnf install nginx -y
    systemctl enable nginx
    
    # Copy nginx configuration
    if [[ -f "nginx.conf" ]]; then
        cp nginx.conf /etc/nginx/conf.d/${DOMAIN}.conf
        print_status "Nginx configuration installed"
    fi
fi

# 13. Configure firewall
print_info "Configuring firewall..."
firewall-cmd --permanent --add-port=3000/tcp
firewall-cmd --permanent --add-port=80/tcp
firewall-cmd --permanent --add-port=443/tcp
firewall-cmd --reload
print_status "Firewall configured"

# 14. Start application with PM2
print_info "Starting WaituMusic with PM2..."
pm2 delete waitumusic-production 2>/dev/null || true
pm2 start ecosystem.config.js --env production
pm2 save
print_status "Application started with PM2"

# 15. Setup SSL certificate (using Let's Encrypt via CyberPanel)
print_info "SSL certificate setup..."
print_warning "Please configure SSL certificate through CyberPanel:"
print_warning "1. Go to CyberPanel > SSL > Issue SSL"
print_warning "2. Select ${DOMAIN} and www.${DOMAIN}"
print_warning "3. Choose Let's Encrypt"

# 16. Database setup reminder
print_warning "Database Configuration Required:"
echo "1. Create PostgreSQL database: waitumusic_prod"
echo "2. Update DATABASE_URL in .env file"
echo "3. Run: npm run db:push"

# 17. Final checks
print_info "Running final system checks..."

# Check if PM2 is running
if pm2 list | grep -q "waitumusic-production"; then
    print_status "PM2 process is running"
else
    print_error "PM2 process failed to start"
fi

# Check if port 3000 is listening
if netstat -tlnp | grep -q ":3000"; then
    print_status "Application is listening on port 3000"
else
    print_error "Application is not listening on port 3000"
fi

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                 Installation Complete!                      ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

print_info "Next Steps:"
echo "1. Edit ${APP_DIR}/.env with your production database and API keys"
echo "2. Configure SSL certificate through CyberPanel"
echo "3. Setup your PostgreSQL database connection"
echo "4. Run: cd ${APP_DIR} && npm run db:push"
echo "5. Test the application: curl http://localhost:3000/api/demo-mode"

echo ""
print_info "Useful Commands:"
echo "• View logs: pm2 logs waitumusic-production"
echo "• Restart app: pm2 restart waitumusic-production"
echo "• Stop app: pm2 stop waitumusic-production"
echo "• App status: pm2 status"
echo "• Nginx restart: systemctl restart nginx"

echo ""
print_warning "Important Security Notes:"
echo "• Change all default passwords in .env file"
echo "• Configure proper database credentials"
echo "• Setup SSL certificate through CyberPanel"
echo "• Review firewall settings"

echo ""
print_status "WaituMusic is ready for production on https://${DOMAIN}!"