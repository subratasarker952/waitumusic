# WaituMusic Platform - Quick Installation Guide

## Prerequisites

- AlmaLinux 9 server with CyberPanel/OpenLiteSpeed installed
- Root access to the server
- Domain name pointing to your server

## Installation Steps

### 1. Create Deployment Package (On Development Machine)

```bash
cd deploy
chmod +x create-deployment.sh
./create-deployment.sh
```

This creates `waitumusic-platform-deploy.tar.gz`

### 2. Transfer to Server

```bash
scp waitumusic-platform-deploy.tar.gz root@your-server.com:/root/
```

### 3. Install on Server

```bash
# SSH to your server
ssh root@your-server.com

# Extract package
tar -xzf waitumusic-platform-deploy.tar.gz
cd waitumusic-deploy

# Run installer (replace with your domain)
chmod +x install.sh
./install.sh yourdomain.com
```

### 4. Configure DNS

Point your domain A record to your server IP:
```
yourdomain.com → YOUR_SERVER_IP
```

### 5. Setup SSL (In CyberPanel)

1. Access CyberPanel: `https://YOUR_SERVER_IP:8090`
2. Go to **SSL** → **Issue SSL**
3. Select your domain and issue certificate

### 6. Access Platform

Visit `https://yourdomain.com` and login:
- **Superadmin**: `superadmin@waitumusic.com` / `secret123`
- **Admin**: `admin@waitumusic.com` / `secret123`

**⚠️ Change passwords immediately!**

## What the Installer Does

✅ Installs Node.js 20 and PostgreSQL 15  
✅ Creates secure database with random passwords  
✅ Builds and deploys the application  
✅ Configures OpenLiteSpeed reverse proxy  
✅ Sets up systemd service for auto-start  
✅ Configures firewall rules  
✅ Creates daily backup system  
✅ Generates secure environment configuration  

## Post-Installation

1. **Change default passwords**
2. **Configure email settings** in `.env` file
3. **Test all functionality**
4. **Set up monitoring**

## Service Commands

```bash
# Control the application
systemctl start waitumusic
systemctl stop waitumusic
systemctl restart waitumusic
systemctl status waitumusic

# View logs
journalctl -u waitumusic -f
```

## Database Credentials

Saved in: `/root/.waitumusic_db_credentials`

## Support

See `DEPLOYMENT_GUIDE.md` for detailed instructions and troubleshooting.

---

**Total installation time: ~10-15 minutes**