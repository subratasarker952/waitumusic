# WaituMusic Production Deployment Guide

## Overview

This deployment package contains everything needed to deploy WaituMusic on your AlmaLinux 9 server with CyberPanel and PM2. The platform is production-ready with all SSL certificate issues resolved, comprehensive error handling, and authentic data systems.

## Package Contents

```
deploywaitumusic.zip
├── install.sh              # Automated installation script
├── package.json             # Production dependencies
├── ecosystem.config.js      # PM2 configuration
├── .env.production          # Production environment template
├── nginx.conf               # Nginx configuration for reverse proxy
├── README.md                # This deployment guide
├── client/                  # React frontend application
├── server/                  # Node.js backend application
├── shared/                  # Shared types and schemas
└── [all application files]  # Complete WaituMusic codebase
```

## Quick Installation

1. **Upload and Extract**
   ```bash
   cd /tmp
   unzip deploywaitumusic.zip
   cd deploywaitumusic
   ```

2. **Run Installation Script**
   ```bash
   chmod +x install.sh
   sudo ./install.sh
   ```

3. **Configure Environment**
   ```bash
   cd /home/waitumusic.com/public_html
   nano .env
   ```

4. **Setup Database**
   ```bash
   npm run db:push
   ```

## Manual Installation Steps

### Prerequisites

- AlmaLinux 9 server
- CyberPanel installed
- PostgreSQL database
- Domain pointing to server (waitumusic.com)

### 1. System Preparation

```bash
# Update system
sudo dnf update -y

# Install Node.js 20.x
sudo dnf module reset nodejs -y
sudo dnf module install nodejs:20 -y
sudo dnf install npm -y

# Install PM2
sudo npm install -g pm2
```

### 2. Application Setup

```bash
# Create directories
sudo mkdir -p /home/waitumusic.com/public_html
sudo mkdir -p /home/waitumusic.com/logs
sudo mkdir -p /home/waitumusic.com/uploads

# Extract application
sudo cp -r * /home/waitumusic.com/public_html/
cd /home/waitumusic.com/public_html

# Install dependencies
sudo npm install --production

# Build application
sudo npm run build
```

### 3. Environment Configuration

Copy `.env.production` to `.env` and update the following:

```bash
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/waitumusic_prod

# Security
SESSION_SECRET=your-secure-session-secret
JWT_SECRET=your-jwt-secret

# Email (SendGrid)
SENDGRID_API_KEY=your-sendgrid-api-key
FROM_EMAIL=noreply@waitumusic.com

# Payment (Stripe)
STRIPE_SECRET_KEY=sk_live_your_stripe_secret
STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable

# Optional AI Services
OPENAI_API_KEY=your-openai-api-key
ANTHROPIC_API_KEY=your-anthropic-api-key
```

### 4. Database Setup

```bash
# Create PostgreSQL database
sudo -u postgres createdb waitumusic_prod

# Push database schema
npm run db:push
```

### 5. PM2 Configuration

```bash
# Start application
pm2 start ecosystem.config.js --env production

# Save PM2 configuration
pm2 save

# Setup PM2 startup
pm2 startup systemd
```

### 6. Web Server Configuration

#### For CyberPanel (OpenLiteSpeed)

1. Create website in CyberPanel:
   - Domain: waitumusic.com
   - Document Root: /home/waitumusic.com/public_html/dist

2. Configure reverse proxy for API routes:
   ```
   Location: /api/
   Proxy: http://127.0.0.1:3000
   ```

#### For Nginx (Alternative)

```bash
# Copy configuration
sudo cp nginx.conf /etc/nginx/conf.d/waitumusic.com.conf

# Test and restart
sudo nginx -t
sudo systemctl restart nginx
```

### 7. SSL Certificate

Using CyberPanel:
1. Go to SSL → Issue SSL
2. Select waitumusic.com and www.waitumusic.com
3. Choose Let's Encrypt
4. Issue certificate

### 8. Firewall Configuration

```bash
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --permanent --add-port=80/tcp
sudo firewall-cmd --permanent --add-port=443/tcp
sudo firewall-cmd --reload
```

## Production Features

### Fully Functional Systems

✅ **Complete Authentication System**
- Role-based access control (superadmin, admin, artist, musician, professional, fan)
- JWT token authentication
- Secure session management

✅ **Artist Management Platform**
- Complete artist profiles (Princess Trinidad, Lí-Lí Octave, JCro, Janet Azzouz)
- Song catalog with ISRC codes
- Album management
- Merchandise integration

✅ **OppHub AI System**
- Opportunity scanner with 20+ verified music industry sources
- AI-powered opportunity matching
- Revenue optimization engine
- Social media strategy automation

✅ **Business Management Tools**
- Booking system with pricing automation
- Contract management
- Technical rider creation
- Splitsheet processing
- ISRC code generation
- Newsletter management

✅ **Payment Integration**
- Stripe payment processing
- Service pricing tiers
- Managed artist discounts

### Production Optimizations

- **SSL Certificate Issues Resolved**: Complete fix for hostname mismatches
- **Database Connection Stability**: Neon PostgreSQL with HTTP-only connections
- **Error Handling**: Comprehensive error logging and recovery
- **Performance**: PM2 cluster mode with automatic restarts
- **Security**: Production-ready environment variables and CORS configuration
- **Monitoring**: Health checks and uptime monitoring

## Management Commands

### PM2 Commands
```bash
# View status
pm2 status

# View logs
pm2 logs waitumusic-production

# Restart application
pm2 restart waitumusic-production

# Stop application
pm2 stop waitumusic-production

# Monitor resources
pm2 monit
```

### Application Commands
```bash
# Database operations
npm run db:push          # Push schema changes
npm run db:studio        # Open Drizzle Studio

# Production management
npm run start            # Start in production mode
npm run build            # Build for production
```

### Logs and Monitoring
```bash
# Application logs
tail -f /home/waitumusic.com/logs/combined.log

# PM2 logs
pm2 logs waitumusic-production --lines 100

# System logs
journalctl -u pm2-root -f
```

## Troubleshooting

### Common Issues

1. **Port 3000 already in use**
   ```bash
   sudo netstat -tlnp | grep :3000
   sudo kill -9 [PID]
   pm2 restart waitumusic-production
   ```

2. **Database connection failed**
   - Check DATABASE_URL in .env
   - Verify PostgreSQL is running
   - Test connection: `psql $DATABASE_URL`

3. **SSL certificate issues**
   - Renew through CyberPanel
   - Check domain DNS settings
   - Verify firewall ports 80/443

4. **Application not responding**
   ```bash
   pm2 restart waitumusic-production
   pm2 logs waitumusic-production
   ```

### Health Checks

```bash
# API health check
curl http://localhost:3000/api/demo-mode

# Database check
curl http://localhost:3000/api/artists

# Full system check
curl https://www.waitumusic.com/api/demo-mode
```

## Security Considerations

1. **Environment Variables**: Never commit .env files to version control
2. **Database Security**: Use strong passwords and restrict access
3. **API Keys**: Rotate keys regularly and use environment-specific keys
4. **SSL**: Keep certificates updated through CyberPanel
5. **Firewall**: Only open necessary ports
6. **Updates**: Regularly update dependencies and system packages

## Support

For technical support or deployment assistance:
- Check application logs: `pm2 logs waitumusic-production`
- Review system health: `curl http://localhost:3000/api/demo-mode`
- Monitor PM2 status: `pm2 status`

## Architecture

- **Frontend**: React 18 with TypeScript, Tailwind CSS, Shadcn/ui
- **Backend**: Node.js with Express, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: JWT with role-based access control
- **File Uploads**: Multer with secure storage
- **Email**: SendGrid integration
- **Payments**: Stripe integration
- **Process Management**: PM2 with cluster mode
- **Web Server**: OpenLiteSpeed (CyberPanel) or Nginx
- **SSL**: Let's Encrypt via CyberPanel

WaituMusic is now ready for production deployment on your AlmaLinux 9 server!