# WaituMusic Platform - Production Deployment Guide

## Overview

This guide provides step-by-step instructions for deploying WaituMusic Platform on AlmaLinux 9 with CyberPanel/OpenLiteSpeed. The platform is designed for production use with comprehensive music industry management features.

## System Requirements

### Server Specifications
- **OS**: AlmaLinux 9 (minimal install)
- **RAM**: Minimum 4GB, Recommended 8GB+
- **Storage**: Minimum 50GB SSD
- **CPU**: 2+ cores
- **Network**: Public IP with ports 80, 443, 5000 accessible

### Pre-installed Requirements
- CyberPanel with OpenLiteSpeed
- Root or sudo access
- Internet connectivity

## Quick Installation (Recommended)

### Step 1: Download and Extract Deployment Package

```bash
# Download the deployment package to your server
wget https://your-server.com/waitumusic-platform-deploy.tar.gz

# Extract the package
tar -xzf waitumusic-platform-deploy.tar.gz
cd waitumusic-deploy
```

### Step 2: Run the Automated Installer

```bash
# Make installer executable
chmod +x install.sh

# Run installer (replace 'yourdomain.com' with your actual domain)
sudo ./install.sh yourdomain.com
```

The installer will automatically:
- Install Node.js 20 and PostgreSQL 15
- Create database with secure credentials
- Install and build the application
- Configure OpenLiteSpeed virtual host
- Set up systemd service
- Configure firewall rules
- Create backup scripts

### Step 3: DNS Configuration

Point your domain to your server's IP address:
```
A Record: yourdomain.com → YOUR_SERVER_IP
```

### Step 4: SSL Certificate (via CyberPanel)

1. Log into CyberPanel at `https://YOUR_SERVER_IP:8090`
2. Go to **SSL** → **Issue SSL**
3. Select your domain and issue Let's Encrypt certificate

### Step 5: Access Your Platform

Visit `https://yourdomain.com` and log in with:
- **Superadmin**: `superadmin@waitumusic.com` / `secret123`
- **Admin**: `admin@waitumusic.com` / `secret123`

**⚠️ Important**: Change these default passwords immediately!

## Manual Installation (Advanced Users)

If you prefer manual installation or need custom configurations:

### Step 1: Install System Dependencies

```bash
# Update system
dnf update -y

# Install development tools
dnf groupinstall -y "Development Tools"
dnf install -y git curl wget unzip gcc-c++ make python3 python3-pip ffmpeg-free libsndfile-devel
```

### Step 2: Install Node.js 20

```bash
# Install NodeSource repository
curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
dnf install -y nodejs

# Verify installation
node --version
npm --version
```

### Step 3: Install PostgreSQL 15

```bash
# Install PostgreSQL repository
dnf install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-9-x86_64/pgdg-redhat-repo-latest.noarch.rpm

# Install PostgreSQL 15
dnf install -y postgresql15-server postgresql15

# Initialize and start PostgreSQL
/usr/pgsql-15/bin/postgresql-15-setup initdb
systemctl enable postgresql-15
systemctl start postgresql-15
```

### Step 4: Configure Database

```bash
# Create database and user
sudo -u postgres psql << 'EOF'
CREATE DATABASE waitumusic_db;
CREATE USER waitumusic_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE waitumusic_db TO waitumusic_user;
ALTER USER waitumusic_user CREATEDB;
\q
EOF
```

### Step 5: Deploy Application

```bash
# Create site directory
SITE_PATH="/usr/local/lsws/Example/html/yourdomain.com"
mkdir -p "$SITE_PATH"
cd "$SITE_PATH"

# Copy application files
cp -r /path/to/waitumusic-deploy/* .

# Install dependencies and build
npm install --production
npm run build

# Set permissions
chown -R lsadm:lsadm "$SITE_PATH"
chmod -R 755 "$SITE_PATH"
```

### Step 6: Configure Environment

Create `.env` file in your site directory:

```bash
cat > .env << 'EOF'
# Database Configuration
DATABASE_URL=postgresql://waitumusic_user:your_secure_password@localhost:5432/waitumusic_db
PGHOST=localhost
PGPORT=5432
PGDATABASE=waitumusic_db
PGUSER=waitumusic_user
PGPASSWORD=your_secure_password

# Application Configuration
NODE_ENV=production
PORT=5000
DOMAIN=yourdomain.com

# Security (generate new secrets)
JWT_SECRET=your_jwt_secret_here
SESSION_SECRET=your_session_secret_here

# Demo Mode
DEMO_MODE_ENABLED=false

# Email Configuration
SMTP_HOST=localhost
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
FROM_EMAIL=noreply@yourdomain.com
EOF

chmod 600 .env
chown lsadm:lsadm .env
```

### Step 7: Run Database Migrations

```bash
cd "$SITE_PATH"
npm run db:push
```

### Step 8: Create Systemd Service

```bash
cat > /etc/systemd/system/waitumusic.service << 'EOF'
[Unit]
Description=WaituMusic Platform
After=network.target postgresql-15.service
Wants=postgresql-15.service

[Service]
Type=simple
User=lsadm
Group=lsadm
WorkingDirectory=/usr/local/lsws/Example/html/yourdomain.com
Environment=NODE_ENV=production
EnvironmentFile=/usr/local/lsws/Example/html/yourdomain.com/.env
ExecStart=/usr/bin/node server/index.js
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=waitumusic

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable waitumusic
systemctl start waitumusic
```

### Step 9: Configure OpenLiteSpeed

1. Create virtual host in CyberPanel for your domain
2. Configure proxy to port 5000 for the Node.js application
3. Set up static file serving for `/uploads` and `/invoices`

## Configuration Options

### Email Setup

Configure SMTP settings in `.env` file:

```bash
# For Gmail
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
FROM_EMAIL=your-email@gmail.com

# For SendGrid
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASSWORD=your-sendgrid-api-key
FROM_EMAIL=noreply@yourdomain.com
```

### File Upload Configuration

Adjust file upload limits in `.env`:

```bash
MAX_FILE_SIZE=100MB
UPLOAD_PATH=/usr/local/lsws/Example/html/yourdomain.com/uploads
```

### Security Configuration

Generate secure secrets:

```bash
# Generate JWT secret
openssl rand -base64 64

# Generate session secret
openssl rand -base64 64
```

## Management Commands

### Service Management

```bash
# Start the service
systemctl start waitumusic

# Stop the service
systemctl stop waitumusic

# Restart the service
systemctl restart waitumusic

# Check service status
systemctl status waitumusic

# View logs
journalctl -u waitumusic -f
```

### Database Management

```bash
# Access PostgreSQL
sudo -u postgres psql waitumusic_db

# Backup database
pg_dump -U waitumusic_user -h localhost waitumusic_db > backup.sql

# Restore database
psql -U waitumusic_user -h localhost waitumusic_db < backup.sql
```

### Application Updates

```bash
# Navigate to application directory
cd /usr/local/lsws/Example/html/yourdomain.com

# Pull latest changes (if using git)
git pull origin main

# Install new dependencies
npm install --production

# Rebuild application
npm run build

# Run database migrations
npm run db:push

# Restart service
systemctl restart waitumusic
```

## Monitoring and Maintenance

### Log Files

Application logs are available through systemd:

```bash
# View real-time logs
journalctl -u waitumusic -f

# View logs from last hour
journalctl -u waitumusic --since="1 hour ago"

# View error logs only
journalctl -u waitumusic -p err
```

### Performance Monitoring

Monitor system resources:

```bash
# CPU and memory usage
htop

# Disk usage
df -h

# Database connections
sudo -u postgres psql -c "SELECT count(*) FROM pg_stat_activity;"
```

### Automated Backups

The installer creates daily backups at `/backups/waitumusic/`. Manual backup:

```bash
/usr/local/bin/waitumusic-backup.sh
```

## Troubleshooting

### Common Issues

**Service won't start:**
```bash
# Check service status
systemctl status waitumusic

# Check logs for errors
journalctl -u waitumusic -n 50
```

**Database connection errors:**
```bash
# Test database connection
sudo -u postgres psql waitumusic_db -c "SELECT version();"

# Check PostgreSQL status
systemctl status postgresql-15
```

**Port conflicts:**
```bash
# Check what's using port 5000
netstat -tulpn | grep :5000

# Kill process if needed
sudo kill -9 $(lsof -t -i:5000)
```

**Permission issues:**
```bash
# Fix file permissions
chown -R lsadm:lsadm /usr/local/lsws/Example/html/yourdomain.com
chmod -R 755 /usr/local/lsws/Example/html/yourdomain.com
```

### Getting Help

For technical support:
1. Check the application logs first
2. Verify all services are running
3. Test database connectivity
4. Check file permissions
5. Review environment configuration

## Security Considerations

### Essential Security Steps

1. **Change Default Passwords**: Update all default user passwords immediately
2. **Secure Database**: Use strong database passwords and restrict access
3. **SSL Certificate**: Always use HTTPS in production
4. **Firewall**: Configure firewall to allow only necessary ports
5. **Regular Updates**: Keep system and application updated
6. **Backup Strategy**: Implement regular, tested backups

### Recommended Security Hardening

```bash
# Disable demo mode
echo "DEMO_MODE_ENABLED=false" >> .env

# Set secure file permissions
chmod 600 .env
chmod -R 750 uploads/
chmod -R 750 invoices/

# Configure PostgreSQL for security
# Edit /var/lib/pgsql/15/data/pg_hba.conf to restrict access
```

## Production Optimization

### Performance Tuning

1. **Database Optimization**: Configure PostgreSQL for your server specs
2. **Node.js Optimization**: Use PM2 for production process management
3. **Static File Caching**: Configure OpenLiteSpeed caching
4. **Content Compression**: Enable gzip compression

### Scaling Considerations

For high-traffic deployments:
- Use a dedicated database server
- Implement Redis for session storage
- Set up load balancing
- Use CDN for static assets

## Conclusion

Your WaituMusic Platform is now ready for production use. The platform includes comprehensive music industry management features, user authentication, booking systems, and administrative tools.

Remember to:
- Change default passwords immediately
- Configure email settings for notifications
- Set up regular backups
- Monitor system performance
- Keep the application updated

For additional support or feature requests, consult the application documentation or contact technical support.