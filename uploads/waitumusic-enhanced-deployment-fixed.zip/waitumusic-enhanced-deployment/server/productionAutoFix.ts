// Production Auto-Fix Integration for server/index.ts
import { Request, Response, NextFunction } from 'express';
import { oppHubProductionFixer } from './oppHubProductionErrorFixer';

// Enhanced error handling middleware that integrates with existing system
export const enhancedErrorHandler = async (err: any, req: Request, res: Response, next: NextFunction) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";

  // OppHub Auto-Fix for production database errors
  if (process.env.NODE_ENV === 'production' && isDatabaseError(err)) {
    console.log('🤖 OppHub Production Auto-Fix: Database error detected');
    
    try {
      const fixResult = await oppHubProductionFixer.detectAndFixDatabaseErrors();
      
      if (fixResult.fixed && fixResult.solutions.length > 0) {
        console.log('🔧 OppHub Auto-Fix successful:', fixResult.solutions);
        
        // Log the fix
        await oppHubProductionFixer.logProductionIssue(err, `Auto-fixed: ${req.method} ${req.path}`);
        
        // Return success response with fix details
        return res.status(200).json({
          success: true,
          message: 'Database issue detected and automatically resolved',
          autoFixApplied: fixResult.solutions,
          originalError: message,
          retryAdvised: true
        });
      }
    } catch (autoFixError) {
      console.error('🚫 OppHub Auto-Fix failed:', autoFixError);
    }
  }

  // Learn from all server errors (existing functionality)
  if ((global as any).oppHubErrorLearning) {
    await (global as any).oppHubErrorLearning.learnFromError(err, 'express_server');
  }

  res.status(status).json({ message });
};

function isDatabaseError(error: any): boolean {
  const dbErrorPatterns = [
    'column does not exist',
    'relation does not exist', 
    'table does not exist',
    'foreign key violation',
    'invalid input syntax',
    'connection failed',
    'ECONNREFUSED',
    'ENOTFOUND',
    'Host: localhost. is not in the cert\'s altnames'
  ];
  
  return dbErrorPatterns.some(pattern => 
    error.message.toLowerCase().includes(pattern.toLowerCase())
  );
}

// Production startup health check
export async function performStartupHealthCheck() {
  if (process.env.NODE_ENV === 'production') {
    console.log('🤖 OppHub: Performing production startup health check...');
    
    try {
      const result = await oppHubProductionFixer.performComprehensiveHealthCheck();
      console.log(`🏥 Production Health Status: ${result.status.toUpperCase()}`);
      
      if (result.autoFixesApplied.length > 0) {
        console.log('🔧 Startup auto-fixes applied:', result.autoFixesApplied);
      }
      
      if (result.issues.length > 0) {
        console.log('⚠️ Issues detected (auto-fixing):', result.issues);
      }
      
      return result;
    } catch (error) {
      console.error('❌ Production health check failed:', error);
      return { status: 'critical', issues: [error.message], autoFixesApplied: [] };
    }
  }
  
  return { status: 'healthy', issues: [], autoFixesApplied: [] };
}