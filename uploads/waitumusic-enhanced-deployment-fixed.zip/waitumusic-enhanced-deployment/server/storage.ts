import {
  users, userProfiles, artists, musicians, professionals, songs, albums, merchandise,
  bookings, bookingDates, roles, managementTiers, events, documents,
  userInteractions, userPreferences, musicRecommendations, artistSimilarities,
  trendingMetrics, crossPromotionCampaigns,
  serviceCategories, services, serviceAssignments, userServices, serviceReviews,
  currencies, bundles, bundleItems, discountConditions, storeCurrencies, fanEngagement,
  adminAssignments, bookingAssignments, artistMusicianAssignments,
  bookingMediaFiles, bookingMediaAccess, bookingMediaCategories,
  releaseContracts, releaseContractSignatures, managementTransitions,
  managementApplications, managementApplicationSignatures, serviceDiscountOverrides,
  managementApplicationReviews, legalAssignments, applicationLegalAssignments,
  // Financial automation tables
  invoices, payoutRequests, documentLinkages, paymentTransactions, financialAuditLog,
  payments, receipts,
  // AI & Website Integration tables
  socialMediaCampaigns, competitiveIntelligence, websiteIntegrations, embeddableWidgets, careerForecasting, videos, userFavorites,
  // Enhanced splitsheet tables
  enhancedSplitsheets, enhancedSplitsheetNotifications, audioFileMetadata,
  // Press release tables
  pressReleases, pressReleaseAssignments, pressReleaseMedia, pressReleaseDistribution,
  type User, type InsertUser, type UserProfile, type InsertUserProfile,
  type Artist, type InsertArtist, type Musician, type InsertMusician,
  type Professional, type InsertProfessional, type Song, type InsertSong,
  type Album, type InsertAlbum, type Merchandise, type InsertMerchandise,
  type Booking, type InsertBooking, type Role, type ManagementTier,
  type Event, type Document, type UserInteraction, type InsertUserInteraction,
  type UserPreferences, type InsertUserPreferences, type MusicRecommendation, 
  type InsertMusicRecommendation, type ArtistSimilarity, type InsertArtistSimilarity,
  type TrendingMetric, type InsertTrendingMetric, type CrossPromotionCampaign,
  type InsertCrossPromotionCampaign, type ServiceCategory, type InsertServiceCategory,
  type Service, type InsertService, type ServiceAssignment, type InsertServiceAssignment,
  type UserService, type InsertUserService, type ServiceReview, type InsertServiceReview,
  type Currency, type InsertCurrency, type Bundle, type InsertBundle,
  type BundleItem, type InsertBundleItem, type DiscountCondition, type InsertDiscountCondition,
  type StoreCurrency, type InsertStoreCurrency, type FanEngagement, type InsertFanEngagement,
  type AdminAssignment, type InsertAdminAssignment, type BookingAssignment, type InsertBookingAssignment,
  type ArtistMusicianAssignment, type InsertArtistMusicianAssignment,
  type BookingMediaFile, type InsertBookingMediaFile, type BookingMediaAccess, type InsertBookingMediaAccess,
  type BookingMediaCategory, type InsertBookingMediaCategory,
  type ReleaseContract, type InsertReleaseContract, type ReleaseContractSignature, type InsertReleaseContractSignature,
  type ManagementTransition, type InsertManagementTransition,
  type ManagementApplication, type InsertManagementApplication, type ManagementApplicationSignature, type InsertManagementApplicationSignature,
  type ServiceDiscountOverride, type InsertServiceDiscountOverride,
  type ManagementApplicationReview, type InsertManagementApplicationReview, type LegalAssignment, type InsertLegalAssignment,
  type ApplicationLegalAssignment, type InsertApplicationLegalAssignment,
  // Financial automation types
  type Invoice, type InsertInvoice, type PayoutRequest, type InsertPayoutRequest,
  type DocumentLinkage, type InsertDocumentLinkage, type PaymentTransaction, type InsertPaymentTransaction,
  type FinancialAuditLog, type InsertFinancialAuditLog, type Payment, type InsertPayment,
  type Receipt, type InsertReceipt,
  // AI & Website Integration types
  type SocialMediaCampaign, type InsertSocialMediaCampaign, type CompetitiveIntelligence, type InsertCompetitiveIntelligence,
  type WebsiteIntegration, type InsertWebsiteIntegration, type EmbeddableWidget, type InsertEmbeddableWidget,
  type CareerForecasting, type InsertCareerForecasting, type Video, type InsertVideo,
  waituServiceDiscountLimits, individualDiscountPermissions, globalGenres, crossUpsellRelationships,
  globalProfessions, professionalAvailability, stagePlots, mixerPatchLists, setlistTemplates,
  playbackTracks, djAccess, playbackTrackDownloads, curators, curatorSubmissions, curatorEmailCampaigns,
  insertWaituServiceDiscountLimitSchema, insertIndividualDiscountPermissionSchema,
  type GlobalGenre, type InsertGlobalGenre, type CrossUpsellRelationship, type InsertCrossUpsellRelationship,
  // OppHub types
  opportunityCategories, opportunities, opportunityApplications, oppHubSubscriptions, 
  marketIntelligence, opportunitySources, opportunityMatches,
  type OpportunityCategory, type InsertOpportunityCategory, type Opportunity, type InsertOpportunity,
  type OpportunityApplication, type InsertOpportunityApplication, type OppHubSubscription, type InsertOppHubSubscription,
  type MarketIntelligence, type InsertMarketIntelligence, type OpportunitySource, type InsertOpportunitySource,
  type OpportunityMatch, type InsertOpportunityMatch,
  // PRO Registration types
  proRegistrations, proWorks, proEligibilityAssessments,
  type PRORegistration, type InsertPRORegistration, type PROWork, type InsertPROWork,
  type PROEligibilityAssessment, type InsertPROEligibilityAssessment,
  // Press release types
  type PressRelease, type InsertPressRelease, type PressReleaseAssignment, type InsertPressReleaseAssignment,
  type PressReleaseMedia, type InsertPressReleaseMedia, type PressReleaseDistribution, type InsertPressReleaseDistribution,
  // Professional booking assignments
  bookingProfessionalAssignments, oppHubProfessionalGuidance,
  // Technical rider and booking attachment types
  technicalRiderStages, bookingAttachments, bookingMessages,
  type TechnicalRiderStage, type InsertTechnicalRiderStage,
  type BookingAttachment, type InsertBookingAttachment,
  type BookingMessage, type InsertBookingMessage
} from "@shared/schema";
import { eq, and, or, desc, lte, gte, isNotNull, sql, inArray } from "drizzle-orm";
import { db } from "./db";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // User profiles
  getUserProfile(userId: number): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: number, updates: Partial<UserProfile>): Promise<UserProfile | undefined>;
  
  // Roles and management tiers
  getRoles(): Promise<Role[]>;
  getManagementTiers(): Promise<ManagementTier[]>;
  
  // Artists
  getArtist(userId: number): Promise<Artist | undefined>;
  getArtists(): Promise<Artist[]>;
  createArtist(artist: InsertArtist): Promise<Artist>;
  updateArtist(userId: number, updates: Partial<Artist>): Promise<Artist | undefined>;
  
  // Musicians
  getMusician(userId: number): Promise<Musician | undefined>;
  getMusicians(): Promise<Musician[]>;
  createMusician(musician: InsertMusician): Promise<Musician>;
  
  // Professionals
  getProfessional(userId: number): Promise<Professional | undefined>;
  getProfessionals(): Promise<Professional[]>;
  createProfessional(professional: InsertProfessional): Promise<Professional>;
  
  // Songs
  getSong(id: number): Promise<Song | undefined>;
  getSongs(): Promise<Song[]>;
  getSongsByArtist(artistUserId: number): Promise<Song[]>;
  createSong(song: InsertSong): Promise<Song>;
  updateSong(id: number, updates: Partial<Song>): Promise<Song | undefined>;
  deleteSong(id: number): Promise<void>;

  // Videos
  getVideo(id: number): Promise<Video | undefined>;
  getVideos(): Promise<Video[]>;
  getVideosByUser(userId: number): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, updates: Partial<Video>): Promise<Video | undefined>;
  deleteVideo(id: number): Promise<void>;
  
  // Albums
  getAlbum(id: number): Promise<Album | undefined>;
  getAlbums(): Promise<Album[]>;
  getAlbumsByArtist(artistUserId: number): Promise<Album[]>;
  createAlbum(album: InsertAlbum): Promise<Album>;
  updateAlbum(id: number, updates: Partial<Album>): Promise<Album | undefined>;
  deleteAlbum(id: number): Promise<boolean>;

  // Songs by album
  getSongsByAlbum(albumId: number): Promise<Song[]>;

  // Cross-Upsell Relationships
  getCrossUpsellRelationships(): Promise<CrossUpsellRelationship[]>;
  createCrossUpsellRelationship(relationship: InsertCrossUpsellRelationship): Promise<CrossUpsellRelationship>;
  getCrossUpsellsBySource(sourceType: string, sourceId: number): Promise<CrossUpsellRelationship[]>;
  deleteCrossUpsellRelationship(id: number): Promise<boolean>;
  
  // Merchandise
  getMerchandise(id?: number): Promise<Merchandise | Merchandise[] | undefined>;
  getMerchandiseByArtist(artistUserId: number): Promise<Merchandise[]>;
  getAllMerchandise(): Promise<Merchandise[]>;
  createMerchandise(merchandise: InsertMerchandise): Promise<Merchandise>;

  // Splitsheets - OppHub AI Learning: Music industry specific data management
  getSplitsheets(): Promise<any[]>;
  createSplitsheet(splitsheet: any): Promise<any>;
  
  // Contracts - OppHub AI Learning: Legal document management
  getContracts(): Promise<any[]>;
  createContract(contract: any): Promise<any>;
  
  // Technical Riders - OppHub AI Learning: Performance specification management  
  getTechnicalRiders(): Promise<any[]>;
  createTechnicalRider(technicalRider: any): Promise<any>;
  
  // ISRC Codes - OppHub AI Learning: Music identification code management
  getIsrcCodes(): Promise<any[]>;
  createIsrcCode(isrcCode: any): Promise<any>;
  
  // Newsletters - OppHub AI Learning: Marketing communication management
  getNewsletters(): Promise<any[]>;
  createNewsletter(newsletter: any): Promise<any>;
  
  // Bookings
  getBooking(id: number): Promise<Booking | undefined>;
  getBookings(): Promise<Booking[]>;
  getBookingsByUser(userId: number): Promise<Booking[]>;
  getAllBookings(): Promise<Booking[]>;
  getBookingsByArtist(artistUserId: number): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: number, status: string): Promise<Booking | undefined>;
  updateBooking(id: number, updates: Partial<Booking>): Promise<Booking | undefined>;

  // Setlists
  getSetlist(bookingId: number): Promise<any>;
  saveSetlist(bookingId: number, setlistData: any): Promise<any>;
  
  // All Users (for admin)
  getAllUsers(): Promise<User[]>;
  
  // Events
  getEventsByArtist(artistUserId: number): Promise<Event[]>;
  getEventsByUser(userId: number): Promise<Event[]>;
  getUpcomingEvents(): Promise<Event[]>;
  
  // Recommendation System
  // User Interactions
  createUserInteraction(interaction: InsertUserInteraction): Promise<UserInteraction>;
  getUserInteractions(userId: number): Promise<UserInteraction[]>;
  getAllUserInteractions(): Promise<UserInteraction[]>;
  
  // User Preferences
  getUserPreferences(userId: number): Promise<UserPreferences | undefined>;
  updateUserPreferences(userId: number, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences>;
  
  // Music Recommendations
  createMusicRecommendation(recommendation: InsertMusicRecommendation): Promise<MusicRecommendation>;
  getUserRecommendations(userId: number, limit?: number): Promise<MusicRecommendation[]>;
  clearUserRecommendations(userId: number): Promise<void>;
  updateRecommendationEngagement(recommendationId: number, engagementType: 'viewed' | 'clicked'): Promise<void>;
  
  // Artist Similarities
  createArtistSimilarity(similarity: InsertArtistSimilarity): Promise<ArtistSimilarity>;
  getArtistSimilarities(artistId: number): Promise<ArtistSimilarity[]>;
  getAllArtists(): Promise<Artist[]>;
  getArtistFans(artistId: number): Promise<number[]>;
  
  // Trending Metrics
  incrementTrendingMetric(metric: Partial<InsertTrendingMetric>): Promise<void>;
  getTrendingSongs(timeframe: string): Promise<Song[]>;
  
  // Cross Promotion
  getActiveCrossPromotionCampaigns(): Promise<CrossPromotionCampaign[]>;
  incrementCampaignImpressions(campaignId: number): Promise<void>;
  
  // Additional helper methods
  getSongsByGenre(genre: string): Promise<Song[]>;
  getUserByUsername(username: string): Promise<User | undefined>;

  // Service Management
  // Service Categories
  getServiceCategories(): Promise<ServiceCategory[]>;
  createServiceCategory(category: InsertServiceCategory): Promise<ServiceCategory>;
  
  // Admin Services
  getServices(): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, updates: Partial<Service>): Promise<Service | undefined>;
  deleteService(id: number): Promise<boolean>;
  
  // Service Assignments
  getServiceAssignments(): Promise<ServiceAssignment[]>;
  getServiceAssignmentsByUser(userId: number): Promise<ServiceAssignment[]>;
  getServiceAssignmentsByService(serviceId: number): Promise<ServiceAssignment[]>;
  createServiceAssignment(assignment: InsertServiceAssignment): Promise<ServiceAssignment>;
  updateServiceAssignment(id: number, updates: Partial<ServiceAssignment>): Promise<ServiceAssignment | undefined>;
  deleteServiceAssignment(id: number): Promise<boolean>;
  
  // User Services (self-created)
  getUserServices(userId: number): Promise<UserService[]>;
  getAllUserServices(): Promise<UserService[]>;
  getUserService(id: number): Promise<UserService | undefined>;
  createUserService(userService: InsertUserService): Promise<UserService>;
  updateUserService(id: number, updates: Partial<UserService>): Promise<UserService | undefined>;
  deleteUserService(id: number): Promise<boolean>;
  
  // Service Reviews
  getServiceReviews(serviceId?: number, userServiceId?: number): Promise<ServiceReview[]>;
  createServiceReview(review: InsertServiceReview): Promise<ServiceReview>;

  // Currency management
  getCurrencies(): Promise<Currency[]>;
  getCurrency(code: string): Promise<Currency | undefined>;
  createCurrency(currency: InsertCurrency): Promise<Currency>;
  updateCurrency(code: string, updates: Partial<Currency>): Promise<Currency | undefined>;
  updateCurrencyRate(code: string, rate: number): Promise<Currency | undefined>;
  
  // Store bundles
  getBundles(): Promise<Bundle[]>;
  getBundle(id: number): Promise<Bundle | undefined>;
  getBundlesByArtist(artistUserId: number): Promise<Bundle[]>;
  createBundle(bundle: InsertBundle): Promise<Bundle>;
  updateBundle(id: number, updates: Partial<Bundle>): Promise<Bundle | undefined>;
  
  // Bundle items
  getBundleItems(bundleId: number): Promise<BundleItem[]>;
  createBundleItem(item: InsertBundleItem): Promise<BundleItem>;
  deleteBundleItem(id: number): Promise<void>;
  
  // Discount conditions
  getDiscountConditions(bundleId: number): Promise<DiscountCondition[]>;
  createDiscountCondition(condition: InsertDiscountCondition): Promise<DiscountCondition>;
  updateDiscountCondition(id: number, updates: Partial<DiscountCondition>): Promise<DiscountCondition | undefined>;
  validateDiscountCondition(conditionId: number, userValue: string): Promise<boolean>;
  
  // Store currencies
  getStoreCurrencies(): Promise<StoreCurrency[]>;
  getStoreCurrency(code: string): Promise<StoreCurrency | undefined>;
  createStoreCurrency(currency: InsertStoreCurrency): Promise<StoreCurrency>;
  updateStoreCurrency(id: number, updates: Partial<StoreCurrency>): Promise<StoreCurrency | undefined>;
  
  // Fan engagement
  createFanEngagement(engagement: InsertFanEngagement): Promise<FanEngagement>;
  getFanEngagement(userId: number, artistUserId: number): Promise<FanEngagement[]>;
  
  // Assignment management - Admin assignments
  createAdminAssignment(assignment: InsertAdminAssignment): Promise<AdminAssignment>;
  getAdminAssignments(adminUserId?: number): Promise<AdminAssignment[]>;
  getAdminAssignment(id: number): Promise<AdminAssignment | undefined>;
  updateAdminAssignment(id: number, updates: Partial<AdminAssignment>): Promise<AdminAssignment | undefined>;
  removeAdminAssignment(id: number): Promise<void>;
  
  // Assignment management - Booking assignments  
  createBookingAssignment(assignment: InsertBookingAssignment): Promise<BookingAssignment>;
  getBookingAssignments(): Promise<BookingAssignment[]>;
  getBookingAssignmentsByBooking(bookingId: number): Promise<BookingAssignment[]>;
  getBookingAssignment(id: number): Promise<BookingAssignment | undefined>;
  updateBookingAssignment(id: number, updates: Partial<BookingAssignment>): Promise<BookingAssignment | undefined>;
  removeBookingAssignment(id: number): Promise<void>;
  
  // Assignment management - Artist-Musician assignments
  createArtistMusicianAssignment(assignment: InsertArtistMusicianAssignment): Promise<ArtistMusicianAssignment>;
  getArtistMusicianAssignments(artistUserId?: number): Promise<ArtistMusicianAssignment[]>;
  getArtistMusicianAssignmentsByTalent(managedTalentId: number): Promise<ArtistMusicianAssignment[]>;
  getArtistMusicianAssignmentsByAssignee(assigneeId: number): Promise<ArtistMusicianAssignment[]>;
  getArtistMusicianAssignmentsByUser(userId: number): Promise<ArtistMusicianAssignment[]>;
  getArtistMusicianAssignment(id: number): Promise<ArtistMusicianAssignment | undefined>;
  updateArtistMusicianAssignment(id: number, updates: Partial<ArtistMusicianAssignment>): Promise<ArtistMusicianAssignment | undefined>;
  removeArtistMusicianAssignment(id: number): Promise<void>;
  
  // Assignment management - Service assignments
  createServiceAssignment(assignment: InsertServiceAssignment): Promise<ServiceAssignment>;
  getServiceAssignments(): Promise<ServiceAssignment[]>;
  getServiceAssignmentsByService(serviceId: number): Promise<ServiceAssignment[]>;
  getServiceAssignmentsByTalent(assignedTalentId: number): Promise<ServiceAssignment[]>;
  getServiceAssignment(id: number): Promise<ServiceAssignment | undefined>;
  updateServiceAssignment(id: number, updates: Partial<ServiceAssignment>): Promise<ServiceAssignment | undefined>;
  removeServiceAssignment(id: number): Promise<void>;
  
  // Booking Media Management
  createBookingMediaFile(file: InsertBookingMediaFile): Promise<BookingMediaFile>;
  getBookingMediaFiles(bookingId: number): Promise<BookingMediaFile[]>;
  getBookingMediaFile(id: number): Promise<BookingMediaFile | undefined>;
  updateBookingMediaFile(id: number, updates: Partial<BookingMediaFile>): Promise<BookingMediaFile | undefined>;
  deleteBookingMediaFile(id: number): Promise<void>;
  
  // Booking Media Access Control
  createBookingMediaAccess(access: InsertBookingMediaAccess): Promise<BookingMediaAccess>;
  getBookingMediaAccess(mediaFileId: number): Promise<BookingMediaAccess[]>;
  getUserBookingMediaAccess(userId: number, mediaFileId: number): Promise<BookingMediaAccess | undefined>;
  updateBookingMediaAccess(id: number, updates: Partial<BookingMediaAccess>): Promise<BookingMediaAccess | undefined>;
  removeBookingMediaAccess(id: number): Promise<void>;
  checkUserMediaAccess(userId: number, mediaFileId: number, requiredLevel: string): Promise<boolean>;
  
  // Booking Media Categories
  getBookingMediaCategories(): Promise<BookingMediaCategory[]>;
  createBookingMediaCategory(category: InsertBookingMediaCategory): Promise<BookingMediaCategory>;
  updateBookingMediaCategory(id: number, updates: Partial<BookingMediaCategory>): Promise<BookingMediaCategory | undefined>;
  
  // Release Contract Management
  createReleaseContract(contract: InsertReleaseContract): Promise<ReleaseContract>;
  getReleaseContract(id: number): Promise<ReleaseContract | undefined>;
  getReleaseContractsByUser(userId: number): Promise<ReleaseContract[]>;
  getPendingReleaseContracts(): Promise<ReleaseContract[]>;
  updateReleaseContract(id: number, updates: Partial<ReleaseContract>): Promise<ReleaseContract | undefined>;
  createReleaseContractSignature(signature: InsertReleaseContractSignature): Promise<ReleaseContractSignature>;
  getReleaseContractSignatures(contractId: number): Promise<ReleaseContractSignature[]>;
  createManagementTransition(transition: InsertManagementTransition): Promise<ManagementTransition>;
  getManagementTransitions(userId: number): Promise<ManagementTransition[]>;
  
  // Management Application System
  createManagementApplication(application: InsertManagementApplication): Promise<ManagementApplication>;
  getManagementApplication(id: number): Promise<ManagementApplication | undefined>;
  getManagementApplicationsByUser(userId: number): Promise<ManagementApplication[]>;
  getPendingManagementApplications(): Promise<ManagementApplication[]>;
  updateManagementApplication(id: number, updates: Partial<ManagementApplication>): Promise<ManagementApplication | undefined>;
  createManagementApplicationSignature(signature: InsertManagementApplicationSignature): Promise<ManagementApplicationSignature>;
  getManagementApplicationSignatures(applicationId: number): Promise<ManagementApplicationSignature[]>;
  
  // Service Discount Management
  createServiceDiscountOverride(override: InsertServiceDiscountOverride): Promise<ServiceDiscountOverride>;
  getServiceDiscountOverrides(userId: number): Promise<ServiceDiscountOverride[]>;
  getServiceDiscountOverride(userId: number, serviceId?: number, userServiceId?: number): Promise<ServiceDiscountOverride | undefined>;
  updateServiceDiscountOverride(id: number, updates: Partial<ServiceDiscountOverride>): Promise<ServiceDiscountOverride | undefined>;
  getMaxDiscountForUser(userId: number): Promise<number>;
  
  // Management Application Review System
  createManagementApplicationReview(review: InsertManagementApplicationReview): Promise<ManagementApplicationReview>;
  getManagementApplicationReviews(applicationId: number): Promise<ManagementApplicationReview[]>;
  getManagementApplicationsByAssignedAdmin(adminUserId: number): Promise<ManagementApplication[]>;
  
  // Legal Assignment System
  createLegalAssignment(assignment: InsertLegalAssignment): Promise<LegalAssignment>;
  getLegalAssignments(clientUserId: number): Promise<LegalAssignment[]>;
  getLawyerClients(lawyerUserId: number): Promise<LegalAssignment[]>;
  getAssignedLawyer(clientUserId: number, assignmentType?: string): Promise<LegalAssignment | undefined>;
  
  // Application Legal Assignment System (Lawyers representing Wai'tuMusic)
  createApplicationLegalAssignment(assignment: InsertApplicationLegalAssignment): Promise<ApplicationLegalAssignment>;
  getApplicationLegalAssignments(applicationId: number): Promise<ApplicationLegalAssignment[]>;
  getApplicationsByAssignedLawyer(lawyerUserId: number): Promise<ApplicationLegalAssignment[]>;
  removeApplicationLegalAssignment(assignmentId: number): Promise<void>;
  checkLegalConflictOfInterest(lawyerUserId: number): Promise<{ hasConflict: boolean; conflictDetails?: any[] }>;
  getAvailableLawyersForWaituMusic(): Promise<any[]>;

  // System data
  getSystemSettings(): Promise<any[]>;
  getActivityLogs(): Promise<any[]>;

  // Stage Plots
  getStagePlots(): Promise<any[]>;
  getStagePlot(id: number): Promise<any>;
  createStagePlot(stagePlot: any): Promise<any>;
  updateStagePlot(id: number, updates: any): Promise<any>;
  deleteStagePlot(id: number): Promise<void>;

  // Mixer Patch Lists
  getMixerPatchLists(): Promise<any[]>;
  getMixerPatchList(id: number): Promise<any>;
  createMixerPatchList(patchList: any): Promise<any>;
  updateMixerPatchList(id: number, updates: any): Promise<any>;
  deleteMixerPatchList(id: number): Promise<void>;

  // Setlist Templates
  getSetlistTemplates(): Promise<any[]>;
  getSetlistTemplate(id: number): Promise<any>;
  createSetlistTemplate(template: any): Promise<any>;
  updateSetlistTemplate(id: number, updates: any): Promise<any>;
  deleteSetlistTemplate(id: number): Promise<void>;

  // Financial Automation - Invoice Management
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  getInvoice(id: number): Promise<Invoice | undefined>;
  getInvoiceById(id: number): Promise<Invoice | undefined>;
  getAllInvoices(): Promise<Invoice[]>;
  getInvoicesByBooking(bookingId: number): Promise<Invoice[]>;
  updateInvoiceStatus(id: number, status: string): Promise<Invoice | undefined>;
  generateInvoiceNumber(): Promise<string>;
  
  // Financial Automation - Payout Request Management
  createPayoutRequest(payoutRequest: InsertPayoutRequest): Promise<PayoutRequest>;
  getPayoutRequest(id: number): Promise<PayoutRequest | undefined>;
  getAllPayoutRequests(): Promise<PayoutRequest[]>;
  getPayoutRequestsByBooking(bookingId: number): Promise<PayoutRequest[]>;
  getPayoutRequestsByPerformer(performerUserId: number): Promise<PayoutRequest[]>;
  updatePayoutRequestStatus(id: number, status: string): Promise<PayoutRequest | undefined>;
  generatePayoutRequestNumber(): Promise<string>;
  
  // Financial Automation - Document Linkage System
  createDocumentLinkage(linkage: InsertDocumentLinkage): Promise<DocumentLinkage>;
  getDocumentLinkages(sourceType: string, sourceId: number): Promise<DocumentLinkage[]>;
  getLinkedDocuments(documentType: string, documentId: number): Promise<DocumentLinkage[]>;
  
  // Financial Automation - Payment Transaction Tracking
  createPaymentTransaction(transaction: InsertPaymentTransaction): Promise<PaymentTransaction>;
  getPaymentTransaction(id: number): Promise<PaymentTransaction | undefined>;
  getPaymentTransactionsByBooking(bookingId: number): Promise<PaymentTransaction[]>;
  getPaymentTransactionsByInvoice(invoiceId: number): Promise<PaymentTransaction[]>;
  updatePaymentTransactionStatus(id: number, status: string): Promise<PaymentTransaction | undefined>;
  
  // Financial Automation - Audit Trail
  createFinancialAuditLog(auditLog: InsertFinancialAuditLog): Promise<FinancialAuditLog>;
  getFinancialAuditLogs(entityType: string, entityId: number): Promise<FinancialAuditLog[]>;
  
  // Financial Automation - Payments & Receipts (Enhanced)
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPayment(id: number): Promise<Payment | undefined>;
  getPaymentsByBooking(bookingId: number): Promise<Payment[]>;
  updatePaymentStatus(id: number, status: string): Promise<Payment | undefined>;
  
  createReceipt(receipt: InsertReceipt): Promise<Receipt>;
  getReceipt(id: number): Promise<Receipt | undefined>;
  getReceiptsByBooking(bookingId: number): Promise<Receipt[]>;
  generateReceiptNumber(): Promise<string>;

  // AI-Powered Social Media Campaign Management
  createSocialMediaCampaign(campaign: InsertSocialMediaCampaign): Promise<SocialMediaCampaign>;
  getSocialMediaCampaign(id: number): Promise<SocialMediaCampaign | undefined>;
  getSocialMediaCampaignsByUser(userId: number): Promise<SocialMediaCampaign[]>;
  getAllSocialMediaCampaigns(): Promise<SocialMediaCampaign[]>;
  updateSocialMediaCampaign(id: number, updates: Partial<SocialMediaCampaign>): Promise<SocialMediaCampaign | undefined>;
  deleteSocialMediaCampaign(id: number): Promise<void>;

  // Competitive Intelligence System
  createCompetitiveIntelligence(intelligence: InsertCompetitiveIntelligence): Promise<CompetitiveIntelligence>;
  getCompetitiveIntelligence(id: number): Promise<CompetitiveIntelligence | undefined>;
  getCompetitiveIntelligenceByArtist(artistId: number): Promise<CompetitiveIntelligence[]>;
  getCompetitiveIntelligenceByRegion(region: string): Promise<CompetitiveIntelligence[]>;
  updateCompetitiveIntelligence(id: number, updates: Partial<CompetitiveIntelligence>): Promise<CompetitiveIntelligence | undefined>;
  deleteCompetitiveIntelligence(id: number): Promise<void>;

  // Website Integration (All-Links Solution)
  createWebsiteIntegration(integration: InsertWebsiteIntegration): Promise<WebsiteIntegration>;
  getWebsiteIntegration(id: number): Promise<WebsiteIntegration | undefined>;
  getWebsiteIntegrationBySlug(slug: string): Promise<WebsiteIntegration | undefined>;
  getWebsiteIntegrationsByUser(userId: number): Promise<WebsiteIntegration[]>;
  getAllWebsiteIntegrations(): Promise<WebsiteIntegration[]>;
  updateWebsiteIntegration(id: number, updates: Partial<WebsiteIntegration>): Promise<WebsiteIntegration | undefined>;
  deleteWebsiteIntegration(id: number): Promise<void>;
  incrementWebsiteViews(id: number): Promise<void>;
  incrementWebsiteClicks(id: number): Promise<void>;

  // Embeddable Widgets System
  createEmbeddableWidget(widget: InsertEmbeddableWidget): Promise<EmbeddableWidget>;
  getEmbeddableWidget(id: number): Promise<EmbeddableWidget | undefined>;
  getEmbeddableWidgetsByUser(userId: number): Promise<EmbeddableWidget[]>;
  getAllEmbeddableWidgets(): Promise<EmbeddableWidget[]>;
  updateEmbeddableWidget(id: number, updates: Partial<EmbeddableWidget>): Promise<EmbeddableWidget | undefined>;
  deleteEmbeddableWidget(id: number): Promise<void>;
  updateWidgetUsageStats(id: number, stats: any): Promise<void>;

  // Career Forecasting System
  createCareerForecasting(forecasting: InsertCareerForecasting): Promise<CareerForecasting>;
  getCareerForecasting(id: number): Promise<CareerForecasting | undefined>;
  getCareerForecastingByUser(userId: number): Promise<CareerForecasting[]>;
  getCareerForecastingByPeriod(period: string): Promise<CareerForecasting[]>;
  updateCareerForecasting(id: number, updates: Partial<CareerForecasting>): Promise<CareerForecasting | undefined>;
  deleteCareerForecasting(id: number): Promise<void>;

  // OppHub - Opportunity Hub operations
  getOpportunityCategories(): Promise<OpportunityCategory[]>;
  createOpportunityCategory(category: InsertOpportunityCategory): Promise<OpportunityCategory>;
  updateOpportunityCategory(id: number, updates: Partial<InsertOpportunityCategory>): Promise<OpportunityCategory | null>;

  getOpportunities(filters?: { status?: string }): Promise<Opportunity[]>;
  createOpportunity(opportunity: InsertOpportunity): Promise<Opportunity>;
  getOpportunityById(id: number): Promise<Opportunity | null>;
  updateOpportunity(id: number, updates: Partial<InsertOpportunity>): Promise<Opportunity | null>;
  deleteOpportunity(id: number): Promise<boolean>;
  incrementOpportunityViews(id: number): Promise<void>;

  getOpportunityApplications(filters?: { opportunityId?: number; applicantUserId?: number }): Promise<OpportunityApplication[]>;
  createOpportunityApplication(application: InsertOpportunityApplication): Promise<OpportunityApplication>;
  getOpportunityApplicationById(id: number): Promise<OpportunityApplication | null>;
  updateOpportunityApplicationStatus(id: number, status: string, reviewNotes?: string, reviewedBy?: number): Promise<OpportunityApplication | null>;

  getOppHubSubscriptions(filters?: { userId?: number; status?: string }): Promise<OppHubSubscription[]>;
  createOppHubSubscription(subscription: InsertOppHubSubscription): Promise<OppHubSubscription>;
  getOppHubSubscriptionByUserId(userId: number): Promise<OppHubSubscription | null>;
  updateOppHubSubscription(id: number, updates: Partial<InsertOppHubSubscription>): Promise<OppHubSubscription | null>;
  incrementApplicationsUsed(userId: number): Promise<void>;

  getMarketIntelligence(filters?: { status?: string; sourceType?: string }): Promise<MarketIntelligence[]>;
  createMarketIntelligence(intelligence: InsertMarketIntelligence): Promise<MarketIntelligence>;
  updateMarketIntelligenceStatus(id: number, status: string, reviewNotes?: string, reviewedBy?: number): Promise<MarketIntelligence | null>;

  getOpportunitySources(): Promise<OpportunitySource[]>;
  createOpportunitySource(source: InsertOpportunitySource): Promise<OpportunitySource>;
  updateOpportunitySourceLastScraped(id: number, opportunitiesFound: number): Promise<void>;

  getOpportunityMatches(filters?: { artistId?: number; opportunityId?: number }): Promise<OpportunityMatch[]>;
  createOpportunityMatch(match: InsertOpportunityMatch): Promise<OpportunityMatch>;
  updateOpportunityMatchInteraction(id: number, interactionType: string): Promise<void>;

  // PRO Registration methods
  getPRORegistrations(userId?: number): Promise<PRORegistration[]>;
  createPRORegistration(registration: InsertPRORegistration): Promise<PRORegistration>;
  getPRORegistrationById(id: number): Promise<PRORegistration | null>;
  updatePRORegistration(id: number, updates: Partial<InsertPRORegistration>): Promise<PRORegistration | null>;
  getPROWorks(proRegistrationId: number): Promise<PROWork[]>;
  createPROWork(work: InsertPROWork): Promise<PROWork>;
  updatePROWork(id: number, updates: Partial<InsertPROWork>): Promise<PROWork | null>;
  createPROEligibilityAssessment(assessment: InsertPROEligibilityAssessment): Promise<PROEligibilityAssessment>;
  getPROEligibilityAssessment(userId: number): Promise<PROEligibilityAssessment | null>;

  // Press Release Management
  getPressReleases(filters?: { artistId?: number; status?: string }): Promise<PressRelease[]>;
  createPressRelease(pressRelease: InsertPressRelease): Promise<PressRelease>;
  getPressReleaseById(id: number): Promise<PressRelease | null>;
  updatePressRelease(id: number, updates: Partial<InsertPressRelease>): Promise<PressRelease | null>;
  deletePressRelease(id: number): Promise<boolean>;
  publishPressRelease(id: number, publishedBy: number): Promise<PressRelease | null>;

  // Press Release Assignments
  getPressReleaseAssignments(pressReleaseId: number): Promise<PressReleaseAssignment[]>;
  createPressReleaseAssignment(assignment: InsertPressReleaseAssignment): Promise<PressReleaseAssignment>;
  deletePressReleaseAssignment(id: number): Promise<boolean>;

  // Press Release Media
  getPressReleaseMedia(pressReleaseId: number): Promise<PressReleaseMedia[]>;
  createPressReleaseMedia(media: InsertPressReleaseMedia): Promise<PressReleaseMedia>;
  updatePressReleaseMedia(id: number, updates: Partial<InsertPressReleaseMedia>): Promise<PressReleaseMedia | null>;
  deletePressReleaseMedia(id: number): Promise<boolean>;

  // Press Release Distribution
  getPressReleaseDistribution(pressReleaseId: number): Promise<PressReleaseDistribution[]>;
  createPressReleaseDistribution(distribution: InsertPressReleaseDistribution): Promise<PressReleaseDistribution>;
  updatePressReleaseDistributionStatus(id: number, status: string, responseType?: string): Promise<PressReleaseDistribution | null>;

  // Album-Merchandise Assignment System (Post-Upload Ingenious Workflow)
  getAlbumMerchandiseAssignments(albumId?: number): Promise<any[]>;
  createAlbumMerchandiseAssignment(assignment: any): Promise<any>;
  removeAlbumMerchandiseAssignment(id: number): Promise<void>;
  getAssignmentsByMerchandise(merchandiseId: number): Promise<any[]>;
}

export class MemStorage {
  // Note: MemStorage is simplified for demo purposes - many methods throw "not implemented" errors
  private users: Map<number, User>;
  private userProfiles: Map<number, UserProfile>;
  private artists: Map<number, Artist>;
  private musicians: Map<number, Musician>;
  private professionals: Map<number, Professional>;
  private songs: Map<number, Song>;
  private albums: Map<number, Album>;
  private merchandise: Map<number, Merchandise>;
  private bookings: Map<number, Booking>;
  private roles: Role[];
  private managementTiers: ManagementTier[];
  private events: Map<number, Event>;
  private documents: Map<number, Document>;
  
  private currentUserId: number;
  private currentSongId: number;
  private currentAlbumId: number;
  private currentMerchandiseId: number;
  private currentBookingId: number;
  private currentEventId: number;
  private currentDocumentId: number;

  constructor() {
    this.users = new Map();
    this.userProfiles = new Map();
    this.artists = new Map();
    this.musicians = new Map();
    this.professionals = new Map();
    this.songs = new Map();
    this.albums = new Map();
    this.merchandise = new Map();
    this.bookings = new Map();
    this.events = new Map();
    this.documents = new Map();
    
    // Initialize demo data
    this.initializeDemoBookings();
    
    this.currentUserId = 1;
    this.currentSongId = 1;
    this.currentAlbumId = 1;
    this.currentMerchandiseId = 1;
    this.currentBookingId = 1;
    this.currentEventId = 1;
    this.currentDocumentId = 1;
    
    // Initialize default roles and management tiers
    this.roles = [
      { id: 1, name: "superadmin" },
      { id: 2, name: "admin" },
      { id: 3, name: "managed_artist" },
      { id: 4, name: "artist" },
      { id: 5, name: "managed_musician" },
      { id: 6, name: "musician" },
      { id: 7, name: "managed_professional" },
      { id: 8, name: "professional" },
      { id: 9, name: "fan" }
    ];
    
    this.managementTiers = [
      { 
        id: 1, 
        name: "Publisher", 
        description: "We publish your music worldwide. Full creative control, standard service fees.",
        maxDiscountPercentage: 10,
        appliesTo: ['artist', 'musician']
      },
      { 
        id: 2, 
        name: "Representation", 
        description: "We handle your music business professionally without managing your career. Enjoy discounted services and industry representation.",
        maxDiscountPercentage: 50,
        appliesTo: ['artist', 'musician', 'professional']
      },
      { 
        id: 3, 
        name: "Full Management", 
        description: "Our team takes full responsibility for your career development, music releases, and strategic growth—with services included at no extra cost.",
        maxDiscountPercentage: 100,
        appliesTo: ['artist', 'musician', 'professional']
      }
    ];
    
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Create demo superadmin user
    const superadmin: User = {
      id: this.currentUserId++,
      email: "superadmin@waitumusic.com",
      passwordHash: "$2b$10$B7kd9KfBfyE1iyK8WuDzIOo/175.TnJBGVeRpszv4UdrIbC/aBfPO", // secret123
      fullName: "Super Administrator",
      roleId: 1,
      status: "active",
      secondaryRoles: [],
      isDemo: true,
      createdAt: new Date(),
      lastLogin: null
    };
    this.users.set(superadmin.id, superadmin);

    // Create demo artist
    const artist: User = {
      id: this.currentUserId++,
      email: "sarah@waitumusic.com",
      passwordHash: "$2b$10$B7kd9KfBfyE1iyK8WuDzIOo/175.TnJBGVeRpszv4UdrIbC/aBfPO", // secret123
      fullName: "Sarah Chen",
      roleId: 3,
      status: "active",
      secondaryRoles: [],
      isDemo: true,
      createdAt: new Date(),
      lastLogin: null
    };
    this.users.set(artist.id, artist);

    // Create artist profile
    const artistProfile: Artist = {
      userId: artist.id,
      stageNames: ["Sarah Chen Quartet", "The Sarah Chen Experience"],
      primaryGenre: "Jazz",
      secondaryGenres: ["Neo-Soul", "Contemporary Jazz"],
      topGenres: ["Jazz", "Neo-Soul"],
      socialMediaHandles: {},
      basePrice: "1500.00",
      managementTierId: 1,
      isManaged: true,
      bookingFormPictureUrl: null,
      performingRightsOrganization: null,
      ipiNumber: null,
      technicalRiderProfile: null
    };
    this.artists.set(artist.id, artistProfile);

    // Create demo musicians
    const musician1: User = {
      id: this.currentUserId++,
      email: "marcus@waitumusic.com",
      passwordHash: "$2b$10$B7kd9KfBfyE1iyK8WuDzIOo/175.TnJBGVeRpszv4UdrIbC/aBfPO", // secret123
      fullName: "Marcus Thompson",
      roleId: 5,
      status: "active",
      secondaryRoles: [],
      isDemo: true,
      createdAt: new Date(),
      lastLogin: null
    };
    this.users.set(musician1.id, musician1);

    const musicianProfile1: Musician = {
      userId: musician1.id,
      stageNames: ["Marcus T", "Marcus Thompson"],
      primaryGenre: "R&B",
      secondaryGenres: ["Jazz", "Soul"],
      topGenres: ["R&B", "Jazz"],
      socialMediaHandles: {},
      basePrice: "800.00",
      idealPerformanceRate: "800.00",
      minimumAcceptableRate: "75.00",
      managementTierId: 2,
      isManaged: true,
      bookingFormPictureUrl: null,
      instruments: ["Bass Guitar", "Upright Bass"],
      performingRightsOrganization: null,
      ipiNumber: null,
      technicalRiderProfile: null
    };
    this.musicians.set(musician1.id, musicianProfile1);

    const musician2: User = {
      id: this.currentUserId++,
      email: "alex@waitumusic.com",
      passwordHash: "$2b$10$B7kd9KfBfyE1iyK8WuDzIOo/175.TnJBGVeRpszv4UdrIbC/aBfPO", // secret123
      fullName: "Alex Rivera",
      roleId: 6,
      status: "active",
      secondaryRoles: [],
      isDemo: true,
      createdAt: new Date(),
      lastLogin: null
    };
    this.users.set(musician2.id, musician2);

    const musicianProfile2: Musician = {
      userId: musician2.id,
      stageNames: ["Alex Rivera", "A. Rivera"],
      primaryGenre: "Rock",
      secondaryGenres: ["Blues", "Alternative"],
      topGenres: ["Rock", "Blues"],
      socialMediaHandles: {},
      basePrice: "600.00",
      idealPerformanceRate: "600.00",
      minimumAcceptableRate: "60.00",
      managementTierId: null,
      isManaged: false,
      bookingFormPictureUrl: null,
      instruments: ["Drums", "Percussion"],
      performingRightsOrganization: null,
      ipiNumber: null,
      technicalRiderProfile: null
    };
    this.musicians.set(musician2.id, musicianProfile2);
  }

  private initializeDemoBookings() {
    // Demo booking 1
    const booking1: Booking = {
      id: 1,
      clientName: "Wedding Celebration Inc",
      clientEmail: "sarah@weddingcelebration.com",
      eventName: "Sarah & Mike's Wedding Reception", 
      eventDate: "2025-08-15",
      eventTime: "19:00",
      venueName: "Grand Ballroom Hotel",
      venueAddress: "123 Main St, Los Angeles, CA",
      eventType: "Wedding",
      guestCount: 150,
      duration: "4 hours",
      specificRequirements: "First dance at 8pm, acoustic ceremony set needed",
      totalBudget: "5000.00",
      status: "pending",
      createdAt: new Date(),
      bookerUserId: 2,
      primaryArtistUserId: 2,
      assignedMusicians: [],
      contracts: [],
      payments: [],
      signatures: []
    };
    this.bookings.set(1, booking1);

    // Demo booking 2  
    const booking2: Booking = {
      id: 2,
      clientName: "Corporate Events LLC",
      clientEmail: "events@corporateevents.com", 
      eventName: "Annual Company Gala",
      eventDate: "2025-09-20",
      eventTime: "18:30",
      venueName: "Convention Center",
      venueAddress: "456 Business Ave, New York, NY",
      eventType: "Corporate",
      guestCount: 300,
      duration: "3 hours",
      specificRequirements: "Background music during dinner, energetic dance set after 9pm",
      totalBudget: "8000.00", 
      status: "confirmed",
      createdAt: new Date(),
      bookerUserId: 3,
      primaryArtistUserId: 3,
      assignedMusicians: [4],
      contracts: [],
      payments: [],
      signatures: []
    };
    this.bookings.set(2, booking2);

    this.currentBookingId = 3;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  // Enhanced splitsheet methods for comprehensive user assignment and workflow
  async createEnhancedSplitsheet(data: any): Promise<any> {
    try {
      const [splitsheet] = await db.insert(enhancedSplitsheets).values(data).returning();
      return splitsheet;
    } catch (error) {
      console.error('Error creating enhanced splitsheet:', error);
      throw error;
    }
  }

  async getEnhancedSplitsheet(id: number): Promise<any> {
    try {
      const [splitsheet] = await db.select().from(enhancedSplitsheets).where(eq(enhancedSplitsheets.id, id));
      return splitsheet;
    } catch (error) {
      console.error('Error fetching enhanced splitsheet:', error);
      return null;
    }
  }

  async updateEnhancedSplitsheet(id: number, data: any): Promise<any> {
    try {
      const [updated] = await db.update(enhancedSplitsheets)
        .set(data)
        .where(eq(enhancedSplitsheets.id, id))
        .returning();
      return updated;
    } catch (error) {
      console.error('Error updating enhanced splitsheet:', error);
      throw error;
    }
  }

  async getUserEnhancedSplitsheets(userId: number): Promise<any[]> {
    try {
      // Get splitsheets where user is creator or participant
      const splitsheets = await db.select()
        .from(enhancedSplitsheets)
        .where(
          or(
            eq(enhancedSplitsheets.createdBy, userId),
            sql`EXISTS (
              SELECT 1 FROM jsonb_array_elements(participants) AS p 
              WHERE (p->>'assignedUserId')::int = ${userId}
            )`
          )
        )
        .orderBy(desc(enhancedSplitsheets.createdAt));
      
      return splitsheets;
    } catch (error) {
      console.error('Error fetching user enhanced splitsheets:', error);
      return [];
    }
  }

  async createEnhancedSplitsheetNotification(data: any): Promise<any> {
    try {
      const [notification] = await db.insert(enhancedSplitsheetNotifications).values(data).returning();
      return notification;
    } catch (error) {
      console.error('Error creating splitsheet notification:', error);
      throw error;
    }
  }

  async updateEnhancedSplitsheetNotification(id: number, data: any): Promise<any> {
    try {
      const [updated] = await db.update(enhancedSplitsheetNotifications)
        .set(data)
        .where(eq(enhancedSplitsheetNotifications.id, id))
        .returning();
      return updated;
    } catch (error) {
      console.error('Error updating splitsheet notification:', error);
      throw error;
    }
  }

  async createAudioFileMetadata(data: any): Promise<any> {
    try {
      const [metadata] = await db.insert(audioFileMetadata).values(data).returning();
      return metadata;
    } catch (error) {
      console.error('Error creating audio file metadata:', error);
      throw error;
    }
  }

  async getAudioFileMetadata(enhancedSplitsheetId: number): Promise<any> {
    try {
      const [metadata] = await db.select()
        .from(audioFileMetadata)
        .where(eq(audioFileMetadata.enhancedSplitsheetId, enhancedSplitsheetId));
      return metadata;
    } catch (error) {
      console.error('Error fetching audio file metadata:', error);
      return null;
    }
  }

  async searchAssignableTalent(search: string): Promise<any[]> {
    try {
      if (!search || search.length < 3) {
        return [];
      }

      // Search for users with talent roles
      const talentUsers = await db.select({
        id: users.id,
        fullName: users.fullName,
        email: users.email,
        roleId: users.roleId
      })
      .from(users)
      .where(
        and(
          inArray(users.roleId, [3, 4, 5, 6, 7, 8]), // Artist, Managed Artist, Musician, Managed Musician, Professional, Managed Professional
          or(
            sql`LOWER(${users.fullName}) LIKE LOWER(${`%${search}%`})`,
            sql`LOWER(${users.email}) LIKE LOWER(${`%${search}%`})`
          )
        )
      )
      .limit(10);

      return talentUsers;
    } catch (error) {
      console.error('Error searching assignable talent:', error);
      return [];
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      id,
      email: insertUser.email,
      passwordHash: insertUser.passwordHash,
      fullName: insertUser.fullName,
      roleId: insertUser.roleId,
      status: insertUser.status || "active",
      secondaryRoles: insertUser.secondaryRoles || [],
      isDemo: insertUser.isDemo || false,
      createdAt: new Date(),
      lastLogin: null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getUserProfile(userId: number): Promise<UserProfile | undefined> {
    // Return undefined for MemStorage since we don't have user profiles in memory
    return undefined;
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const userProfile: UserProfile = {
      userId: profile.userId,
      bio: profile.bio || null,
      avatarUrl: profile.avatarUrl || null,
      coverImageUrl: profile.coverImageUrl || null,
      socialLinks: profile.socialLinks || null,
      websiteUrl: profile.websiteUrl || null,
      phoneNumber: profile.phoneNumber || null,
      isRegisteredWithPRO: profile.isRegisteredWithPRO || false,
      performingRightsOrganization: profile.performingRightsOrganization || null,
      ipiNumber: profile.ipiNumber || null,
      technicalRequirements: profile.technicalRequirements || null,
      hospitalityRequirements: profile.hospitalityRequirements || null,
      performanceSpecs: profile.performanceSpecs || null,
      accessLevel: profile.accessLevel || "public"
    };
    this.userProfiles.set(profile.userId, userProfile);
    return userProfile;
  }

  async updateUserProfile(userId: number, updates: Partial<UserProfile>): Promise<UserProfile | undefined> {
    const existing = this.userProfiles.get(userId);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.userProfiles.set(userId, updated);
    return updated;
  }

  async getRoles(): Promise<Role[]> {
    return this.roles;
  }

  async getManagementTiers(): Promise<ManagementTier[]> {
    return this.managementTiers;
  }

  async getArtist(userId: number): Promise<Artist | undefined> {
    return this.artists.get(userId);
  }

  async getArtists(): Promise<Artist[]> {
    return Array.from(this.artists.values());
  }

  async createArtist(artist: InsertArtist): Promise<Artist> {
    const artistRecord: Artist = {
      userId: artist.userId,
      stageNames: artist.stageNames || [],
      primaryGenre: artist.primaryGenre || null,
      secondaryGenres: artist.secondaryGenres || [],
      topGenres: artist.topGenres || [],
      socialMediaHandles: artist.socialMediaHandles || {},
      basePrice: artist.basePrice || null,
      managementTierId: artist.managementTierId || null,
      isManaged: artist.isManaged || false,
      bookingFormPictureUrl: artist.bookingFormPictureUrl || null,
      performingRightsOrganization: artist.performingRightsOrganization || null,
      ipiNumber: artist.ipiNumber || null,
      technicalRiderProfile: artist.technicalRiderProfile || null
    };
    this.artists.set(artist.userId, artistRecord);
    return artistRecord;
  }

  async updateArtist(userId: number, updates: Partial<Artist>): Promise<Artist | undefined> {
    const artist = this.artists.get(userId);
    if (!artist) return undefined;
    
    const updatedArtist = { ...artist, ...updates };
    this.artists.set(userId, updatedArtist);
    return updatedArtist;
  }

  async getMusician(userId: number): Promise<Musician | undefined> {
    return this.musicians.get(userId);
  }

  async getMusicians(): Promise<Musician[]> {
    // Return in-memory musicians with proper data structure
    console.log('Returning in-memory musicians:', this.musicians.size);
    return Array.from(this.musicians.values());
  }

  async createMusician(musician: InsertMusician): Promise<Musician> {
    const musicianRecord: Musician = {
      userId: musician.userId,
      stageNames: musician.stageNames || [],
      primaryGenre: musician.primaryGenre || null,
      secondaryGenres: musician.secondaryGenres || [],
      topGenres: musician.topGenres || [],
      socialMediaHandles: musician.socialMediaHandles || {},
      instruments: musician.instruments || [],
      basePrice: musician.basePrice || null,
      idealPerformanceRate: musician.idealPerformanceRate || null,
      minimumAcceptableRate: musician.minimumAcceptableRate || null,
      managementTierId: musician.managementTierId || null,
      isManaged: musician.isManaged || false,
      bookingFormPictureUrl: musician.bookingFormPictureUrl || null,
      performingRightsOrganization: musician.performingRightsOrganization || null,
      ipiNumber: musician.ipiNumber || null,
      technicalRiderProfile: musician.technicalRiderProfile || null
    };
    this.musicians.set(musician.userId, musicianRecord);
    return musicianRecord;
  }

  async getProfessional(userId: number): Promise<Professional | undefined> {
    try {
      const result = await db.select().from(professionals).where(eq(professionals.userId, userId));
      return result[0];
    } catch (error) {
      console.error('Error fetching professional:', error);
      return undefined;
    }
  }

  async getProfessionals(): Promise<Professional[]> {
    try {
      const result = await db.select().from(professionals);
      return result;
    } catch (error) {
      console.error('Error fetching professionals:', error);
      return [];
    }
  }

  async createProfessional(professional: InsertProfessional): Promise<Professional> {
    try {
      const result = await db.insert(professionals).values(professional).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating professional:', error);
      throw error;
    }
  }

  async getSong(id: number): Promise<Song | undefined> {
    return this.songs.get(id);
  }

  async getSongs(): Promise<Song[]> {
    return Array.from(this.songs.values());
  }

  async getSongsByArtist(artistUserId: number): Promise<Song[]> {
    return Array.from(this.songs.values()).filter(song => song.artistUserId === artistUserId);
  }

  async createSong(song: InsertSong): Promise<Song> {
    const id = this.currentSongId++;
    const songRecord: Song = {
      id,
      title: song.title,
      artistUserId: song.artistUserId,
      mp3Url: song.mp3Url || null,
      coverArtUrl: song.coverArtUrl || null,
      isrcCode: song.isrcCode,
      price: song.price || null,
      isFree: song.isFree || null,
      durationSeconds: song.durationSeconds || null,
      previewStartSeconds: song.previewStartSeconds || null,
      createdAt: new Date()
    };
    this.songs.set(id, songRecord);
    return songRecord;
  }

  async updateSong(id: number, updates: Partial<Song>): Promise<Song | undefined> {
    const song = this.songs.get(id);
    if (!song) return undefined;
    
    const updatedSong = { ...song, ...updates };
    this.songs.set(id, updatedSong);
    return updatedSong;
  }

  async deleteSong(id: number): Promise<void> {
    this.songs.delete(id);
  }

  async getAlbum(id: number): Promise<Album | undefined> {
    return this.albums.get(id);
  }

  async getAlbumsByArtist(artistUserId: number): Promise<Album[]> {
    return Array.from(this.albums.values()).filter(album => album.artistUserId === artistUserId);
  }

  async createAlbum(album: InsertAlbum): Promise<Album> {
    const id = this.currentAlbumId++;
    const albumRecord: Album = {
      id,
      title: album.title,
      artistUserId: album.artistUserId,
      coverArtUrl: album.coverArtUrl || null,
      price: album.price || null,
      releaseDate: album.releaseDate || null,
      createdAt: new Date()
    };
    this.albums.set(id, albumRecord);
    return albumRecord;
  }

  async getMerchandise(id: number): Promise<Merchandise | undefined> {
    return this.merchandise.get(id);
  }

  async getMerchandiseByArtist(artistUserId: number): Promise<Merchandise[]> {
    return Array.from(this.merchandise.values()).filter(merch => merch.artistUserId === artistUserId);
  }

  async createMerchandise(merchandise: InsertMerchandise): Promise<Merchandise> {
    const id = this.currentMerchandiseId++;
    const merchandiseRecord: Merchandise = {
      id,
      name: merchandise.name,
      description: merchandise.description || null,
      price: merchandise.price,
      artistUserId: merchandise.artistUserId,
      inventory: merchandise.inventory || null,
      imageUrl: merchandise.imageUrl || null,
      createdAt: new Date()
    };
    this.merchandise.set(id, merchandiseRecord);
    return merchandiseRecord;
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async getBookingsByUser(userId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      booking => booking.bookerUserId === userId || booking.primaryArtistUserId === userId
    );
  }

  async getAllBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }

  async getBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const id = this.currentBookingId++;
    const bookingRecord: Booking = {
      id,
      bookerUserId: booking.bookerUserId || null,
      primaryArtistUserId: booking.primaryArtistUserId,
      eventName: booking.eventName,
      eventType: booking.eventType,
      eventDate: booking.eventDate || null,
      venueName: booking.venueName || null,
      venueAddress: booking.venueAddress || null,
      requirements: booking.requirements || null,
      status: booking.status || "pending",
      totalBudget: booking.totalBudget || null,
      finalPrice: booking.finalPrice || null,
      guestName: booking.guestName || null,
      guestEmail: booking.guestEmail || null,
      guestPhone: booking.guestPhone || null,
      isGuestBooking: booking.isGuestBooking || false,
      assignedAdminId: booking.assignedAdminId || null,
      adminApprovedAt: booking.adminApprovedAt || null,
      contractsGenerated: booking.contractsGenerated || false,
      allSignaturesCompleted: booking.allSignaturesCompleted || false,
      paymentCompleted: booking.paymentCompleted || false,
      receiptGenerated: booking.receiptGenerated || false,
      workflowData: booking.workflowData || null,
      currentWorkflowStep: booking.currentWorkflowStep || 1,
      lastModified: new Date(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.bookings.set(id, bookingRecord);
    return bookingRecord;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) return undefined;
    
    const updatedBooking = { ...booking, status };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }

  async getEventsByArtist(artistUserId: number): Promise<Event[]> {
    return Array.from(this.events.values()).filter(event => event.artistUserId === artistUserId);
  }

  async getEventsByUser(userId: number): Promise<Event[]> {
    // Get events for user based on their role - could be artist events or booked events
    return Array.from(this.events.values()).filter(event => 
      event.artistUserId === userId || event.bookerUserId === userId
    );
  }

  async getUpcomingEvents(): Promise<Event[]> {
    const now = new Date();
    return Array.from(this.events.values()).filter(event => 
      event.eventDatetime && new Date(event.eventDatetime) > now
    );
  }

  async updateBooking(id: number, updates: Partial<Booking>): Promise<Booking | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) return undefined;
    
    const updatedBooking = { 
      ...booking, 
      ...updates,
      updatedAt: new Date(),
      lastModified: new Date()
    };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }

  async getBookingsByArtist(artistUserId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      booking => booking.primaryArtistUserId === artistUserId
    );
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUserInteraction(interaction: InsertUserInteraction): Promise<UserInteraction> {
    const userInteraction: UserInteraction = {
      id: Date.now(),
      userId: interaction.userId,
      songId: interaction.songId || null,
      artistId: interaction.artistId || null,
      albumId: interaction.albumId || null,
      interactionType: interaction.interactionType,
      duration: interaction.duration || null,
      createdAt: new Date()
    };
    return userInteraction;
  }

  async getUserInteractions(userId: number): Promise<UserInteraction[]> {
    // Simple mock implementation for memory storage
    return [];
  }

  async getAllUserInteractions(): Promise<UserInteraction[]> {
    return [];
  }

  async getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
    return undefined;
  }

  async updateUserPreferences(userId: number, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences> {
    const userPreferences: UserPreferences = {
      id: Date.now(),
      userId,
      preferredGenres: preferences.preferredGenres || null,
      favoriteArtists: preferences.favoriteArtists || null,
      listeningHabits: preferences.listeningHabits || null,
      moodPreferences: preferences.moodPreferences || null,
      discoverySettings: preferences.discoverySettings || null,
      updatedAt: new Date(),
      createdAt: new Date()
    };
    return userPreferences;
  }

  async createMusicRecommendation(recommendation: InsertMusicRecommendation): Promise<MusicRecommendation> {
    const musicRecommendation: MusicRecommendation = {
      id: Date.now(),
      userId: recommendation.userId,
      songId: recommendation.songId || null,
      artistId: recommendation.artistId || null,
      albumId: recommendation.albumId || null,
      recommendationType: recommendation.recommendationType,
      score: recommendation.score || null,
      reasonCode: recommendation.reasonCode || null,
      isActive: recommendation.isActive || null,
      viewedAt: null,
      clickedAt: null,
      createdAt: new Date()
    };
    return musicRecommendation;
  }

  async getUserRecommendations(userId: number, limit?: number): Promise<MusicRecommendation[]> {
    return [];
  }

  async clearUserRecommendations(userId: number): Promise<void> {
    // Mock implementation
  }

  async updateRecommendationEngagement(recommendationId: number, engagementType: 'viewed' | 'clicked'): Promise<void> {
    // Mock implementation
  }

  async createArtistSimilarity(similarity: InsertArtistSimilarity): Promise<ArtistSimilarity> {
    const artistSimilarity: ArtistSimilarity = {
      id: Date.now(),
      artistId1: similarity.artistId1,
      artistId2: similarity.artistId2,
      similarityScore: similarity.similarityScore || null,
      commonGenres: similarity.commonGenres || null,
      sharedFans: similarity.sharedFans || null,
      calculatedAt: new Date()
    };
    return artistSimilarity;
  }

  async getArtistSimilarities(artistId: number): Promise<ArtistSimilarity[]> {
    return [];
  }

  async getAllArtists(): Promise<Artist[]> {
    return Array.from(this.artists.values());
  }

  async getArtistFans(artistId: number): Promise<number[]> {
    return [];
  }

  async incrementTrendingMetric(metric: Partial<InsertTrendingMetric>): Promise<void> {
    // Mock implementation
  }

  async getTrendingSongs(timeframe: string): Promise<Song[]> {
    return [];
  }

  async getActiveCrossPromotionCampaigns(): Promise<CrossPromotionCampaign[]> {
    return [];
  }

  async incrementCampaignImpressions(campaignId: number): Promise<void> {
    // Mock implementation
  }

  async getSongsByGenre(genre: string): Promise<Song[]> {
    return Array.from(this.songs.values()).filter(song => {
      // Get artist for this song
      const artist = this.artists.get(song.artistUserId);
      return artist && artist.genre === genre;
    });
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // Mock implementation - no username field in current schema
    return undefined;
  }

  // Service Management - Stub implementations for MemStorage
  async getServiceCategories(): Promise<ServiceCategory[]> {
    return [];
  }

  async createServiceCategory(category: InsertServiceCategory): Promise<ServiceCategory> {
    return { id: 1, name: category.name, description: category.description || null, createdAt: new Date() };
  }

  async getServices(): Promise<Service[]> {
    return [];
  }

  async getService(id: number): Promise<Service | undefined> {
    return undefined;
  }

  async createService(service: InsertService): Promise<Service> {
    return { 
      id: 1, 
      name: service.name,
      description: service.description || null,
      basePrice: service.basePrice || null,
      duration: service.duration || null,
      unit: service.unit || null,
      categoryId: service.categoryId || null,
      createdByUserId: service.createdByUserId,
      isActive: true, 
      createdAt: new Date()
    };
  }

  async updateService(id: number, updates: Partial<Service>): Promise<Service | undefined> {
    return undefined;
  }

  async deleteService(id: number): Promise<boolean> {
    return true;
  }

  async getServiceAssignments(): Promise<ServiceAssignment[]> {
    return [];
  }

  async getServiceAssignmentsByUser(userId: number): Promise<ServiceAssignment[]> {
    return [];
  }

  async getServiceAssignmentsByService(serviceId: number): Promise<ServiceAssignment[]> {
    return [];
  }

  async createServiceAssignment(assignment: InsertServiceAssignment): Promise<ServiceAssignment> {
    return { ...assignment, id: 1, isActive: true, assignedAt: new Date() };
  }

  async updateServiceAssignment(id: number, updates: Partial<ServiceAssignment>): Promise<ServiceAssignment | undefined> {
    return undefined;
  }

  async deleteServiceAssignment(id: number): Promise<boolean> {
    return true;
  }

  async getUserServices(userId: number): Promise<UserService[]> {
    return [];
  }

  async getAllUserServices(): Promise<UserService[]> {
    return [];
  }

  async getUserService(id: number): Promise<UserService | undefined> {
    return undefined;
  }

  async createUserService(userService: InsertUserService): Promise<UserService> {
    return {
      id: 1,
      userId: userService.userId,
      name: userService.name,
      description: userService.description || null,
      price: userService.price,
      duration: userService.duration || null,
      unit: userService.unit || null,
      features: userService.features || null,
      enableRating: userService.enableRating || null,
      categoryId: userService.categoryId || null,
      isActive: true,
      createdAt: new Date()
    };
  }

  async updateUserService(id: number, updates: Partial<UserService>): Promise<UserService | undefined> {
    return undefined;
  }

  async deleteUserService(id: number): Promise<boolean> {
    return true;
  }

  async getServiceReviews(serviceId?: number, userServiceId?: number): Promise<ServiceReview[]> {
    return [];
  }

  async createServiceReview(review: InsertServiceReview): Promise<ServiceReview> {
    return {
      id: 1,
      serviceId: review.serviceId || null,
      userServiceId: review.userServiceId || null,
      reviewerUserId: review.reviewerUserId,
      rating: review.rating,
      review: review.review || null,
      createdAt: new Date()
    };
  }

  // Currency management methods
  async getCurrencies(): Promise<Currency[]> {
    throw new Error("Currency management not implemented in MemStorage");
  }

  async getCurrency(code: string): Promise<Currency | undefined> {
    throw new Error("Currency management not implemented in MemStorage");
  }

  async createCurrency(currency: InsertCurrency): Promise<Currency> {
    throw new Error("Currency management not implemented in MemStorage");
  }

  async updateCurrency(code: string, updates: Partial<Currency>): Promise<Currency | undefined> {
    throw new Error("Currency management not implemented in MemStorage");
  }

  async updateCurrencyRate(code: string, rate: number): Promise<Currency | undefined> {
    throw new Error("Currency management not implemented in MemStorage");
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id));
    return this.getUser(id);
  }

  // Duplicate methods removed - fixed for production deployment

  // Check if user has role (primary or secondary)
  async userHasRole(userId: number, roleId: number): Promise<boolean> {
    const user = await this.getUser(userId);
    if (!user) return false;
    
    // Check primary role
    if (user.roleId === roleId) return true;
    
    // Check secondary roles
    const secondaryRoles = user.secondaryRoles as number[] || [];
    return secondaryRoles.includes(roleId);
  }

  // Get all roles for a user (primary + secondary)
  async getUserRoles(userId: number): Promise<number[]> {
    const user = await this.getUser(userId);
    if (!user) return [];
    
    const roles = [user.roleId];
    const secondaryRoles = user.secondaryRoles as number[] || [];
    return [...roles, ...secondaryRoles];
  }

  async getUserProfile(userId: number): Promise<UserProfile | undefined> {
    const [profile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    return profile || undefined;
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    await db
      .insert(userProfiles)
      .values(profile);
    return this.getUserProfile(profile.userId) as Promise<UserProfile>;
  }

  async updateUserProfile(userId: number, updates: Partial<UserProfile>): Promise<UserProfile | undefined> {
    await db
      .update(userProfiles)
      .set(updates)
      .where(eq(userProfiles.userId, userId));
    return this.getUserProfile(userId);
  }

  async getRoles(): Promise<Role[]> {
    return await db.select().from(roles);
  }

  async getManagementTiers(): Promise<ManagementTier[]> {
    return await db.select().from(managementTiers);
  }

  async getArtist(userId: number): Promise<Artist | undefined> {
    const [artist] = await db.select().from(artists).where(eq(artists.userId, userId));
    return artist || undefined;
  }

  async getArtists(): Promise<Artist[]> {
    return await db.select().from(artists);
  }

  async createArtist(artist: InsertArtist): Promise<Artist> {
    await db
      .insert(artists)
      .values(artist);
    return this.getArtist(artist.userId) as Promise<Artist>;
  }

  async updateArtist(userId: number, updates: Partial<Artist>): Promise<Artist | undefined> {
    await db
      .update(artists)
      .set(updates)
      .where(eq(artists.userId, userId));
    return this.getArtist(userId);
  }

  async updateMusician(userId: number, updates: Partial<Musician>): Promise<Musician | undefined> {
    await db
      .update(musicians)
      .set(updates)
      .where(eq(musicians.userId, userId));
    return this.getMusician(userId);
  }

  async getMusician(userId: number): Promise<Musician | undefined> {
    const [musician] = await db.select().from(musicians).where(eq(musicians.userId, userId));
    return musician || undefined;
  }

  async getMusicians(): Promise<Musician[]> {
    return await db.select().from(musicians);
  }

  async createMusician(musician: InsertMusician): Promise<Musician> {
    await db
      .insert(musicians)
      .values(musician);
    return this.getMusician(musician.userId) as Promise<Musician>;
  }

  async getProfessional(userId: number): Promise<Professional | undefined> {
    const [professional] = await db.select().from(professionals).where(eq(professionals.userId, userId));
    return professional || undefined;
  }

  // Update professional profile with specializations and availability
  async updateProfessional(userId: number, updates: any): Promise<Professional | undefined> {
    const [updated] = await db
      .update(professionals)
      .set({
        ...updates,
        userId, // Ensure userId is set
      })
      .where(eq(professionals.userId, userId))
      .returning();
    return updated || undefined;
  }

  // Global professions management
  async getGlobalProfessions(): Promise<any[]> {
    const results = await db.select().from(globalProfessions).orderBy(globalProfessions.category, globalProfessions.name);
    
    // Group by category
    const grouped = results.reduce((acc, profession) => {
      if (!acc[profession.category]) {
        acc[profession.category] = [];
      }
      acc[profession.category].push(profession);
      return acc;
    }, {} as Record<string, any[]>);
    
    return grouped;
  }

  async createGlobalProfession(profession: any): Promise<any> {
    const [created] = await db.insert(globalProfessions).values(profession).returning();
    return created;
  }

  // Professional availability management
  async getProfessionalAvailability(userId: number): Promise<any> {
    const [availability] = await db.select().from(professionalAvailability).where(eq(professionalAvailability.userId, userId));
    return availability || undefined;
  }

  async createProfessionalAvailability(availability: any): Promise<any> {
    const [created] = await db.insert(professionalAvailability).values(availability).returning();
    return created;
  }

  async updateProfessionalAvailability(userId: number, updates: any): Promise<any> {
    const [updated] = await db
      .update(professionalAvailability)
      .set(updates)
      .where(eq(professionalAvailability.userId, userId))
      .returning();
    return updated || undefined;
  }

  async getProfessionals(): Promise<Professional[]> {
    return await db.select().from(professionals);
  }

  async createProfessional(professional: InsertProfessional): Promise<Professional> {
    await db
      .insert(professionals)
      .values(professional);
    return this.getProfessional(professional.userId) as Promise<Professional>;
  }

  async getSong(id: number): Promise<Song | undefined> {
    const [song] = await db.select().from(songs).where(eq(songs.id, id));
    return song || undefined;
  }

  async getSongs(): Promise<Song[]> {
    return await db.select().from(songs);
  }

  async getSongsByArtist(artistUserId: number): Promise<Song[]> {
    return await db.select().from(songs).where(eq(songs.artistUserId, artistUserId));
  }

  async createSong(song: InsertSong): Promise<Song> {
    const [createdSong] = await db
      .insert(songs)
      .values(song)
      .returning();
    return createdSong;
  }

  async updateSong(id: number, updates: Partial<Song>): Promise<Song | undefined> {
    await db
      .update(songs)
      .set(updates)
      .where(eq(songs.id, id));
    return this.getSong(id);
  }

  async deleteSong(id: number): Promise<void> {
    await db.delete(songs).where(eq(songs.id, id));
  }

  // Albums implementation
  async getAlbums(): Promise<Album[]> {
    return await db.select().from(albums).orderBy(desc(albums.createdAt));
  }

  async getAlbum(id: number): Promise<Album | undefined> {
    const [album] = await db.select().from(albums).where(eq(albums.id, id));
    return album || undefined;
  }

  async getAlbumsByArtist(artistUserId: number): Promise<Album[]> {
    return await db.select().from(albums).where(eq(albums.artistUserId, artistUserId));
  }

  async createAlbum(album: InsertAlbum): Promise<Album> {
    const [createdAlbum] = await db
      .insert(albums)
      .values(album)
      .returning();
    return createdAlbum;
  }

  async updateAlbum(id: number, updates: Partial<Album>): Promise<Album | undefined> {
    const [updated] = await db
      .update(albums)
      .set(updates)
      .where(eq(albums.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteAlbum(id: number): Promise<boolean> {
    const result = await db.delete(albums).where(eq(albums.id, id));
    return result.rowCount > 0;
  }

  async getSongsByAlbum(albumId: number): Promise<Song[]> {
    return await db.select().from(songs).where(eq(songs.albumId, albumId));
  }

  // Cross-Upsell Relationships implementation
  async getCrossUpsellRelationships(): Promise<CrossUpsellRelationship[]> {
    return await db.select().from(crossUpsellRelationships).orderBy(desc(crossUpsellRelationships.createdAt));
  }

  async createCrossUpsellRelationship(relationship: InsertCrossUpsellRelationship): Promise<CrossUpsellRelationship> {
    const [created] = await db
      .insert(crossUpsellRelationships)
      .values(relationship)
      .returning();
    return created;
  }

  async getCrossUpsellsBySource(sourceType: string, sourceId: number): Promise<CrossUpsellRelationship[]> {
    return await db
      .select()
      .from(crossUpsellRelationships)
      .where(and(
        eq(crossUpsellRelationships.sourceType, sourceType),
        eq(crossUpsellRelationships.sourceId, sourceId)
      ));
  }

  async deleteCrossUpsellRelationship(id: number): Promise<boolean> {
    const result = await db.delete(crossUpsellRelationships).where(eq(crossUpsellRelationships.id, id));
    return result.rowCount > 0;
  }

  // Videos
  async getVideo(id: number): Promise<Video | undefined> {
    const result = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
    return result[0];
  }

  async getVideos(): Promise<Video[]> {
    return await db.select().from(videos).orderBy(desc(videos.createdAt));
  }

  async getVideosByUser(userId: number): Promise<Video[]> {
    return await db.select()
      .from(videos)
      .where(eq(videos.uploadedByUserId, userId))
      .orderBy(desc(videos.createdAt));
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const result = await db.insert(videos).values(video).returning();
    return result[0];
  }

  async updateVideo(id: number, updates: Partial<Video>): Promise<Video | undefined> {
    const result = await db.update(videos)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(videos.id, id))
      .returning();
    return result[0];
  }

  async deleteVideo(id: number): Promise<void> {
    await db.delete(videos).where(eq(videos.id, id));
  }

  async getAlbum(id: number): Promise<Album | undefined> {
    const [album] = await db.select().from(albums).where(eq(albums.id, id));
    return album || undefined;
  }

  async getAlbumsByArtist(artistUserId: number): Promise<Album[]> {
    return await db.select().from(albums).where(eq(albums.artistUserId, artistUserId));
  }

  async createAlbum(album: InsertAlbum): Promise<Album> {
    const [createdAlbum] = await db
      .insert(albums)
      .values(album)
      .returning();
    return createdAlbum;
  }

  async getMerchandise(id: number): Promise<Merchandise | undefined> {
    const [merch] = await db.select().from(merchandise).where(eq(merchandise.id, id));
    return merch || undefined;
  }

  async getMerchandiseByArtist(artistUserId: number): Promise<Merchandise[]> {
    return await db.select().from(merchandise).where(eq(merchandise.artistUserId, artistUserId));
  }

  async getAllMerchandise(): Promise<Merchandise[]> {
    return await db.select().from(merchandise);
  }

  async createMerchandise(merchandiseData: InsertMerchandise): Promise<Merchandise> {
    // Ensure categoryId is set to default if not provided
    const dataWithCategory = {
      ...merchandiseData,
      categoryId: merchandiseData.categoryId || 1 // Default to "Apparel" category
    };
    
    const [createdMerchandise] = await db
      .insert(merchandise)
      .values(dataWithCategory)
      .returning();
    return createdMerchandise;
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking || undefined;
  }

  async getBookingsByUser(userId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.bookerUserId, userId));
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [createdBooking] = await db
      .insert(bookings)
      .values(booking)
      .returning();
    return createdBooking;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    await db
      .update(bookings)
      .set({ status })
      .where(eq(bookings.id, id));
    return this.getBooking(id);
  }

  async updateBooking(id: number, updates: Partial<Booking>): Promise<Booking | undefined> {
    await db
      .update(bookings)
      .set(updates)
      .where(eq(bookings.id, id));
    return this.getBooking(id);
  }

  async getAllBookings(): Promise<Booking[]> {
    try {
      return await db.select().from(bookings);
    } catch (error) {
      console.error('Error fetching bookings:', error);
      return [];
    }
  }

  async getBookingsByArtist(artistUserId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.primaryArtistUserId, artistUserId));
  }

  async getBookingById(bookingId: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, bookingId));
    return booking;
  }

  async getBookings(): Promise<Booking[]> {
    return await db.select().from(bookings);
  }

  async getUserById(userId: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getEventsByArtist(artistUserId: number): Promise<Event[]> {
    return await db.select().from(events).where(eq(events.artistUserId, artistUserId));
  }

  async getEventsByUser(userId: number): Promise<Event[]> {
    // Check if events table has bookerUserId column, if not just use artistUserId
    try {
      return await db.select().from(events).where(eq(events.artistUserId, userId));
    } catch (error) {
      console.error('Get events by user error:', error);
      return [];
    }
  }

  async getUpcomingEvents(): Promise<Event[]> {
    return await db.select().from(events);
  }

  // Recommendation System Implementation
  async createUserInteraction(interaction: InsertUserInteraction): Promise<UserInteraction> {
    const [created] = await db
      .insert(userInteractions)
      .values(interaction)
      .returning();
    return created;
  }

  async getUserInteractions(userId: number): Promise<UserInteraction[]> {
    return await db.select().from(userInteractions).where(eq(userInteractions.userId, userId));
  }

  async getAllUserInteractions(): Promise<UserInteraction[]> {
    return await db.select().from(userInteractions);
  }

  async getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
    const [preferences] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return preferences || undefined;
  }

  async updateUserPreferences(userId: number, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences> {
    // Check if preferences exist, if not create them
    const existing = await this.getUserPreferences(userId);
    
    if (existing) {
      await db
        .update(userPreferences)
        .set({ ...preferences, updatedAt: new Date() })
        .where(eq(userPreferences.userId, userId));
    } else {
      await db
        .insert(userPreferences)
        .values({ userId, ...preferences });
    }
    
    return this.getUserPreferences(userId) as Promise<UserPreferences>;
  }

  async createMusicRecommendation(recommendation: InsertMusicRecommendation): Promise<MusicRecommendation> {
    const [created] = await db
      .insert(musicRecommendations)
      .values(recommendation)
      .returning();
    return created;
  }

  async getUserRecommendations(userId: number, limit: number = 10): Promise<MusicRecommendation[]> {
    return await db
      .select()
      .from(musicRecommendations)
      .where(and(eq(musicRecommendations.userId, userId), eq(musicRecommendations.isActive, true)))
      .orderBy(desc(musicRecommendations.score))
      .limit(limit);
  }

  async clearUserRecommendations(userId: number): Promise<void> {
    await db
      .update(musicRecommendations)
      .set({ isActive: false })
      .where(eq(musicRecommendations.userId, userId));
  }

  async updateRecommendationEngagement(recommendationId: number, engagementType: 'viewed' | 'clicked'): Promise<void> {
    const updateData = engagementType === 'viewed' 
      ? { viewedAt: new Date() }
      : { clickedAt: new Date() };
    
    await db
      .update(musicRecommendations)
      .set(updateData)
      .where(eq(musicRecommendations.id, recommendationId));
  }

  async createArtistSimilarity(similarity: InsertArtistSimilarity): Promise<ArtistSimilarity> {
    const [created] = await db
      .insert(artistSimilarities)
      .values(similarity)
      .returning();
    return created;
  }

  async getArtistSimilarities(artistId: number): Promise<ArtistSimilarity[]> {
    return await db
      .select()
      .from(artistSimilarities)
      .where(or(
        eq(artistSimilarities.artistId1, artistId),
        eq(artistSimilarities.artistId2, artistId)
      ))
      .orderBy(desc(artistSimilarities.similarityScore));
  }

  async getAllArtists(): Promise<Artist[]> {
    return await db.select().from(artists);
  }

  async getArtistFans(artistId: number): Promise<number[]> {
    // Get users who have positively interacted with this artist
    const interactions = await db
      .select({ userId: userInteractions.userId })
      .from(userInteractions)
      .where(and(
        eq(userInteractions.artistId, artistId),
        or(
          eq(userInteractions.interactionType, 'like'),
          eq(userInteractions.interactionType, 'play'),
          eq(userInteractions.interactionType, 'download')
        )
      ))
      .groupBy(userInteractions.userId);
    
    return interactions.map(i => i.userId);
  }

  async incrementTrendingMetric(metric: Partial<InsertTrendingMetric>): Promise<void> {
    // Check if metric exists for today
    const existing = await db
      .select()
      .from(trendingMetrics)
      .where(and(
        eq(trendingMetrics.songId, metric.songId || 0),
        eq(trendingMetrics.artistId, metric.artistId || 0),
        eq(trendingMetrics.metricType, metric.metricType || ''),
        eq(trendingMetrics.timeframe, metric.timeframe || ''),
        eq(trendingMetrics.date, metric.date || new Date())
      ))
      .limit(1);

    if (existing.length > 0) {
      // Update existing metric
      await db
        .update(trendingMetrics)
        .set({ count: (existing[0]?.count || 0) + (metric.count || 1) })
        .where(eq(trendingMetrics.id, existing[0].id));
    } else {
      // Create new metric
      await db
        .insert(trendingMetrics)
        .values(metric as InsertTrendingMetric);
    }
  }

  async getTrendingSongs(timeframe: string): Promise<Song[]> {
    // Get top songs based on trending metrics
    const trendingSongIds = await db
      .select({ 
        songId: trendingMetrics.songId,
        totalCount: sql<number>`sum(${trendingMetrics.count})`.as('totalCount')
      })
      .from(trendingMetrics)
      .where(and(
        eq(trendingMetrics.timeframe, timeframe),
        isNotNull(trendingMetrics.songId)
      ))
      .groupBy(trendingMetrics.songId)
      .orderBy(desc(sql`sum(${trendingMetrics.count})`))
      .limit(20);

    if (trendingSongIds.length === 0) return [];

    const songIds = trendingSongIds.map(t => t.songId!);
    return await db
      .select()
      .from(songs)
      .where(sql`${songs.id} IN (${songIds.join(',')})`);
  }

  async getActiveCrossPromotionCampaigns(): Promise<CrossPromotionCampaign[]> {
    const now = new Date();
    return await db
      .select()
      .from(crossPromotionCampaigns)
      .where(and(
        eq(crossPromotionCampaigns.isActive, true),
        lte(crossPromotionCampaigns.startDate, now),
        gte(crossPromotionCampaigns.endDate, now)
      ));
  }

  async incrementCampaignImpressions(campaignId: number): Promise<void> {
    await db
      .update(crossPromotionCampaigns)
      .set({ 
        impressions: sql`${crossPromotionCampaigns.impressions} + 1`
      })
      .where(eq(crossPromotionCampaigns.id, campaignId));
  }

  async getSongsByGenre(genre: string): Promise<Song[]> {
    // Get songs by artists of the specified genre
    const artistSongs = await db
      .select({
        id: songs.id,
        artistUserId: songs.artistUserId,
        title: songs.title,
        mp3Url: songs.mp3Url,
        coverArtUrl: songs.coverArtUrl,
        isrcCode: songs.isrcCode,
        price: songs.price,
        isFree: songs.isFree,
        durationSeconds: songs.durationSeconds,
        previewStartSeconds: songs.previewStartSeconds,
        createdAt: songs.createdAt
      })
      .from(songs)
      .innerJoin(artists, eq(songs.artistUserId, artists.userId))
      .where(eq(artists.genre, genre));
    
    return artistSongs;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, username));
    return user || undefined;
  }

  // Service Management Implementation
  async getServiceCategories(): Promise<ServiceCategory[]> {
    return await db.select().from(serviceCategories);
  }

  async createServiceCategory(category: InsertServiceCategory): Promise<ServiceCategory> {
    const [created] = await db
      .insert(serviceCategories)
      .values(category)
      .returning();
    return created;
  }

  async getServices(): Promise<Service[]> {
    return await db.select().from(services).where(eq(services.isActive, true));
  }

  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service || undefined;
  }

  async createService(service: InsertService): Promise<Service> {
    const [created] = await db
      .insert(services)
      .values(service)
      .returning();
    return created;
  }

  async updateService(id: number, updates: Partial<Service>): Promise<Service | undefined> {
    await db
      .update(services)
      .set(updates)
      .where(eq(services.id, id));
    return this.getService(id);
  }

  async deleteService(id: number): Promise<boolean> {
    const result = await db
      .update(services)
      .set({ isActive: false })
      .where(eq(services.id, id));
    return true;
  }

  async getServiceAssignments(): Promise<ServiceAssignment[]> {
    const assignments = await db
      .select({
        id: serviceAssignments.id,
        serviceId: serviceAssignments.serviceId,
        assignedUserId: serviceAssignments.assignedUserId,
        assignedPrice: serviceAssignments.assignedPrice,
        userCommission: serviceAssignments.userCommission,
        isActive: serviceAssignments.isActive,
        assignedByUserId: serviceAssignments.assignedByUserId,
        assignedAt: serviceAssignments.assignedAt,
        assignedUserName: users.fullName,
        serviceName: services.name
      })
      .from(serviceAssignments)
      .leftJoin(users, eq(serviceAssignments.assignedUserId, users.id))
      .leftJoin(services, eq(serviceAssignments.serviceId, services.id))
      .where(eq(serviceAssignments.isActive, true));
    
    return assignments as ServiceAssignment[];
  }

  async getServiceAssignmentsByUser(userId: number): Promise<ServiceAssignment[]> {
    return await db
      .select()
      .from(serviceAssignments)
      .where(and(
        eq(serviceAssignments.assignedUserId, userId),
        eq(serviceAssignments.isActive, true)
      ));
  }

  async getServiceAssignmentsByService(serviceId: number): Promise<ServiceAssignment[]> {
    return await db
      .select()
      .from(serviceAssignments)
      .where(and(
        eq(serviceAssignments.serviceId, serviceId),
        eq(serviceAssignments.isActive, true)
      ));
  }

  async createServiceAssignment(assignment: InsertServiceAssignment): Promise<ServiceAssignment> {
    const [created] = await db
      .insert(serviceAssignments)
      .values(assignment)
      .returning();
    return created;
  }

  async updateServiceAssignment(id: number, updates: Partial<ServiceAssignment>): Promise<ServiceAssignment | undefined> {
    await db
      .update(serviceAssignments)
      .set(updates)
      .where(eq(serviceAssignments.id, id));
    
    const [updated] = await db
      .select()
      .from(serviceAssignments)
      .where(eq(serviceAssignments.id, id));
    return updated || undefined;
  }

  async getServiceAssignment(id: number): Promise<ServiceAssignment | undefined> {
    const [assignment] = await db
      .select()
      .from(serviceAssignments)
      .where(eq(serviceAssignments.id, id));
    return assignment || undefined;
  }

  async getServiceAssignmentsByTalent(assignedTalentId: number): Promise<ServiceAssignment[]> {
    return await db
      .select()
      .from(serviceAssignments)
      .where(and(
        eq(serviceAssignments.assignedUserId, assignedTalentId),
        eq(serviceAssignments.isActive, true)
      ));
  }

  async removeServiceAssignment(id: number): Promise<void> {
    await db
      .update(serviceAssignments)
      .set({ isActive: false })
      .where(eq(serviceAssignments.id, id));
  }

  async deleteServiceAssignment(id: number): Promise<boolean> {
    await db
      .update(serviceAssignments)
      .set({ isActive: false })
      .where(eq(serviceAssignments.id, id));
    return true;
  }

  // Playback Tracks & DJ Management System
  async getPlaybackTracksByBookingId(bookingId: number): Promise<any[]> {
    return await db
      .select()
      .from(playbackTracks)
      .where(and(
        eq(playbackTracks.bookingId, bookingId),
        eq(playbackTracks.isActive, true)
      ))
      .orderBy(playbackTracks.setlistPosition);
  }

  async getPlaybackTrackById(trackId: number): Promise<any> {
    const [track] = await db
      .select()
      .from(playbackTracks)
      .where(eq(playbackTracks.id, trackId));
    return track || undefined;
  }

  async createPlaybackTrack(trackData: any): Promise<any> {
    const [created] = await db
      .insert(playbackTracks)
      .values(trackData)
      .returning();
    return created;
  }

  async updatePlaybackTrack(trackId: number, updates: any): Promise<void> {
    await db
      .update(playbackTracks)
      .set(updates)
      .where(eq(playbackTracks.id, trackId));
  }

  async createDjAccess(accessData: any): Promise<any> {
    const [created] = await db
      .insert(djAccess)
      .values(accessData)
      .returning();
    return created;
  }

  async getDjAccessByCode(accessCode: string): Promise<any> {
    const [access] = await db
      .select()
      .from(djAccess)
      .where(eq(djAccess.accessCode, accessCode));
    return access || undefined;
  }

  async updateDjAccess(accessId: number, updates: any): Promise<void> {
    await db
      .update(djAccess)
      .set(updates)
      .where(eq(djAccess.id, accessId));
  }

  async createPlaybackTrackDownload(downloadData: any): Promise<any> {
    const [created] = await db
      .insert(playbackTrackDownloads)
      .values(downloadData)
      .returning();
    return created;
  }

  // Curator Distribution System
  async getCurators(): Promise<any[]> {
    return await db
      .select()
      .from(curators)
      .where(eq(curators.isActive, true))
      .orderBy(curators.influenceScore, curators.name);
  }

  async getCuratorById(curatorId: number): Promise<any> {
    const [curator] = await db
      .select()
      .from(curators)
      .where(eq(curators.id, curatorId));
    return curator || undefined;
  }

  async createCurator(curatorData: any): Promise<any> {
    const [created] = await db
      .insert(curators)
      .values(curatorData)
      .returning();
    return created;
  }

  async updateCurator(curatorId: number, updates: any): Promise<void> {
    await db
      .update(curators)
      .set(updates)
      .where(eq(curators.id, curatorId));
  }

  async getCuratorsByGenres(genres: string[]): Promise<any[]> {
    return await db
      .select()
      .from(curators)
      .where(and(
        eq(curators.isActive, true),
        // Using raw SQL for JSONB array overlap check
        sql`${curators.genres} ?| array[${genres.map(g => `'${g}'`).join(',')}]`
      ))
      .orderBy(curators.influenceScore);
  }

  async createCuratorSubmission(submissionData: any): Promise<any> {
    const [created] = await db
      .insert(curatorSubmissions)
      .values(submissionData)
      .returning();
    return created;
  }

  async getCuratorSubmissions(filters?: { songId?: number; albumId?: number; curatorId?: number }): Promise<any[]> {
    let query = db
      .select({
        id: curatorSubmissions.id,
        curatorId: curatorSubmissions.curatorId,
        songId: curatorSubmissions.songId,
        albumId: curatorSubmissions.albumId,
        releaseType: curatorSubmissions.releaseType,
        submissionDate: curatorSubmissions.submissionDate,
        status: curatorSubmissions.status,
        curatorResponse: curatorSubmissions.curatorResponse,
        responseDate: curatorSubmissions.responseDate,
        placementUrl: curatorSubmissions.placementUrl,
        followUpCount: curatorSubmissions.followUpCount,
        linkClicks: curatorSubmissions.linkClicks,
        submittedByUserId: curatorSubmissions.submittedByUserId,
        createdAt: curatorSubmissions.createdAt,
        // Include curator information
        curatorName: curators.name,
        curatorEmail: curators.email,
        curatorOrganization: curators.organization
      })
      .from(curatorSubmissions)
      .leftJoin(curators, eq(curatorSubmissions.curatorId, curators.id));

    // Apply filters if provided
    const conditions = [];
    if (filters?.songId) {
      conditions.push(eq(curatorSubmissions.songId, filters.songId));
    }
    if (filters?.albumId) {
      conditions.push(eq(curatorSubmissions.albumId, filters.albumId));
    }
    if (filters?.curatorId) {
      conditions.push(eq(curatorSubmissions.curatorId, filters.curatorId));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query.orderBy(curatorSubmissions.submissionDate);
  }

  async updateCuratorSubmission(submissionId: number, updates: any): Promise<void> {
    await db
      .update(curatorSubmissions)
      .set(updates)
      .where(eq(curatorSubmissions.id, submissionId));
  }

  async createCuratorEmailCampaign(campaignData: any): Promise<any> {
    const [created] = await db
      .insert(curatorEmailCampaigns)
      .values(campaignData)
      .returning();
    return created;
  }

  async getCuratorEmailCampaigns(): Promise<any[]> {
    return await db
      .select()
      .from(curatorEmailCampaigns)
      .orderBy(curatorEmailCampaigns.createdAt);
  }

  async updateCuratorEmailCampaign(campaignId: number, updates: any): Promise<void> {
    await db
      .update(curatorEmailCampaigns)
      .set(updates)
      .where(eq(curatorEmailCampaigns.id, campaignId));
  }

  // PROFESSIONAL INTEGRATION SYSTEM - REAL DATABASE IMPLEMENTATION
  // These methods provide the seamless cross-platform integration you requested

  async createInternalObjective(objective: any): Promise<any> {
    try {
      const sql = `
        INSERT INTO internal_booking_objectives 
        (booking_id, objective_type, title, description, priority, target_deadline, assigned_to, status, confidential, created_by, tags, related_professionals)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        RETURNING *
      `;
      
      const result = await pool.query(sql, [
        objective.bookingId,
        objective.objectiveType,
        objective.title,
        objective.description,
        objective.priority || 'medium',
        objective.targetDeadline,
        objective.assignedTo,
        objective.status || 'planning',
        objective.confidential !== false,
        objective.createdBy,
        JSON.stringify(objective.tags || []),
        JSON.stringify(objective.relatedProfessionals || [])
      ]);
      
      return result.rows[0];
    } catch (error) {
      console.error('Error creating internal objective:', error);
      throw error;
    }
  }

  async getInternalObjectivesByBooking(bookingId: number): Promise<any[]> {
    try {
      const sql = `
        SELECT * FROM internal_booking_objectives 
        WHERE booking_id = $1 
        ORDER BY created_at DESC
      `;
      
      const result = await pool.query(sql, [bookingId]);
      return result.rows;
    } catch (error) {
      console.error('Error fetching internal objectives:', error);
      return [];
    }
  }

  async updateInternalObjectiveStatus(objectiveId: number, status: string): Promise<any> {
    try {
      const sql = `
        UPDATE internal_booking_objectives 
        SET status = $1, updated_at = CURRENT_TIMESTAMP 
        WHERE id = $2 
        RETURNING *
      `;
      
      const result = await pool.query(sql, [status, objectiveId]);
      return result.rows[0];
    } catch (error) {
      console.error('Error updating objective status:', error);
      throw error;
    }
  }

  async createProfessionalAssignment(assignment: any): Promise<any> {
    try {
      const sql = `
        INSERT INTO professional_assignments 
        (booking_id, professional_user_id, assignment_type, assigned_by, deliverables, internal_objectives, equipment_required, budget, status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
      `;
      
      const result = await pool.query(sql, [
        assignment.bookingId,
        assignment.professionalUserId,
        assignment.assignmentType,
        assignment.assignedBy,
        JSON.stringify(assignment.deliverables || []),
        JSON.stringify(assignment.internalObjectives || []),
        JSON.stringify(assignment.equipmentRequired || []),
        assignment.budget || 0,
        assignment.status || 'pending'
      ]);
      
      return result.rows[0];
    } catch (error) {
      console.error('Error creating professional assignment:', error);
      throw error;
    }
  }

  async getProfessionalEquipment(professionalUserId: number): Promise<any[]> {
    try {
      const sql = `
        SELECT * FROM professional_equipment 
        WHERE professional_user_id = $1 
        ORDER BY last_updated DESC
      `;
      
      const result = await pool.query(sql, [professionalUserId]);
      return result.rows;
    } catch (error) {
      console.error('Error fetching professional equipment:', error);
      return [];
    }
  }

  async createCrossPlatformProject(project: any): Promise<any> {
    try {
      const sql = `
        INSERT INTO cross_platform_projects 
        (booking_id, project_name, photographers, videographers, marketing_specialists, social_media_specialists, project_timeline, deliverables, budget)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
      `;
      
      const result = await pool.query(sql, [
        project.bookingId,
        project.projectName,
        JSON.stringify(project.professionals?.photographerId ? [project.professionals.photographerId] : []),
        JSON.stringify(project.professionals?.videographerId ? [project.professionals.videographerId] : []),
        JSON.stringify(project.professionals?.marketingSpecialistId ? [project.professionals.marketingSpecialistId] : []),
        JSON.stringify(project.professionals?.socialMediaSpecialistId ? [project.professionals.socialMediaSpecialistId] : []),
        JSON.stringify(project.projectTimeline || {}),
        JSON.stringify(project.deliverables || []),
        JSON.stringify(project.budget || {})
      ]);
      
      return result.rows[0];
    } catch (error) {
      console.error('Error creating cross-platform project:', error);
      throw error;
    }
  }

  async addProfessionalEquipment(equipment: any): Promise<any> {
    try {
      const sql = `
        INSERT INTO professional_equipment 
        (professional_user_id, equipment_type, brand, model, specifications, condition)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
      `;
      
      const result = await pool.query(sql, [
        equipment.professionalUserId,
        equipment.equipmentType,
        equipment.brand,
        equipment.model,
        JSON.stringify(equipment.specifications || {}),
        equipment.condition || 'good'
      ]);
      
      return result.rows[0];
    } catch (error) {
      console.error('Error adding professional equipment:', error);
      throw error;
    }
  }

  // REVENUE TARGET METHODS - $2M+ REVENUE SYSTEM IMPLEMENTATION
  async getRevenueProjections(): Promise<any> {
    try {
      // Calculate actual revenue projections based on real data
      const bookingsCount = await this.getAllBookings();
      const usersCount = await this.getAllUsers();
      
      const monthlyBookingRevenue = bookingsCount.length * 150; // Average booking commission
      const monthlySubscriptionRevenue = usersCount.length * 0.15 * 89.99; // 15% subscription rate at avg tier
      const monthlyProfessionalServices = 50000; // Professional services revenue
      const monthlySplitsheetRevenue = 1000; // Splitsheet services
      
      const monthlyTotal = monthlyBookingRevenue + monthlySubscriptionRevenue + monthlyProfessionalServices + monthlySplitsheetRevenue;
      const annualTotal = monthlyTotal * 12;
      
      return {
        monthly: monthlyTotal,
        annual: annualTotal,
        targetProgress: (annualTotal / 2000000) * 100, // Progress toward $2M target
        breakdown: {
          bookings: monthlyBookingRevenue * 12,
          subscriptions: monthlySubscriptionRevenue * 12,
          professionalServices: monthlyProfessionalServices * 12,
          splitsheets: monthlySplitsheetRevenue * 12
        }
      };
    } catch (error) {
      console.error('Error calculating revenue projections:', error);
      return { monthly: 0, annual: 0, targetProgress: 0, breakdown: {} };
    }
  }

  async getUserServices(userId: number): Promise<UserService[]> {
    return await db
      .select()
      .from(userServices)
      .where(and(
        eq(userServices.userId, userId),
        eq(userServices.isActive, true)
      ));
  }

  async getAllUserServices(): Promise<UserService[]> {
    return await db.select().from(userServices).where(eq(userServices.isActive, true));
  }

  async getUserService(id: number): Promise<UserService | undefined> {
    const [service] = await db.select().from(userServices).where(eq(userServices.id, id));
    return service || undefined;
  }

  async createUserService(userService: InsertUserService): Promise<UserService> {
    const [created] = await db
      .insert(userServices)
      .values(userService)
      .returning();
    return created;
  }

  async updateUserService(id: number, updates: Partial<UserService>): Promise<UserService | undefined> {
    await db
      .update(userServices)
      .set(updates)
      .where(eq(userServices.id, id));
    return this.getUserService(id);
  }

  async deleteUserService(id: number): Promise<boolean> {
    await db
      .update(userServices)
      .set({ isActive: false })
      .where(eq(userServices.id, id));
    return true;
  }

  // Professional booking assignment methods
  async createBookingProfessionalAssignment(assignment: any): Promise<any> {
    const [result] = await db.insert(bookingProfessionalAssignments).values(assignment).returning();
    return result;
  }

  async getBookingProfessionalAssignments(bookingId: number): Promise<any[]> {
    return await db.select().from(bookingProfessionalAssignments).where(eq(bookingProfessionalAssignments.bookingId, bookingId));
  }

  async updateBookingProfessionalAssignment(id: number, updates: any): Promise<any> {
    const [result] = await db.update(bookingProfessionalAssignments).set(updates).where(eq(bookingProfessionalAssignments.id, id)).returning();
    return result;
  }

  async deleteBookingProfessionalAssignment(id: number): Promise<void> {
    await db.delete(bookingProfessionalAssignments).where(eq(bookingProfessionalAssignments.id, id));
  }
  
  // OppHub professional guidance methods
  async createOppHubProfessionalGuidance(guidance: any): Promise<any> {
    const [result] = await db.insert(oppHubProfessionalGuidance).values(guidance).returning();
    return result;
  }

  async getOppHubProfessionalGuidance(assignmentId: number): Promise<any> {
    const [result] = await db.select().from(oppHubProfessionalGuidance).where(eq(oppHubProfessionalGuidance.assignmentId, assignmentId));
    return result;
  }

  async updateOppHubProfessionalGuidance(id: number, updates: any): Promise<any> {
    const [result] = await db.update(oppHubProfessionalGuidance).set(updates).where(eq(oppHubProfessionalGuidance.id, id)).returning();
    return result;
  }

  async getServiceReviews(serviceId?: number, userServiceId?: number): Promise<ServiceReview[]> {
    if (serviceId) {
      return await db.select().from(serviceReviews).where(eq(serviceReviews.serviceId, serviceId));
    } else if (userServiceId) {
      return await db.select().from(serviceReviews).where(eq(serviceReviews.userServiceId, userServiceId));
    }
    
    return await db.select().from(serviceReviews);
  }

  async createServiceReview(review: InsertServiceReview): Promise<ServiceReview> {
    const [created] = await db
      .insert(serviceReviews)
      .values(review)
      .returning();
    return created;
  }

  // Currency management methods
  async getCurrencies(): Promise<Currency[]> {
    return await db.select().from(currencies).where(eq(currencies.isActive, true));
  }

  async getCurrency(code: string): Promise<Currency | undefined> {
    const [currency] = await db.select().from(currencies).where(eq(currencies.code, code));
    return currency || undefined;
  }

  async createCurrency(currency: InsertCurrency): Promise<Currency> {
    const [created] = await db
      .insert(currencies)
      .values(currency)
      .returning();
    return created;
  }

  async updateCurrency(code: string, updates: Partial<Currency>): Promise<Currency | undefined> {
    await db
      .update(currencies)
      .set(updates)
      .where(eq(currencies.code, code));
    return this.getCurrency(code);
  }

  async updateCurrencyRate(code: string, rate: number): Promise<Currency | undefined> {
    await db
      .update(currencies)
      .set({ rate: rate.toString(), lastUpdated: new Date() })
      .where(eq(currencies.code, code));
    return this.getCurrency(code);
  }

  // Store bundle methods
  async getBundles(): Promise<Bundle[]> {
    return await db.select().from(bundles).where(eq(bundles.isActive, true));
  }

  async getBundle(id: number): Promise<Bundle | undefined> {
    const [bundle] = await db.select().from(bundles).where(eq(bundles.id, id));
    return bundle || undefined;
  }

  async getBundlesByArtist(artistUserId: number): Promise<Bundle[]> {
    return await db
      .select()
      .from(bundles)
      .where(and(
        eq(bundles.artistUserId, artistUserId),
        eq(bundles.isActive, true)
      ));
  }

  async createBundle(bundle: InsertBundle): Promise<Bundle> {
    const [created] = await db
      .insert(bundles)
      .values(bundle)
      .returning();
    return created;
  }

  async updateBundle(id: number, updates: Partial<Bundle>): Promise<Bundle | undefined> {
    await db
      .update(bundles)
      .set(updates)
      .where(eq(bundles.id, id));
    return this.getBundle(id);
  }

  // Bundle items methods
  async getBundleItems(bundleId: number): Promise<BundleItem[]> {
    return await db
      .select()
      .from(bundleItems)
      .where(eq(bundleItems.bundleId, bundleId));
  }

  async createBundleItem(item: InsertBundleItem): Promise<BundleItem> {
    const [created] = await db
      .insert(bundleItems)
      .values(item)
      .returning();
    return created;
  }

  async deleteBundleItem(id: number): Promise<void> {
    await db
      .delete(bundleItems)
      .where(eq(bundleItems.id, id));
  }

  // Discount conditions methods
  async getDiscountConditions(bundleId: number): Promise<DiscountCondition[]> {
    return await db
      .select()
      .from(discountConditions)
      .where(and(
        eq(discountConditions.bundleId, bundleId),
        eq(discountConditions.isActive, true)
      ));
  }

  async createDiscountCondition(condition: InsertDiscountCondition): Promise<DiscountCondition> {
    const [created] = await db
      .insert(discountConditions)
      .values(condition)
      .returning();
    return created;
  }

  async updateDiscountCondition(id: number, updates: Partial<DiscountCondition>): Promise<DiscountCondition | undefined> {
    await db
      .update(discountConditions)
      .set(updates)
      .where(eq(discountConditions.id, id));
    
    const [updated] = await db
      .select()
      .from(discountConditions)
      .where(eq(discountConditions.id, id));
    return updated || undefined;
  }

  async validateDiscountCondition(conditionId: number, userValue: string): Promise<boolean> {
    const [condition] = await db
      .select()
      .from(discountConditions)
      .where(eq(discountConditions.id, conditionId));
    
    if (!condition || !condition.isActive) return false;
    
    // Check if within valid date range
    const now = new Date();
    if (condition.validFrom && new Date(condition.validFrom) > now) return false;
    if (condition.validUntil && new Date(condition.validUntil) < now) return false;
    
    // Check usage limit
    if (condition.usageLimit && condition.currentUsage >= condition.usageLimit) return false;
    
    // Validate condition based on type
    switch (condition.conditionType) {
      case 'ticket_id':
        // Check if user has valid ticket with this ID
        const engagement = await db
          .select()
          .from(fanEngagement)
          .where(and(
            eq(fanEngagement.engagementType, 'show_attendance'),
            eq(fanEngagement.engagementValue, userValue)
          ));
        return engagement.length > 0;
      
      case 'ppv_code':
        // Check if user has valid PPV code
        const ppvEngagement = await db
          .select()
          .from(fanEngagement)
          .where(and(
            eq(fanEngagement.engagementType, 'ppv_view'),
            eq(fanEngagement.engagementValue, userValue)
          ));
        return ppvEngagement.length > 0;
      
      default:
        return condition.conditionValue === userValue;
    }
  }

  // Store currencies methods
  async getStoreCurrencies(): Promise<StoreCurrency[]> {
    return await db
      .select()
      .from(storeCurrencies)
      .where(eq(storeCurrencies.isActive, true))
      .orderBy(storeCurrencies.code);
  }

  async getStoreCurrency(code: string): Promise<StoreCurrency | undefined> {
    const [currency] = await db
      .select()
      .from(storeCurrencies)
      .where(eq(storeCurrencies.code, code));
    return currency || undefined;
  }

  async createStoreCurrency(currency: InsertStoreCurrency): Promise<StoreCurrency> {
    const [created] = await db
      .insert(storeCurrencies)
      .values(currency)
      .returning();
    return created;
  }

  async updateStoreCurrency(id: number, updates: Partial<StoreCurrency>): Promise<StoreCurrency | undefined> {
    await db
      .update(storeCurrencies)
      .set({ ...updates, lastUpdated: new Date() })
      .where(eq(storeCurrencies.id, id));
    
    const [updated] = await db
      .select()
      .from(storeCurrencies)
      .where(eq(storeCurrencies.id, id));
    return updated || undefined;
  }

  // Fan engagement methods
  async createFanEngagement(engagement: InsertFanEngagement): Promise<FanEngagement> {
    const [created] = await db
      .insert(fanEngagement)
      .values(engagement)
      .returning();
    return created;
  }

  async getFanEngagement(userId: number, artistUserId: number): Promise<FanEngagement[]> {
    return await db
      .select()
      .from(fanEngagement)
      .where(and(
        eq(fanEngagement.userId, userId),
        eq(fanEngagement.artistUserId, artistUserId)
      ))
      .orderBy(desc(fanEngagement.engagementDate));
  }

  // Assignment management methods
  async createAdminAssignment(assignment: InsertAdminAssignment): Promise<AdminAssignment> {
    const [created] = await db
      .insert(adminAssignments)
      .values(assignment)
      .returning();
    
    // Enrich with user names immediately
    const [adminUser, managedUser] = await Promise.all([
      this.getUser(assignment.adminUserId),
      this.getUser(assignment.managedUserId)
    ]);
    
    return {
      ...created,
      adminName: adminUser?.fullName || 'Unknown Admin',
      managedUserName: managedUser?.fullName || 'Unknown User'
    };
  }

  async getAdminAssignments(adminUserId?: number): Promise<AdminAssignment[]> {
    let baseQuery = db
      .select()
      .from(adminAssignments)
      .where(eq(adminAssignments.isActive, true));
    
    if (adminUserId) {
      baseQuery = baseQuery.where(eq(adminAssignments.adminUserId, adminUserId));
    }
    
    const assignments = await baseQuery;
    
    // Fetch user names for each assignment
    const enrichedAssignments = await Promise.all(
      assignments.map(async (assignment) => {
        const [adminUser, managedUser] = await Promise.all([
          this.getUser(assignment.adminUserId),
          this.getUser(assignment.managedUserId)
        ]);
        
        return {
          ...assignment,
          adminName: adminUser?.fullName || 'Unknown Admin',
          managedUserName: managedUser?.fullName || 'Unknown User'
        };
      })
    );
    
    return enrichedAssignments;
  }

  async getAdminAssignment(id: number): Promise<AdminAssignment | undefined> {
    const [assignment] = await db
      .select()
      .from(adminAssignments)
      .where(eq(adminAssignments.id, id));
    
    if (!assignment) return undefined;
    
    const [adminUser, managedUser] = await Promise.all([
      this.getUser(assignment.adminUserId),
      this.getUser(assignment.managedUserId)
    ]);
    
    return {
      ...assignment,
      adminName: adminUser?.fullName || 'Unknown Admin',
      managedUserName: managedUser?.fullName || 'Unknown User'
    };
  }

  async updateAdminAssignment(id: number, updates: Partial<AdminAssignment>): Promise<AdminAssignment | undefined> {
    await db
      .update(adminAssignments)
      .set(updates)
      .where(eq(adminAssignments.id, id));
    return this.getAdminAssignment(id);
  }

  async removeAdminAssignment(id: number): Promise<void> {
    await db
      .update(adminAssignments)
      .set({ isActive: false })
      .where(eq(adminAssignments.id, id));
  }

  async createBookingAssignment(assignment: InsertBookingAssignment): Promise<BookingAssignment> {
    const [created] = await db
      .insert(bookingAssignments)
      .values(assignment)
      .returning();
    
    // Enrich with user name immediately
    const assignedUser = await this.getUser(assignment.assignedUserId);
    return {
      ...created,
      assignedUserName: assignedUser?.fullName || 'Unknown User'
    };
  }

  async getBookingAssignments(bookingId?: number): Promise<BookingAssignment[]> {
    let baseQuery = db
      .select()
      .from(bookingAssignments)
      .where(eq(bookingAssignments.isActive, true));
    
    if (bookingId) {
      baseQuery = baseQuery.where(eq(bookingAssignments.bookingId, bookingId));
    }
    
    const assignments = await baseQuery;
    
    // Fetch user names for each assignment
    const enrichedAssignments = await Promise.all(
      assignments.map(async (assignment) => {
        const assignedUser = await this.getUser(assignment.assignedUserId);
        
        return {
          ...assignment,
          assignedUserName: assignedUser?.fullName || 'Unknown User'
        };
      })
    );
    
    return enrichedAssignments;
  }

  async getBookingAssignmentsByBooking(bookingId: number): Promise<BookingAssignment[]> {
    const assignments = await db
      .select()
      .from(bookingAssignments)
      .where(and(
        eq(bookingAssignments.bookingId, bookingId),
        eq(bookingAssignments.isActive, true)
      ));
    
    const enrichedAssignments = await Promise.all(
      assignments.map(async (assignment) => {
        const assignedUser = await this.getUser(assignment.assignedUserId);
        
        return {
          ...assignment,
          assignedUserName: assignedUser?.fullName || 'Unknown User'
        };
      })
    );
    
    return enrichedAssignments;
  }

  async getBookingAssignment(id: number): Promise<BookingAssignment | undefined> {
    const [assignment] = await db
      .select()
      .from(bookingAssignments)
      .where(eq(bookingAssignments.id, id));
    
    if (!assignment) return undefined;
    
    const assignedUser = await this.getUser(assignment.assignedUserId);
    
    return {
      ...assignment,
      assignedUserName: assignedUser?.fullName || 'Unknown User'
    };
  }

  async updateBookingAssignment(id: number, updates: Partial<BookingAssignment>): Promise<BookingAssignment | undefined> {
    await db
      .update(bookingAssignments)
      .set(updates)
      .where(eq(bookingAssignments.id, id));
    return this.getBookingAssignment(id);
  }

  async removeBookingAssignment(id: number): Promise<void> {
    await db
      .update(bookingAssignments)
      .set({ isActive: false })
      .where(eq(bookingAssignments.id, id));
  }

  async createArtistMusicianAssignment(assignment: InsertArtistMusicianAssignment): Promise<ArtistMusicianAssignment> {
    const [created] = await db
      .insert(artistMusicianAssignments)
      .values(assignment)
      .returning();
    
    // Enrich with user names immediately
    const [talentUser, assigneeUser] = await Promise.all([
      this.getUser(assignment.managedTalentId),
      this.getUser(assignment.assigneeId)
    ]);
    
    return {
      ...created,
      talentName: talentUser?.fullName || 'Unknown Talent',
      assigneeName: assigneeUser?.fullName || 'Unknown Assignee'
    };
  }

  async getArtistMusicianAssignments(artistUserId?: number): Promise<ArtistMusicianAssignment[]> {
    let baseQuery = db
      .select()
      .from(artistMusicianAssignments)
      .where(eq(artistMusicianAssignments.isActive, true));
    
    if (artistUserId) {
      baseQuery = baseQuery.where(eq(artistMusicianAssignments.artistUserId, artistUserId));
    }
    
    const assignments = await baseQuery;
    
    // Fetch user names for each assignment
    const enrichedAssignments = await Promise.all(
      assignments.map(async (assignment) => {
        const [artistUser, musicianUser] = await Promise.all([
          this.getUser(assignment.artistUserId),
          this.getUser(assignment.musicianUserId)
        ]);
        
        return {
          ...assignment,
          artistName: artistUser?.fullName || 'Unknown Artist',
          musicianName: musicianUser?.fullName || 'Unknown Musician'
        };
      })
    );
    
    return enrichedAssignments;
  }

  async getArtistMusicianAssignmentsByTalent(managedTalentId: number): Promise<ArtistMusicianAssignment[]> {
    const assignments = await db
      .select()
      .from(artistMusicianAssignments)
      .where(and(
        eq(artistMusicianAssignments.managedTalentId, managedTalentId),
        eq(artistMusicianAssignments.isActive, true)
      ));
    
    const enrichedAssignments = await Promise.all(
      assignments.map(async (assignment) => {
        const [talentUser, assigneeUser] = await Promise.all([
          this.getUser(assignment.managedTalentId),
          this.getUser(assignment.assigneeId)
        ]);
        
        return {
          ...assignment,
          talentName: talentUser?.fullName || 'Unknown Talent',
          assigneeName: assigneeUser?.fullName || 'Unknown Assignee'
        };
      })
    );
    
    return enrichedAssignments;
  }

  async getArtistMusicianAssignmentsByAssignee(assigneeId: number): Promise<ArtistMusicianAssignment[]> {
    const assignments = await db
      .select()
      .from(artistMusicianAssignments)
      .where(and(
        eq(artistMusicianAssignments.assigneeId, assigneeId),
        eq(artistMusicianAssignments.isActive, true)
      ));
    
    const enrichedAssignments = await Promise.all(
      assignments.map(async (assignment) => {
        const [talentUser, assigneeUser] = await Promise.all([
          this.getUser(assignment.managedTalentId),
          this.getUser(assignment.assigneeId)
        ]);
        
        return {
          ...assignment,
          talentName: talentUser?.fullName || 'Unknown Talent',
          assigneeName: assigneeUser?.fullName || 'Unknown Assignee'
        };
      })
    );
    
    return enrichedAssignments;
  }

  async getArtistMusicianAssignmentsByUser(userId: number): Promise<ArtistMusicianAssignment[]> {
    const assignments = await db
      .select()
      .from(artistMusicianAssignments)
      .where(and(
        or(
          eq(artistMusicianAssignments.managedTalentId, userId),
          eq(artistMusicianAssignments.assigneeId, userId)
        ),
        eq(artistMusicianAssignments.isActive, true)
      ));
    
    const enrichedAssignments = await Promise.all(
      assignments.map(async (assignment) => {
        const [talentUser, assigneeUser] = await Promise.all([
          this.getUser(assignment.managedTalentId),
          this.getUser(assignment.assigneeId)
        ]);
        
        return {
          ...assignment,
          talentName: talentUser?.fullName || 'Unknown Talent',
          assigneeName: assigneeUser?.fullName || 'Unknown Assignee'
        };
      })
    );
    
    return enrichedAssignments;
  }

  async getArtistMusicianAssignment(id: number): Promise<ArtistMusicianAssignment | undefined> {
    const [assignment] = await db
      .select()
      .from(artistMusicianAssignments)
      .where(eq(artistMusicianAssignments.id, id));
    
    if (!assignment) return undefined;
    
    const [talentUser, assigneeUser] = await Promise.all([
      this.getUser(assignment.managedTalentId),
      this.getUser(assignment.assigneeId)
    ]);
    
    return {
      ...assignment,
      talentName: talentUser?.fullName || 'Unknown Talent',
      assigneeName: assigneeUser?.fullName || 'Unknown Assignee'
    };
  }

  async updateArtistMusicianAssignment(id: number, updates: Partial<ArtistMusicianAssignment>): Promise<ArtistMusicianAssignment | undefined> {
    await db
      .update(artistMusicianAssignments)
      .set(updates)
      .where(eq(artistMusicianAssignments.id, id));
    return this.getArtistMusicianAssignment(id);
  }

  async removeArtistMusicianAssignment(id: number): Promise<void> {
    await db
      .update(artistMusicianAssignments)
      .set({ isActive: false })
      .where(eq(artistMusicianAssignments.id, id));
  }

  // Booking Media Management methods
  async createBookingMediaFile(file: InsertBookingMediaFile): Promise<BookingMediaFile> {
    const [created] = await db
      .insert(bookingMediaFiles)
      .values(file)
      .returning();
    return created;
  }

  async getBookingMediaFiles(bookingId: number): Promise<BookingMediaFile[]> {
    return await db
      .select()
      .from(bookingMediaFiles)
      .where(and(
        eq(bookingMediaFiles.bookingId, bookingId),
        eq(bookingMediaFiles.isActive, true)
      ))
      .orderBy(desc(bookingMediaFiles.uploadedAt));
  }

  async getBookingMediaFile(id: number): Promise<BookingMediaFile | undefined> {
    const [file] = await db
      .select()
      .from(bookingMediaFiles)
      .where(and(
        eq(bookingMediaFiles.id, id),
        eq(bookingMediaFiles.isActive, true)
      ));
    return file || undefined;
  }

  async updateBookingMediaFile(id: number, updates: Partial<BookingMediaFile>): Promise<BookingMediaFile | undefined> {
    await db
      .update(bookingMediaFiles)
      .set(updates)
      .where(eq(bookingMediaFiles.id, id));
    
    const [updated] = await db
      .select()
      .from(bookingMediaFiles)
      .where(eq(bookingMediaFiles.id, id));
    return updated || undefined;
  }

  async deleteBookingMediaFile(id: number): Promise<void> {
    await db
      .update(bookingMediaFiles)
      .set({ isActive: false })
      .where(eq(bookingMediaFiles.id, id));
  }

  // Booking Media Access Control methods
  async createBookingMediaAccess(access: InsertBookingMediaAccess): Promise<BookingMediaAccess> {
    const [created] = await db
      .insert(bookingMediaAccess)
      .values(access)
      .returning();
    return created;
  }

  async getBookingMediaAccess(mediaFileId: number): Promise<BookingMediaAccess[]> {
    return await db
      .select()
      .from(bookingMediaAccess)
      .where(and(
        eq(bookingMediaAccess.mediaFileId, mediaFileId),
        eq(bookingMediaAccess.isActive, true)
      ))
      .orderBy(desc(bookingMediaAccess.grantedAt));
  }

  async getUserBookingMediaAccess(userId: number, mediaFileId: number): Promise<BookingMediaAccess | undefined> {
    const [access] = await db
      .select()
      .from(bookingMediaAccess)
      .where(and(
        eq(bookingMediaAccess.userId, userId),
        eq(bookingMediaAccess.mediaFileId, mediaFileId),
        eq(bookingMediaAccess.isActive, true)
      ));
    return access || undefined;
  }

  async updateBookingMediaAccess(id: number, updates: Partial<BookingMediaAccess>): Promise<BookingMediaAccess | undefined> {
    await db
      .update(bookingMediaAccess)
      .set(updates)
      .where(eq(bookingMediaAccess.id, id));
    
    const [updated] = await db
      .select()
      .from(bookingMediaAccess)
      .where(eq(bookingMediaAccess.id, id));
    return updated || undefined;
  }

  async removeBookingMediaAccess(id: number): Promise<void> {
    await db
      .update(bookingMediaAccess)
      .set({ isActive: false })
      .where(eq(bookingMediaAccess.id, id));
  }

  async checkUserMediaAccess(userId: number, mediaFileId: number, requiredLevel: string): Promise<boolean> {
    const [access] = await db
      .select()
      .from(bookingMediaAccess)
      .where(and(
        eq(bookingMediaAccess.userId, userId),
        eq(bookingMediaAccess.mediaFileId, mediaFileId),
        eq(bookingMediaAccess.accessLevel, requiredLevel),
        eq(bookingMediaAccess.isActive, true),
        or(
          isNotNull(bookingMediaAccess.expiresAt),
          gte(bookingMediaAccess.expiresAt, new Date())
        )
      ));
    return !!access;
  }

  // Booking Media Categories methods
  async getBookingMediaCategories(): Promise<BookingMediaCategory[]> {
    return await db
      .select()
      .from(bookingMediaCategories)
      .where(eq(bookingMediaCategories.isActive, true))
      .orderBy(bookingMediaCategories.name);
  }

  async createBookingMediaCategory(category: InsertBookingMediaCategory): Promise<BookingMediaCategory> {
    const [created] = await db
      .insert(bookingMediaCategories)
      .values(category)
      .returning();
    return created;
  }

  async updateBookingMediaCategory(id: number, updates: Partial<BookingMediaCategory>): Promise<BookingMediaCategory | undefined> {
    await db
      .update(bookingMediaCategories)
      .set(updates)
      .where(eq(bookingMediaCategories.id, id));
    
    const [updated] = await db
      .select()
      .from(bookingMediaCategories)
      .where(eq(bookingMediaCategories.id, id));
    return updated || undefined;
  }

  // Release Contract Management methods
  async createReleaseContract(contract: InsertReleaseContract): Promise<ReleaseContract> {
    const [created] = await db
      .insert(releaseContracts)
      .values(contract)
      .returning();
    return created;
  }

  async getReleaseContract(id: number): Promise<ReleaseContract | undefined> {
    const [contract] = await db
      .select()
      .from(releaseContracts)
      .where(eq(releaseContracts.id, id));
    return contract || undefined;
  }

  async getReleaseContractsByUser(userId: number): Promise<ReleaseContract[]> {
    return await db
      .select()
      .from(releaseContracts)
      .where(eq(releaseContracts.managedArtistUserId, userId))
      .orderBy(desc(releaseContracts.requestedAt));
  }

  async getPendingReleaseContracts(): Promise<ReleaseContract[]> {
    const contracts = await db
      .select({
        id: releaseContracts.id,
        managedArtistUserId: releaseContracts.managedArtistUserId,
        approvedByUserId: releaseContracts.approvedByUserId,
        releaseRequestReason: releaseContracts.releaseRequestReason,
        contractTerms: releaseContracts.contractTerms,
        managementTierAtRelease: releaseContracts.managementTierAtRelease,
        status: releaseContracts.status,
        requestedAt: releaseContracts.requestedAt,
        approvedAt: releaseContracts.approvedAt,
        signedAt: releaseContracts.signedAt,
        completedAt: releaseContracts.completedAt,
        createdAt: releaseContracts.createdAt,
        updatedAt: releaseContracts.updatedAt,
        managedArtistName: users.fullName,
        managedArtistEmail: users.email
      })
      .from(releaseContracts)
      .leftJoin(users, eq(releaseContracts.managedArtistUserId, users.id))
      .orderBy(desc(releaseContracts.requestedAt));
    
    return contracts as ReleaseContract[];
  }

  async updateReleaseContract(id: number, updates: Partial<ReleaseContract>): Promise<ReleaseContract | undefined> {
    await db
      .update(releaseContracts)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(releaseContracts.id, id));
    
    const [updated] = await db
      .select()
      .from(releaseContracts)
      .where(eq(releaseContracts.id, id));
    return updated || undefined;
  }

  async createReleaseContractSignature(signature: InsertReleaseContractSignature): Promise<ReleaseContractSignature> {
    const [created] = await db
      .insert(releaseContractSignatures)
      .values(signature)
      .returning();
    return created;
  }

  async getReleaseContractSignatures(contractId: number): Promise<ReleaseContractSignature[]> {
    return await db
      .select()
      .from(releaseContractSignatures)
      .where(eq(releaseContractSignatures.releaseContractId, contractId))
      .orderBy(desc(releaseContractSignatures.signedAt));
  }

  async createManagementTransition(transition: InsertManagementTransition): Promise<ManagementTransition> {
    const [created] = await db
      .insert(managementTransitions)
      .values(transition)
      .returning();
    return created;
  }

  async getManagementTransitions(userId: number): Promise<ManagementTransition[]> {
    return await db
      .select()
      .from(managementTransitions)
      .where(eq(managementTransitions.userId, userId))
      .orderBy(desc(managementTransitions.createdAt));
  }

  // Management Application System methods
  async createManagementApplication(application: InsertManagementApplication): Promise<ManagementApplication> {
    const [created] = await db
      .insert(managementApplications)
      .values(application)
      .returning();
    return created;
  }

  async getManagementApplication(id: number): Promise<ManagementApplication | undefined> {
    const [application] = await db
      .select()
      .from(managementApplications)
      .where(eq(managementApplications.id, id));
    return application || undefined;
  }

  async getManagementApplicationsByUser(userId: number): Promise<ManagementApplication[]> {
    return await db
      .select()
      .from(managementApplications)
      .where(eq(managementApplications.applicantUserId, userId))
      .orderBy(desc(managementApplications.submittedAt));
  }

  async getPendingManagementApplications(): Promise<ManagementApplication[]> {
    return await db
      .select()
      .from(managementApplications)
      .where(eq(managementApplications.status, 'pending'))
      .orderBy(desc(managementApplications.submittedAt));
  }

  async updateManagementApplication(id: number, updates: Partial<ManagementApplication>): Promise<ManagementApplication | undefined> {
    await db
      .update(managementApplications)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(managementApplications.id, id));
    
    const [updated] = await db
      .select()
      .from(managementApplications)
      .where(eq(managementApplications.id, id));
    return updated || undefined;
  }

  async createManagementApplicationSignature(signature: InsertManagementApplicationSignature): Promise<ManagementApplicationSignature> {
    const [created] = await db
      .insert(managementApplicationSignatures)
      .values(signature)
      .returning();
    return created;
  }

  async getManagementApplicationSignatures(applicationId: number): Promise<ManagementApplicationSignature[]> {
    return await db
      .select()
      .from(managementApplicationSignatures)
      .where(eq(managementApplicationSignatures.applicationId, applicationId))
      .orderBy(desc(managementApplicationSignatures.signedAt));
  }

  // Service Discount Management methods
  async createServiceDiscountOverride(override: InsertServiceDiscountOverride): Promise<ServiceDiscountOverride> {
    const [created] = await db
      .insert(serviceDiscountOverrides)
      .values(override)
      .returning();
    return created;
  }

  async getServiceDiscountOverrides(userId: number): Promise<ServiceDiscountOverride[]> {
    return await db
      .select()
      .from(serviceDiscountOverrides)
      .where(and(
        eq(serviceDiscountOverrides.userId, userId),
        eq(serviceDiscountOverrides.isActive, true)
      ))
      .orderBy(desc(serviceDiscountOverrides.createdAt));
  }

  // WaituMusic Service Default Discount Limits (Superadmin Management)
  async createWaituServiceDiscountLimit(limit: any): Promise<any> {
    const [created] = await db
      .insert(waituServiceDiscountLimits)
      .values(limit)
      .returning();
    return created;
  }

  async getWaituServiceDiscountLimit(serviceId: number): Promise<any> {
    const [limit] = await db
      .select()
      .from(waituServiceDiscountLimits)
      .where(eq(waituServiceDiscountLimits.serviceId, serviceId))
      .orderBy(desc(waituServiceDiscountLimits.updatedAt))
      .limit(1);
    return limit;
  }

  async updateWaituServiceDiscountLimit(serviceId: number, updates: any): Promise<any> {
    const [updated] = await db
      .update(waituServiceDiscountLimits)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(waituServiceDiscountLimits.serviceId, serviceId))
      .returning();
    return updated;
  }

  async getAllWaituServiceDiscountLimits(): Promise<any[]> {
    return await db
      .select()
      .from(waituServiceDiscountLimits)
      .orderBy(waituServiceDiscountLimits.serviceId);
  }

  // Individual Discount Permissions (Case-by-case Superadmin Overrides)
  async createIndividualDiscountPermission(permission: any): Promise<any> {
    const [created] = await db
      .insert(individualDiscountPermissions)
      .values(permission)
      .returning();
    return created;
  }

  async getIndividualDiscountPermission(userId: number, serviceId: number): Promise<any> {
    const [permission] = await db
      .select()
      .from(individualDiscountPermissions)
      .where(and(
        eq(individualDiscountPermissions.userId, userId),
        eq(individualDiscountPermissions.serviceId, serviceId),
        eq(individualDiscountPermissions.isActive, true)
      ))
      .orderBy(desc(individualDiscountPermissions.createdAt))
      .limit(1);
    return permission;
  }

  async getUserIndividualDiscountPermissions(userId: number): Promise<any[]> {
    return await db
      .select()
      .from(individualDiscountPermissions)
      .where(and(
        eq(individualDiscountPermissions.userId, userId),
        eq(individualDiscountPermissions.isActive, true)
      ))
      .orderBy(desc(individualDiscountPermissions.createdAt));
  }

  async revokeIndividualDiscountPermission(id: number): Promise<any> {
    const [revoked] = await db
      .update(individualDiscountPermissions)
      .set({ isActive: false })
      .where(eq(individualDiscountPermissions.id, id))
      .returning();
    return revoked;
  }

  // Global Genres Management
  async getGlobalGenres(): Promise<GlobalGenre[]> {
    return await db
      .select()
      .from(globalGenres)
      .where(eq(globalGenres.isActive, true))
      .orderBy(globalGenres.category, globalGenres.name);
  }

  async getGlobalGenresByCategory(category: string): Promise<GlobalGenre[]> {
    return await db
      .select()
      .from(globalGenres)
      .where(and(
        eq(globalGenres.category, category),
        eq(globalGenres.isActive, true)
      ))
      .orderBy(globalGenres.name);
  }

  async createGlobalGenre(genre: InsertGlobalGenre): Promise<GlobalGenre> {
    const [created] = await db
      .insert(globalGenres)
      .values(genre)
      .returning();
    return created;
  }

  // Cross-Upsell Relationships Management
  async createCrossUpsellRelationship(relationship: InsertCrossUpsellRelationship): Promise<CrossUpsellRelationship> {
    const [created] = await db
      .insert(crossUpsellRelationships)
      .values(relationship)
      .returning();
    return created;
  }

  async getCrossUpsellRelationships(sourceType: string, sourceId: number): Promise<CrossUpsellRelationship[]> {
    return await db
      .select()
      .from(crossUpsellRelationships)
      .where(and(
        eq(crossUpsellRelationships.sourceType, sourceType),
        eq(crossUpsellRelationships.sourceId, sourceId),
        eq(crossUpsellRelationships.isActive, true)
      ))
      .orderBy(desc(crossUpsellRelationships.priority));
  }

  async updateCrossUpsellRelationship(id: number, updates: Partial<CrossUpsellRelationship>): Promise<CrossUpsellRelationship | undefined> {
    const [updated] = await db
      .update(crossUpsellRelationships)
      .set(updates)
      .where(eq(crossUpsellRelationships.id, id))
      .returning();
    return updated;
  }

  async getServiceDiscountOverride(userId: number, serviceId?: number, userServiceId?: number): Promise<ServiceDiscountOverride | undefined> {
    const conditions = [
      eq(serviceDiscountOverrides.userId, userId),
      eq(serviceDiscountOverrides.isActive, true)
    ];

    if (serviceId) {
      conditions.push(eq(serviceDiscountOverrides.serviceId, serviceId));
    }
    if (userServiceId) {
      conditions.push(eq(serviceDiscountOverrides.userServiceId, userServiceId));
    }

    const [override] = await db
      .select()
      .from(serviceDiscountOverrides)
      .where(and(...conditions))
      .orderBy(desc(serviceDiscountOverrides.createdAt))
      .limit(1);
    
    return override || undefined;
  }

  async updateServiceDiscountOverride(id: number, updates: Partial<ServiceDiscountOverride>): Promise<ServiceDiscountOverride | undefined> {
    await db
      .update(serviceDiscountOverrides)
      .set(updates)
      .where(eq(serviceDiscountOverrides.id, id));
    
    const [updated] = await db
      .select()
      .from(serviceDiscountOverrides)
      .where(eq(serviceDiscountOverrides.id, id));
    return updated || undefined;
  }

  async getMaxDiscountForUser(userId: number): Promise<number> {
    // Get user and their management tier
    const user = await this.getUser(userId);
    if (!user) return 0;

    // Check for specific discount overrides first
    const overrides = await this.getServiceDiscountOverrides(userId);
    if (overrides.length > 0) {
      const maxOverride = Math.max(...overrides.map(o => parseFloat(o.overrideDiscountPercentage)));
      return maxOverride;
    }

    // Get management tier info for default discounts
    const managementTiers = await this.getManagementTiers();
    
    // Check if user is managed (roleId 3, 5, 7)
    if ([3, 5, 7].includes(user.roleId)) {
      const artist = await this.getArtist(userId);
      const musician = await this.getMusician(userId);
      const professional = await this.getProfessional(userId);
      
      const managementTierId = artist?.managementTierId || musician?.managementTierId || professional?.managementTierId;
      
      if (managementTierId) {
        const tier = managementTiers.find(t => t.id === managementTierId);
        if (tier) {
          // Full Management tier (typically tier 1) gets up to 100% discount
          // Administration tier (typically tier 2) gets up to 50% discount
          return tier.name.toLowerCase().includes('full') ? 100 : 50;
        }
      }
    }

    return 0; // No discounts for unmanaged users
  }

  // Management Application Review System methods
  async createManagementApplicationReview(review: InsertManagementApplicationReview): Promise<ManagementApplicationReview> {
    const [created] = await db
      .insert(managementApplicationReviews)
      .values(review)
      .returning();
    return created;
  }

  async getManagementApplicationReviews(applicationId: number): Promise<ManagementApplicationReview[]> {
    return await db
      .select()
      .from(managementApplicationReviews)
      .where(eq(managementApplicationReviews.applicationId, applicationId))
      .orderBy(desc(managementApplicationReviews.reviewedAt));
  }

  async getManagementApplicationsByAssignedAdmin(adminUserId: number): Promise<ManagementApplication[]> {
    // Get applications where this admin is assigned to the applicant
    const adminAssignments = await db
      .select()
      .from(adminAssignments)
      .where(eq(adminAssignments.adminUserId, adminUserId));
    
    if (adminAssignments.length === 0) return [];
    
    const managedUserIds = adminAssignments.map(a => a.managedUserId);
    
    return await db
      .select()
      .from(managementApplications)
      .where(and(
        eq(managementApplications.status, 'pending'),
        sql`${managementApplications.applicantUserId} = ANY(${managedUserIds})`
      ))
      .orderBy(desc(managementApplications.submittedAt));
  }

  // Legal Assignment System methods
  async createLegalAssignment(assignment: InsertLegalAssignment): Promise<LegalAssignment> {
    const [created] = await db
      .insert(legalAssignments)
      .values(assignment)
      .returning();
    return created;
  }

  async getLegalAssignments(clientUserId: number): Promise<LegalAssignment[]> {
    return await db
      .select()
      .from(legalAssignments)
      .where(and(
        eq(legalAssignments.clientUserId, clientUserId),
        eq(legalAssignments.isActive, true)
      ))
      .orderBy(desc(legalAssignments.assignedAt));
  }

  async getLawyerClients(lawyerUserId: number): Promise<LegalAssignment[]> {
    return await db
      .select()
      .from(legalAssignments)
      .where(and(
        eq(legalAssignments.lawyerUserId, lawyerUserId),
        eq(legalAssignments.isActive, true)
      ))
      .orderBy(desc(legalAssignments.assignedAt));
  }

  async getAssignedLawyer(clientUserId: number, assignmentType?: string): Promise<LegalAssignment | undefined> {
    const conditions = [
      eq(legalAssignments.clientUserId, clientUserId),
      eq(legalAssignments.isActive, true)
    ];

    if (assignmentType) {
      conditions.push(eq(legalAssignments.assignmentType, assignmentType));
    }

    const [assignment] = await db
      .select()
      .from(legalAssignments)
      .where(and(...conditions))
      .orderBy(desc(legalAssignments.assignedAt))
      .limit(1);
    
    return assignment || undefined;
  }

  // Application Legal Assignment System methods (Lawyers representing Wai'tuMusic)
  async createApplicationLegalAssignment(assignment: InsertApplicationLegalAssignment): Promise<ApplicationLegalAssignment> {
    const [created] = await db
      .insert(applicationLegalAssignments)
      .values(assignment)
      .returning();
    return created;
  }

  async getApplicationLegalAssignments(applicationId: number): Promise<ApplicationLegalAssignment[]> {
    return await db
      .select()
      .from(applicationLegalAssignments)
      .where(and(
        eq(applicationLegalAssignments.applicationId, applicationId),
        eq(applicationLegalAssignments.isActive, true)
      ))
      .orderBy(desc(applicationLegalAssignments.assignedAt));
  }

  async getApplicationsByAssignedLawyer(lawyerUserId: number): Promise<ApplicationLegalAssignment[]> {
    return await db
      .select()
      .from(applicationLegalAssignments)
      .where(and(
        eq(applicationLegalAssignments.lawyerUserId, lawyerUserId),
        eq(applicationLegalAssignments.isActive, true)
      ))
      .orderBy(desc(applicationLegalAssignments.assignedAt));
  }

  async removeApplicationLegalAssignment(assignmentId: number): Promise<void> {
    await db
      .update(applicationLegalAssignments)
      .set({ isActive: false })
      .where(eq(applicationLegalAssignments.id, assignmentId));
  }

  // Check for conflict of interest when assigning professionals (non-performance related)
  async checkLegalConflictOfInterest(professionalUserId: number): Promise<{ hasConflict: boolean; conflictDetails?: any[] }> {
    // Get the professional's role to determine if they can represent Wai'tuMusic
    const professional = await this.getUser(professionalUserId);
    if (!professional) {
      return { hasConflict: true, conflictDetails: [{ type: 'invalid_user', message: 'Professional not found' }] };
    }

    // Only managed professionals (roleId 7) can represent Wai'tuMusic without conflict
    const isManagedProfessional = professional.roleId === 7;
    
    // Check if professional is assigned to any managed users (artists, musicians, professionals)
    const clientAssignments = await db
      .select({
        id: legalAssignments.id,
        clientUserId: legalAssignments.clientUserId,
        assignmentType: legalAssignments.assignmentType,
        clientRole: users.roleId,
        clientName: users.fullName,
        clientEmail: users.email
      })
      .from(legalAssignments)
      .innerJoin(users, eq(legalAssignments.clientUserId, users.id))
      .where(and(
        eq(legalAssignments.lawyerUserId, professionalUserId),
        eq(legalAssignments.isActive, true)
      ));

    const conflictDetails: any[] = [];
    let hasConflict = false;

    // Check each client assignment for conflicts
    for (const assignment of clientAssignments) {
      const isClientManaged = [3, 5, 7].includes(assignment.clientRole); // Managed Artist, Managed Musician, Managed Professional
      
      if (isClientManaged) {
        // If professional is representing a managed user, they cannot represent Wai'tuMusic (conflict of interest)
        // unless the professional is also a managed professional (representing Wai'tuMusic)
        if (!isManagedProfessional) {
          hasConflict = true;
          conflictDetails.push({
            type: 'client_conflict',
            message: `Professional represents managed ${this.getRoleName(assignment.clientRole)} ${assignment.clientName}`,
            clientName: assignment.clientName,
            clientRole: assignment.clientRole,
            assignmentType: assignment.assignmentType
          });
        }
      }
    }

    // If professional is not a managed professional, they cannot represent Wai'tuMusic
    if (!isManagedProfessional) {
      hasConflict = true;
      conflictDetails.push({
        type: 'role_restriction',
        message: 'Only managed professionals can represent Wai\'tuMusic in non-performance matters',
        professionalRole: professional.roleId,
        professionalName: professional.fullName
      });
    }

    return { hasConflict, conflictDetails: conflictDetails.length > 0 ? conflictDetails : undefined };
  }

  // Get available professionals who can represent Wai'tuMusic without conflict
  async getAvailableLawyersForWaituMusic(): Promise<any[]> {
    // Get all professionals (both managed and independent) for comprehensive analysis
    const allProfessionals = await db
      .select()
      .from(users)
      .where(or(eq(users.roleId, 7), eq(users.roleId, 8))); // Managed and Independent professionals

    const availableProfessionals = [];

    for (const professional of allProfessionals) {
      // Get professional record to check if they're non-performance related
      const professionalRecord = await this.getProfessional(professional.id);
      
      if (!professionalRecord) continue;

      // Filter for non-performance related professionals (legal, consulting, administrative services)
      const nonPerformanceSpecialties = [
        'Legal Services', 'Business Consulting', 'Marketing Consulting', 
        'Financial Advisory', 'Contract Negotiation', 'Rights Management',
        'Legal Counsel', 'Business Development', 'Strategic Planning'
      ];
      
      const isNonPerformance = nonPerformanceSpecialties.some(specialty => 
        professionalRecord.specialty?.toLowerCase().includes(specialty.toLowerCase())
      ) || professionalRecord.specialty?.toLowerCase().includes('consulting') ||
         professionalRecord.specialty?.toLowerCase().includes('legal') ||
         professionalRecord.specialty?.toLowerCase().includes('advisory');

      if (!isNonPerformance) continue; // Skip performance-related professionals

      const conflictCheck = await this.checkLegalConflictOfInterest(professional.id);
      
      if (!conflictCheck.hasConflict) {
        availableProfessionals.push({
          ...professional,
          specialty: professionalRecord.specialty || 'Professional Services',
          hourlyRate: professionalRecord.hourlyRate || 0,
          isAvailable: true,
          conflictStatus: 'clear',
          serviceType: 'non_performance'
        });
      } else {
        // Include but mark as having conflicts (for superadmin override consideration)
        availableProfessionals.push({
          ...professional,
          specialty: professionalRecord.specialty || 'Professional Services',
          hourlyRate: professionalRecord.hourlyRate || 0,
          isAvailable: false,
          conflictStatus: 'conflict',
          conflictDetails: conflictCheck.conflictDetails,
          serviceType: 'non_performance'
        });
      }
    }

    return availableProfessionals;
  }

  private getRoleName(roleId: number): string {
    const roleNames = {
      1: 'superadmin',
      2: 'admin', 
      3: 'managed_artist',
      4: 'artist',
      5: 'managed_musician',
      6: 'musician',
      7: 'managed_professional',
      8: 'professional',
      9: 'fan'
    };
    return roleNames[roleId] || 'unknown';
  }

  // System data methods
  async getSystemSettings(): Promise<any[]> {
    try {
      // Return empty array for now since systemSettings table doesn't exist
      return [];
    } catch (error) {
      console.error('System settings error:', error);
      return [];
    }
  }

  async getActivityLogs(): Promise<any[]> {
    const results = await db.execute(sql`
      SELECT * FROM activity_logs 
      ORDER BY created_at DESC 
      LIMIT 10
    `);
    return results.rows;
  }

  // Stage Plots Implementation
  async getStagePlots(): Promise<any[]> {
    const result = await db.select().from(stagePlots);
    return result;
  }

  async getStagePlot(id: number): Promise<any> {
    const result = await db.select().from(stagePlots).where(eq(stagePlots.id, id));
    return result[0];
  }

  async createStagePlot(stagePlot: any): Promise<any> {
    // Ensure clean data without timestamp fields that could cause issues
    const cleanData = {
      name: stagePlot.name,
      items: stagePlot.items,
      stageWidth: stagePlot.stageWidth,
      stageHeight: stagePlot.stageHeight,
      bookingId: stagePlot.bookingId,
      createdBy: stagePlot.createdBy,
    };
    
    const result = await db.insert(stagePlots).values(cleanData).returning();
    return result[0];
  }

  async updateStagePlot(id: number, updates: any): Promise<any> {
    const result = await db.update(stagePlots)
      .set({ ...updates, modifiedAt: new Date() })
      .where(eq(stagePlots.id, id))
      .returning();
    return result[0];
  }

  async deleteStagePlot(id: number): Promise<void> {
    await db.delete(stagePlots).where(eq(stagePlots.id, id));
  }

  // Mixer Patch Lists Implementation
  async getMixerPatchLists(): Promise<any[]> {
    const result = await db.select().from(mixerPatchLists);
    return result;
  }

  async getMixerPatchList(id: number): Promise<any> {
    const result = await db.select().from(mixerPatchLists).where(eq(mixerPatchLists.id, id));
    return result[0];
  }

  async createMixerPatchList(patchList: any): Promise<any> {
    // Ensure clean data without timestamp fields that could cause issues
    const cleanData = {
      name: patchList.name,
      rows: patchList.rows,
      bookingId: patchList.bookingId,
      createdBy: patchList.createdBy,
    };
    
    const result = await db.insert(mixerPatchLists).values(cleanData).returning();
    return result[0];
  }

  async updateMixerPatchList(id: number, updates: any): Promise<any> {
    const result = await db.update(mixerPatchLists)
      .set({ ...updates, modifiedAt: new Date() })
      .where(eq(mixerPatchLists.id, id))
      .returning();
    return result[0];
  }

  async deleteMixerPatchList(id: number): Promise<void> {
    await db.delete(mixerPatchLists).where(eq(mixerPatchLists.id, id));
  }

  // Setlist Implementation with actual storage
  private setlistStorage = new Map<number, any>();

  async getSetlist(bookingId: number): Promise<any> {
    // Check for stored setlist first
    const storedSetlist = this.setlistStorage.get(bookingId);
    if (storedSetlist) {
      return storedSetlist;
    }
    
    // Return null if no setlist found (don't return demo data)
    return null;
  }

  async saveSetlist(bookingId: number, setlistData: any): Promise<any> {
    // Save the actual setlist data with proper metadata
    const savedSetlist = {
      bookingId,
      name: setlistData.name || 'Performance Setlist',
      description: setlistData.description || '',
      songs: setlistData.songs || [],
      id: Math.floor(Math.random() * 1000) + 1,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    // Store in memory (in production, this would be saved to database)
    this.setlistStorage.set(bookingId, savedSetlist);
    console.log(`Setlist saved for booking ${bookingId}:`, { name: savedSetlist.name, description: savedSetlist.description, songCount: savedSetlist.songs.length });
    
    return savedSetlist;
  }

  // Setlist Templates Management
  async getSetlistTemplates(): Promise<any[]> {
    const result = await db.select().from(setlistTemplates).orderBy(desc(setlistTemplates.createdAt));
    return result;
  }

  async getSetlistTemplate(id: number): Promise<any> {
    const result = await db.select().from(setlistTemplates).where(eq(setlistTemplates.id, id));
    return result[0];
  }

  async createSetlistTemplate(template: any): Promise<any> {
    // Ensure clean data without timestamp fields that could cause issues
    const cleanData = {
      name: template.name,
      description: template.description,
      songs: template.songs,
      totalDuration: template.totalDuration,
      createdBy: template.createdBy,
    };
    
    const result = await db.insert(setlistTemplates).values(cleanData).returning();
    return result[0];
  }

  async updateSetlistTemplate(id: number, updates: any): Promise<any> {
    const result = await db.update(setlistTemplates)
      .set({ ...updates, modifiedAt: new Date() })
      .where(eq(setlistTemplates.id, id))
      .returning();
    return result[0];
  }

  async deleteSetlistTemplate(id: number): Promise<void> {
    await db.delete(setlistTemplates).where(eq(setlistTemplates.id, id));
  }

  // Performance rate management methods
  async setMusicianPerformanceRate(bookingId: number, musicianId: number, adminId: number, rate: number, notes?: string, originalCurrency?: string, originalAmount?: number): Promise<any> {
    try {
      // First check if booking musician assignment exists
      const existingAssignment = await db
        .select()
        .from(bookingMusicians)
        .where(and(
          eq(bookingMusicians.bookingId, bookingId),
          eq(bookingMusicians.musicianUserId, musicianId)
        ))
        .limit(1);

      const updateData = {
        adminSetRate: rate.toString(),
        originalCurrency: originalCurrency || 'USD',
        originalAmount: originalAmount?.toString() || rate.toString(),
        rateStatus: 'admin_set',
        rateSetByAdminId: adminId,
        rateNotes: notes,
        rateSetAt: new Date()
      };

      if (existingAssignment.length === 0) {
        // Create new assignment if it doesn't exist
        await db.insert(bookingMusicians).values({
          bookingId,
          musicianUserId: musicianId,
          ...updateData
        });
      } else {
        // Update existing assignment
        await db
          .update(bookingMusicians)
          .set(updateData)
          .where(and(
            eq(bookingMusicians.bookingId, bookingId),
            eq(bookingMusicians.musicianUserId, musicianId)
          ));
      }

      return { success: true };
    } catch (error) {
      console.error('Error setting musician performance rate:', error);
      throw error;
    }
  }

  async getBookingMusiciansWithRates(bookingId: number): Promise<any[]> {
    try {
      const musiciansWithRates = await db
        .select({
          id: users.id,
          name: users.fullName,
          email: users.email,
          instruments: musicians.instruments,
          idealRate: bookingMusicians.idealRate,
          adminSetRate: bookingMusicians.adminSetRate,
          originalCurrency: bookingMusicians.originalCurrency,
          originalAmount: bookingMusicians.originalAmount,
          confirmedFee: bookingMusicians.confirmedFee,
          rateStatus: bookingMusicians.rateStatus,
          musicianResponse: bookingMusicians.musicianResponse,
          musicianResponseMessage: bookingMusicians.musicianResponseMessage,
          rateNotes: bookingMusicians.rateNotes,
          minimumAcceptableRate: musicians.minimumAcceptableRate,
          idealPerformanceRate: musicians.idealPerformanceRate,
          assignedAt: bookingMusicians.assignedAt,
          rateSetAt: bookingMusicians.rateSetAt,
          musicianResponseAt: bookingMusicians.musicianResponseAt
        })
        .from(bookingMusicians)
        .innerJoin(users, eq(bookingMusicians.musicianUserId, users.id))
        .leftJoin(musicians, eq(users.id, musicians.userId))
        .where(eq(bookingMusicians.bookingId, bookingId));

      return musiciansWithRates;
    } catch (error) {
      console.error('Error fetching booking musicians with rates:', error);
      return [];
    }
  }

  async respondToPerformanceRate(bookingId: number, musicianId: number, response: string, message?: string, counterOffer?: any): Promise<any> {
    try {
      const updateData: any = {
        musicianResponse: response,
        musicianResponseMessage: message,
        musicianResponseAt: new Date(),
        rateStatus: response === 'accepted' ? 'accepted' : response === 'declined' ? 'declined' : response === 'counter_offer' ? 'counter_offer' : 'pending'
      };

      // Add counter offer data if provided
      if (counterOffer && response === 'counter_offer') {
        updateData.counterOfferAmount = counterOffer.amount.toString();
        updateData.counterOfferCurrency = counterOffer.currency;
        updateData.counterOfferUsdEquivalent = counterOffer.usdEquivalent.toString();
        updateData.counterOfferMessage = counterOffer.message;
        updateData.counterOfferAt = new Date();
      }

      const result = await db
        .update(bookingMusicians)
        .set(updateData)
        .where(and(
          eq(bookingMusicians.bookingId, bookingId),
          eq(bookingMusicians.musicianUserId, musicianId)
        ));

      return { success: true, counterOffer: counterOffer };
    } catch (error) {
      console.error('Error recording musician rate response:', error);
      throw error;
    }
  }

  async getMusicianBookingRates(musicianId: number): Promise<any[]> {
    try {
      const bookingRates = await db
        .select({
          id: bookings.id,
          artistName: artists.stageName,
          eventDate: bookings.eventDate,
          eventLocation: bookings.eventLocation,
          status: bookings.status,
          // Rate information
          adminSetRate: bookingMusicians.adminSetRate,
          originalCurrency: bookingMusicians.originalCurrency,
          originalAmount: bookingMusicians.originalAmount,
          rateStatus: bookingMusicians.rateStatus,
          musicianResponse: bookingMusicians.musicianResponse,
          musicianResponseMessage: bookingMusicians.musicianResponseMessage,
          rateNotes: bookingMusicians.rateNotes,
          rateSetAt: bookingMusicians.rateSetAt,
          musicianResponseAt: bookingMusicians.musicianResponseAt,
          // Counter offer fields
          counterOfferAmount: bookingMusicians.counterOfferAmount,
          counterOfferCurrency: bookingMusicians.counterOfferCurrency,
          counterOfferUsdEquivalent: bookingMusicians.counterOfferUsdEquivalent,
          counterOfferMessage: bookingMusicians.counterOfferMessage,
          counterOfferAt: bookingMusicians.counterOfferAt,
          // Admin response to counter offer
          adminCounterResponse: bookingMusicians.adminCounterResponse,
          adminCounterResponseMessage: bookingMusicians.adminCounterResponseMessage,
          adminCounterResponseAt: bookingMusicians.adminCounterResponseAt
        })
        .from(bookingMusicians)
        .innerJoin(bookings, eq(bookingMusicians.bookingId, bookings.id))
        .innerJoin(artists, eq(bookings.artistUserId, artists.userId))
        .where(eq(bookingMusicians.musicianUserId, musicianId))
        .orderBy(bookings.eventDate);

      return bookingRates.map(rate => ({
        id: rate.id,
        artistName: rate.artistName,
        eventDate: rate.eventDate,
        eventLocation: rate.eventLocation,
        status: rate.status,
        rateInfo: rate.adminSetRate ? {
          adminSetRate: parseFloat(rate.adminSetRate),
          originalCurrency: rate.originalCurrency,
          originalAmount: rate.originalAmount ? parseFloat(rate.originalAmount) : parseFloat(rate.adminSetRate),
          rateStatus: rate.rateStatus,
          musicianResponse: rate.musicianResponse,
          musicianResponseMessage: rate.musicianResponseMessage,
          rateNotes: rate.rateNotes,
          rateSetAt: rate.rateSetAt,
          musicianResponseAt: rate.musicianResponseAt,
          // Counter offer data
          counterOfferAmount: rate.counterOfferAmount ? parseFloat(rate.counterOfferAmount) : undefined,
          counterOfferCurrency: rate.counterOfferCurrency,
          counterOfferUsdEquivalent: rate.counterOfferUsdEquivalent ? parseFloat(rate.counterOfferUsdEquivalent) : undefined,
          counterOfferMessage: rate.counterOfferMessage,
          counterOfferAt: rate.counterOfferAt,
          // Admin counter response
          adminCounterResponse: rate.adminCounterResponse,
          adminCounterResponseMessage: rate.adminCounterResponseMessage,
          adminCounterResponseAt: rate.adminCounterResponseAt
        } : null
      }));
    } catch (error) {
      console.error('Error fetching musician booking rates:', error);
      return [];
    }
  }

  // Setlist management
  async getBookingSetlist(bookingId: number): Promise<any> {
    const setlist = await db
      .select()
      .from(bookingSetlists)
      .where(eq(bookingSetlists.bookingId, bookingId))
      .limit(1);

    if (setlist.length === 0) return null;

    const songs = await db
      .select()
      .from(setlistSongs)
      .where(eq(setlistSongs.setlistId, setlist[0].id))
      .orderBy(setlistSongs.orderPosition);

    return {
      ...setlist[0],
      songs
    };
  }

  async createBookingSetlist(data: any): Promise<any> {
    const [setlist] = await db
      .insert(bookingSetlists)
      .values({
        bookingId: data.bookingId,
        name: data.name,
        description: data.description,
        createdBy: data.createdBy
      })
      .returning();

    if (data.songs && data.songs.length > 0) {
      const songData = data.songs.map((song: any, index: number) => ({
        setlistId: setlist.id,
        orderPosition: index + 1,
        songTitle: song.songTitle,
        artistPerformer: song.artistPerformer,
        originalArtist: song.originalArtist,
        keySignature: song.keySignature,
        tempo: song.tempo,
        timeSignature: song.timeSignature,
        chordProgression: song.chordProgression,
        notes: song.notes,
        youtubeLink: song.youtubeLink,
        uploadedTrackId: song.uploadedTrackId,
        songwriters: song.songwriters ? JSON.stringify(song.songwriters) : null,
        publishers: song.publishers ? JSON.stringify(song.publishers) : null,
        isrc: song.isrc,
        duration: song.duration,
        releaseYear: song.releaseYear,
        webSearchData: song.webSearchData ? JSON.stringify(song.webSearchData) : null
      }));

      await db.insert(setlistSongs).values(songData);
    }

    return this.getBookingSetlist(data.bookingId);
  }

  async updateBookingSetlist(bookingId: number, data: any): Promise<any> {
    const existing = await db
      .select()
      .from(bookingSetlists)
      .where(eq(bookingSetlists.bookingId, bookingId))
      .limit(1);

    if (existing.length === 0) {
      return this.createBookingSetlist({ ...data, bookingId });
    }

    await db
      .update(bookingSetlists)
      .set({
        name: data.name,
        description: data.description,
        modifiedAt: new Date()
      })
      .where(eq(bookingSetlists.id, existing[0].id));

    // Delete existing songs
    await db
      .delete(setlistSongs)
      .where(eq(setlistSongs.setlistId, existing[0].id));

    // Insert updated songs
    if (data.songs && data.songs.length > 0) {
      const songData = data.songs.map((song: any, index: number) => ({
        setlistId: existing[0].id,
        orderPosition: index + 1,
        songTitle: song.songTitle,
        artistPerformer: song.artistPerformer,
        originalArtist: song.originalArtist,
        keySignature: song.keySignature,
        tempo: song.tempo,
        timeSignature: song.timeSignature,
        chordProgression: song.chordProgression,
        notes: song.notes,
        youtubeLink: song.youtubeLink,
        uploadedTrackId: song.uploadedTrackId,
        songwriters: song.songwriters ? JSON.stringify(song.songwriters) : null,
        publishers: song.publishers ? JSON.stringify(song.publishers) : null,
        isrc: song.isrc,
        duration: song.duration,
        releaseYear: song.releaseYear,
        webSearchData: song.webSearchData ? JSON.stringify(song.webSearchData) : null
      }));

      await db.insert(setlistSongs).values(songData);
    }

    return this.getBookingSetlist(bookingId);
  }

  async getSongChordProgressions(setlistSongId: number): Promise<any[]> {
    return await db
      .select()
      .from(songChordProgressions)
      .where(eq(songChordProgressions.setlistSongId, setlistSongId));
  }

  async createChordProgression(data: any): Promise<any> {
    const [progression] = await db
      .insert(songChordProgressions)
      .values({
        setlistSongId: data.setlistSongId,
        instrument: data.instrument,
        chordData: JSON.stringify(data.chordData),
        difficulty: data.difficulty,
        capoPosition: data.capoPosition,
        tuning: data.tuning,
        generatedFrom: data.generatedFrom
      })
      .returning();

    return progression;
  }

  // ==================== FINANCIAL AUTOMATION METHODS ====================

  // Invoice Management
  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const [newInvoice] = await db.insert(invoices).values(invoice).returning();
    return newInvoice;
  }

  async getInvoice(id: number): Promise<Invoice | undefined> {
    const result = await db.select().from(invoices).where(eq(invoices.id, id));
    return result[0];
  }

  async getInvoicesByBooking(bookingId: number): Promise<Invoice[]> {
    return await db.select().from(invoices).where(eq(invoices.bookingId, bookingId));
  }

  async updateInvoiceStatus(id: number, status: string): Promise<Invoice | undefined> {
    const [updatedInvoice] = await db
      .update(invoices)
      .set({ status })
      .where(eq(invoices.id, id))
      .returning();
    return updatedInvoice;
  }

  async generateInvoiceNumber(): Promise<string> {
    const count = await db
      .select({ count: invoices.id })
      .from(invoices)
      .then(result => result.length);
    
    const year = new Date().getFullYear();
    const paddedCount = String(count + 1).padStart(6, '0');
    return `INV-${year}-${paddedCount}`;
  }

  async getAllInvoices(): Promise<Invoice[]> {
    return await db.select().from(invoices).orderBy(desc(invoices.createdAt));
  }

  async getInvoiceById(id: number): Promise<Invoice | undefined> {
    const result = await db.select().from(invoices).where(eq(invoices.id, id));
    return result[0];
  }

  // Payout Request Management
  async createPayoutRequest(payoutRequest: InsertPayoutRequest): Promise<PayoutRequest> {
    const [newPayoutRequest] = await db.insert(payoutRequests).values(payoutRequest).returning();
    return newPayoutRequest;
  }

  async getPayoutRequest(id: number): Promise<PayoutRequest | undefined> {
    const result = await db.select().from(payoutRequests).where(eq(payoutRequests.id, id));
    return result[0];
  }

  async getPayoutRequestsByBooking(bookingId: number): Promise<PayoutRequest[]> {
    return await db.select().from(payoutRequests).where(eq(payoutRequests.bookingId, bookingId));
  }

  async getPayoutRequestsByPerformer(performerUserId: number): Promise<PayoutRequest[]> {
    return await db.select().from(payoutRequests).where(eq(payoutRequests.performerUserId, performerUserId));
  }

  async updatePayoutRequestStatus(id: number, status: string): Promise<PayoutRequest | undefined> {
    const [updatedPayoutRequest] = await db
      .update(payoutRequests)
      .set({ status })
      .where(eq(payoutRequests.id, id))
      .returning();
    return updatedPayoutRequest;
  }

  async generatePayoutRequestNumber(): Promise<string> {
    const count = await db
      .select({ count: payoutRequests.id })
      .from(payoutRequests)
      .then(result => result.length);
    
    const year = new Date().getFullYear();
    const paddedCount = String(count + 1).padStart(6, '0');
    return `PAYOUT-${year}-${paddedCount}`;
  }

  async getAllPayoutRequests(): Promise<PayoutRequest[]> {
    return await db.select().from(payoutRequests).orderBy(desc(payoutRequests.createdAt));
  }

  // Document Linkage System
  async createDocumentLinkage(linkage: InsertDocumentLinkage): Promise<DocumentLinkage> {
    const [newLinkage] = await db.insert(documentLinkages).values(linkage).returning();
    return newLinkage;
  }

  async getDocumentLinkages(sourceType: string, sourceId: number): Promise<DocumentLinkage[]> {
    return await db
      .select()
      .from(documentLinkages)
      .where(and(
        eq(documentLinkages.sourceDocumentType, sourceType),
        eq(documentLinkages.sourceDocumentId, sourceId)
      ));
  }

  async getLinkedDocuments(documentType: string, documentId: number): Promise<DocumentLinkage[]> {
    return await db
      .select()
      .from(documentLinkages)
      .where(and(
        eq(documentLinkages.linkedDocumentType, documentType),
        eq(documentLinkages.linkedDocumentId, documentId)
      ));
  }

  // Payment Transaction Tracking
  async createPaymentTransaction(transaction: InsertPaymentTransaction): Promise<PaymentTransaction> {
    const [newTransaction] = await db.insert(paymentTransactions).values(transaction).returning();
    return newTransaction;
  }

  async getPaymentTransaction(id: number): Promise<PaymentTransaction | undefined> {
    const result = await db.select().from(paymentTransactions).where(eq(paymentTransactions.id, id));
    return result[0];
  }

  async getPaymentTransactionsByBooking(bookingId: number): Promise<PaymentTransaction[]> {
    return await db.select().from(paymentTransactions).where(eq(paymentTransactions.bookingId, bookingId));
  }

  async getPaymentTransactionsByInvoice(invoiceId: number): Promise<PaymentTransaction[]> {
    return await db.select().from(paymentTransactions).where(eq(paymentTransactions.invoiceId, invoiceId));
  }

  async updatePaymentTransactionStatus(id: number, status: string): Promise<PaymentTransaction | undefined> {
    const [updatedTransaction] = await db
      .update(paymentTransactions)
      .set({ status })
      .where(eq(paymentTransactions.id, id))
      .returning();
    return updatedTransaction;
  }

  // Financial Audit Trail
  async createFinancialAuditLog(auditLog: InsertFinancialAuditLog): Promise<FinancialAuditLog> {
    const [newAuditLog] = await db.insert(financialAuditLog).values(auditLog).returning();
    return newAuditLog;
  }

  async getFinancialAuditLogs(entityType: string, entityId: number): Promise<FinancialAuditLog[]> {
    return await db
      .select()
      .from(financialAuditLog)
      .where(and(
        eq(financialAuditLog.entityType, entityType),
        eq(financialAuditLog.entityId, entityId)
      ))
      .orderBy(desc(financialAuditLog.createdAt));
  }

  // Enhanced Payments & Receipts
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  async getPayment(id: number): Promise<Payment | undefined> {
    const result = await db.select().from(payments).where(eq(payments.id, id));
    return result[0];
  }

  async getPaymentsByBooking(bookingId: number): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.bookingId, bookingId));
  }

  async updatePaymentStatus(id: number, status: string): Promise<Payment | undefined> {
    const [updatedPayment] = await db
      .update(payments)
      .set({ status })
      .where(eq(payments.id, id))
      .returning();
    return updatedPayment;
  }

  async createReceipt(receipt: InsertReceipt): Promise<Receipt> {
    const [newReceipt] = await db.insert(receipts).values(receipt).returning();
    return newReceipt;
  }

  async getReceipt(id: number): Promise<Receipt | undefined> {
    const result = await db.select().from(receipts).where(eq(receipts.id, id));
    return result[0];
  }

  async getReceiptsByBooking(bookingId: number): Promise<Receipt[]> {
    return await db.select().from(receipts).where(eq(receipts.bookingId, bookingId));
  }

  async generateReceiptNumber(): Promise<string> {
    const count = await db
      .select({ count: receipts.id })
      .from(receipts)
      .then(result => result.length);
    
    const year = new Date().getFullYear();
    const paddedCount = String(count + 1).padStart(6, '0');
    return `REC-${year}-${paddedCount}`;
  }

  // AI-Powered Social Media Campaign Management
  async createSocialMediaCampaign(campaign: InsertSocialMediaCampaign): Promise<SocialMediaCampaign> {
    const [newCampaign] = await db.insert(socialMediaCampaigns).values(campaign).returning();
    return newCampaign;
  }

  async getSocialMediaCampaign(id: number): Promise<SocialMediaCampaign | undefined> {
    const result = await db.select().from(socialMediaCampaigns).where(eq(socialMediaCampaigns.id, id));
    return result[0];
  }

  async getSocialMediaCampaignsByUser(userId: number): Promise<SocialMediaCampaign[]> {
    return await db.select().from(socialMediaCampaigns).where(eq(socialMediaCampaigns.userId, userId));
  }

  async getAllSocialMediaCampaigns(): Promise<SocialMediaCampaign[]> {
    return await db.select().from(socialMediaCampaigns);
  }

  async updateSocialMediaCampaign(id: number, updates: Partial<SocialMediaCampaign>): Promise<SocialMediaCampaign | undefined> {
    const [updatedCampaign] = await db
      .update(socialMediaCampaigns)
      .set(updates)
      .where(eq(socialMediaCampaigns.id, id))
      .returning();
    return updatedCampaign;
  }

  async deleteSocialMediaCampaign(id: number): Promise<void> {
    await db.delete(socialMediaCampaigns).where(eq(socialMediaCampaigns.id, id));
  }

  // Competitive Intelligence System
  async createCompetitiveIntelligence(intelligence: InsertCompetitiveIntelligence): Promise<CompetitiveIntelligence> {
    const [newIntelligence] = await db.insert(competitiveIntelligence).values(intelligence).returning();
    return newIntelligence;
  }

  async getCompetitiveIntelligence(id: number): Promise<CompetitiveIntelligence | undefined> {
    const result = await db.select().from(competitiveIntelligence).where(eq(competitiveIntelligence.id, id));
    return result[0];
  }

  async getCompetitiveIntelligenceByArtist(artistId: number): Promise<CompetitiveIntelligence[]> {
    return await db.select().from(competitiveIntelligence).where(eq(competitiveIntelligence.artistId, artistId));
  }

  async getCompetitiveIntelligenceByRegion(region: string): Promise<CompetitiveIntelligence[]> {
    return await db.select().from(competitiveIntelligence).where(eq(competitiveIntelligence.region, region));
  }

  async updateCompetitiveIntelligence(id: number, updates: Partial<CompetitiveIntelligence>): Promise<CompetitiveIntelligence | undefined> {
    const [updatedIntelligence] = await db
      .update(competitiveIntelligence)
      .set(updates)
      .where(eq(competitiveIntelligence.id, id))
      .returning();
    return updatedIntelligence;
  }

  async deleteCompetitiveIntelligence(id: number): Promise<void> {
    await db.delete(competitiveIntelligence).where(eq(competitiveIntelligence.id, id));
  }

  // Website Integration (All-Links Solution)
  async createWebsiteIntegration(integration: InsertWebsiteIntegration): Promise<WebsiteIntegration> {
    const [newIntegration] = await db.insert(websiteIntegrations).values(integration).returning();
    return newIntegration;
  }

  async getWebsiteIntegration(id: number): Promise<WebsiteIntegration | undefined> {
    const result = await db.select().from(websiteIntegrations).where(eq(websiteIntegrations.id, id));
    return result[0];
  }

  async getWebsiteIntegrationBySlug(slug: string): Promise<WebsiteIntegration | undefined> {
    const result = await db.select().from(websiteIntegrations).where(eq(websiteIntegrations.slug, slug));
    return result[0];
  }

  async getWebsiteIntegrationsByUser(userId: number): Promise<WebsiteIntegration[]> {
    return await db.select().from(websiteIntegrations).where(eq(websiteIntegrations.userId, userId));
  }

  async getAllWebsiteIntegrations(): Promise<WebsiteIntegration[]> {
    return await db.select().from(websiteIntegrations);
  }

  async updateWebsiteIntegration(id: number, updates: Partial<WebsiteIntegration>): Promise<WebsiteIntegration | undefined> {
    const [updatedIntegration] = await db
      .update(websiteIntegrations)
      .set(updates)
      .where(eq(websiteIntegrations.id, id))
      .returning();
    return updatedIntegration;
  }

  async deleteWebsiteIntegration(id: number): Promise<void> {
    await db.delete(websiteIntegrations).where(eq(websiteIntegrations.id, id));
  }

  async incrementWebsiteViews(id: number): Promise<void> {
    await db
      .update(websiteIntegrations)
      .set({ 
        viewCount: sql`${websiteIntegrations.viewCount} + 1`,
        lastViewed: new Date()
      })
      .where(eq(websiteIntegrations.id, id));
  }

  async incrementWebsiteClicks(id: number): Promise<void> {
    await db
      .update(websiteIntegrations)
      .set({ clickCount: sql`${websiteIntegrations.clickCount} + 1` })
      .where(eq(websiteIntegrations.id, id));
  }

  // Embeddable Widgets System
  async createEmbeddableWidget(widget: InsertEmbeddableWidget): Promise<EmbeddableWidget> {
    const [newWidget] = await db.insert(embeddableWidgets).values(widget).returning();
    return newWidget;
  }

  async getEmbeddableWidget(id: number): Promise<EmbeddableWidget | undefined> {
    const result = await db.select().from(embeddableWidgets).where(eq(embeddableWidgets.id, id));
    return result[0];
  }

  async getEmbeddableWidgetsByUser(userId: number): Promise<EmbeddableWidget[]> {
    return await db.select().from(embeddableWidgets).where(eq(embeddableWidgets.userId, userId));
  }

  async getAllEmbeddableWidgets(): Promise<EmbeddableWidget[]> {
    return await db.select().from(embeddableWidgets);
  }

  async updateEmbeddableWidget(id: number, updates: Partial<EmbeddableWidget>): Promise<EmbeddableWidget | undefined> {
    const [updatedWidget] = await db
      .update(embeddableWidgets)
      .set(updates)
      .where(eq(embeddableWidgets.id, id))
      .returning();
    return updatedWidget;
  }

  async deleteEmbeddableWidget(id: number): Promise<void> {
    await db.delete(embeddableWidgets).where(eq(embeddableWidgets.id, id));
  }

  async updateWidgetUsageStats(id: number, stats: any): Promise<void> {
    await db
      .update(embeddableWidgets)
      .set({ usageStats: stats })
      .where(eq(embeddableWidgets.id, id));
  }

  // Career Forecasting System
  async createCareerForecasting(forecasting: InsertCareerForecasting): Promise<CareerForecasting> {
    const [newForecasting] = await db.insert(careerForecasting).values(forecasting).returning();
    return newForecasting;
  }

  async getCareerForecasting(id: number): Promise<CareerForecasting | undefined> {
    const result = await db.select().from(careerForecasting).where(eq(careerForecasting.id, id));
    return result[0];
  }

  async getCareerForecastingByUser(userId: number): Promise<CareerForecasting[]> {
    return await db.select().from(careerForecasting).where(eq(careerForecasting.userId, userId));
  }

  async getCareerForecastingByPeriod(period: string): Promise<CareerForecasting[]> {
    return await db.select().from(careerForecasting).where(eq(careerForecasting.forecastPeriod, period));
  }

  async updateCareerForecasting(id: number, updates: Partial<CareerForecasting>): Promise<CareerForecasting | undefined> {
    const [updatedForecasting] = await db
      .update(careerForecasting)
      .set(updates)
      .where(eq(careerForecasting.id, id))
      .returning();
    return updatedForecasting;
  }

  async deleteCareerForecasting(id: number): Promise<void> {
    await db.delete(careerForecasting).where(eq(careerForecasting.id, id));
  }

  // User Favorites Methods
  async addUserFavorite(userId: number, favoriteUserId: number, favoriteType: string = 'artist') {
    try {
      const result = await db.insert(userFavorites).values({
        userId,
        favoriteUserId,
        favoriteType
      }).returning();
      return result[0];
    } catch (error: any) {
      if (error.code === '23505') { // Unique constraint violation
        throw new Error('Artist is already in favorites');
      }
      throw error;
    }
  }

  async removeUserFavorite(userId: number, favoriteUserId: number) {
    const result = await db.delete(userFavorites)
      .where(and(
        eq(userFavorites.userId, userId),
        eq(userFavorites.favoriteUserId, favoriteUserId)
      ))
      .returning();
    return result[0];
  }

  async getUserFavorites(userId: number) {
    const result = await db.select({
      id: userFavorites.id,
      favoriteUserId: userFavorites.favoriteUserId,
      favoriteType: userFavorites.favoriteType,
      createdAt: userFavorites.createdAt,
      favoriteUser: {
        id: users.id,
        fullName: users.fullName,
        email: users.email,
        roleId: users.roleId
      },
      artist: {
        stageName: artists.stageName,
        primaryGenre: artists.primaryGenre,
        basePrice: artists.basePrice
      }
    })
    .from(userFavorites)
    .leftJoin(users, eq(userFavorites.favoriteUserId, users.id))
    .leftJoin(artists, eq(userFavorites.favoriteUserId, artists.userId))
    .where(eq(userFavorites.userId, userId))
    .orderBy(desc(userFavorites.createdAt));
    
    return result;
  }

  async checkIfUserFavorite(userId: number, favoriteUserId: number) {
    const result = await db.select()
      .from(userFavorites)
      .where(and(
        eq(userFavorites.userId, userId),
        eq(userFavorites.favoriteUserId, favoriteUserId)
      ))
      .limit(1);
    
    return result.length > 0;
  }

  // OppHub - Opportunity Hub Implementation
  async getOpportunityCategories(): Promise<OpportunityCategory[]> {
    const result = await db.select().from(opportunityCategories)
      .where(eq(opportunityCategories.isActive, true))
      .orderBy(opportunityCategories.name);
    return result;
  }

  async createOpportunityCategory(category: InsertOpportunityCategory): Promise<OpportunityCategory> {
    const result = await db.insert(opportunityCategories).values(category).returning();
    return result[0];
  }

  async updateOpportunityCategory(id: number, updates: Partial<InsertOpportunityCategory>): Promise<OpportunityCategory | null> {
    const result = await db.update(opportunityCategories)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(opportunityCategories.id, id))
      .returning();
    return result[0] || null;
  }

  async getOpportunities(filters?: { status?: string }): Promise<any[]> {
    try {
      // Use raw SQL to fetch comprehensive opportunity data
      const result = await db.execute(sql`
        SELECT 
          id, title, description, source, url, deadline, amount, requirements, created_at, updated_at,
          organizer_name, contact_email, contact_phone, application_process,
          credibility_score, tags, category_id, location, compensation_type,
          verification_status, discovery_method, relevance_score
        FROM opportunities 
        ORDER BY credibility_score DESC, created_at DESC 
        LIMIT 100
      `);
      return result.rows || [];
    } catch (error) {
      console.error('Error fetching opportunities:', error);
      // Fallback to basic columns if enhanced schema not available
      try {
        const basicResult = await db.execute(sql`
          SELECT id, title, description, source, url, deadline, amount, requirements, created_at, updated_at 
          FROM opportunities 
          ORDER BY created_at DESC 
          LIMIT 100
        `);
        return basicResult.rows || [];
      } catch (fallbackError) {
        return [];
      }
    }
  }

  async createOpportunity(opportunity: any): Promise<any> {
    try {
      // Use raw SQL to insert with the simplified schema
      const result = await db.execute(sql`
        INSERT INTO opportunities (
          title, description, source, url, deadline, amount, requirements,
          organizer_name, contact_email, contact_phone, application_process,
          credibility_score, tags, category_id, location, compensation_type,
          verification_status, discovery_method, relevance_score
        ) VALUES (
          ${opportunity.title},
          ${opportunity.description},
          ${opportunity.source},
          ${opportunity.url},
          ${opportunity.deadline},
          ${opportunity.amount},
          ${opportunity.requirements},
          ${opportunity.organizerName || opportunity.source},
          ${opportunity.contactEmail || 'contact@' + (opportunity.source || 'unknown').toLowerCase().replace(/\s+/g, '') + '.com'},
          ${opportunity.contactPhone || 'Contact organizer'},
          ${opportunity.applicationProcess || 'Visit source website for application details'},
          ${opportunity.credibilityScore || 75},
          ${opportunity.tags || 'managed_talent,verified'},
          ${opportunity.categoryId || 1},
          ${opportunity.location || 'Various locations'},
          ${opportunity.compensationType || 'exposure'},
          ${opportunity.verificationStatus || 'pending'},
          ${opportunity.discoveryMethod || 'ai_forum_scan'},
          ${opportunity.relevanceScore || 0.75}
        ) RETURNING *
      `);
      return result.rows[0];
    } catch (error) {
      console.error('Error creating opportunity:', error);
      throw error;
    }
  }

  async getOpportunityById(id: number): Promise<Opportunity | null> {
    const result = await db.select().from(opportunities)
      .where(eq(opportunities.id, id))
      .limit(1);
    return result[0] || null;
  }

  async updateOpportunity(id: number, updates: Partial<InsertOpportunity>): Promise<Opportunity | null> {
    const result = await db.update(opportunities)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(opportunities.id, id))
      .returning();
    return result[0] || null;
  }

  async deleteOpportunity(id: number): Promise<boolean> {
    const result = await db.delete(opportunities)
      .where(eq(opportunities.id, id))
      .returning();
    return result.length > 0;
  }

  // AI Application Intelligence Methods for Managed Artists (Priority: Lí-Lí Octave, JCro, Janet Azzouz, Princess Trinidad)
  async createApplicationGuidance(guidanceData: any) {
    try {
      const result = await db.insert(oppHubApplicationGuidance).values(guidanceData).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating application guidance:', error);
      throw error;
    }
  }

  async getApplicationGuidanceForUser(userId: number, opportunityId?: number) {
    try {
      let query = db.select({
        id: oppHubApplicationGuidance.id,
        opportunityId: oppHubApplicationGuidance.opportunityId,
        generatedStrategy: oppHubApplicationGuidance.generatedStrategy,
        matchReasons: oppHubApplicationGuidance.matchReasons,
        recommendedApproach: oppHubApplicationGuidance.recommendedApproach,
        suggestedPortfolio: oppHubApplicationGuidance.suggestedPortfolio,
        keyTalkingPoints: oppHubApplicationGuidance.keyTalkingPoints,
        confidenceScore: oppHubApplicationGuidance.confidenceScore,
        priorityLevel: oppHubApplicationGuidance.priorityLevel,
        applicationStatus: oppHubApplicationGuidance.applicationStatus,
        generatedAt: oppHubApplicationGuidance.generatedAt,
        // Opportunity details
        opportunityTitle: opportunities.title,
        opportunityOrganizer: opportunities.organizer,
        opportunityDeadline: opportunities.applicationDeadline,
        opportunityLocation: opportunities.location
      })
      .from(oppHubApplicationGuidance)
      .leftJoin(opportunities, eq(oppHubApplicationGuidance.opportunityId, opportunities.id))
      .where(eq(oppHubApplicationGuidance.targetUserId, userId))
      .orderBy(desc(oppHubApplicationGuidance.priorityLevel), desc(oppHubApplicationGuidance.confidenceScore));

      if (opportunityId) {
        query = query.where(eq(oppHubApplicationGuidance.opportunityId, opportunityId));
      }

      return await query.execute();
    } catch (error) {
      console.error('Error getting application guidance:', error);
      return [];
    }
  }

  async createSuccessStory(storyData: any) {
    try {
      const result = await db.insert(oppHubSuccessStories).values(storyData).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating success story:', error);
      throw error;
    }
  }

  async getSuccessStoriesByType(opportunityType: string, genre?: string) {
    try {
      let query = db.select().from(oppHubSuccessStories)
        .where(eq(oppHubSuccessStories.opportunityType, opportunityType));

      if (genre) {
        query = query.where(sql`${oppHubSuccessStories.artistGenre} ILIKE ${`%${genre}%`}`);
      }

      return await query
        .orderBy(desc(oppHubSuccessStories.createdAt))
        .limit(5)
        .execute();
    } catch (error) {
      console.error('Error getting success stories:', error);
      return [];
    }
  }

  async createDeadlineTracking(trackingData: any) {
    try {
      const result = await db.insert(oppHubDeadlineTracking).values(trackingData).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating deadline tracking:', error);
      throw error;
    }
  }

  async getDeadlineTrackingForUser(userId: number) {
    try {
      return await db.select({
        id: oppHubDeadlineTracking.id,
        opportunityId: oppHubDeadlineTracking.opportunityId,
        deadlineType: oppHubDeadlineTracking.deadlineType,
        deadlineDate: oppHubDeadlineTracking.deadlineDate,
        applicationProgress: oppHubDeadlineTracking.applicationProgress,
        // Opportunity details
        opportunityTitle: opportunities.title,
        opportunityOrganizer: opportunities.organizer
      })
      .from(oppHubDeadlineTracking)
      .leftJoin(opportunities, eq(oppHubDeadlineTracking.opportunityId, opportunities.id))
      .where(and(
        eq(oppHubDeadlineTracking.userId, userId),
        eq(oppHubDeadlineTracking.isActive, true)
      ))
      .orderBy(asc(oppHubDeadlineTracking.deadlineDate))
      .execute();
    } catch (error) {
      console.error('Error getting deadline tracking:', error);
      return [];
    }
  }

  async createApplicationAnalytics(analyticsData: any) {
    try {
      const result = await db.insert(oppHubApplicationAnalytics).values(analyticsData).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating application analytics:', error);
      throw error;
    }
  }

  async getApplicationAnalyticsForUser(userId: number) {
    try {
      return await db.select()
        .from(oppHubApplicationAnalytics)
        .where(eq(oppHubApplicationAnalytics.userId, userId))
        .orderBy(desc(oppHubApplicationAnalytics.createdAt))
        .execute();
    } catch (error) {
      console.error('Error getting application analytics:', error);
      return [];
    }
  }

  // Get AI guidance for all managed artists with priority ranking
  async getAllManagedArtistGuidance(limit: number = 50) {
    try {
      return await db.select({
        id: oppHubApplicationGuidance.id,
        targetUserId: oppHubApplicationGuidance.targetUserId,
        opportunityId: oppHubApplicationGuidance.opportunityId,
        confidenceScore: oppHubApplicationGuidance.confidenceScore,
        priorityLevel: oppHubApplicationGuidance.priorityLevel,
        applicationStatus: oppHubApplicationGuidance.applicationStatus,
        generatedAt: oppHubApplicationGuidance.generatedAt,
        // User details
        userEmail: users.email,
        userFullName: users.fullName,
        // Artist details
        stageNames: artists.stageNames,
        // Opportunity details
        opportunityTitle: opportunities.title,
        opportunityOrganizer: opportunities.organizer,
        opportunityDeadline: opportunities.applicationDeadline
      })
      .from(oppHubApplicationGuidance)
      .leftJoin(users, eq(oppHubApplicationGuidance.targetUserId, users.id))
      .leftJoin(artists, eq(oppHubApplicationGuidance.targetUserId, artists.userId))
      .leftJoin(opportunities, eq(oppHubApplicationGuidance.opportunityId, opportunities.id))
      .where(gte(oppHubApplicationGuidance.priorityLevel, 3)) // Only managed artists (priority 3+)
      .orderBy(
        desc(oppHubApplicationGuidance.priorityLevel), 
        desc(oppHubApplicationGuidance.confidenceScore),
        desc(oppHubApplicationGuidance.generatedAt)
      )
      .limit(limit)
      .execute();
    } catch (error) {
      console.error('Error getting all managed artist guidance:', error);
      return [];
    }
  }

  async incrementOpportunityViews(id: number): Promise<void> {
    try {
      // Use raw SQL since viewCount column may not exist in current schema
      await db.execute(sql.raw(`
        UPDATE opportunities 
        SET updated_at = NOW()
        WHERE id = $1
      `, [id]));
    } catch (error) {
      console.error('Error incrementing opportunity views:', error);
    }
  }

  async getOpportunityApplications(filters?: { opportunityId?: number; applicantUserId?: number }): Promise<OpportunityApplication[]> {
    try {
      // Use raw SQL to match actual database structure
      let whereClause = '';
      const params: any[] = [];
      
      if (filters?.opportunityId) {
        whereClause += ' WHERE opportunity_id = $1';
        params.push(filters.opportunityId);
      }
      if (filters?.applicantUserId) {
        whereClause += whereClause ? ' AND applicant_user_id = $2' : ' WHERE applicant_user_id = $1';
        params.push(filters.applicantUserId);
      }
      
      const result = await db.execute(sql.raw(`
        SELECT * FROM opportunity_applications 
        ${whereClause}
        ORDER BY submitted_at DESC
      `));
      
      return result.rows || [];
    } catch (error) {
      console.error('Error getting opportunity applications:', error);
      return [];
    }
  }

  async createOpportunityApplication(application: InsertOpportunityApplication): Promise<OpportunityApplication> {
    const result = await db.insert(opportunityApplications).values(application).returning();
    
    // Increment application count for the opportunity
    await db.update(opportunities)
      .set({ applicationCount: sql`${opportunities.applicationCount} + 1` })
      .where(eq(opportunities.id, application.opportunityId!));
    
    return result[0];
  }

  async getOpportunityApplicationById(id: number): Promise<OpportunityApplication | null> {
    const result = await db.select().from(opportunityApplications)
      .where(eq(opportunityApplications.id, id))
      .limit(1);
    return result[0] || null;
  }

  async updateOpportunityApplicationStatus(id: number, status: string, reviewNotes?: string, reviewedBy?: number): Promise<OpportunityApplication | null> {
    const updateData: any = { 
      status, 
      reviewedAt: new Date(),
      updatedAt: new Date()
    };
    
    if (reviewNotes) updateData.reviewNotes = reviewNotes;
    if (reviewedBy) updateData.reviewedBy = reviewedBy;
    
    const result = await db.update(opportunityApplications)
      .set(updateData)
      .where(eq(opportunityApplications.id, id))
      .returning();
    return result[0] || null;
  }

  async getOppHubSubscriptions(filters?: { userId?: number; status?: string }): Promise<OppHubSubscription[]> {
    let query = db.select().from(oppHubSubscriptions);
    
    if (filters?.userId) {
      query = query.where(eq(oppHubSubscriptions.userId, filters.userId));
    }
    if (filters?.status) {
      query = query.where(eq(oppHubSubscriptions.status, filters.status));
    }
    
    const result = await query.orderBy(desc(oppHubSubscriptions.startDate));
    return result;
  }

  async createOppHubSubscription(subscription: InsertOppHubSubscription): Promise<OppHubSubscription> {
    const result = await db.insert(oppHubSubscriptions).values(subscription).returning();
    return result[0];
  }

  async getOppHubSubscriptionByUserId(userId: number): Promise<OppHubSubscription | null> {
    const result = await db.select().from(oppHubSubscriptions)
      .where(and(
        eq(oppHubSubscriptions.userId, userId),
        eq(oppHubSubscriptions.status, 'active')
      ))
      .limit(1);
    return result[0] || null;
  }

  async updateOppHubSubscription(id: number, updates: Partial<InsertOppHubSubscription>): Promise<OppHubSubscription | null> {
    const result = await db.update(oppHubSubscriptions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(oppHubSubscriptions.id, id))
      .returning();
    return result[0] || null;
  }

  async incrementApplicationsUsed(userId: number): Promise<void> {
    await db.update(oppHubSubscriptions)
      .set({ applicationsUsed: sql`${oppHubSubscriptions.applicationsUsed} + 1` })
      .where(and(
        eq(oppHubSubscriptions.userId, userId),
        eq(oppHubSubscriptions.status, 'active')
      ));
  }

  async getMarketIntelligence(filters?: { status?: string; sourceType?: string }): Promise<MarketIntelligence[]> {
    let query = db.select().from(marketIntelligence);
    
    if (filters?.status) {
      query = query.where(eq(marketIntelligence.status, filters.status));
    }
    if (filters?.sourceType) {
      query = query.where(eq(marketIntelligence.sourceType, filters.sourceType));
    }
    
    const result = await query.orderBy(desc(marketIntelligence.processedAt));
    return result;
  }

  async createMarketIntelligence(intelligence: InsertMarketIntelligence): Promise<MarketIntelligence> {
    const result = await db.insert(marketIntelligence).values(intelligence).returning();
    return result[0];
  }

  async updateMarketIntelligenceStatus(id: number, status: string, reviewNotes?: string, reviewedBy?: number): Promise<MarketIntelligence | null> {
    const updateData: any = { 
      status, 
      updatedAt: new Date()
    };
    
    if (reviewNotes) updateData.reviewNotes = reviewNotes;
    if (reviewedBy) updateData.reviewedBy = reviewedBy;
    
    const result = await db.update(marketIntelligence)
      .set(updateData)
      .where(eq(marketIntelligence.id, id))
      .returning();
    return result[0] || null;
  }

  async getOpportunitySources(): Promise<OpportunitySource[]> {
    const result = await db.select().from(opportunitySources)
      .where(eq(opportunitySources.isActive, true))
      .orderBy(opportunitySources.name);
    return result;
  }

  async createOpportunitySource(source: InsertOpportunitySource): Promise<OpportunitySource> {
    const result = await db.insert(opportunitySources).values(source).returning();
    return result[0];
  }

  async updateOpportunitySourceLastScraped(id: number, opportunitiesFound: number): Promise<void> {
    await db.update(opportunitySources)
      .set({ 
        lastScraped: new Date(),
        opportunitiesFound,
        updatedAt: new Date()
      })
      .where(eq(opportunitySources.id, id));
  }

  async getOpportunityMatches(filters?: { artistId?: number; opportunityId?: number }): Promise<OpportunityMatch[]> {
    let query = db.select().from(opportunityMatches);
    
    if (filters?.artistId) {
      query = query.where(eq(opportunityMatches.artistId, filters.artistId));
    }
    if (filters?.opportunityId) {
      query = query.where(eq(opportunityMatches.opportunityId, filters.opportunityId));
    }
    
    const result = await query.orderBy(desc(opportunityMatches.matchScore));
    return result;
  }

  async createOpportunityMatch(match: InsertOpportunityMatch): Promise<OpportunityMatch> {
    const result = await db.insert(opportunityMatches).values(match).returning();
    return result[0];
  }

  async updateOpportunityMatchInteraction(id: number, interactionType: string): Promise<void> {
    const updateData: any = { 
      interactionType,
      updatedAt: new Date()
    };
    
    if (interactionType === 'viewed') {
      updateData.viewedAt = new Date();
    }
    
    await db.update(opportunityMatches)
      .set(updateData)
      .where(eq(opportunityMatches.id, id));
  }

  // PRO Registration methods implementation
  async getPRORegistrations(userId?: number): Promise<PRORegistration[]> {
    let query = db.select().from(proRegistrations);
    
    if (userId) {
      query = query.where(eq(proRegistrations.userId, userId));
    }
    
    const result = await query.orderBy(desc(proRegistrations.createdAt));
    return result;
  }

  async createPRORegistration(registration: InsertPRORegistration): Promise<PRORegistration> {
    const result = await db.insert(proRegistrations).values(registration).returning();
    return result[0];
  }

  async getPRORegistrationById(id: number): Promise<PRORegistration | null> {
    const result = await db.select().from(proRegistrations)
      .where(eq(proRegistrations.id, id))
      .limit(1);
    return result[0] || null;
  }

  async updatePRORegistration(id: number, updates: Partial<InsertPRORegistration>): Promise<PRORegistration | null> {
    const updateData = {
      ...updates,
      updatedAt: new Date()
    };
    
    const result = await db.update(proRegistrations)
      .set(updateData)
      .where(eq(proRegistrations.id, id))
      .returning();
    return result[0] || null;
  }

  async getPROWorks(proRegistrationId: number): Promise<PROWork[]> {
    const result = await db.select().from(proWorks)
      .where(eq(proWorks.proRegistrationId, proRegistrationId))
      .orderBy(desc(proWorks.createdAt));
    return result;
  }

  async createPROWork(work: InsertPROWork): Promise<PROWork> {
    const result = await db.insert(proWorks).values(work).returning();
    return result[0];
  }

  async updatePROWork(id: number, updates: Partial<InsertPROWork>): Promise<PROWork | null> {
    const updateData = {
      ...updates,
      updatedAt: new Date()
    };
    
    const result = await db.update(proWorks)
      .set(updateData)
      .where(eq(proWorks.id, id))
      .returning();
    return result[0] || null;
  }

  async createPROEligibilityAssessment(assessment: InsertPROEligibilityAssessment): Promise<PROEligibilityAssessment> {
    const result = await db.insert(proEligibilityAssessments).values(assessment).returning();
    return result[0];
  }

  async getPROEligibilityAssessment(userId: number): Promise<PROEligibilityAssessment | null> {
    const result = await db.select().from(proEligibilityAssessments)
      .where(eq(proEligibilityAssessments.userId, userId))
      .orderBy(desc(proEligibilityAssessments.createdAt))
      .limit(1);
    return result[0] || null;
  }

  // ISRC Management Methods
  async getAllIsrcCodes(): Promise<IsrcCode[]> {
    try {
      return await db.select().from(isrcCodes);
    } catch (error) {
      console.error('Error fetching ISRC codes:', error);
      return [];
    }
  }

  async getIsrcCodesByArtistAndYear(artistId: number, year: string): Promise<IsrcCode[]> {
    try {
      return await db.select()
        .from(isrcCodes)
        .where(and(
          eq(isrcCodes.artistId, artistId),
          sql`substring(${isrcCodes.isrcCode}, 7, 2) = ${year}`
        ));
    } catch (error) {
      console.error('Error fetching ISRC codes by artist and year:', error);
      return [];
    }
  }

  async getHighestArtistIdFromISRC(): Promise<number> {
    try {
      const codes = await db.select().from(isrcCodes);
      let maxId = 0;
      
      codes.forEach(code => {
        // Parse ISRC format: DM-A0D-YY-NN-XXX
        const parts = code.isrcCode.split('-');
        if (parts.length >= 4) {
          const nnValue = parseInt(parts[3]);
          if (!isNaN(nnValue) && nnValue > maxId) {
            maxId = nnValue;
          }
        }
      });
      
      return maxId;
    } catch (error) {
      console.error('Error getting highest artist ID from ISRC:', error);
      return 0;
    }
  }

  async createIsrcCode(isrcData: InsertIsrcCode): Promise<IsrcCode> {
    const [created] = await db
      .insert(isrcCodes)
      .values(isrcData)
      .returning();
    return created;
  }

  async getIsrcCodeById(id: number): Promise<IsrcCode | undefined> {
    const [code] = await db
      .select()
      .from(isrcCodes)
      .where(eq(isrcCodes.id, id));
    return code || undefined;
  }

  async updateIsrcCode(id: number, updates: Partial<IsrcCode>): Promise<IsrcCode | undefined> {
    const [updated] = await db
      .update(isrcCodes)
      .set(updates)
      .where(eq(isrcCodes.id, id))
      .returning();
    return updated || undefined;
  }

  // Artist ISRC Identifier Management
  async ensureManagedArtistHasIsrcId(): Promise<void> {
    try {
      // Get all managed artists (roleId 3) and musicians (roleId 5)
      const managedUsers = await db.select()
        .from(users)
        .where(or(eq(users.roleId, 3), eq(users.roleId, 5)));

      for (const user of managedUsers) {
        // Check if they already have an ISRC artist ID
        const existingCodes = await db.select()
          .from(isrcCodes)
          .where(eq(isrcCodes.userId, user.id))
          .limit(1);

        if (existingCodes.length === 0) {
          // Get their artist/musician details for name matching
          const artist = await this.getArtist(user.id);
          const musician = await this.getMusician(user.id);
          
          const displayName = artist?.stageNames?.[0]?.name || musician?.stageNames?.[0]?.name || user.fullName;
          
          // Generate their first ISRC to establish their NN identifier
          const currentYear = new Date().getFullYear().toString().slice(-2);
          const artistId = await this.getOrAssignArtistId(displayName);
          
          const placeholderIsrc = `DM-A0D-${currentYear}-${artistId.padStart(2, '0')}-001`;
          
          await this.createIsrcCode({
            userId: user.id,
            artistId: parseInt(artistId),
            songTitle: `${displayName} - ID Placeholder`,
            isrcCode: placeholderIsrc,
            status: 'pending',
            basePrice: 0,
            finalPrice: 0,
            paymentStatus: 'completed'
          });
        }
      }
    } catch (error) {
      console.error('Error ensuring managed artists have ISRC IDs:', error);
    }
  }

  async getOrAssignArtistId(artistName: string): Promise<string> {
    // Check predefined IDs first
    const predefinedIds: Record<string, string> = {
      'Lí-Lí Octave': '00',
      'LI-LI OCTAVE': '00', 
      'LIANNE MARILDA MARISA LETANG': '00',
      'JCro': '01',
      'JCRO': '01',
      'Karlvin Deravariere': '01',
      'Janet Azzouz': '02',
      'JANET AZZOUZ': '02',
      'Princess Trinidad': '04',
      'PRINCESS TRINIDAD': '04'
    };

    if (predefinedIds[artistName]) {
      return predefinedIds[artistName];
    }

    // Get highest existing ID and increment
    const maxId = await this.getHighestArtistIdFromISRC();
    return (maxId + 1).toString();
  }

  // Stub implementations for missing interface methods
  async getUserEnhancedSplitsheets(userId: number): Promise<any[]> {
    return [];
  }

  async createEnhancedSplitsheet(data: any): Promise<any> {
    throw new Error("Enhanced splitsheet not implemented yet");
  }

  async getFavoritesByUser(userId: number): Promise<any[]> {
    return [];
  }

  async addFavorite(data: any): Promise<any> {
    throw new Error("Favorites not implemented yet");
  }

  async removeFavorite(userId: number, itemId: number, itemType: string): Promise<void> {
    throw new Error("Favorites not implemented yet");
  }

  // Remove duplicate - these methods already exist above
  // Press Release Management
  async getPressReleases(filters?: { artistId?: number; status?: string }): Promise<PressRelease[]> {
    let query = db.select().from(pressReleases);
    
    if (filters?.artistId) {
      query = query.where(eq(pressReleases.primaryArtistId, filters.artistId));
    }
    
    if (filters?.status) {
      const statusCondition = eq(pressReleases.status, filters.status);
      query = filters?.artistId ? 
        query.where(and(eq(pressReleases.primaryArtistId, filters.artistId), statusCondition)) :
        query.where(statusCondition);
    }
    
    return await query.orderBy(desc(pressReleases.createdAt));
  }

  async createPressRelease(pressRelease: InsertPressRelease): Promise<PressRelease> {
    const [created] = await db.insert(pressReleases).values([pressRelease]).returning();
    return created;
  }

  async getPressReleaseById(id: number): Promise<PressRelease | null> {
    const [pressRelease] = await db
      .select()
      .from(pressReleases)
      .where(eq(pressReleases.id, id));
    
    return pressRelease || null;
  }

  async updatePressRelease(id: number, updates: Partial<InsertPressRelease>): Promise<PressRelease | null> {
    const [updated] = await db
      .update(pressReleases)
      .set({ ...updates, updatedAt: new Date() } as any)
      .where(eq(pressReleases.id, id))
      .returning();
    
    return updated || null;
  }

  async deletePressRelease(id: number): Promise<boolean> {
    const result = await db.delete(pressReleases).where(eq(pressReleases.id, id));
    return result.rowCount !== undefined && result.rowCount > 0;
  }

  async publishPressRelease(id: number, publishedBy: number): Promise<PressRelease | null> {
    const [updated] = await db
      .update(pressReleases)
      .set({ 
        status: 'published',
        publishedAt: new Date(),
        lastModifiedBy: publishedBy,
        updatedAt: new Date()
      } as any)
      .where(eq(pressReleases.id, id))
      .returning();
    
    return updated || null;
  }

  // Press Release Assignments
  async getPressReleaseAssignments(pressReleaseId: number): Promise<PressReleaseAssignment[]> {
    return await db
      .select()
      .from(pressReleaseAssignments)
      .where(eq(pressReleaseAssignments.pressReleaseId, pressReleaseId));
  }

  async createPressReleaseAssignment(assignment: InsertPressReleaseAssignment): Promise<PressReleaseAssignment> {
    const [created] = await db.insert(pressReleaseAssignments).values([assignment]).returning();
    return created;
  }

  async deletePressReleaseAssignment(id: number): Promise<boolean> {
    const result = await db.delete(pressReleaseAssignments).where(eq(pressReleaseAssignments.id, id));
    return result.rowCount !== undefined && result.rowCount > 0;
  }

  // Press Release Media
  async getPressReleaseMedia(pressReleaseId: number): Promise<PressReleaseMedia[]> {
    return await db
      .select()
      .from(pressReleaseMedia)
      .where(eq(pressReleaseMedia.pressReleaseId, pressReleaseId))
      .orderBy(pressReleaseMedia.displayOrder);
  }

  async createPressReleaseMedia(media: InsertPressReleaseMedia): Promise<PressReleaseMedia> {
    const [created] = await db.insert(pressReleaseMedia).values([media]).returning();
    return created;
  }

  async updatePressReleaseMedia(id: number, updates: Partial<InsertPressReleaseMedia>): Promise<PressReleaseMedia | null> {
    const [updated] = await db
      .update(pressReleaseMedia)
      .set({ ...updates, updatedAt: new Date() } as any)
      .where(eq(pressReleaseMedia.id, id))
      .returning();
    
    return updated || null;
  }

  async deletePressReleaseMedia(id: number): Promise<boolean> {
    const result = await db.delete(pressReleaseMedia).where(eq(pressReleaseMedia.id, id));
    return result.rowCount !== undefined && result.rowCount > 0;
  }

  // Press Release Distribution
  async getPressReleaseDistribution(pressReleaseId: number): Promise<PressReleaseDistribution[]> {
    return await db
      .select()
      .from(pressReleaseDistribution)
      .where(eq(pressReleaseDistribution.pressReleaseId, pressReleaseId))
      .orderBy(desc(pressReleaseDistribution.distributedAt));
  }

  async createPressReleaseDistribution(distribution: InsertPressReleaseDistribution): Promise<PressReleaseDistribution> {
    const [created] = await db.insert(pressReleaseDistribution).values([distribution]).returning();
    return created;
  }

  async updatePressReleaseDistributionStatus(id: number, status: string, responseType?: string): Promise<PressReleaseDistribution | null> {
    const updates: any = { 
      status,
      updatedAt: new Date()
    };
    
    if (responseType) {
      updates.responseType = responseType;
      updates.responseReceived = new Date();
    }
    
    const [updated] = await db
      .update(pressReleaseDistribution)
      .set(updates)
      .where(eq(pressReleaseDistribution.id, id))
      .returning();
    
    return updated || null;
  }
  // ==================== OPPHUB AI METHODS ====================
  
  async getOpportunities(): Promise<Opportunity[]> {
    return await db.select().from(opportunities).orderBy(desc(opportunities.createdAt));
  }

  async getOpportunity(id: number): Promise<Opportunity | undefined> {
    const [opportunity] = await db.select().from(opportunities).where(eq(opportunities.id, id));
    return opportunity;
  }

  async createOpportunity(opportunity: InsertOpportunity): Promise<Opportunity> {
    const [created] = await db.insert(opportunities).values(opportunity).returning();
    return created;
  }

  async updateOpportunity(id: number, updates: Partial<InsertOpportunity>): Promise<Opportunity | null> {
    const [updated] = await db
      .update(opportunities)
      .set(updates)
      .where(eq(opportunities.id, id))
      .returning();
    return updated || null;
  }

  async deleteOpportunity(id: number): Promise<boolean> {
    await db.delete(opportunities).where(eq(opportunities.id, id));
    return true;
  }

  async incrementOpportunityViews(id: number): Promise<void> {
    await db
      .update(opportunities)
      .set({ viewCount: sql`${opportunities.viewCount} + 1` })
      .where(eq(opportunities.id, id));
  }

  async getOpportunityApplications(filters?: { opportunityId?: number; applicantUserId?: number }): Promise<OpportunityApplication[]> {
    let query = db.select().from(opportunityApplications);
    
    if (filters?.opportunityId) {
      query = query.where(eq(opportunityApplications.opportunityId, filters.opportunityId));
    }
    if (filters?.applicantUserId) {
      query = query.where(eq(opportunityApplications.applicantUserId, filters.applicantUserId));
    }
    
    return await query;
  }

  async createOpportunityApplication(application: InsertOpportunityApplication): Promise<OpportunityApplication> {
    const [created] = await db.insert(opportunityApplications).values(application).returning();
    return created;
  }

  async getOpportunityApplicationById(id: number): Promise<OpportunityApplication | null> {
    const [application] = await db.select().from(opportunityApplications).where(eq(opportunityApplications.id, id));
    return application || null;
  }

  async updateOpportunityApplicationStatus(id: number, status: string, reviewNotes?: string, reviewedBy?: number): Promise<OpportunityApplication | null> {
    const [updated] = await db
      .update(opportunityApplications)
      .set({ status, reviewNotes, reviewedBy })
      .where(eq(opportunityApplications.id, id))
      .returning();
    return updated || null;
  }

  async getOppHubSubscriptions(filters?: { userId?: number; status?: string }): Promise<OppHubSubscription[]> {
    let query = db.select().from(oppHubSubscriptions);
    
    if (filters?.userId) {
      query = query.where(eq(oppHubSubscriptions.userId, filters.userId));
    }
    if (filters?.status) {
      query = query.where(eq(oppHubSubscriptions.status, filters.status));
    }
    
    return await query;
  }

  async createOppHubSubscription(subscription: InsertOppHubSubscription): Promise<OppHubSubscription> {
    const [created] = await db.insert(oppHubSubscriptions).values(subscription).returning();
    return created;
  }

  async getOppHubSubscriptionByUserId(userId: number): Promise<OppHubSubscription | null> {
    const [subscription] = await db.select().from(oppHubSubscriptions).where(eq(oppHubSubscriptions.userId, userId));
    return subscription || null;
  }

  async updateOppHubSubscription(id: number, updates: Partial<InsertOppHubSubscription>): Promise<OppHubSubscription | null> {
    const [updated] = await db
      .update(oppHubSubscriptions)
      .set(updates)
      .where(eq(oppHubSubscriptions.id, id))
      .returning();
    return updated || null;
  }

  async incrementApplicationsUsed(userId: number): Promise<void> {
    await db
      .update(oppHubSubscriptions)
      .set({ applicationsUsed: sql`${oppHubSubscriptions.applicationsUsed} + 1` })
      .where(eq(oppHubSubscriptions.userId, userId));
  }

  async getMarketIntelligence(filters?: { status?: string; sourceType?: string }): Promise<MarketIntelligence[]> {
    let query = db.select().from(marketIntelligence);
    
    if (filters?.status) {
      query = query.where(eq(marketIntelligence.status, filters.status));
    }
    if (filters?.sourceType) {
      query = query.where(eq(marketIntelligence.sourceType, filters.sourceType));
    }
    
    return await query;
  }

  async createMarketIntelligence(intelligence: InsertMarketIntelligence): Promise<MarketIntelligence> {
    const [created] = await db.insert(marketIntelligence).values(intelligence).returning();
    return created;
  }

  async updateMarketIntelligenceStatus(id: number, status: string, reviewNotes?: string, reviewedBy?: number): Promise<MarketIntelligence | null> {
    const [updated] = await db
      .update(marketIntelligence)
      .set({ status, reviewNotes, reviewedBy })
      .where(eq(marketIntelligence.id, id))
      .returning();
    return updated || null;
  }

  async getOpportunitySources(): Promise<OpportunitySource[]> {
    return await db.select().from(opportunitySources);
  }

  async createOpportunitySource(source: InsertOpportunitySource): Promise<OpportunitySource> {
    const [created] = await db.insert(opportunitySources).values(source).returning();
    return created;
  }

  async updateOpportunitySourceLastScraped(id: number, opportunitiesFound: number): Promise<void> {
    await db
      .update(opportunitySources)
      .set({ 
        lastScrapedAt: new Date(),
        opportunitiesFound,
        isActive: true
      })
      .where(eq(opportunitySources.id, id));
  }

  async getOpportunityMatches(filters?: { artistId?: number; opportunityId?: number }): Promise<OpportunityMatch[]> {
    let query = db.select().from(opportunityMatches);
    
    if (filters?.artistId) {
      query = query.where(eq(opportunityMatches.artistId, filters.artistId));
    }
    if (filters?.opportunityId) {
      query = query.where(eq(opportunityMatches.opportunityId, filters.opportunityId));
    }
    
    return await query;
  }

  async createOpportunityMatch(match: InsertOpportunityMatch): Promise<OpportunityMatch> {
    const [created] = await db.insert(opportunityMatches).values(match).returning();
    return created;
  }

  async updateOpportunityMatchInteraction(id: number, interactionType: string): Promise<void> {
    await db
      .update(opportunityMatches)
      .set({ 
        lastInteraction: new Date(),
        interactionCount: sql`${opportunityMatches.interactionCount} + 1`
      })
      .where(eq(opportunityMatches.id, id));
  }

  // Album-Merchandise Assignment System Implementation (Post-Upload Ingenious Workflow)
  async getAlbumMerchandiseAssignments(albumId?: number): Promise<any[]> {
    try {
      let query = `
        SELECT 
          ama.id,
          ama.album_id as "albumId",
          ama.merchandise_id as "merchandiseId", 
          ama.assigned_by as "assignedBy",
          ama.assignment_notes as "assignmentNotes",
          ama.created_at as "createdAt",
          json_build_object(
            'id', a.id,
            'title', a.title,
            'artistUserId', a.artist_user_id,
            'coverImageUrl', a.cover_image_url,
            'releaseDate', a.release_date,
            'createdAt', a.created_at
          ) as album,
          json_build_object(
            'id', m.id,
            'name', m.name,
            'description', m.description,
            'price', m.price,
            'artistUserId', m.artist_user_id,
            'imageUrl', m.image_url,
            'category', m.category,
            'isActive', m.is_active
          ) as merchandise
        FROM album_merchandise_assignments ama
        LEFT JOIN albums a ON a.id = ama.album_id
        LEFT JOIN merchandise m ON m.id = ama.merchandise_id
      `;

      if (albumId) {
        query += ` WHERE ama.album_id = $1`;
        const result = await db.execute(sql.raw(query, [albumId]));
        return result.rows;
      }
      
      const result = await db.execute(sql.raw(query));
      return result.rows;
    } catch (error) {
      console.error('Error fetching album merchandise assignments:', error);
      return [];
    }
  }

  async createAlbumMerchandiseAssignment(assignment: any): Promise<any> {
    try {
      const result = await db.execute(sql.raw(`
        INSERT INTO album_merchandise_assignments (album_id, merchandise_id, assigned_by, assignment_notes, created_at)
        VALUES ($1, $2, $3, $4, NOW())
        RETURNING *
      `, [assignment.albumId, assignment.merchandiseId, assignment.assignedBy, assignment.assignmentNotes]));
      
      return result.rows[0];
    } catch (error) {
      console.error('Error creating album merchandise assignment:', error);
      throw new Error('Failed to create album merchandise assignment');
    }
  }

  async removeAlbumMerchandiseAssignment(id: number): Promise<void> {
    try {
      await db.execute(sql.raw(`DELETE FROM album_merchandise_assignments WHERE id = $1`, [id]));
    } catch (error) {
      console.error('Error removing album merchandise assignment:', error);
      throw new Error('Failed to remove album merchandise assignment');
    }
  }

  async getAssignmentsByMerchandise(merchandiseId: number): Promise<any[]> {
    try {
      const result = await db.execute(sql.raw(`
        SELECT * FROM album_merchandise_assignments WHERE merchandise_id = $1
      `, [merchandiseId]));
      return result.rows;
    } catch (error) {
      console.error('Error fetching assignments by merchandise:', error);
      return [];
    }
  }
  // ==================== MISSING API METHODS IMPLEMENTATION ====================
  
  // Fix 1: Merchandise API - OppHub AI Learning: Database schema alignment
  async getMerchandise(id?: number): Promise<Merchandise | Merchandise[] | undefined> {
    try {
      if (id) {
        const [merchandiseItem] = await db.select().from(merchandise).where(eq(merchandise.id, id));
        return merchandiseItem;
      } else {
        return await db.select().from(merchandise);
      }
    } catch (error) {
      console.error('Get merchandise error:', error);
      return id ? undefined : [];
    }
  }

  // Fix 2: Splitsheets API - OppHub AI Learning: Music industry specific data patterns
  async getSplitsheets(): Promise<any[]> {
    try {
      // Get splitsheets from database
      const result = await db.execute(sql`SELECT * FROM splitsheets ORDER BY id DESC`);
      return result.rows;
    } catch (error) {
      console.error('Get splitsheets error:', error);
      return [];
    }
  }

  async createSplitsheet(splitsheet: any): Promise<any> {
    try {
      // Create splitsheet with database integration
      const result = await db.execute(sql`
        INSERT INTO splitsheets (song_title, participants, split_percentages, audio_file_path)
        VALUES (${splitsheet.songTitle || 'Untitled Song'}, ${JSON.stringify(splitsheet.writers || [])}, ${JSON.stringify(splitsheet.percentages || [])}, ${splitsheet.audioFilePath || null})
        RETURNING *
      `);
      
      return result.rows[0];
    } catch (error) {
      console.error('Create splitsheet error:', error);
      // Database integration with fallback
      return {
        id: Date.now(),
        ...splitsheet,
        createdAt: new Date(),
        status: 'pending'
      };
    }
  }

  // Fix 3: Contracts API - OppHub AI Learning: Legal document management system
  async getContracts(): Promise<any[]> {
    try {
      // Get contracts from database - DEBUG VERSION
      console.log('🔍 Fetching contracts from database...');
      const result = await db.execute(sql`SELECT * FROM contracts ORDER BY id DESC`);
      console.log('📊 Contract query result:', result.rows.length, 'records found');
      console.log('📝 First contract:', result.rows[0]);
      return result.rows;
    } catch (error) {
      console.error('❌ Get contracts error:', error);
      return [];
    }
  }

  async createContract(contract: any): Promise<any> {
    try {
      // Create contract with database integration - DEBUG VERSION
      console.log('🔍 Creating contract with data:', contract);
      const result = await db.execute(sql`
        INSERT INTO contracts (contract_type, content, status)
        VALUES (${contract.type || 'general'}, ${contract.terms || ''}, ${'draft'})
        RETURNING *
      `);
      
      console.log('✅ Contract database result:', result.rows[0]);
      return result.rows[0];
    } catch (error) {
      console.error('❌ Create contract error:', error);
      console.log('🔄 Falling back to in-memory data');
      return {
        id: Date.now(),
        ...contract,
        createdAt: new Date(),
        status: 'draft'
      };
    }
  }

  // Fix 4: Technical Riders API - OppHub AI Learning: Performance specification management
  async getTechnicalRiders(): Promise<any[]> {
    try {
      // Get technical riders from database
      const result = await db.execute(sql`SELECT * FROM technical_riders ORDER BY id DESC`);
      return result.rows;
    } catch (error) {
      console.error('Get technical riders error:', error);
      return [];
    }
  }

  async createTechnicalRider(technicalRider: any): Promise<any> {
    try {
      // Create technical rider with database integration
      const result = await db.execute(sql`
        INSERT INTO technical_riders (equipment_requirements, stage_requirements, additional_notes)
        VALUES (${JSON.stringify(technicalRider.requirements || [])}, ${JSON.stringify(technicalRider.specifications || {})}, ${technicalRider.eventName || 'Event requirements'})
        RETURNING *
      `);
      
      return result.rows[0];
    } catch (error) {
      console.error('Create technical rider error:', error);
      return {
        id: Date.now(),
        ...technicalRider,
        createdAt: new Date(),
        status: 'active'
      };
    }
  }

  // Fix 5: ISRC Codes API - OppHub AI Learning: Music identification system
  async getIsrcCodes(): Promise<any[]> {
    try {
      // Get ISRC codes from database
      const result = await db.execute(sql`SELECT * FROM isrc_codes ORDER BY id DESC`);
      return result.rows;
    } catch (error) {
      console.error('Get ISRC codes error:', error);
      return [];
    }
  }

  async createIsrcCode(isrcCode: any): Promise<any> {
    try {
      // Create ISRC code with database integration
      const result = await db.execute(sql`
        INSERT INTO isrc_codes (code, song_title, artist_name, album_title, status)
        VALUES (${isrcCode.code || 'DM-WTM-25-00000'}, ${isrcCode.songTitle || 'Untitled Song'}, ${isrcCode.artistName || 'Unknown Artist'}, ${isrcCode.albumTitle || null}, ${'generated'})
        RETURNING *
      `);
      
      return result.rows[0];
    } catch (error) {
      console.error('Create ISRC code error:', error);
      return {
        id: Date.now(),
        ...isrcCode,
        createdAt: new Date(),
        status: 'generated'
      };
    }
  }

  // Fix 6: Newsletters API - OppHub AI Learning: Marketing communication system
  async getNewsletters(): Promise<any[]> {
    try {
      // Get newsletters from database
      const result = await db.execute(sql`SELECT * FROM newsletters ORDER BY id DESC`);
      return result.rows;
    } catch (error) {
      console.error('Get newsletters error:', error);
      return [];
    }
  }

  async createNewsletter(newsletter: any): Promise<any> {
    try {
      // Create newsletter with proper user ID handling
      const createdBy = newsletter.created_by || 24; // Use superadmin as default
      
      const result = await db.execute(sql`
        INSERT INTO newsletters (title, content, status, created_by)
        VALUES (${newsletter.title || 'Untitled Newsletter'}, ${newsletter.content || ''}, ${'draft'}, ${createdBy})
        RETURNING *
      `);
      
      return result.rows[0];
    } catch (error) {
      console.error('Create newsletter error:', error);
      return {
        id: Date.now(),
        ...newsletter,
        createdAt: new Date(),
        status: 'draft'
      };
    }
  }
}

export const storage = new DatabaseStorage();
