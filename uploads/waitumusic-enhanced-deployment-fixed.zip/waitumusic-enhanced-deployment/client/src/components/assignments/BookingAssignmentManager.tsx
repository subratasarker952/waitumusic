import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

// UI Components
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

// Icons
import { Calendar, Plus, Trash2, Users, Music, UserCheck } from 'lucide-react';

export default function BookingAssignmentManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedBookingId, setSelectedBookingId] = useState<string>('');
  const [selectedTalentIds, setSelectedTalentIds] = useState<string[]>([]);
  const [selectedRole, setSelectedRole] = useState<string>('');

  // Fetch data
  const { data: bookings } = useQuery({
    queryKey: ['/api/bookings/all']
  });

  const { data: managedArtists } = useQuery({
    queryKey: ['/api/users/managed-artists']
  });

  const { data: managedMusicians } = useQuery({
    queryKey: ['/api/users/managed-musicians']
  });

  const { data: bookingAssignments, isLoading } = useQuery({
    queryKey: ['/api/assignments/booking']
  });

  // All managed talent for selection
  const allManagedTalent = [
    ...(Array.isArray(managedArtists) ? managedArtists : []).map((artist: any) => ({ ...artist, type: 'artist' })),
    ...(Array.isArray(managedMusicians) ? managedMusicians : []).map((musician: any) => ({ ...musician, type: 'musician' }))
  ];

  // Create assignment mutation
  const createAssignmentMutation = useMutation({
    mutationFn: async (assignment: any) => {
      return apiRequest('/api/assignments/booking', { method: 'POST', body: assignment });
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Booking assignment created successfully" });
      queryClient.invalidateQueries({ queryKey: ['/api/assignments/booking'] });
      setSelectedBookingId('');
      setSelectedTalentIds([]);
      setSelectedRole('');
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to create booking assignment",
        variant: "destructive"
      });
    }
  });

  // Remove assignment mutation
  const removeAssignmentMutation = useMutation({
    mutationFn: async (assignmentId: number) => {
      return apiRequest(`/api/assignments/booking/${assignmentId}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Booking assignment removed successfully" });
      queryClient.invalidateQueries({ queryKey: ['/api/assignments/booking'] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to remove booking assignment",
        variant: "destructive"
      });
    }
  });

  const handleTalentSelection = (talentId: string, checked: boolean) => {
    if (checked) {
      setSelectedTalentIds([...selectedTalentIds, talentId]);
    } else {
      setSelectedTalentIds(selectedTalentIds.filter(id => id !== talentId));
    }
  };

  const handleCreateAssignment = () => {
    if (!selectedBookingId || selectedTalentIds.length === 0) {
      toast({
        title: "Missing Information",
        description: "Please select a booking and at least one talent",
        variant: "destructive"
      });
      return;
    }

    // Create multiple assignments for multi-talent bookings
    selectedTalentIds.forEach(talentId => {
      const talent = allManagedTalent.find(t => t.id.toString() === talentId);
      if (talent) {
        createAssignmentMutation.mutate({
          bookingId: parseInt(selectedBookingId),
          assignedUserId: parseInt(talentId),
          assignmentRole: selectedRole || (talent.type === 'artist' ? 'main_performer' : 'supporting_musician'),
          assignmentType: talent.type
        });
      }
    });
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading booking assignments...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Create New Assignment */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Plus className="w-4 h-4 mr-2" />
            Assign Talent to Booking
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Support for multiple managed artists and musicians per booking
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium">Select Booking</label>
              <Select value={selectedBookingId} onValueChange={setSelectedBookingId}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose booking" />
                </SelectTrigger>
                <SelectContent>
                  {(Array.isArray(bookings) ? bookings : []).map((booking: any) => (
                    <SelectItem key={booking.id} value={booking.id.toString()}>
                      {booking.eventName} - {new Date(booking.eventDate).toLocaleDateString()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Assignment Role</label>
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger>
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="main_performer">Main Performer</SelectItem>
                  <SelectItem value="supporting_artist">Supporting Artist</SelectItem>
                  <SelectItem value="session_musician">Session Musician</SelectItem>
                  <SelectItem value="backup_vocalist">Backup Vocalist</SelectItem>
                  <SelectItem value="band_member">Band Member</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button 
                onClick={handleCreateAssignment}
                disabled={createAssignmentMutation.isPending || selectedTalentIds.length === 0}
                className="w-full"
              >
                <UserCheck className="w-4 h-4 mr-2" />
                Assign Selected ({selectedTalentIds.length})
              </Button>
            </div>
          </div>

          {/* Select managed talent dropdown */}
          <div>
            <label className="text-sm font-medium mb-2 block">Select Managed Talent</label>
            <Select value={selectedTalentIds[0] || ""} onValueChange={(value) => setSelectedTalentIds([value])}>
              <SelectTrigger>
                <SelectValue placeholder="Choose managed talent" />
              </SelectTrigger>
              <SelectContent>
                {allManagedTalent.map((talent: any) => (
                  <SelectItem key={talent.id} value={talent.id.toString()}>
                    <div className="flex items-center space-x-2">
                      {talent.type === 'artist' ? <Music className="w-3 h-3" /> : <Users className="w-3 h-3" />}
                      <span>{talent.fullName}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Current Assignments */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="w-4 h-4 mr-2" />
            Current Booking Assignments ({Array.isArray(bookingAssignments) ? bookingAssignments.length : 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {Array.isArray(bookingAssignments) && bookingAssignments.length > 0 ? (
            <div className="space-y-3">
              {bookingAssignments.map((assignment: any) => (
                <div key={assignment.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <div>
                      <p className="font-medium">{assignment.bookingName}</p>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <Users className="w-3 h-3" />
                        <span>{assignment.assignedUserName}</span>
                        <span>•</span>
                        <span className="capitalize">{assignment.assignmentRole?.replace('_', ' ')}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="capitalize">
                      {assignment.assignmentType}
                    </Badge>
                    <Button
                      onClick={() => removeAssignmentMutation.mutate(assignment.id)}
                      disabled={removeAssignmentMutation.isPending}
                      variant="ghost"
                      size="sm"
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No booking assignments found</p>
              <p className="text-sm">Assign talent to bookings to manage performances</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}