import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { 
  Brain, 
  Shield, 
  TrendingUp, 
  Instagram, 
  Twitter, 
  Youtube, 
  BookOpen,
  Target,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  Users,
  DollarSign,
  Globe,
  Lightbulb,
  Cpu,
  Activity,
  Zap
} from 'lucide-react';

interface OppHubUnifiedAIProps {
  userRole: string;
  userId: number;
}

interface HealthCheck {
  name: string;
  status: 'healthy' | 'warning' | 'critical';
  details: string;
  responseTime?: string;
}

interface BusinessForecast {
  revenue: {
    trend: 'growing' | 'declining' | 'stable';
    currentMonthProjection: number;
    nextMonthForecast: number;
    recommendations: string[];
  };
  userGrowth: {
    weeklyGrowthRate: number;
    projectedMonthlyUsers: number;
    recommendations: string[];
  };
  recommendations: string[];
}

interface SocialMediaStrategy {
  strategy: {
    brandVoice: string;
    contentPillars: string[];
    targetAudience: any;
    platforms: any;
  };
  contentSuggestions: string[];
  postingSchedule: any;
  hashtagRecommendations: string[];
  engagementTactics: string[];
}

interface AILearning {
  insights: string[];
  patterns: any[];
  recommendations: string[];
}

export default function OppHubUnifiedAI({ userRole, userId }: OppHubUnifiedAIProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedArtist, setSelectedArtist] = useState<number | null>(null);
  const isAdmin = ['superadmin', 'admin'].includes(userRole);
  const isManaged = ['managed_artist', 'managed_musician', 'managed_professional'].includes(userRole);

  // Platform Health Monitoring (Admin only)
  const { data: platformHealth, refetch: refetchHealth } = useQuery<{
    status: string;
    checks: HealthCheck[];
    recommendations: string[];
  }>({
    queryKey: ['/api/opphub-ai/health'],
    enabled: isAdmin,
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // Business Forecasting (Admin only)
  const { data: businessForecasts } = useQuery<BusinessForecast>({
    queryKey: ['/api/opphub-ai/forecasts'],
    enabled: isAdmin,
    refetchInterval: 300000 // Refresh every 5 minutes
  });

  // AI Guidance for current user
  const { data: userGuidance } = useQuery<{
    guidance: string[];
    recommendations: string[];
  }>({
    queryKey: ['/api/opphub-ai/guidance', userId],
    enabled: isManaged || isAdmin
  });

  // Social Media Strategy
  const { data: socialMediaStrategy } = useQuery<SocialMediaStrategy>({
    queryKey: ['/api/opphub-ai/social-media', selectedArtist || userId],
    enabled: Boolean((isManaged && userRole === 'managed_artist') || (isAdmin && selectedArtist))
  });

  // AI Learning Data (Admin only)
  const { data: aiLearning } = useQuery<AILearning>({
    queryKey: ['/api/opphub-ai/learning'],
    enabled: isAdmin,
    refetchInterval: 600000 // Refresh every 10 minutes
  });

  // Dashboard Overview (Admin only)
  const { data: aiDashboard } = useQuery<{
    health: any;
    forecasts: any;
    learning: any;
    timestamp: string;
  }>({
    queryKey: ['/api/opphub-ai/dashboard'],
    enabled: isAdmin,
    refetchInterval: 60000 // Refresh every minute
  });

  // Generate AI guidance for opportunity
  const generateGuidanceMutation = useMutation({
    mutationFn: (data: { opportunityId: number; targetUserId: number }) =>
      apiRequest('/api/opphub-ai/guidance/generate', { method: 'POST', body: data }),
    onSuccess: () => {
      toast({ title: 'Success', description: 'AI guidance generated successfully' });
      queryClient.invalidateQueries({ queryKey: ['/api/opphub-ai/guidance'] });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to generate AI guidance', variant: 'destructive' });
    }
  });

  // Add success story for learning
  const addSuccessStoryMutation = useMutation({
    mutationFn: (storyData: any) =>
      apiRequest('/api/opphub-ai/success-story', { method: 'POST', body: storyData }),
    onSuccess: () => {
      toast({ title: 'Success', description: 'Success story added to AI learning database' });
      queryClient.invalidateQueries({ queryKey: ['/api/opphub-ai/learning'] });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to add success story', variant: 'destructive' });
    }
  });

  const getHealthStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'critical': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getHealthStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'bg-green-100 text-green-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* OppHub AI Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="relative">
            <Brain className="w-8 h-8 text-emerald-600" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
          </div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-cyan-600 bg-clip-text text-transparent">
            OppHub AI
          </h2>
          <Zap className="w-6 h-6 text-yellow-500" />
        </div>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Central Intelligence System for Wai'tuMusic Platform - Monitoring, Forecasting, Social Media AI, 
          Opportunity Discovery, and Learning from Platform Data
        </p>
      </div>

      <Tabs defaultValue={isAdmin ? "monitoring" : "guidance"} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-6">
          {isAdmin && (
            <>
              <TabsTrigger value="monitoring" className="flex items-center space-x-2">
                <Shield className="w-4 h-4" />
                <span className="hidden sm:inline">Monitoring</span>
              </TabsTrigger>
              <TabsTrigger value="forecasting" className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4" />
                <span className="hidden sm:inline">Forecasting</span>
              </TabsTrigger>
              <TabsTrigger value="learning" className="flex items-center space-x-2">
                <BookOpen className="w-4 h-4" />
                <span className="hidden sm:inline">Learning</span>
              </TabsTrigger>
            </>
          )}
          {(isManaged || isAdmin) && (
            <TabsTrigger value="guidance" className="flex items-center space-x-2">
              <Target className="w-4 h-4" />
              <span className="hidden sm:inline">AI Guidance</span>
            </TabsTrigger>
          )}
          {(userRole === 'managed_artist' || isAdmin) && (
            <TabsTrigger value="social" className="flex items-center space-x-2">
              <Instagram className="w-4 h-4" />
              <span className="hidden sm:inline">Social AI</span>
            </TabsTrigger>
          )}
          {isAdmin && (
            <TabsTrigger value="dashboard" className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
          )}
        </TabsList>

        {/* Platform Monitoring Tab */}
        {isAdmin && (
          <TabsContent value="monitoring" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center space-y-0 pb-2">
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-emerald-600" />
                  <span>Platform Health Monitoring</span>
                </CardTitle>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => refetchHealth()}
                  className="ml-auto"
                >
                  Refresh
                </Button>
              </CardHeader>
              <CardContent>
                {platformHealth ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Overall Status:</span>
                      <Badge className={getHealthStatusColor(platformHealth.status)}>
                        {getHealthStatusIcon(platformHealth.status)}
                        <span className="ml-1 capitalize">{platformHealth.status}</span>
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {platformHealth.checks?.map((check: HealthCheck, index: number) => (
                        <Card key={index} className="border-l-4 border-l-emerald-500">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium">{check.name}</h4>
                              {getHealthStatusIcon(check.status)}
                            </div>
                            <p className="text-sm text-gray-600">{check.details}</p>
                            {check.responseTime && (
                              <p className="text-xs text-gray-500 mt-1">Response: {check.responseTime}</p>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    {platformHealth.recommendations?.length > 0 && (
                      <div className="mt-6">
                        <h4 className="font-medium mb-3 flex items-center">
                          <Lightbulb className="w-4 h-4 mr-2 text-yellow-500" />
                          AI Recommendations
                        </h4>
                        <ul className="space-y-2">
                          {platformHealth.recommendations.map((rec: string, index: number) => (
                            <li key={index} className="text-sm text-gray-700 flex items-start">
                              <span className="text-emerald-500 mr-2">•</span>
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    Loading platform health data...
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Business Forecasting Tab */}
        {isAdmin && (
          <TabsContent value="forecasting" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {businessForecasts && (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <DollarSign className="w-5 h-5 text-green-600" />
                        <span>Revenue Forecasting</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span>Trend:</span>
                          <Badge className={
                            businessForecasts.revenue?.trend === 'growing' ? 'bg-green-100 text-green-800' :
                            businessForecasts.revenue?.trend === 'declining' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }>
                            {businessForecasts.revenue?.trend}
                          </Badge>
                        </div>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Current Month Projection:</span>
                            <span className="font-medium">${businessForecasts.revenue?.currentMonthProjection || 0}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Next Month Forecast:</span>
                            <span className="font-medium">${businessForecasts.revenue?.nextMonthForecast || 0}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Users className="w-5 h-5 text-blue-600" />
                        <span>User Growth Analysis</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Weekly Growth Rate:</span>
                            <span className="font-medium">{businessForecasts.userGrowth?.weeklyGrowthRate || 0}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Projected Monthly Users:</span>
                            <span className="font-medium">{businessForecasts.userGrowth?.projectedMonthlyUsers || 0}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>

            {businessForecasts?.recommendations && businessForecasts.recommendations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lightbulb className="w-5 h-5 text-yellow-500" />
                    <span>AI Business Recommendations</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {businessForecasts?.recommendations?.map((rec: string, index: number) => (
                      <li key={index} className="text-sm text-gray-700 flex items-start">
                        <span className="text-emerald-500 mr-2">•</span>
                        {rec}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        )}

        {/* AI Learning Tab */}
        {isAdmin && (
          <TabsContent value="learning" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Cpu className="w-5 h-5 text-purple-600" />
                  <span>AI Learning System</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {aiLearning ? (
                  <div className="space-y-6">
                    {aiLearning.insights?.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">AI Insights</h4>
                        <ul className="space-y-2">
                          {aiLearning.insights.map((insight: string, index: number) => (
                            <li key={index} className="text-sm text-gray-700 flex items-start">
                              <Brain className="w-4 h-4 text-emerald-500 mr-2 mt-0.5 flex-shrink-0" />
                              {insight}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {aiLearning.recommendations?.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">Learning-Based Recommendations</h4>
                        <ul className="space-y-2">
                          {aiLearning.recommendations.map((rec: string, index: number) => (
                            <li key={index} className="text-sm text-gray-700 flex items-start">
                              <span className="text-purple-500 mr-2">•</span>
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="pt-4 border-t">
                      <Button 
                        onClick={() => {
                          const storyData = {
                            opportunityType: 'learning_example',
                            applicationStrategy: 'Platform learning integration',
                            successOutcome: 'Improved AI recommendations',
                            artistGenre: 'Various',
                            outcomeDetails: { source: 'Platform data analysis' },
                            successFactors: ['Data-driven insights', 'User behavior patterns']
                          };
                          addSuccessStoryMutation.mutate(storyData);
                        }}
                        disabled={addSuccessStoryMutation.isPending}
                        className="w-full"
                      >
                        {addSuccessStoryMutation.isPending ? 'Adding...' : 'Add Learning Example'}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    Loading AI learning data...
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* AI Guidance Tab */}
        {(isManaged || isAdmin) && (
          <TabsContent value="guidance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-blue-600" />
                  <span>AI Application Guidance</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {userGuidance ? (
                  <div className="space-y-4">
                    {userGuidance.guidance && userGuidance.guidance.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">AI Guidance</h4>
                        <ul className="space-y-2">
                          {userGuidance.guidance.map((guidance: string, index: number) => (
                            <li key={index} className="text-sm text-gray-700 flex items-start">
                              <span className="text-blue-500 mr-2">•</span>
                              {guidance}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    {userGuidance.recommendations && userGuidance.recommendations.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">AI Recommendations</h4>
                        <ul className="space-y-2">
                          {userGuidance.recommendations.map((rec: string, index: number) => (
                            <li key={index} className="text-sm text-gray-700 flex items-start">
                              <span className="text-emerald-500 mr-2">•</span>
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    No AI guidance available yet. AI guidance will be generated as new opportunities are discovered.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Social Media AI Tab */}
        {(userRole === 'managed_artist' || isAdmin) && (
          <TabsContent value="social" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Instagram className="w-5 h-5 text-pink-600" />
                  <span>AI Social Media Strategy</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {socialMediaStrategy ? (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-medium mb-3">Brand Voice & Strategy</h4>
                      <p className="text-sm text-gray-700 mb-4">{socialMediaStrategy.strategy?.brandVoice}</p>
                      
                      {socialMediaStrategy.strategy?.contentPillars?.length > 0 && (
                        <div>
                          <h5 className="font-medium text-sm mb-2">Content Pillars:</h5>
                          <div className="flex flex-wrap gap-2">
                            {socialMediaStrategy.strategy.contentPillars.map((pillar: string, index: number) => (
                              <Badge key={index} variant="outline">{pillar}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {socialMediaStrategy.contentSuggestions?.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">AI Content Suggestions</h4>
                        <ul className="space-y-2">
                          {socialMediaStrategy.contentSuggestions.slice(0, 5).map((suggestion: string, index: number) => (
                            <li key={index} className="text-sm text-gray-700 flex items-start">
                              <Lightbulb className="w-4 h-4 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                              {suggestion}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {socialMediaStrategy.hashtagRecommendations?.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">Recommended Hashtags</h4>
                        <div className="flex flex-wrap gap-2">
                          {socialMediaStrategy.hashtagRecommendations.slice(0, 10).map((hashtag: string, index: number) => (
                            <Badge key={index} variant="secondary" className="text-xs break-words max-w-full">
                              {hashtag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {socialMediaStrategy.engagementTactics?.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">AI Engagement Tactics</h4>
                        <ul className="space-y-2">
                          {socialMediaStrategy.engagementTactics.slice(0, 5).map((tactic: string, index: number) => (
                            <li key={index} className="text-sm text-gray-700 flex items-start">
                              <span className="text-pink-500 mr-2">•</span>
                              {tactic}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    Loading AI social media strategy...
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* AI Dashboard Tab */}
        {isAdmin && (
          <TabsContent value="dashboard" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-emerald-600" />
                  <span>Comprehensive AI Dashboard</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {aiDashboard ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm font-medium text-emerald-600">Platform Health</p>
                              <p className="text-2xl font-bold capitalize">{aiDashboard.health?.status}</p>
                            </div>
                            <Shield className="w-8 h-8 text-emerald-600" />
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm font-medium text-blue-600">Revenue Trend</p>
                              <p className="text-2xl font-bold capitalize">{aiDashboard.forecasts?.revenue?.trend}</p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-blue-600" />
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm font-medium text-purple-600">AI Insights</p>
                              <p className="text-2xl font-bold">{aiDashboard.learning?.insights?.length || 0}</p>
                            </div>
                            <Brain className="w-8 h-8 text-purple-600" />
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="text-center text-sm text-gray-500">
                      Last updated: {aiDashboard.timestamp ? new Date(aiDashboard.timestamp).toLocaleString() : 'Unknown'}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    Loading AI dashboard data...
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}