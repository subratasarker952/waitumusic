import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  Search, 
  Target, 
  TrendingUp, 
  Calendar,
  MapPin,
  DollarSign,
  Star,
  Clock,
  Users,
  Zap,
  Filter,
  CheckCircle,
  XCircle,
  AlertCircle,
  ExternalLink,
  Bookmark,
  Share2,
  Eye,
  ThumbsUp,
  Award,
  Building
} from 'lucide-react';

interface OpportunityMatch {
  id: number;
  title: string;
  type: string;
  organization: string;
  description: string;
  matchScore: number;
  location: string;
  deadline: string;
  compensation: {
    min: number;
    max: number;
    currency: string;
    type: 'fixed' | 'royalty' | 'percentage' | 'revenue_share';
  };
  requirements: string[];
  benefits: string[];
  applicationUrl: string;
  contactInfo: {
    name?: string;
    email?: string;
    phone?: string;
  };
  tags: string[];
  status: 'new' | 'applied' | 'under_review' | 'accepted' | 'rejected' | 'expired';
  relevanceFactors: {
    genreMatch: number;
    locationMatch: number;
    experienceMatch: number;
    networkMatch: number;
  };
  difficulty: 'easy' | 'medium' | 'hard';
  estimatedSuccess: number;
  createdAt: string;
}

interface MatchingCriteria {
  genres: string[];
  location: string;
  compensationRange: { min: number; max: number };
  opportunityTypes: string[];
  maxDistance: number;
  experienceLevel: string;
  keywords: string[];
}

interface ApplicationTracking {
  opportunityId: number;
  applicationDate: string;
  status: string;
  followUpDate?: string;
  notes: string;
  documents: string[];
  responseReceived: boolean;
}

const OpportunityMatchingAlgorithm: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterLocation, setFilterLocation] = useState('all');
  const [sortBy, setSortBy] = useState('match_score');

  // Fetch opportunity matches
  const { data: opportunities, isLoading: opportunitiesLoading } = useQuery({
    queryKey: ['/api/intelligence/opportunities/matches', searchTerm, filterType, filterLocation, sortBy],
    queryFn: () => apiRequest(`/api/intelligence/opportunities/matches?search=${searchTerm}&type=${filterType}&location=${filterLocation}&sort=${sortBy}`).then(res => res.json())
  });

  // Fetch matching criteria
  const { data: criteria } = useQuery({
    queryKey: ['/api/intelligence/opportunities/criteria'],
    queryFn: () => apiRequest('/api/intelligence/opportunities/criteria').then(res => res.json())
  });

  // Fetch application tracking
  const { data: applications } = useQuery({
    queryKey: ['/api/intelligence/opportunities/applications'],
    queryFn: () => apiRequest('/api/intelligence/opportunities/applications').then(res => res.json())
  });

  // Fetch analytics
  const { data: analytics } = useQuery({
    queryKey: ['/api/intelligence/opportunities/analytics'],
    queryFn: () => apiRequest('/api/intelligence/opportunities/analytics').then(res => res.json())
  });

  // Apply to opportunity
  const applyToOpportunity = useMutation({
    mutationFn: ({ opportunityId, documents }: { opportunityId: number; documents: string[] }) => 
      apiRequest('/api/intelligence/opportunities/apply', {
        method: 'POST',
        body: JSON.stringify({ opportunityId, documents })
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/opportunities/matches'] });
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/opportunities/applications'] });
      toast({ title: "Application Submitted", description: "Your application has been submitted successfully" });
    }
  });

  // Save opportunity
  const saveOpportunity = useMutation({
    mutationFn: (opportunityId: number) => 
      apiRequest('/api/intelligence/opportunities/save', {
        method: 'POST',
        body: JSON.stringify({ opportunityId })
      }),
    onSuccess: () => {
      toast({ title: "Opportunity Saved", description: "Opportunity saved to your bookmarks" });
    }
  });

  // Update matching criteria
  const updateCriteria = useMutation({
    mutationFn: (newCriteria: MatchingCriteria) => 
      apiRequest('/api/intelligence/opportunities/criteria', {
        method: 'PUT',
        body: JSON.stringify(newCriteria)
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/opportunities/matches'] });
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/opportunities/criteria'] });
      toast({ title: "Criteria Updated", description: "Matching criteria updated successfully" });
    }
  });

  const opportunityTypes = [
    'Recording Contract', 'Live Performance', 'Sync Licensing', 'Collaboration', 
    'Music Supervision', 'Brand Partnership', 'Festival', 'Contest', 'Grant', 'Residency'
  ];

  const locations = [
    'New York', 'Los Angeles', 'Nashville', 'Atlanta', 'Miami', 'London', 'Toronto', 
    'Remote', 'Caribbean', 'Europe', 'Global'
  ];

  const experienceLevels = ['Beginner', 'Intermediate', 'Advanced', 'Professional'];

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-50';
    if (score >= 70) return 'text-blue-600 bg-blue-50';
    if (score >= 50) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-red-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-500';
      case 'applied': return 'bg-yellow-500';
      case 'under_review': return 'bg-purple-500';
      case 'accepted': return 'bg-green-500';
      case 'rejected': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'accepted': return <CheckCircle className="h-4 w-4" />;
      case 'rejected': return <XCircle className="h-4 w-4" />;
      case 'under_review': return <Clock className="h-4 w-4" />;
      default: return <AlertCircle className="h-4 w-4" />;
    }
  };

  const filteredOpportunities = opportunities?.filter((opp: OpportunityMatch) => {
    const matchesSearch = opp.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         opp.organization.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         opp.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || opp.type === filterType;
    const matchesLocation = filterLocation === 'all' || opp.location === filterLocation;
    
    return matchesSearch && matchesType && matchesLocation;
  });

  if (opportunitiesLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="matches" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="matches">Matches</TabsTrigger>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="criteria">Criteria</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Opportunity Matches Tab */}
        <TabsContent value="matches" className="space-y-4">
          {/* Analytics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Matches</p>
                    <p className="text-2xl font-bold">{opportunities?.length || 0}</p>
                  </div>
                  <Target className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">High Match Score</p>
                    <p className="text-2xl font-bold">
                      {opportunities?.filter((o: OpportunityMatch) => o.matchScore >= 90).length || 0}
                    </p>
                  </div>
                  <Star className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Applied</p>
                    <p className="text-2xl font-bold">{applications?.length || 0}</p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                    <p className="text-2xl font-bold">{analytics?.successRate || 0}%</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="flex-1 min-w-[200px]">
              <Input
                placeholder="Search opportunities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {opportunityTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterLocation} onValueChange={setFilterLocation}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                {locations.map(location => (
                  <SelectItem key={location} value={location}>{location}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort By" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="match_score">Match Score</SelectItem>
                <SelectItem value="deadline">Deadline</SelectItem>
                <SelectItem value="compensation">Compensation</SelectItem>
                <SelectItem value="created_at">Date Added</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Opportunities Grid */}
          <div className="space-y-4">
            {filteredOpportunities?.map((opportunity: OpportunityMatch) => (
              <Card key={opportunity.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-start gap-3">
                        <div>
                          <h3 className="font-medium text-lg">{opportunity.title}</h3>
                          <p className="text-sm text-muted-foreground">
                            {opportunity.organization} • {opportunity.type}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`${getMatchScoreColor(opportunity.matchScore)} border-0`}>
                        {opportunity.matchScore}% match
                      </Badge>
                      <Badge className={`${getDifficultyColor(opportunity.difficulty)} text-white`}>
                        {opportunity.difficulty}
                      </Badge>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {opportunity.description}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{opportunity.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Due: {new Date(opportunity.deadline).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        {opportunity.compensation.min.toLocaleString()}-{opportunity.compensation.max.toLocaleString()} {opportunity.compensation.currency}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{opportunity.estimatedSuccess}% success rate</span>
                    </div>
                  </div>

                  {/* Relevance Factors */}
                  <div className="mb-4">
                    <p className="text-sm font-medium mb-2">Match Breakdown</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Genre</span>
                          <span>{opportunity.relevanceFactors.genreMatch}%</span>
                        </div>
                        <Progress value={opportunity.relevanceFactors.genreMatch} className="h-1" />
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Location</span>
                          <span>{opportunity.relevanceFactors.locationMatch}%</span>
                        </div>
                        <Progress value={opportunity.relevanceFactors.locationMatch} className="h-1" />
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Experience</span>
                          <span>{opportunity.relevanceFactors.experienceMatch}%</span>
                        </div>
                        <Progress value={opportunity.relevanceFactors.experienceMatch} className="h-1" />
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Network</span>
                          <span>{opportunity.relevanceFactors.networkMatch}%</span>
                        </div>
                        <Progress value={opportunity.relevanceFactors.networkMatch} className="h-1" />
                      </div>
                    </div>
                  </div>

                  {/* Requirements & Benefits */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm font-medium mb-2">Requirements</p>
                      <ul className="text-xs space-y-1">
                        {opportunity.requirements.slice(0, 3).map((req, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <div className="w-1 h-1 bg-gray-400 rounded-full mt-2 flex-shrink-0" />
                            <span>{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-2">Benefits</p>
                      <ul className="text-xs space-y-1">
                        {opportunity.benefits.slice(0, 3).map((benefit, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <div className="w-1 h-1 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-1">
                      {opportunity.tags.slice(0, 5).map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        onClick={() => applyToOpportunity.mutate({ opportunityId: opportunity.id, documents: [] })}
                        disabled={applyToOpportunity.isPending || opportunity.status === 'applied'}
                      >
                        {opportunity.status === 'applied' ? (
                          <>
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Applied
                          </>
                        ) : (
                          <>
                            <Zap className="h-3 w-3 mr-1" />
                            Apply Now
                          </>
                        )}
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => saveOpportunity.mutate(opportunity.id)}
                      >
                        <Bookmark className="h-3 w-3 mr-1" />
                        Save
                      </Button>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" asChild>
                        <a href={opportunity.applicationUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-3 w-3 mr-1" />
                          View Details
                        </a>
                      </Button>
                      <Button size="sm" variant="outline">
                        <Share2 className="h-3 w-3 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Applications Tracking Tab */}
        <TabsContent value="applications" className="space-y-4">
          <div className="space-y-4">
            {applications?.map((application: ApplicationTracking) => {
              const opportunity = opportunities?.find((o: OpportunityMatch) => o.id === application.opportunityId);
              return (
                <Card key={application.opportunityId}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-medium">{opportunity?.title || 'Opportunity'}</h4>
                        <p className="text-sm text-muted-foreground">
                          {opportunity?.organization} • Applied {new Date(application.applicationDate).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={`${getStatusColor(application.status)} text-white`}>
                          <div className="flex items-center gap-1">
                            {getStatusIcon(application.status)}
                            {application.status.replace('_', ' ')}
                          </div>
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                      <div className="flex items-center gap-2">
                        <Eye className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">
                          Response: {application.responseReceived ? 'Received' : 'Pending'}
                        </span>
                      </div>
                      {application.followUpDate && (
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">
                            Follow-up: {new Date(application.followUpDate).toLocaleDateString()}
                          </span>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <Building className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{application.documents.length} documents</span>
                      </div>
                    </div>

                    {application.notes && (
                      <div className="mb-3 p-3 bg-gray-50 rounded">
                        <p className="text-sm">{application.notes}</p>
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        Update Status
                      </Button>
                      <Button size="sm" variant="outline">
                        Add Note
                      </Button>
                      <Button size="sm" variant="outline">
                        Follow Up
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Matching Criteria Tab */}
        <TabsContent value="criteria" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Matching Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Configure your preferences to receive better matched opportunities
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Preferred Genres</label>
                  <div className="space-y-2">
                    {['Hip-Hop', 'R&B', 'Pop', 'Caribbean', 'Electronic', 'Rock'].map(genre => (
                      <div key={genre} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={genre}
                          defaultChecked={criteria?.genres?.includes(genre)}
                          className="rounded"
                        />
                        <label htmlFor={genre} className="text-sm">{genre}</label>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Opportunity Types</label>
                  <div className="space-y-2">
                    {opportunityTypes.slice(0, 6).map(type => (
                      <div key={type} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={type}
                          defaultChecked={criteria?.opportunityTypes?.includes(type)}
                          className="rounded"
                        />
                        <label htmlFor={type} className="text-sm">{type}</label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Preferred Location</label>
                  <Select defaultValue={criteria?.location}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations.map(location => (
                        <SelectItem key={location} value={location}>
                          {location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Experience Level</label>
                  <Select defaultValue={criteria?.experienceLevel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select experience level" />
                    </SelectTrigger>
                    <SelectContent>
                      {experienceLevels.map(level => (
                        <SelectItem key={level} value={level}>
                          {level}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Compensation Range (USD)</label>
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    type="number"
                    placeholder="Minimum"
                    defaultValue={criteria?.compensationRange?.min}
                  />
                  <Input
                    type="number"
                    placeholder="Maximum"
                    defaultValue={criteria?.compensationRange?.max}
                  />
                </div>
              </div>

              <Button className="w-full">
                <Filter className="h-4 w-4 mr-2" />
                Update Matching Criteria
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Application Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Applications Sent</span>
                    <span className="font-medium">{analytics?.totalApplications || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Response Rate</span>
                    <span className="font-medium">{analytics?.responseRate || 0}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Success Rate</span>
                    <span className="font-medium">{analytics?.successRate || 0}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Average Match Score</span>
                    <span className="font-medium">{analytics?.averageMatchScore || 0}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Opportunity Types</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {analytics?.topOpportunityTypes?.map((item: any) => (
                    <div key={item.type} className="flex justify-between">
                      <span>{item.type}</span>
                      <span className="font-medium">{item.count}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default OpportunityMatchingAlgorithm;