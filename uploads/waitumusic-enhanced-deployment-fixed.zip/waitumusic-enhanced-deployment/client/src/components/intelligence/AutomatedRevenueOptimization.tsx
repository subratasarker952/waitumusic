import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  DollarSign, 
  TrendingUp, 
  BarChart3, 
  Zap,
  Target,
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  Music,
  Calendar,
  ArrowUp,
  ArrowDown,
  Play,
  Pause
} from 'lucide-react';

interface RevenueStream {
  id: number;
  name: string;
  type: 'streaming' | 'live' | 'merchandise' | 'sync' | 'royalties' | 'sponsorship';
  currentRevenue: number;
  projectedRevenue: number;
  growth: number;
  optimization: {
    potentialIncrease: number;
    confidence: number;
    strategies: string[];
    timeframe: string;
    effort: 'low' | 'medium' | 'high';
  };
  performance: {
    lastMonth: number;
    lastQuarter: number;
    yearToDate: number;
  };
  status: 'optimized' | 'needs_attention' | 'underperforming' | 'new_opportunity';
}

interface PricingStrategy {
  id: number;
  service: string;
  currentPrice: number;
  recommendedPrice: number;
  priceChange: number;
  impactForecast: {
    revenueChange: number;
    demandChange: number;
    competitorPosition: string;
  };
  marketAnalysis: {
    competitorPrices: number[];
    marketAverage: number;
    priceElasticity: number;
  };
  implementation: {
    rolloutDate: string;
    testDuration: string;
    monitoringMetrics: string[];
  };
}

interface AutomationRule {
  id: number;
  name: string;
  trigger: string;
  action: string;
  conditions: string[];
  impact: number;
  frequency: string;
  isActive: boolean;
  performance: {
    timesTriggered: number;
    successRate: number;
    revenueGenerated: number;
  };
}

const AutomatedRevenueOptimization: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTimeframe, setSelectedTimeframe] = useState('30d');

  // Fetch revenue streams
  const { data: revenueStreams, isLoading: streamsLoading } = useQuery({
    queryKey: ['/api/intelligence/revenue/streams', selectedTimeframe],
    queryFn: () => apiRequest(`/api/intelligence/revenue/streams?timeframe=${selectedTimeframe}`).then(res => res.json())
  });

  // Fetch pricing strategies
  const { data: pricingStrategies } = useQuery({
    queryKey: ['/api/intelligence/revenue/pricing'],
    queryFn: () => apiRequest('/api/intelligence/revenue/pricing').then(res => res.json())
  });

  // Fetch automation rules
  const { data: automationRules } = useQuery({
    queryKey: ['/api/intelligence/revenue/automation'],
    queryFn: () => apiRequest('/api/intelligence/revenue/automation').then(res => res.json())
  });

  // Fetch analytics
  const { data: analytics } = useQuery({
    queryKey: ['/api/intelligence/revenue/analytics'],
    queryFn: () => apiRequest('/api/intelligence/revenue/analytics').then(res => res.json())
  });

  // Optimize revenue stream
  const optimizeStream = useMutation({
    mutationFn: (streamId: number) => apiRequest(`/api/intelligence/revenue/optimize/${streamId}`, {
      method: 'POST'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/revenue/streams'] });
      toast({ title: "Stream Optimized", description: "Revenue stream optimization applied successfully" });
    }
  });

  // Apply pricing strategy
  const applyPricing = useMutation({
    mutationFn: (strategyId: number) => apiRequest(`/api/intelligence/revenue/pricing/${strategyId}/apply`, {
      method: 'POST'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/revenue/pricing'] });
      toast({ title: "Pricing Applied", description: "New pricing strategy implemented successfully" });
    }
  });

  // Toggle automation rule
  const toggleAutomation = useMutation({
    mutationFn: ({ ruleId, isActive }: { ruleId: number; isActive: boolean }) => 
      apiRequest(`/api/intelligence/revenue/automation/${ruleId}`, {
        method: 'PATCH',
        body: JSON.stringify({ isActive })
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/revenue/automation'] });
      toast({ title: "Automation Updated", description: "Automation rule status updated successfully" });
    }
  });

  const timeframes = [
    { id: '7d', name: 'Last 7 Days' },
    { id: '30d', name: 'Last 30 Days' },
    { id: '90d', name: 'Last 3 Months' },
    { id: '1y', name: 'Last Year' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimized': return 'bg-green-500';
      case 'needs_attention': return 'bg-yellow-500';
      case 'underperforming': return 'bg-red-500';
      default: return 'bg-blue-500';
    }
  };

  const getGrowthColor = (growth: number) => {
    if (growth > 10) return 'text-green-600';
    if (growth > 0) return 'text-blue-600';
    return 'text-red-600';
  };

  const getEffortColor = (effort: string) => {
    switch (effort) {
      case 'low': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-red-500';
    }
  };

  if (streamsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="streams" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="streams">Revenue Streams</TabsTrigger>
          <TabsTrigger value="pricing">Pricing</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Revenue Streams Tab */}
        <TabsContent value="streams" className="space-y-4">
          {/* Filters */}
          <div className="flex gap-4 mb-6">
            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Timeframe" />
              </SelectTrigger>
              <SelectContent>
                {timeframes.map(timeframe => (
                  <SelectItem key={timeframe.id} value={timeframe.id}>
                    {timeframe.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                    <p className="text-2xl font-bold">${analytics?.totalRevenue?.toLocaleString() || 0}</p>
                    <p className={`text-xs ${getGrowthColor(analytics?.revenueGrowth || 0)}`}>
                      {analytics?.revenueGrowth > 0 ? '+' : ''}{analytics?.revenueGrowth || 0}%
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Optimization Potential</p>
                    <p className="text-2xl font-bold">${analytics?.optimizationPotential?.toLocaleString() || 0}</p>
                    <p className="text-xs text-blue-600">Projected increase</p>
                  </div>
                  <Target className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Streams</p>
                    <p className="text-2xl font-bold">{revenueStreams?.length || 0}</p>
                    <p className="text-xs text-green-600">Revenue sources</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Growth</p>
                    <p className="text-2xl font-bold">{analytics?.averageGrowth || 0}%</p>
                    <p className="text-xs text-muted-foreground">Across all streams</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Revenue Streams Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {revenueStreams?.map((stream: RevenueStream) => (
              <Card key={stream.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{stream.name}</CardTitle>
                      <p className="text-sm text-muted-foreground capitalize">{stream.type}</p>
                    </div>
                    <Badge className={`${getStatusColor(stream.status)} text-white`}>
                      {stream.status.replace('_', ' ')}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Current Revenue</p>
                        <p className="text-xl font-bold">${stream.currentRevenue.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Projected</p>
                        <p className="text-xl font-bold">${stream.projectedRevenue.toLocaleString()}</p>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm">Growth Rate</span>
                        <span className={`font-medium ${getGrowthColor(stream.growth)}`}>
                          {stream.growth > 0 ? (
                            <ArrowUp className="h-3 w-3 inline mr-1" />
                          ) : (
                            <ArrowDown className="h-3 w-3 inline mr-1" />
                          )}
                          {Math.abs(stream.growth)}%
                        </span>
                      </div>
                      <Progress value={Math.min(100, Math.abs(stream.growth))} className="h-2" />
                    </div>

                    <div className="p-3 bg-blue-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Optimization Potential</span>
                        <div className="flex items-center gap-2">
                          <Badge className={`${getEffortColor(stream.optimization.effort)} text-white text-xs`}>
                            {stream.optimization.effort} effort
                          </Badge>
                          <span className="text-sm font-medium">
                            +${stream.optimization.potentialIncrease.toLocaleString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs">Confidence</span>
                        <span className="text-xs">{stream.optimization.confidence}%</span>
                      </div>
                      <Progress value={stream.optimization.confidence} className="h-1" />
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Optimization Strategies</p>
                      <ul className="text-xs space-y-1">
                        {stream.optimization.strategies.slice(0, 3).map((strategy, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <Zap className="h-3 w-3 text-blue-500 mt-0.5 flex-shrink-0" />
                            <span>{strategy}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="text-center">
                        <div className="font-medium">${stream.performance.lastMonth.toLocaleString()}</div>
                        <div className="text-muted-foreground">Last Month</div>
                      </div>
                      <div className="text-center">
                        <div className="font-medium">${stream.performance.lastQuarter.toLocaleString()}</div>
                        <div className="text-muted-foreground">Last Quarter</div>
                      </div>
                      <div className="text-center">
                        <div className="font-medium">${stream.performance.yearToDate.toLocaleString()}</div>
                        <div className="text-muted-foreground">YTD</div>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-3 border-t">
                      <Button 
                        size="sm"
                        onClick={() => optimizeStream.mutate(stream.id)}
                        disabled={optimizeStream.isPending}
                      >
                        <Zap className="h-3 w-3 mr-1" />
                        Optimize
                      </Button>
                      <Button size="sm" variant="outline">
                        <Settings className="h-3 w-3 mr-1" />
                        Configure
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Pricing Strategies Tab */}
        <TabsContent value="pricing" className="space-y-4">
          <div className="space-y-6">
            {pricingStrategies?.map((strategy: PricingStrategy) => (
              <Card key={strategy.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-medium text-lg">{strategy.service}</h3>
                      <p className="text-sm text-muted-foreground">
                        Current: ${strategy.currentPrice} → Recommended: ${strategy.recommendedPrice}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className={`text-lg font-medium ${getGrowthColor(strategy.priceChange)}`}>
                        {strategy.priceChange > 0 ? '+' : ''}{strategy.priceChange}%
                      </div>
                      <div className="text-xs text-muted-foreground">Price change</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                    <div>
                      <p className="text-sm font-medium mb-2">Impact Forecast</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Revenue Change:</span>
                          <span className={getGrowthColor(strategy.impactForecast.revenueChange)}>
                            {strategy.impactForecast.revenueChange > 0 ? '+' : ''}{strategy.impactForecast.revenueChange}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Demand Change:</span>
                          <span className={getGrowthColor(strategy.impactForecast.demandChange)}>
                            {strategy.impactForecast.demandChange > 0 ? '+' : ''}{strategy.impactForecast.demandChange}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Market Position:</span>
                          <span>{strategy.impactForecast.competitorPosition}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Market Analysis</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Market Average:</span>
                          <span>${strategy.marketAnalysis.marketAverage}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Price Elasticity:</span>
                          <span>{strategy.marketAnalysis.priceElasticity}</span>
                        </div>
                        <div>
                          <span>Competitor Range:</span>
                          <div className="text-xs mt-1">
                            ${Math.min(...strategy.marketAnalysis.competitorPrices)} - ${Math.max(...strategy.marketAnalysis.competitorPrices)}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Implementation</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Rollout Date:</span>
                          <span>{new Date(strategy.implementation.rolloutDate).toLocaleDateString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Test Duration:</span>
                          <span>{strategy.implementation.testDuration}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm font-medium mb-2">Monitoring Metrics</p>
                    <div className="flex flex-wrap gap-1">
                      {strategy.implementation.monitoringMetrics.map(metric => (
                        <Badge key={metric} variant="outline" className="text-xs">
                          {metric}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2 pt-3 border-t">
                    <Button 
                      size="sm"
                      onClick={() => applyPricing.mutate(strategy.id)}
                      disabled={applyPricing.isPending}
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Apply Strategy
                    </Button>
                    <Button size="sm" variant="outline">
                      <Calendar className="h-3 w-3 mr-1" />
                      Schedule Test
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Automation Rules Tab */}
        <TabsContent value="automation" className="space-y-4">
          <div className="space-y-4">
            {automationRules?.map((rule: AutomationRule) => (
              <Card key={rule.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-medium">{rule.name}</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        When <span className="font-medium">{rule.trigger}</span> → {rule.action}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={rule.isActive ? 'bg-green-500' : 'bg-gray-500'}>
                        {rule.isActive ? (
                          <Play className="h-3 w-3 mr-1" />
                        ) : (
                          <Pause className="h-3 w-3 mr-1" />
                        )}
                        {rule.isActive ? 'Active' : 'Paused'}
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => toggleAutomation.mutate({ 
                          ruleId: rule.id, 
                          isActive: !rule.isActive 
                        })}
                      >
                        {rule.isActive ? 'Pause' : 'Activate'}
                      </Button>
                    </div>
                  </div>

                  <div className="mb-3">
                    <p className="text-sm font-medium mb-1">Conditions</p>
                    <div className="flex flex-wrap gap-1">
                      {rule.conditions.map((condition, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {condition}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                    <div className="text-center">
                      <div className="text-lg font-medium">${rule.performance.revenueGenerated.toLocaleString()}</div>
                      <div className="text-xs text-muted-foreground">Revenue Generated</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-medium">{rule.performance.timesTriggered}</div>
                      <div className="text-xs text-muted-foreground">Times Triggered</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-medium">{rule.performance.successRate}%</div>
                      <div className="text-xs text-muted-foreground">Success Rate</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-medium">{rule.frequency}</div>
                      <div className="text-xs text-muted-foreground">Frequency</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="font-medium">Estimated Impact:</span>
                      <span className="ml-2">${rule.impact.toLocaleString()}/month</span>
                    </div>
                    <Button size="sm" variant="outline">
                      <Settings className="h-3 w-3 mr-1" />
                      Configure
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Total Revenue</span>
                    <span className="font-medium">${analytics?.totalRevenue?.toLocaleString() || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Growth</span>
                    <span className={`font-medium ${getGrowthColor(analytics?.monthlyGrowth || 0)}`}>
                      {analytics?.monthlyGrowth > 0 ? '+' : ''}{analytics?.monthlyGrowth || 0}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Optimization Savings</span>
                    <span className="font-medium">${analytics?.optimizationSavings?.toLocaleString() || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Automation ROI</span>
                    <span className="font-medium">{analytics?.automationROI || 0}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Stream Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {analytics?.streamDistribution?.map((item: any) => (
                    <div key={item.type} className="flex justify-between">
                      <span className="capitalize">{item.type}</span>
                      <span className="font-medium">{item.percentage}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AutomatedRevenueOptimization;