import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Users, 
  DollarSign,
  Brain,
  Zap,
  TrendingUp,
  Shield,
  Calendar,
  Download,
  Plus,
  Edit,
  Eye,
  AlertCircle
} from 'lucide-react';

interface Contract {
  id: number;
  title: string;
  type: 'booking' | 'management' | 'publishing' | 'licensing' | 'performance';
  status: 'draft' | 'review' | 'negotiation' | 'approved' | 'signed' | 'active' | 'expired';
  parties: string[];
  value: number;
  currency: string;
  startDate: string;
  endDate: string;
  riskScore: number;
  complianceScore: number;
  aiRecommendations: string[];
  nextMilestone: string;
  renewalDate?: string;
  createdAt: string;
  updatedAt: string;
}

interface ContractTemplate {
  id: string;
  name: string;
  type: string;
  clauses: string[];
  riskFactors: string[];
  optimizations: string[];
}

export default function SmartContractManager() {
  const [activeTab, setActiveTab] = useState('contracts');
  const [selectedContract, setSelectedContract] = useState<Contract | null>(null);
  const [contractType, setContractType] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch contracts with AI analysis
  const { data: contracts, isLoading: contractsLoading } = useQuery({
    queryKey: ['/api/contracts/smart'],
    queryFn: async () => {
      const response = await apiRequest('/api/contracts/smart');
      if (!response.ok) throw new Error('Failed to fetch contracts');
      return response.json();
    }
  });

  // Fetch contract templates
  const { data: templates } = useQuery({
    queryKey: ['/api/contracts/templates'],
    queryFn: async () => {
      const response = await apiRequest('/api/contracts/templates');
      if (!response.ok) throw new Error('Failed to fetch templates');
      return response.json();
    }
  });

  // Generate smart contract mutation
  const generateContract = useMutation({
    mutationFn: async (contractData: any) => {
      const response = await apiRequest('/api/contracts/generate', {
        method: 'POST',
        body: JSON.stringify(contractData)
      });
      if (!response.ok) throw new Error('Failed to generate contract');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contracts/smart'] });
      toast({ title: "Success", description: "Smart contract generated successfully" });
      setIsGenerating(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to generate contract", variant: "destructive" });
      setIsGenerating(false);
    }
  });

  // AI contract analysis mutation
  const analyzeContract = useMutation({
    mutationFn: async (contractId: number) => {
      const response = await apiRequest(`/api/contracts/${contractId}/analyze`, {
        method: 'POST'
      });
      if (!response.ok) throw new Error('Failed to analyze contract');
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/contracts/smart'] });
      toast({ title: "Analysis Complete", description: `Risk score: ${data.riskScore}/100` });
    }
  });

  const getStatusColor = (status: string) => {
    const colors = {
      draft: 'bg-gray-500',
      review: 'bg-blue-500',
      negotiation: 'bg-yellow-500',
      approved: 'bg-green-500',
      signed: 'bg-purple-500',
      active: 'bg-emerald-500',
      expired: 'bg-red-500'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-500';
  };

  const getRiskLevel = (score: number) => {
    if (score < 30) return { level: 'Low', color: 'text-green-600' };
    if (score < 70) return { level: 'Medium', color: 'text-yellow-600' };
    return { level: 'High', color: 'text-red-600' };
  };

  if (contractsLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Brain className="h-6 w-6 text-blue-600" />
            Smart Contract Management
          </h2>
          <p className="text-muted-foreground">AI-powered contract generation and compliance monitoring</p>
        </div>
        <Button onClick={() => setIsGenerating(true)} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Generate New Contract
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="contracts">Active Contracts</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Active Contracts Tab */}
        <TabsContent value="contracts" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {contracts?.map((contract: Contract) => (
              <Card key={contract.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{contract.title}</CardTitle>
                      <p className="text-sm text-muted-foreground capitalize">{contract.type} Contract</p>
                    </div>
                    <Badge className={`${getStatusColor(contract.status)} text-white`}>
                      {contract.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Value:</span>
                    <span className="font-medium">{contract.currency} {contract.value.toLocaleString()}</span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Risk Level:</span>
                      <span className={`font-medium ${getRiskLevel(contract.riskScore).color}`}>
                        {getRiskLevel(contract.riskScore).level}
                      </span>
                    </div>
                    <Progress value={100 - contract.riskScore} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Compliance:</span>
                      <span className="font-medium">{contract.complianceScore}%</span>
                    </div>
                    <Progress value={contract.complianceScore} className="h-2" />
                  </div>

                  {contract.nextMilestone && (
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Next: {contract.nextMilestone}</span>
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedContract(contract)}
                      className="flex-1"
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      View
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => analyzeContract.mutate(contract.id)}
                      disabled={analyzeContract.isPending}
                    >
                      <Brain className="h-4 w-4 mr-1" />
                      AI Analysis
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates?.map((template: ContractTemplate) => (
              <Card key={template.id}>
                <CardHeader>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <p className="text-sm text-muted-foreground capitalize">{template.type}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-sm mb-2">Key Clauses:</h4>
                    <div className="space-y-1">
                      {template.clauses.slice(0, 3).map((clause, index) => (
                        <div key={index} className="text-xs text-muted-foreground">
                          • {clause}
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-sm mb-2">AI Optimizations:</h4>
                    <div className="space-y-1">
                      {template.optimizations.slice(0, 2).map((optimization, index) => (
                        <div key={index} className="text-xs text-green-600">
                          ✓ {optimization}
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    size="sm"
                    className="w-full"
                    onClick={() => {
                      setContractType(template.type);
                      setIsGenerating(true);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Use Template
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Compliance Tab */}
        <TabsContent value="compliance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-600" />
                  Compliance Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Overall Compliance</span>
                    <span className="font-medium">94%</span>
                  </div>
                  <Progress value={94} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Legal Requirements</span>
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Industry Standards</span>
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Contract Renewals</span>
                    <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-yellow-600" />
                  Action Items
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="p-3 bg-yellow-50 rounded-lg border-l-4 border-yellow-400">
                    <p className="text-sm font-medium">3 contracts expiring in 30 days</p>
                    <p className="text-xs text-muted-foreground">Review renewal terms</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                    <p className="text-sm font-medium">2 contracts pending signatures</p>
                    <p className="text-xs text-muted-foreground">Follow up with parties</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg border-l-4 border-green-400">
                    <p className="text-sm font-medium">5 contracts fully compliant</p>
                    <p className="text-xs text-muted-foreground">No action required</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Contracts</p>
                    <p className="text-2xl font-bold">{contracts?.length || 0}</p>
                  </div>
                  <FileText className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Value</p>
                    <p className="text-2xl font-bold">
                      ${contracts?.reduce((sum: number, contract: Contract) => sum + contract.value, 0).toLocaleString() || '0'}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Risk Score</p>
                    <p className="text-2xl font-bold">
                      {Math.round(contracts?.reduce((sum: number, contract: Contract) => sum + contract.riskScore, 0) / (contracts?.length || 1)) || 0}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Contracts</p>
                    <p className="text-2xl font-bold">
                      {contracts?.filter((c: Contract) => c.status === 'active').length || 0}
                    </p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-emerald-600" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Contract Generation Modal */}
      {isGenerating && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md mx-4">
            <CardHeader>
              <CardTitle>Generate Smart Contract</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Contract Type</label>
                <Select value={contractType} onValueChange={setContractType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select contract type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="booking">Booking Agreement</SelectItem>
                    <SelectItem value="management">Management Contract</SelectItem>
                    <SelectItem value="publishing">Publishing Agreement</SelectItem>
                    <SelectItem value="licensing">Licensing Deal</SelectItem>
                    <SelectItem value="performance">Performance Contract</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium">Contract Title</label>
                <Input placeholder="Enter contract title" />
              </div>

              <div>
                <label className="text-sm font-medium">Additional Requirements</label>
                <Textarea placeholder="Describe any specific requirements..." rows={3} />
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setIsGenerating(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    generateContract.mutate({
                      type: contractType,
                      title: 'Generated Contract',
                      requirements: 'Standard terms'
                    });
                  }}
                  disabled={!contractType || generateContract.isPending}
                  className="flex-1"
                >
                  {generateContract.isPending ? (
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                  ) : (
                    'Generate'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}