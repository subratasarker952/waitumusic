import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  DollarSign, 
  TrendingUp, 
  BarChart3, 
  Target, 
  Zap,
  Brain,
  Clock,
  Users,
  Globe,
  AlertCircle,
  CheckCircle,
  Activity,
  ArrowUp,
  ArrowDown,
  Minus
} from 'lucide-react';

interface PricingRule {
  id: number;
  serviceType: 'booking' | 'splitsheet' | 'isrc' | 'pro_registration' | 'consultation';
  basePrice: number;
  currency: string;
  dynamicFactors: {
    demandMultiplier: number;
    seasonalMultiplier: number;
    competitorMultiplier: number;
    urgencyMultiplier: number;
  };
  priceRange: {
    minimum: number;
    maximum: number;
  };
  isActive: boolean;
  lastUpdated: string;
}

interface MarketAnalysis {
  serviceType: string;
  currentDemand: number;
  competitorPricing: {
    average: number;
    lowest: number;
    highest: number;
  };
  recommendedPrice: number;
  confidence: number;
  trends: {
    direction: 'up' | 'down' | 'stable';
    percentage: number;
  };
  factors: string[];
}

interface PriceOptimization {
  serviceType: string;
  currentPrice: number;
  optimizedPrice: number;
  potentialRevenue: number;
  confidence: number;
  reasoning: string[];
  implementation: {
    immediate: boolean;
    testDuration: string;
    expectedImpact: string;
  };
}

export default function DynamicPricingIntelligence() {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedService, setSelectedService] = useState('booking');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch pricing rules
  const { data: pricingRules, isLoading } = useQuery({
    queryKey: ['/api/intelligence/pricing-rules'],
    queryFn: async () => {
      const response = await apiRequest('/api/intelligence/pricing-rules');
      if (!response.ok) throw new Error('Failed to fetch pricing rules');
      return response.json();
    }
  });

  // Fetch market analysis
  const { data: marketAnalysis } = useQuery({
    queryKey: ['/api/intelligence/market-analysis'],
    queryFn: async () => {
      const response = await apiRequest('/api/intelligence/market-analysis');
      if (!response.ok) throw new Error('Failed to fetch market analysis');
      return response.json();
    }
  });

  // Fetch price optimizations
  const { data: optimizations } = useQuery({
    queryKey: ['/api/intelligence/price-optimizations'],
    queryFn: async () => {
      const response = await apiRequest('/api/intelligence/price-optimizations');
      if (!response.ok) throw new Error('Failed to fetch price optimizations');
      return response.json();
    }
  });

  // Update pricing rule mutation
  const updatePricingRule = useMutation({
    mutationFn: async ({ ruleId, updates }: { ruleId: number; updates: any }) => {
      const response = await apiRequest(`/api/intelligence/pricing-rules/${ruleId}`, {
        method: 'PATCH',
        body: JSON.stringify(updates)
      });
      if (!response.ok) throw new Error('Failed to update pricing rule');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/pricing-rules'] });
      toast({ title: "Success", description: "Pricing rule updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update pricing rule", variant: "destructive" });
    }
  });

  // Apply optimization mutation
  const applyOptimization = useMutation({
    mutationFn: async (serviceType: string) => {
      const response = await apiRequest('/api/intelligence/apply-optimization', {
        method: 'POST',
        body: JSON.stringify({ serviceType })
      });
      if (!response.ok) throw new Error('Failed to apply optimization');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/pricing-rules'] });
      queryClient.invalidateQueries({ queryKey: ['/api/intelligence/price-optimizations'] });
      toast({ title: "Success", description: "Price optimization applied successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to apply optimization", variant: "destructive" });
    }
  });

  const getTrendIcon = (direction: string) => {
    switch (direction) {
      case 'up': return <ArrowUp className="h-4 w-4 text-green-600" />;
      case 'down': return <ArrowDown className="h-4 w-4 text-red-600" />;
      default: return <Minus className="h-4 w-4 text-gray-600" />;
    }
  };

  const getServiceName = (serviceType: string) => {
    const names = {
      booking: 'Artist Booking',
      splitsheet: 'Splitsheet Service',
      isrc: 'ISRC Registration',
      pro_registration: 'PRO Registration',
      consultation: 'Professional Consultation'
    };
    return names[serviceType as keyof typeof names] || serviceType;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Brain className="h-6 w-6 text-green-600" />
            Dynamic Pricing Intelligence
          </h2>
          <p className="text-muted-foreground">AI-powered pricing optimization and market analysis</p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedService} onValueChange={setSelectedService}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="booking">Artist Booking</SelectItem>
              <SelectItem value="splitsheet">Splitsheet Service</SelectItem>
              <SelectItem value="isrc">ISRC Registration</SelectItem>
              <SelectItem value="pro_registration">PRO Registration</SelectItem>
              <SelectItem value="consultation">Consultation</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="market">Market Analysis</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                    <p className="text-2xl font-bold">$127,500</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
                <div className="flex items-center mt-2 text-sm">
                  <ArrowUp className="h-4 w-4 text-green-600 mr-1" />
                  <span className="text-green-600">12.5%</span>
                  <span className="text-muted-foreground ml-1">from optimization</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Price Increase</p>
                    <p className="text-2xl font-bold">8.3%</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-blue-600" />
                </div>
                <div className="flex items-center mt-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600 mr-1" />
                  <span className="text-muted-foreground">Optimized pricing active</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Market Position</p>
                    <p className="text-2xl font-bold">85%</p>
                  </div>
                  <Target className="h-8 w-8 text-purple-600" />
                </div>
                <div className="flex items-center mt-2 text-sm">
                  <Activity className="h-4 w-4 text-blue-600 mr-1" />
                  <span className="text-muted-foreground">Competitive advantage</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Rules</p>
                    <p className="text-2xl font-bold">{pricingRules?.filter((rule: PricingRule) => rule.isActive).length || 0}</p>
                  </div>
                  <Zap className="h-8 w-8 text-yellow-600" />
                </div>
                <div className="flex items-center mt-2 text-sm">
                  <Globe className="h-4 w-4 text-blue-600 mr-1" />
                  <span className="text-muted-foreground">All services covered</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-600" />
                  Service Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {pricingRules?.slice(0, 3).map((rule: PricingRule) => (
                  <div key={rule.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium text-sm">{getServiceName(rule.serviceType)}</h4>
                      <p className="text-xs text-muted-foreground">
                        ${rule.basePrice} base • ${rule.priceRange.minimum}-${rule.priceRange.maximum} range
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant={rule.isActive ? 'default' : 'secondary'}>
                        {rule.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        {((rule.dynamicFactors.demandMultiplier - 1) * 100).toFixed(1)}% demand
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-purple-600" />
                  Recent Optimizations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-green-50 rounded-lg border-l-4 border-green-400">
                  <p className="text-sm font-medium">Booking prices increased 15%</p>
                  <p className="text-xs text-muted-foreground">High demand detected • 2 hours ago</p>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                  <p className="text-sm font-medium">ISRC service price adjusted</p>
                  <p className="text-xs text-muted-foreground">Competitor analysis update • 6 hours ago</p>
                </div>
                <div className="p-3 bg-yellow-50 rounded-lg border-l-4 border-yellow-400">
                  <p className="text-sm font-medium">Consultation rates optimized</p>
                  <p className="text-xs text-muted-foreground">Seasonal adjustment • 1 day ago</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Market Analysis Tab */}
        <TabsContent value="market" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {marketAnalysis?.map((analysis: MarketAnalysis) => (
              <Card key={analysis.serviceType}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{getServiceName(analysis.serviceType)}</span>
                    <div className="flex items-center gap-1">
                      {getTrendIcon(analysis.trends.direction)}
                      <span className="text-sm font-medium">{analysis.trends.percentage}%</span>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Current Demand:</span>
                      <span className="font-medium">{analysis.currentDemand}%</span>
                    </div>
                    <Progress value={analysis.currentDemand} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Competitor Pricing:</h4>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="text-center p-2 bg-gray-50 rounded">
                        <p className="text-muted-foreground">Lowest</p>
                        <p className="font-medium">${analysis.competitorPricing.lowest}</p>
                      </div>
                      <div className="text-center p-2 bg-blue-50 rounded">
                        <p className="text-muted-foreground">Average</p>
                        <p className="font-medium">${analysis.competitorPricing.average}</p>
                      </div>
                      <div className="text-center p-2 bg-green-50 rounded">
                        <p className="text-muted-foreground">Highest</p>
                        <p className="font-medium">${analysis.competitorPricing.highest}</p>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-sm">Recommended Price:</h4>
                      <span className="text-lg font-bold text-blue-600">
                        ${analysis.recommendedPrice}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{analysis.confidence}%</span>
                    </div>
                    <Progress value={analysis.confidence} className="h-1 mt-1" />
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2">Key Factors:</h4>
                    <div className="space-y-1">
                      {analysis.factors.map((factor: string, index: number) => (
                        <div key={index} className="flex items-start gap-2 text-xs">
                          <CheckCircle className="h-3 w-3 text-green-600 mt-0.5 flex-shrink-0" />
                          <span>{factor}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Optimization Tab */}
        <TabsContent value="optimization" className="space-y-4">
          <div className="space-y-4">
            {optimizations?.map((opt: PriceOptimization) => (
              <Card key={opt.serviceType}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{getServiceName(opt.serviceType)} Optimization</span>
                    <Badge variant={opt.implementation.immediate ? 'default' : 'secondary'}>
                      {opt.implementation.immediate ? 'Ready to Apply' : 'Testing Phase'}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-3 border rounded-lg">
                      <p className="text-sm text-muted-foreground">Current Price</p>
                      <p className="text-2xl font-bold">${opt.currentPrice}</p>
                    </div>
                    <div className="text-center p-3 border rounded-lg bg-green-50">
                      <p className="text-sm text-muted-foreground">Optimized Price</p>
                      <p className="text-2xl font-bold text-green-600">${opt.optimizedPrice}</p>
                    </div>
                    <div className="text-center p-3 border rounded-lg bg-blue-50">
                      <p className="text-sm text-muted-foreground">Revenue Impact</p>
                      <p className="text-2xl font-bold text-blue-600">+${opt.potentialRevenue}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Confidence Level:</span>
                      <span className="font-medium">{opt.confidence}%</span>
                    </div>
                    <Progress value={opt.confidence} className="h-2" />
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2">Optimization Reasoning:</h4>
                    <div className="space-y-1">
                      {opt.reasoning.map((reason: string, index: number) => (
                        <div key={index} className="flex items-start gap-2 text-sm">
                          <Brain className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                          <span>{reason}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="text-sm">
                      <p className="font-medium">Implementation: {opt.implementation.testDuration}</p>
                      <p className="text-muted-foreground">{opt.implementation.expectedImpact}</p>
                    </div>
                    <Button
                      onClick={() => applyOptimization.mutate(opt.serviceType)}
                      disabled={applyOptimization.isPending}
                      className="flex items-center gap-2"
                    >
                      {applyOptimization.isPending ? (
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                      ) : (
                        <Zap className="h-4 w-4" />
                      )}
                      Apply Optimization
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-4">
          <div className="space-y-4">
            {pricingRules?.map((rule: PricingRule) => (
              <Card key={rule.id}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{getServiceName(rule.serviceType)} Pricing Rule</span>
                    <Badge variant={rule.isActive ? 'default' : 'secondary'}>
                      {rule.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Base Price</label>
                      <Input
                        type="number"
                        value={rule.basePrice}
                        onChange={(e) => {
                          const updatedRule = { ...rule, basePrice: parseFloat(e.target.value) };
                          updatePricingRule.mutate({ ruleId: rule.id, updates: updatedRule });
                        }}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Min Price</label>
                      <Input
                        type="number"
                        value={rule.priceRange.minimum}
                        onChange={(e) => {
                          const updatedRule = {
                            ...rule,
                            priceRange: { ...rule.priceRange, minimum: parseFloat(e.target.value) }
                          };
                          updatePricingRule.mutate({ ruleId: rule.id, updates: updatedRule });
                        }}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Max Price</label>
                      <Input
                        type="number"
                        value={rule.priceRange.maximum}
                        onChange={(e) => {
                          const updatedRule = {
                            ...rule,
                            priceRange: { ...rule.priceRange, maximum: parseFloat(e.target.value) }
                          };
                          updatePricingRule.mutate({ ruleId: rule.id, updates: updatedRule });
                        }}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Status</label>
                      <Select
                        value={rule.isActive ? 'active' : 'inactive'}
                        onValueChange={(value) => {
                          const updatedRule = { ...rule, isActive: value === 'active' };
                          updatePricingRule.mutate({ ruleId: rule.id, updates: updatedRule });
                        }}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2">Dynamic Factors:</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div className="p-3 border rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Demand</p>
                        <p className="font-medium">{(rule.dynamicFactors.demandMultiplier * 100).toFixed(0)}%</p>
                      </div>
                      <div className="p-3 border rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Seasonal</p>
                        <p className="font-medium">{(rule.dynamicFactors.seasonalMultiplier * 100).toFixed(0)}%</p>
                      </div>
                      <div className="p-3 border rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Competitor</p>
                        <p className="font-medium">{(rule.dynamicFactors.competitorMultiplier * 100).toFixed(0)}%</p>
                      </div>
                      <div className="p-3 border rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Urgency</p>
                        <p className="font-medium">{(rule.dynamicFactors.urgencyMultiplier * 100).toFixed(0)}%</p>
                      </div>
                    </div>
                  </div>

                  <div className="text-xs text-muted-foreground">
                    Last updated: {new Date(rule.lastUpdated).toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}