import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

// Import technical rider modal components
import EnhancedStagePlotDesigner from '@/components/modals/EnhancedStagePlotDesigner';
import Enhanced32PortMixer from '@/components/modals/Enhanced32PortMixer';
import EnhancedSetlistManager from '@/components/modals/EnhancedSetlistManager';
import { 
  Calendar, Clock, Users, FileText, CreditCard, CheckCircle, 
  AlertCircle, Download, Signature, Music, User, ArrowLeft, ArrowRight,
  ChevronRight, ChevronLeft, Edit, Save, Loader2, CheckCircle2,
  Settings, Wrench, Volume2, Mic, Target, DollarSign, UserPlus,
  Crown, Guitar, Star, Briefcase, AlertTriangle, PenTool, Send, Receipt, Layout
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

interface ComprehensiveBookingWorkflowProps {
  bookingId: number;
  onStatusChange?: (status: string) => void;
  userRole?: string;
  canEdit?: boolean;
}

interface WorkflowStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  icon: React.ReactNode;
  isActive: boolean;
  canProgress: boolean;
}

interface BookingData {
  id: number;
  eventName: string;
  eventDate: string;
  eventType?: string;
  venueName?: string;
  venueDetails?: string;
  bookerName?: string;
  clientName?: string;
  status: string;
  price?: number;
  primaryArtist: any;
  assignedMusicians?: any[];
  assignedAdmin?: any;
  currentUserId?: number;
  technicalRider?: any;
  stagePlot?: any;
  mixerSettings?: any;
  contracts?: any[];
  payments: any[];
  signatures: any[];
}

export default function BookingWorkflow({ 
  bookingId, 
  onStatusChange, 
  userRole = 'admin',
  canEdit = true 
}: ComprehensiveBookingWorkflowProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(1);
  const [booking, setBooking] = useState<BookingData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [assignedTalent, setAssignedTalent] = useState<any[]>([]);
  const [talentReviewConfirmed, setTalentReviewConfirmed] = useState(false);
  const [stepConfirmations, setStepConfirmations] = useState<Record<number, boolean>>({});
  const [technicalConfirmed, setTechnicalConfirmed] = useState(false);
  
  // Modal states for technical rider components
  const [stagePlotModalOpen, setStagePlotModalOpen] = useState(false);
  const [mixerModalOpen, setMixerModalOpen] = useState(false);
  const [setlistModalOpen, setSetlistModalOpen] = useState(false);
  const [technicalRiderModalOpen, setTechnicalRiderModalOpen] = useState(false);

  // Define the new 6-step workflow as requested
  const workflowSteps: WorkflowStep[] = [
    {
      id: 'talent_assignment',
      title: 'Talent Assignment',
      description: 'Assign Artists, Musicians and Professionals to the booking',
      status: (booking?.assignedMusicians?.length || 0) > 0 ? 'completed' : currentStep === 1 ? 'in_progress' : 'pending',
      icon: <Users className="h-5 w-5" />,
      isActive: currentStep === 1,
      canProgress: talentReviewConfirmed
    },
    {
      id: 'contract_generation',
      title: 'Contract Generation',
      description: 'Generate booking agreements and performance contracts',
      status: (booking?.contracts?.length || 0) >= 2 ? 'completed' : currentStep === 2 ? 'in_progress' : 'pending',
      icon: <FileText className="h-5 w-5" />,
      isActive: currentStep === 2,
      canProgress: stepConfirmations[2] || false
    },
    {
      id: 'technical_rider',
      title: 'Technical Rider Creation',
      description: 'Create comprehensive technical requirements and stage plot',
      status: booking?.technicalRider && booking?.stagePlot ? 'completed' : currentStep === 3 ? 'in_progress' : 'pending',
      icon: <Settings className="h-5 w-5" />,
      isActive: currentStep === 3,
      canProgress: booking?.technicalRider && booking?.stagePlot
    },
    {
      id: 'signature_collection',
      title: 'Signature Collection',
      description: 'Collect signatures from all parties on contracts',
      status: (booking?.signatures?.length || 0) >= 2 ? 'completed' : currentStep === 4 ? 'in_progress' : 'pending',
      icon: <PenTool className="h-5 w-5" />,
      isActive: currentStep === 4,
      canProgress: (booking?.signatures?.length || 0) >= 2
    },
    {
      id: 'payment_processing',
      title: 'Payment Processing',
      description: 'Process payments and generate receipts',
      status: (booking?.payments?.length || 0) > 0 ? 'completed' : currentStep === 5 ? 'in_progress' : 'pending',
      icon: <CreditCard className="h-5 w-5" />,
      isActive: currentStep === 5,
      canProgress: (booking?.payments?.length || 0) > 0
    },
    {
      id: 'feedback',
      title: 'Feedback (Optional)',
      description: 'AI career enhancement feedback for managed talent',
      status: booking?.status === 'completed' ? 'completed' : currentStep === 6 ? 'in_progress' : 'pending',
      icon: <Star className="h-5 w-5" />,
      isActive: currentStep === 6,
      canProgress: true
    }
  ];

  // Load booking data
  const { data: bookingData, isLoading: bookingLoading } = useQuery({
    queryKey: ['booking-workflow', bookingId],
    queryFn: async () => {
      const response = await apiRequest(`/api/bookings/${bookingId}/workflow`);
      if (!response.ok) throw new Error('Failed to load booking data');
      return response.json();
    },
    enabled: !!bookingId
  });

  // Load all bookings for selection
  const { data: availableBookings = [] } = useQuery({
    queryKey: ['available-bookings'],
    queryFn: async () => {
      const response = await apiRequest('/api/bookings/all');
      if (!response.ok) throw new Error('Failed to load bookings');
      return response.json();
    }
  });

  // Load available users for assignment
  const { data: availableUsers = [] } = useQuery({
    queryKey: ['available-users'],
    queryFn: async () => {
      const response = await apiRequest('/api/users');
      if (!response.ok) throw new Error('Failed to load users');
      return response.json();
    }
  });

  // Load specific user types for assignment
  const { data: availableArtists = [] } = useQuery({
    queryKey: ['/api/artists'],
  });

  const { data: availableMusicians = [] } = useQuery({
    queryKey: ['/api/musicians'],
  });

  const { data: availableProfessionals = [] } = useQuery({
    queryKey: ['/api/professionals'],
  });

  useEffect(() => {
    if (bookingData) {
      setBooking(bookingData);
      setIsLoading(false);
      
      // Add the primary artist to assigned talent if not already there
      if (bookingData.primaryArtist && assignedTalent.length === 0) {
        const primaryTalent = {
          id: `primary-${bookingData.primaryArtist.userId || bookingData.primaryArtist.id}`,
          userId: bookingData.primaryArtist.userId || bookingData.primaryArtist.id,
          name: bookingData.primaryArtist.stageName || bookingData.primaryArtist.fullName,
          type: bookingData.primaryArtist.isManaged ? 'Managed Artist' : 'Artist',
          role: 'Main Booked Talent',
          avatarUrl: bookingData.primaryArtist.profile?.avatarUrl || bookingData.primaryArtist.avatarUrl,
          genre: bookingData.primaryArtist.genre,
          isPrimary: true
        };
        setAssignedTalent([primaryTalent]);
      }
    }
  }, [bookingData]);

  const updateBookingMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest(`/api/bookings/${bookingId}`, {
        method: 'PATCH',
        body: data
      });
      if (!response.ok) throw new Error('Failed to update booking');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['booking-workflow', bookingId] });
      toast({ title: "Success", description: "Booking updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update booking", variant: "destructive" });
    }
  });

  const sendWorkflowNotification = async (type: string, additionalData?: any) => {
    try {
      await apiRequest(`/api/bookings/${bookingId}/workflow/notify`, {
        method: 'POST',
        body: {
          type,
          recipients: ['admin@waitumusic.com'],
          ...additionalData
        }
      });
    } catch (error) {
      console.error('Failed to send workflow notification:', error);
    }
  };

  // Save workflow data function
  const saveWorkflow = async () => {
    setSaving(true);
    try {
      const workflowData = {
        currentStep,
        assignedTalent,
        stagePlot,
        mixerConfig,
        setlist,
        technicalStep,
        selectedTemplate,
        stepConfirmations,
        talentReviewConfirmed
      };

      const response = await apiRequest(`/api/bookings/${bookingId}/workflow/save`, {
        method: 'POST',
        body: { workflowData }
      });

      if (!response.ok) throw new Error('Failed to save workflow');

      toast({ 
        title: "Workflow Saved", 
        description: "All workflow data has been saved successfully" 
      });
    } catch (error) {
      console.error('Save workflow error:', error);
      toast({ 
        title: "Save Failed", 
        description: "Failed to save workflow data", 
        variant: "destructive" 
      });
    } finally {
      setSaving(false);
    }
  };

  // Generate PDF function
  const generatePDF = async () => {
    try {
      // Create a link that navigates to the PDF endpoint directly for download
      const token = localStorage.getItem('token');
      const url = `/api/bookings/${bookingId}/workflow/pdf`;
      
      // Create a temporary link with authentication headers
      const response = await fetch(url, {
        method: 'GET', 
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) throw new Error('Failed to generate PDF');

      // Get the PDF as blob
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      
      // Create download link
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `booking-workflow-${bookingId}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Clean up
      window.URL.revokeObjectURL(downloadUrl);

      toast({ 
        title: "PDF Generated", 
        description: "Comprehensive booking workflow PDF has been downloaded" 
      });
    } catch (error) {
      console.error('Generate PDF error:', error);
      toast({ 
        title: "PDF Generation Failed", 
        description: "Failed to generate workflow PDF", 
        variant: "destructive" 
      });
    }
  };

  const progressToNextStep = async () => {
    // Check if current step has required confirmation
    const currentStepInfo = workflowSteps[currentStep - 1];
    const requiresConfirmation = currentStep === 2 || currentStep === 3; // Contract Generation and Technical Rider require confirmation
    
    if (currentStep === 2 && !stepConfirmations[currentStep]) {
      toast({ 
        title: "Confirmation Required", 
        description: "Please review and confirm the contract terms before proceeding",
        variant: "destructive"
      });
      return;
    }
    
    if (currentStep === 3 && !technicalConfirmed) {
      toast({ 
        title: "Technical Rider Confirmation Required", 
        description: "Please review and confirm all technical requirements before proceeding",
        variant: "destructive"
      });
      return;
    }
    
    if (currentStep < 6) {
      const newStep = currentStep + 1;
      const stepInfo = workflowSteps[newStep - 1];
      
      setCurrentStep(newStep);
      toast({ 
        title: "Progress", 
        description: `Moved to step ${newStep}: ${stepInfo.title}` 
      });

      // Send email notification for step completion
      await sendWorkflowNotification('step_completed', {
        step: currentStep,
        stepName: currentStepInfo.title,
        progress: Math.round((currentStep / 6) * 100)
      });
    }
  };

  const goToPreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  // Handle navigation step click with role-based permissions
  const handleStepClick = (stepNumber: number) => {
    // Superadmins can jump to any step
    if (userRole === 'superadmin') {
      setCurrentStep(stepNumber);
      toast({ 
        title: "Navigation", 
        description: `Jumped to step ${stepNumber}: ${workflowSteps[stepNumber - 1]?.title}` 
      });
      return;
    }

    // Admins and assigned admins can only jump to steps after completing Technical Rider (step 3)
    if ((userRole === 'admin' || userRole === 'assigned_admin') && technicalConfirmed) {
      setCurrentStep(stepNumber);
      toast({ 
        title: "Navigation", 
        description: `Jumped to step ${stepNumber}: ${workflowSteps[stepNumber - 1]?.title}` 
      });
      return;
    }

    // For other users or if technical rider not completed, only allow backward navigation or current step
    if (stepNumber <= currentStep) {
      setCurrentStep(stepNumber);
    } else {
      toast({
        title: "Navigation Restricted",
        description: userRole === 'admin' || userRole === 'assigned_admin' 
          ? "Complete the Technical Rider section first to enable step navigation"
          : "You can only navigate to previous or current steps",
        variant: "destructive"
      });
    }
  };

  const getProgressPercentage = () => {
    const completedSteps = workflowSteps.filter(step => step.status === 'completed').length;
    return (completedSteps / workflowSteps.length) * 100;
  };

  // Step 1: Booking Selection
  const renderBookingSelection = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Current Booking</CardTitle>
          </CardHeader>
          <CardContent>
            {booking ? (
              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium">Event Name</Label>
                  <p className="text-lg">{booking.eventName}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Date</Label>
                  <p>{new Date(booking.eventDate).toLocaleDateString()}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Status</Label>
                  <Badge variant="outline">{booking.status}</Badge>
                </div>
                <div>
                  <Label className="text-sm font-medium">Primary Artist</Label>
                  <p>{booking.primaryArtist?.stageName || 'Not assigned'}</p>
                </div>
              </div>
            ) : (
              <p className="text-muted-foreground">No booking selected</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Available Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {availableBookings.map((bkg: any) => (
                <div key={bkg.id} className={`p-3 border rounded cursor-pointer transition-colors ${
                  bkg.id === bookingId ? 'bg-primary/10 border-primary' : 'hover:bg-muted'
                }`}>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">{bkg.eventName}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(bkg.eventDate).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant="outline">{bkg.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  // Step 2: Talent Assignment
  const renderTalentAssignment = () => {
    // Categorize available talent with priority order
    const categorizedTalent = {
      managedArtists: Array.isArray(availableArtists) ? availableArtists.filter((artist: any) => artist.isManaged) : [],
      artists: Array.isArray(availableArtists) ? availableArtists.filter((artist: any) => !artist.isManaged) : [],
      managedMusicians: Array.isArray(availableMusicians) ? availableMusicians.filter((musician: any) => musician.isManaged) : [],
      musicians: Array.isArray(availableMusicians) ? availableMusicians.filter((musician: any) => !musician.isManaged) : [],
      performanceProfessionals: Array.isArray(availableProfessionals) ? availableProfessionals.filter((prof: any) => 
        prof.services?.some((service: string) => 
          service.includes('Performance') || service.includes('Live') || service.includes('Stage')
        )
      ) : [],
      otherProfessionals: Array.isArray(availableProfessionals) ? availableProfessionals.filter((prof: any) => 
        !prof.services?.some((service: string) => 
          service.includes('Performance') || service.includes('Live') || service.includes('Stage')
        )
      ) : []
    };

    return (
      <div className="space-y-6">
        {/* Main Booked Talent */}
        {booking && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Main Booked Talent
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4 p-4 border rounded bg-gradient-to-r from-emerald-50 to-cyan-50">
                <Avatar className="w-16 h-16 border-2 border-emerald-500">
                  <AvatarImage src={booking.primaryArtist?.profile?.avatarUrl || booking.primaryArtist?.avatarUrl} />
                  <AvatarFallback className="bg-emerald-500 text-white text-xl font-bold">
                    {booking.primaryArtist?.stageName?.[0] || booking.primaryArtist?.fullName?.[0] || 'P'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-emerald-800">
                    {booking.primaryArtist?.stageName || booking.primaryArtist?.fullName || 'Primary Talent'}
                  </h3>
                  <p className="text-emerald-600 font-medium">
                    {booking.primaryArtist?.isManaged ? 'Managed ' : ''}{booking.primaryArtist?.userType || 'Artist'}
                  </p>
                  <p className="text-sm text-gray-600 mt-1">
                    Event: {booking.eventName} • {booking.eventDate ? new Date(booking.eventDate).toLocaleDateString() : 'Date TBD'}
                  </p>
                  <Badge variant="default" className="mt-2 bg-emerald-600">
                    Main Booked Talent
                  </Badge>
                </div>
                <div className="text-right">
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant={booking.status === 'approved' ? 'default' : 'secondary'}>
                      {booking.status || 'pending'}
                    </Badge>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="border-green-500 text-green-700 hover:bg-green-50"
                        onClick={async () => {
                          try {
                            await updateBookingMutation.mutateAsync({
                              status: 'accepted',
                              primaryArtistAccepted: true
                            });
                            toast({ title: "Booking Accepted", description: "The booking has been accepted by the primary artist" });
                          } catch (error) {
                            toast({ title: "Error", description: "Failed to accept booking", variant: "destructive" });
                          }
                        }}>
                        Accept Booking
                      </Button>
                      <Button variant="outline" size="sm" className="border-red-500 text-red-700 hover:bg-red-50"
                        onClick={async () => {
                          try {
                            await updateBookingMutation.mutateAsync({
                              status: 'declined',
                              primaryArtistAccepted: false
                            });
                            toast({ title: "Booking Declined", description: "The booking has been declined by the primary artist" });
                          } catch (error) {
                            toast({ title: "Error", description: "Failed to decline booking", variant: "destructive" });
                          }
                        }}>
                        Decline Booking
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Assigned Talent */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Assigned Talent
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {assignedTalent.length > 0 ? (
                assignedTalent.map((talent: any) => (
                  <div key={talent.id} className="flex items-center justify-between p-3 border rounded bg-blue-50">
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarImage src={talent.avatarUrl} />
                        <AvatarFallback className="bg-blue-500 text-white">
                          {talent.name?.[0] || 'T'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium">{talent.name || 'No name'}</p>
                        <p className="text-sm text-muted-foreground">{talent.type || 'No type'} • {talent.genre || talent.role || 'No role'}</p>
                        {/* Performance Professional Rate Field */}
                        {talent.type === 'Performance Professional' && (
                          <div className="mt-2 flex items-center gap-2">
                            <Label htmlFor={`rate-${talent.id}`} className="text-xs">Rate:</Label>
                            <Input
                              id={`rate-${talent.id}`}
                              type="number"
                              placeholder="$0.00"
                              className="w-24 h-6 text-xs"
                              defaultValue={talent.rate || ''}
                              onChange={(e) => {
                                const updatedTalent = assignedTalent.map(t => 
                                  t.id === talent.id ? { ...t, rate: e.target.value } : t
                                );
                                setAssignedTalent(updatedTalent);
                              }}
                            />
                            <span className="text-xs text-muted-foreground">per hour</span>
                          </div>
                        )}
                      </div>
                    </div>
                    {talent.isPrimary ? (
                      <div className="flex flex-col items-end gap-1">
                        <Badge variant="outline" className="border-emerald-500 text-emerald-700 bg-emerald-50">
                          Main Booked Talent
                        </Badge>
                        <div className="flex gap-1">
                          <Button variant="outline" size="sm" className="border-green-500 text-green-700 hover:bg-green-50 text-xs px-2 py-1">
                            Accept
                          </Button>
                          <Button variant="outline" size="sm" className="border-red-500 text-red-700 hover:bg-red-50 text-xs px-2 py-1">
                            Decline
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="border-red-300 text-red-600 hover:bg-red-50"
                        onClick={() => {
                          setAssignedTalent(assignedTalent.filter(t => t.id !== talent.id));
                          toast({ title: "Unassigned", description: `${talent.name} removed from booking` });
                        }}
                      >
                        Remove
                      </Button>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground text-center py-8">No talent assigned yet</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Available Talent */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5" />
              Available Talent
              <Badge variant="outline" className="ml-auto">Admin Access Only</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Managed Artists (Priority 1) */}
              {categorizedTalent.managedArtists.length > 0 && (
                <div>
                  <h4 className="font-semibold text-sm text-emerald-700 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <Crown className="w-4 h-4 text-emerald-600" />
                    Managed Artists
                  </h4>
                  <div className="space-y-2">
                    {categorizedTalent.managedArtists.map((artist: any) => (
                      <div key={artist.userId} className="flex items-center justify-between p-3 border rounded bg-emerald-50">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={artist.profile?.avatarUrl} />
                            <AvatarFallback className="bg-emerald-500 text-white">
                              {artist.stageName?.[0] || artist.user?.fullName?.[0] || 'A'}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{artist.stageName || artist.user?.fullName}</p>
                            <p className="text-sm text-muted-foreground">Managed Artist • {artist.genre || 'Various'}</p>
                          </div>
                        </div>
                        {assignedTalent.some(t => t.userId === artist.userId) ? (
                          <Badge variant="secondary">Already Assigned</Badge>
                        ) : (
                          <Button variant="outline" size="sm" className="border-emerald-300 hover:bg-emerald-100"
                            onClick={() => {
                              const isMainBookedTalent = assignedTalent.length === 0; // First assigned becomes Main Booked Talent
                              const newAssignment = {
                                id: Date.now(),
                                userId: artist.userId,
                                name: artist.stageName || artist.user?.fullName,
                                type: isMainBookedTalent ? 'Main Booked Talent' : 'Managed Artist',
                                role: 'Artist',
                                avatarUrl: artist.profile?.avatarUrl,
                                genre: artist.genre,
                                isPrimary: isMainBookedTalent,
                                isMainBookedTalent: isMainBookedTalent
                              };
                              setAssignedTalent([...assignedTalent, newAssignment]);
                              toast({ 
                                title: "Assignment", 
                                description: `${artist.stageName || artist.user?.fullName} assigned as ${isMainBookedTalent ? 'Main Booked Talent' : 'Supporting Talent'}` 
                              });
                            }}>
                            Assign
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Artists */}
              {categorizedTalent.artists.length > 0 && (
                <div>
                  <h4 className="font-semibold text-sm text-blue-700 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <Music className="w-4 h-4 text-blue-600" />
                    Artists
                  </h4>
                  <div className="space-y-2">
                    {categorizedTalent.artists.map((artist: any) => (
                      <div key={artist.userId} className="flex items-center justify-between p-3 border rounded">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={artist.profile?.avatarUrl} />
                            <AvatarFallback className="bg-blue-500 text-white">
                              {artist.stageName?.[0] || artist.user?.fullName?.[0] || 'A'}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{artist.stageName || artist.user?.fullName}</p>
                            <p className="text-sm text-muted-foreground">Artist • {artist.genre || 'Various'}</p>
                          </div>
                        </div>
                        {assignedTalent.some(t => t.userId === artist.userId) ? (
                          <Badge variant="secondary">Already Assigned</Badge>
                        ) : (
                          <Button variant="outline" size="sm"
                            onClick={() => {
                              const isMainBookedTalent = assignedTalent.length === 0; // First assigned becomes Main Booked Talent
                              const newAssignment = {
                                id: Date.now(),
                                userId: artist.userId,
                                name: artist.stageName || artist.user?.fullName,
                                type: isMainBookedTalent ? 'Main Booked Talent' : 'Artist',
                                role: 'Artist',
                                avatarUrl: artist.profile?.avatarUrl,
                                genre: artist.genre,
                                isPrimary: isMainBookedTalent,
                                isMainBookedTalent: isMainBookedTalent
                              };
                              setAssignedTalent([...assignedTalent, newAssignment]);
                              toast({ 
                                title: "Assignment", 
                                description: `${artist.stageName || artist.user?.fullName} assigned as ${isMainBookedTalent ? 'Main Booked Talent' : 'Supporting Talent'}` 
                              });
                            }}>
                            Assign
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Managed Musicians (Priority 2) */}
              {categorizedTalent.managedMusicians.length > 0 && (
                <div>
                  <h4 className="font-semibold text-sm text-purple-700 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <Crown className="w-4 h-4 text-purple-600" />
                    Managed Musicians
                  </h4>
                  <div className="space-y-2">
                    {categorizedTalent.managedMusicians.map((musician: any) => (
                      <div key={musician.userId} className="flex items-center justify-between p-3 border rounded bg-purple-50">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={musician.profile?.avatarUrl} />
                            <AvatarFallback className="bg-purple-500 text-white">
                              {musician.stageName?.[0] || musician.user?.fullName?.[0] || 'M'}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{musician.stageName || musician.user?.fullName}</p>
                            <p className="text-sm text-muted-foreground">Managed Musician • {musician.primaryInstrument || 'Multi-instrumentalist'}</p>
                          </div>
                        </div>
                        {assignedTalent.some(t => t.userId === musician.userId) ? (
                          <Badge variant="secondary">Already Assigned</Badge>
                        ) : (
                          <Button variant="outline" size="sm" className="border-purple-300 hover:bg-purple-100"
                            onClick={() => {
                              const isMainBookedTalent = assignedTalent.length === 0; // First assigned becomes Main Booked Talent
                              const newAssignment = {
                                id: Date.now(),
                                userId: musician.userId,
                                name: musician.stageName || musician.user?.fullName,
                                type: isMainBookedTalent ? 'Main Booked Talent' : 'Managed Musician',
                                role: musician.primaryInstrument || 'Musician',
                                avatarUrl: musician.profile?.avatarUrl,
                                isPrimary: isMainBookedTalent,
                                isMainBookedTalent: isMainBookedTalent
                              };
                              setAssignedTalent([...assignedTalent, newAssignment]);
                              toast({ 
                                title: "Assignment", 
                                description: `${musician.stageName || musician.user?.fullName} assigned as ${isMainBookedTalent ? 'Main Booked Talent' : 'Supporting Talent'}` 
                              });
                            }}>
                            Assign
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Musicians */}
              {categorizedTalent.musicians.length > 0 && (
                <div>
                  <h4 className="font-semibold text-sm text-indigo-700 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <Guitar className="w-4 h-4 text-indigo-600" />
                    Musicians
                  </h4>
                  <div className="space-y-2">
                    {categorizedTalent.musicians.map((musician: any) => (
                      <div key={musician.userId} className="flex items-center justify-between p-3 border rounded">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={musician.profile?.avatarUrl} />
                            <AvatarFallback className="bg-indigo-500 text-white">
                              {musician.stageName?.[0] || musician.user?.fullName?.[0] || 'M'}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{musician.stageName || musician.user?.fullName}</p>
                            <p className="text-sm text-muted-foreground">Musician • {musician.primaryInstrument || 'Multi-instrumentalist'}</p>
                          </div>
                        </div>
                        {assignedTalent.some(t => t.userId === musician.userId) ? (
                          <Badge variant="secondary">Already Assigned</Badge>
                        ) : (
                          <Button variant="outline" size="sm"
                            onClick={() => {
                              const isMainBookedTalent = assignedTalent.length === 0; // First assigned becomes Main Booked Talent
                              const newAssignment = {
                                id: Date.now(),
                                userId: musician.userId,
                                name: musician.stageName || musician.user?.fullName,
                                type: isMainBookedTalent ? 'Main Booked Talent' : 'Musician',
                                role: musician.primaryInstrument || 'Musician',
                                avatarUrl: musician.profile?.avatarUrl,
                                isPrimary: isMainBookedTalent,
                                isMainBookedTalent: isMainBookedTalent
                              };
                              setAssignedTalent([...assignedTalent, newAssignment]);
                              toast({ 
                                title: "Assignment", 
                                description: `${musician.stageName || musician.user?.fullName} assigned as ${isMainBookedTalent ? 'Main Booked Talent' : 'Supporting Talent'}` 
                              });
                            }}>
                            Assign
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Performance Professionals (Priority) */}
              {categorizedTalent.performanceProfessionals.length > 0 && (
                <div>
                  <h4 className="font-semibold text-sm text-orange-700 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <Star className="w-4 h-4 text-orange-600" />
                    Performance Professionals
                  </h4>
                  <div className="space-y-2">
                    {categorizedTalent.performanceProfessionals.map((professional: any) => (
                      <div key={professional.userId} className="flex items-center justify-between p-3 border rounded bg-orange-50">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={professional.profile?.avatarUrl} />
                            <AvatarFallback className="bg-orange-500 text-white">
                              {professional.stageName?.[0] || professional.user?.fullName?.[0] || 'P'}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{professional.stageName || professional.user?.fullName}</p>
                            <p className="text-sm text-muted-foreground">Performance Professional • {professional.primarySpecialization || 'Various Services'}</p>
                          </div>
                        </div>
                        {assignedTalent.some(t => t.userId === professional.userId) ? (
                          <Badge variant="secondary">Already Assigned</Badge>
                        ) : (
                          <Button variant="outline" size="sm" className="border-orange-300 hover:bg-orange-100"
                            onClick={() => {
                              const isMainBookedTalent = assignedTalent.length === 0; // First assigned becomes Main Booked Talent
                              const newAssignment = {
                                id: Date.now(),
                                userId: professional.userId,
                                name: professional.stageName || professional.user?.fullName,
                                type: isMainBookedTalent ? 'Main Booked Talent' : 'Performance Professional',
                                role: professional.primarySpecialization || 'Performance Professional',
                                avatarUrl: professional.profile?.avatarUrl,
                                isPrimary: isMainBookedTalent,
                                isMainBookedTalent: isMainBookedTalent,
                                rate: '' // Initialize rate field for performance professionals
                              };
                              setAssignedTalent([...assignedTalent, newAssignment]);
                              toast({ 
                                title: "Assignment", 
                                description: `${professional.stageName || professional.user?.fullName} assigned as ${isMainBookedTalent ? 'Main Booked Talent' : 'Supporting Talent'}` 
                              });
                            }}>
                            Assign
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Other Professionals */}
              {categorizedTalent.otherProfessionals.length > 0 && (
                <div>
                  <h4 className="font-semibold text-sm text-gray-700 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-gray-600" />
                    Other Professionals
                  </h4>
                  <div className="space-y-2">
                    {categorizedTalent.otherProfessionals.map((professional: any) => (
                      <div key={professional.userId} className="flex items-center justify-between p-3 border rounded">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={professional.profile?.avatarUrl} />
                            <AvatarFallback className="bg-gray-500 text-white">
                              {professional.stageName?.[0] || professional.user?.fullName?.[0] || 'P'}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{professional.stageName || professional.user?.fullName}</p>
                            <p className="text-sm text-muted-foreground">Professional ({professional.primarySpecialization || 'General'}) • {professional.services?.join(', ') || 'Various Services'}</p>
                          </div>
                        </div>
                        {assignedTalent.some(t => t.userId === professional.userId) ? (
                          <Badge variant="secondary">Already Assigned</Badge>
                        ) : (
                          <Button variant="outline" size="sm"
                            onClick={() => {
                              const isMainBookedTalent = assignedTalent.length === 0; // First assigned becomes Main Booked Talent
                              const newAssignment = {
                                id: Date.now(),
                                userId: professional.userId,
                                name: professional.stageName || professional.user?.fullName,
                                type: isMainBookedTalent ? 'Main Booked Talent' : 'Professional',
                                role: professional.primarySpecialization || 'Professional',
                                avatarUrl: professional.profile?.avatarUrl,
                                isPrimary: isMainBookedTalent,
                                isMainBookedTalent: isMainBookedTalent
                              };
                              setAssignedTalent([...assignedTalent, newAssignment]);
                              toast({ 
                                title: "Assignment", 
                                description: `${professional.stageName || professional.user?.fullName} assigned as ${isMainBookedTalent ? 'Main Booked Talent' : 'Supporting Talent'}` 
                              });
                            }}>
                            Assign
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Loading states */}
              {(!availableArtists || !availableMusicians || !availableProfessionals) && (
                <div className="text-center py-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto mb-2"></div>
                  <p className="text-muted-foreground">Loading available talent...</p>
                </div>
              )}

              {/* No talent available */}
              {(Array.isArray(availableArtists) ? availableArtists.length : 0) === 0 && 
               (Array.isArray(availableMusicians) ? availableMusicians.length : 0) === 0 && 
               (Array.isArray(availableProfessionals) ? availableProfessionals.length : 0) === 0 && (
                <p className="text-muted-foreground text-center py-4">No talent available for assignment</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Talent Review Confirmation */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="talent-review-confirm"
                checked={talentReviewConfirmed}
                onCheckedChange={(checked) => setTalentReviewConfirmed(checked === true)}
              />
              <label htmlFor="talent-review-confirm" className="text-sm font-medium text-gray-700">
                I have reviewed the talent assignments and confirm they are ready for the next step
              </label>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Check this box to enable the Next button and proceed to technical setup.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Step 2: Enhanced Contract Generation with Category-Based Pricing
  const [contractPreview, setContractPreview] = useState<{
    bookingAgreement: string | null;
    performanceContract: string | null;
  }>({
    bookingAgreement: null,
    performanceContract: null
  });
  
  const [contractConfig, setContractConfig] = useState({
    counterOfferDeadline: '',
    paymentTerms: '50% deposit, 50% on completion',
    cancellationPolicy: '72 hours notice required',
    additionalTerms: '',
    waituMusicPlatformName: 'Wai\'tuMusic',
    labelAddress: '123 Music Lane\nNashville, TN 37203\nUnited States',
    totalBookingPrice: 0
  });

  // Calculate dynamic total booking price based on category and individual pricing
  const calculateTotalBookingPrice = () => {
    return assignedTalent.reduce((total, talent) => {
      // Main Booked Talent has special priority - only individual overrides apply
      if (talent.isMainBookedTalent) {
        return total + (individualPricing[talent.id]?.price || categoryPricing['Main Booked Talent'] || 0);
      }
      // For other talent, individual pricing overrides category pricing
      return total + (individualPricing[talent.id]?.price || categoryPricing[talent.type as keyof typeof categoryPricing] || 0);
    }, 0);
  };

  // Get assigned talent categories for readonly logic
  const getAssignedCategories = () => {
    const categories = new Set<string>();
    assignedTalent.forEach(talent => {
      if (talent.isMainBookedTalent) {
        categories.add('Main Booked Talent');
      } else {
        categories.add(talent.type);
      }
    });
    return categories;
  };

  // Category-based pricing for talent types with Main Booked Talent priority
  const [categoryPricing, setCategoryPricing] = useState({
    'Main Booked Talent': 0,
    'Managed Artist': 0,
    'Managed Musician': 0,
    'Managed Professional': 0,
    'Artist': 0,
    'Musician': 0,
    'Professional': 0
  });

  // Individual talent pricing overrides
  const [individualPricing, setIndividualPricing] = useState<Record<string, {
    price: number;
    counterOfferDeadline: string;
    paymentTerms: string;
    cancellationPolicy: string;
    additionalTerms: string;
  }>>({});

  const [counterOffer, setCounterOffer] = useState({
    received: false,
    amount: 0,
    deadline: '',
    notes: ''
  });

  const generateContractPreview = async (type: 'booking' | 'performance') => {
    try {
      // Enhanced preview data with category-based and individual pricing
      const previewData = {
        assignedTalent: assignedTalent.map(talent => ({
          ...talent,
          individualPrice: individualPricing[talent.id]?.price || categoryPricing[talent.type as keyof typeof categoryPricing] || 0,
          paymentTerms: individualPricing[talent.id]?.paymentTerms || contractConfig.paymentTerms,
          cancellationPolicy: individualPricing[talent.id]?.cancellationPolicy || contractConfig.cancellationPolicy,
          additionalTerms: individualPricing[talent.id]?.additionalTerms || '',
          counterOfferDeadline: individualPricing[talent.id]?.counterOfferDeadline || contractConfig.counterOfferDeadline
        })),
        contractConfig: {
          ...contractConfig,
          categoryPricing,
          totalTalentCost: assignedTalent.reduce((total, talent) => {
            const talentPrice = individualPricing[talent.id]?.price || categoryPricing[talent.type as keyof typeof categoryPricing] || 0;
            return total + talentPrice;
          }, 0),
          // Ensure platform name is included in contract generation
          platformName: contractConfig.waituMusicPlatformName,
          labelAddress: contractConfig.labelAddress
        },
        counterOffer,
        booking: {
          ...booking,
          clientName: booking?.bookerName || booking?.clientName || '',
          eventName: booking?.eventName || '',
          eventDate: booking?.eventDate || '',
          venueName: booking?.venueName || booking?.venueDetails || 'TBD'
        },
        totalBookingPrice: contractConfig.totalBookingPrice || calculateTotalBookingPrice(),
        finalOfferPrice: contractConfig.totalBookingPrice || calculateTotalBookingPrice(),
        talentAskingPrice: calculateTotalBookingPrice()
      };

      const response = await apiRequest(`/api/bookings/${booking?.id}/${type}-agreement-preview`, {
        method: 'POST',
        body: previewData
      });
      
      if (response.ok) {
        const preview = await response.text();
        setContractPreview(prev => ({
          ...prev,
          [type === 'booking' ? 'bookingAgreement' : 'performanceContract']: preview
        }));
        toast({ 
          title: "Contract Preview Generated", 
          description: `${type === 'booking' ? 'Booking Agreement' : 'Performance Contract'} preview with enhanced pricing` 
        });
      }
    } catch (error) {
      console.error('Contract preview error:', error);
      toast({ 
        title: "Preview Error", 
        description: "Unable to generate contract preview",
        variant: "destructive"
      });
    }
  };

  const renderContractGeneration = () => {
    return (
      <div className="space-y-6">
        {/* Contract Configuration */}
        {/* Enhanced Contract Configuration with Category-Based Pricing */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Contract Configuration
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Configure contract terms, set category-based pricing, and customize individual talent terms
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Counter-Offer Deadline */}
            <div>
              <label className="text-sm font-medium">Counter-Offer Deadline</label>
              <input
                type="datetime-local"
                value={contractConfig.counterOfferDeadline}
                onChange={(e) => setContractConfig(prev => ({
                  ...prev,
                  counterOfferDeadline: e.target.value
                }))}
                className="w-full mt-1 p-2 border rounded"
              />
            </div>

            {/* Category-Based Pricing */}
            <div>
              <h4 className="text-lg font-medium mb-3 flex items-center gap-2">
                <div className="w-1 h-6 bg-gradient-to-b from-blue-500 to-indigo-600 rounded"></div>
                Category-Based Pricing
              </h4>
              <p className="text-sm text-muted-foreground mb-4">
                Set default asking prices for each talent category. Unassigned categories are readonly and set to zero.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(categoryPricing).map(([category, price]) => (
                  <div key={category} className={`p-3 rounded-lg border ${
                    getAssignedCategories().has(category) 
                      ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200' 
                      : 'bg-gradient-to-br from-gray-50 to-slate-50 border-gray-200'
                  }`}>
                    <label className={`text-sm font-medium flex items-center gap-2 ${
                      getAssignedCategories().has(category) ? 'text-green-800' : 'text-gray-600'
                    }`}>
                      <div className={`w-2 h-2 rounded-full ${
                        getAssignedCategories().has(category) ? 'bg-green-500' : 'bg-gray-400'
                      }`}></div>
                      {category}
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={price}
                      onChange={(e) => {
                        const value = Math.max(0, parseFloat(e.target.value) || 0);
                        setCategoryPricing(prev => ({
                          ...prev,
                          [category]: value
                        }));
                      }}
                      className={`w-full mt-2 p-2 border rounded ${
                        !getAssignedCategories().has(category) 
                          ? 'bg-gray-100 text-gray-500' 
                          : 'bg-white focus:ring-2 focus:ring-green-500 focus:border-transparent'
                      }`}
                      placeholder={getAssignedCategories().has(category) ? `${category} asking price` : '0'}
                      readOnly={!getAssignedCategories().has(category)}
                    />
                    {!getAssignedCategories().has(category) ? (
                      <p className="text-xs text-gray-500 mt-1">No talent assigned</p>
                    ) : (
                      <p className="text-xs text-green-600 mt-1">Active category</p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Individual Talent Overrides */}
            <div>
              <h4 className="text-lg font-medium mb-3">Individual Talent Pricing</h4>
              <p className="text-sm text-muted-foreground mb-4">
                Override category pricing and set individual terms for specific talent
              </p>
              <div className="space-y-4">
                {assignedTalent.map((talent) => (
                  <Card key={talent.id} className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={talent.avatarUrl} />
                        <AvatarFallback>{talent.name.split(' ').map((n: string) => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{talent.name}</p>
                        <p className="text-sm text-muted-foreground">{talent.type} - {talent.role}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Individual Price ($)</label>
                        <input
                          type="number"
                          min="0"
                          value={individualPricing[talent.id]?.price || categoryPricing[talent.type as keyof typeof categoryPricing] || 0}
                          onChange={(e) => {
                            const value = Math.max(0, parseFloat(e.target.value) || 0);
                            setIndividualPricing(prev => ({
                              ...prev,
                              [talent.id]: {
                                ...prev[talent.id],
                                price: value,
                                counterOfferDeadline: prev[talent.id]?.counterOfferDeadline || '',
                                paymentTerms: prev[talent.id]?.paymentTerms || '50% deposit, 50% on completion',
                                cancellationPolicy: prev[talent.id]?.cancellationPolicy || '72 hours notice required',
                                additionalTerms: prev[talent.id]?.additionalTerms || ''
                              }
                            }));
                          }}
                          className="w-full mt-1 p-2 border rounded"
                          placeholder="Individual rate"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Counter-Offer Deadline</label>
                        <input
                          type="datetime-local"
                          value={individualPricing[talent.id]?.counterOfferDeadline || ''}
                          onChange={(e) => setIndividualPricing(prev => ({
                            ...prev,
                            [talent.id]: {
                              ...prev[talent.id],
                              price: prev[talent.id]?.price || categoryPricing[talent.type as keyof typeof categoryPricing] || 0,
                              counterOfferDeadline: e.target.value,
                              paymentTerms: prev[talent.id]?.paymentTerms || '50% deposit, 50% on completion',
                              cancellationPolicy: prev[talent.id]?.cancellationPolicy || '72 hours notice required',
                              additionalTerms: prev[talent.id]?.additionalTerms || ''
                            }
                          }))}
                          className="w-full mt-1 p-2 border rounded"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Payment Terms</label>
                        <select
                          value={individualPricing[talent.id]?.paymentTerms || '50% deposit, 50% on completion'}
                          onChange={(e) => setIndividualPricing(prev => ({
                            ...prev,
                            [talent.id]: {
                              ...prev[talent.id],
                              price: prev[talent.id]?.price || categoryPricing[talent.type as keyof typeof categoryPricing] || 0,
                              counterOfferDeadline: prev[talent.id]?.counterOfferDeadline || '',
                              paymentTerms: e.target.value,
                              cancellationPolicy: prev[talent.id]?.cancellationPolicy || '72 hours notice required',
                              additionalTerms: prev[talent.id]?.additionalTerms || ''
                            }
                          }))}
                          className="w-full mt-1 p-2 border rounded"
                        >
                          <option value="50% deposit, 50% on completion">50% deposit, 50% on completion</option>
                          <option value="100% upfront">100% upfront</option>
                          <option value="Payment on completion">Payment on completion</option>
                          <option value="Net 30 terms">Net 30 terms</option>
                          <option value="Payment within 7 days">Payment within 7 days</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Cancellation Policy</label>
                        <select
                          value={individualPricing[talent.id]?.cancellationPolicy || '72 hours notice required'}
                          onChange={(e) => setIndividualPricing(prev => ({
                            ...prev,
                            [talent.id]: {
                              ...prev[talent.id],
                              price: prev[talent.id]?.price || categoryPricing[talent.type as keyof typeof categoryPricing] || 0,
                              counterOfferDeadline: prev[talent.id]?.counterOfferDeadline || '',
                              paymentTerms: prev[talent.id]?.paymentTerms || '50% deposit, 50% on completion',
                              cancellationPolicy: e.target.value,
                              additionalTerms: prev[talent.id]?.additionalTerms || ''
                            }
                          }))}
                          className="w-full mt-1 p-2 border rounded"
                        >
                          <option value="72 hours notice required">72 hours notice required</option>
                          <option value="7 days notice required">7 days notice required</option>
                          <option value="14 days notice required">14 days notice required</option>
                          <option value="30 days notice required">30 days notice required</option>
                          <option value="No cancellation allowed">No cancellation allowed</option>
                        </select>
                      </div>
                      <div className="md:col-span-2">
                        <label className="text-sm font-medium">Additional Terms for {talent.name}</label>
                        <textarea
                          value={individualPricing[talent.id]?.additionalTerms || ''}
                          onChange={(e) => setIndividualPricing(prev => ({
                            ...prev,
                            [talent.id]: {
                              ...prev[talent.id],
                              price: prev[talent.id]?.price || categoryPricing[talent.type as keyof typeof categoryPricing] || 0,
                              counterOfferDeadline: prev[talent.id]?.counterOfferDeadline || '',
                              paymentTerms: prev[talent.id]?.paymentTerms || '50% deposit, 50% on completion',
                              cancellationPolicy: prev[talent.id]?.cancellationPolicy || '72 hours notice required',
                              additionalTerms: e.target.value
                            }
                          }))}
                          rows={2}
                          className="w-full mt-1 p-2 border rounded"
                          placeholder="Special terms or requirements for this talent"
                        />
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Global Contract Terms */}
            <div>
              <h4 className="text-lg font-medium mb-3">Global Contract Terms</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium">Total Booking Price ($)</label>
                  <input
                    type="number"
                    min="0"
                    value={contractConfig.totalBookingPrice || calculateTotalBookingPrice()}
                    onChange={(e) => {
                      const value = Math.max(0, parseFloat(e.target.value) || 0);
                      setContractConfig(prev => ({
                        ...prev,
                        totalBookingPrice: value
                      }));
                    }}
                    className="w-full mt-1 p-2 border rounded font-semibold text-green-700 bg-green-50"
                    placeholder="Set final booking price"
                  />
                  {/* Enhanced Pricing Hint */}
                  <div className="mt-2 p-3 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <p className="text-sm font-medium text-blue-800">Pricing Breakdown</p>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-blue-700">Talent asking total:</span>
                        <span className="font-semibold text-blue-900">${calculateTotalBookingPrice()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-blue-700">Your offer/counter:</span>
                        <span className="font-semibold text-green-700">${contractConfig.totalBookingPrice || calculateTotalBookingPrice()}</span>
                      </div>
                      {counterOffer.received && (
                        <div className="flex justify-between border-t pt-1">
                          <span className="text-orange-700">Counter-offer received:</span>
                          <span className="font-semibold text-orange-900">${counterOffer.amount}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-gray-600 pt-1 border-t">
                        <span>Talent assigned:</span>
                        <span className="font-semibold">{assignedTalent.length}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-emerald-50 to-cyan-50 p-4 rounded-lg border border-emerald-200">
                  <label className="text-sm font-medium text-emerald-800 flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    Wai'tuMusic Platform Name
                  </label>
                  <input
                    type="text"
                    value={contractConfig.waituMusicPlatformName}
                    onChange={(e) => setContractConfig(prev => ({
                      ...prev,
                      waituMusicPlatformName: e.target.value
                    }))}
                    className="w-full mt-2 p-3 border border-emerald-300 rounded-lg bg-white focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="Platform name for contracts"
                  />
                  <p className="text-xs text-emerald-600 mt-1">Used in all generated contracts</p>
                </div>
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-4 rounded-lg border border-purple-200">
                  <label className="text-sm font-medium text-purple-800 flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    Label Address
                  </label>
                  <textarea
                    value={contractConfig.labelAddress}
                    onChange={(e) => setContractConfig(prev => ({
                      ...prev,
                      labelAddress: e.target.value
                    }))}
                    className="w-full mt-2 p-3 border border-purple-300 rounded-lg bg-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    rows={3}
                    placeholder="Complete address for inclusion in agreements"
                  />
                  <p className="text-xs text-purple-600 mt-1">Complete business address</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-4 rounded-lg border border-amber-200">
                  <label className="text-sm font-medium text-amber-800 flex items-center gap-2">
                    <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                    Payment Terms
                  </label>
                  <select
                    value={contractConfig.paymentTerms}
                    onChange={(e) => setContractConfig(prev => ({
                      ...prev,
                      paymentTerms: e.target.value
                    }))}
                    className="w-full mt-2 p-3 border border-amber-300 rounded-lg bg-white focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  >
                    <option value="50% deposit, 50% on completion">50% deposit, 50% on completion</option>
                    <option value="100% upfront">100% upfront</option>
                    <option value="Payment on completion">Payment on completion</option>
                    <option value="Net 30 terms">Net 30 terms</option>
                  </select>
                </div>
                <div className="bg-gradient-to-br from-red-50 to-pink-50 p-4 rounded-lg border border-red-200">
                  <label className="text-sm font-medium text-red-800 flex items-center gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    Cancellation Policy
                  </label>
                  <select
                    value={contractConfig.cancellationPolicy}
                    onChange={(e) => setContractConfig(prev => ({
                      ...prev,
                      cancellationPolicy: e.target.value
                    }))}
                    className="w-full mt-2 p-3 border border-red-300 rounded-lg bg-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  >
                    <option value="72 hours notice required">72 hours notice required</option>
                    <option value="7 days notice required">7 days notice required</option>
                    <option value="14 days notice required">14 days notice required</option>
                    <option value="No cancellation allowed">No cancellation allowed</option>
                  </select>
                </div>
              </div>
              <div className="mt-6 bg-gradient-to-br from-slate-50 to-gray-50 p-4 rounded-lg border border-slate-200">
                <label className="text-sm font-medium text-slate-800 flex items-center gap-2">
                  <div className="w-2 h-2 bg-slate-500 rounded-full"></div>
                  Additional Terms
                </label>
                <textarea
                  value={contractConfig.additionalTerms}
                  onChange={(e) => setContractConfig(prev => ({
                    ...prev,
                    additionalTerms: e.target.value
                  }))}
                  className="w-full mt-2 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                  rows={4}
                  placeholder="Enter any additional contract terms or special requirements"
                />
                <p className="text-xs text-slate-600 mt-1">Special clauses and custom requirements</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Counter-Offer Management */}
        <Card className="border-orange-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-700">
              <AlertTriangle className="h-5 w-5" />
              Counter-Offer Management
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Handle price negotiations from assigned talent
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {!counterOffer.received ? (
              <div className="text-center py-4">
                <p className="text-muted-foreground">No counter-offers received yet</p>
                <Button 
                  variant="outline" 
                  className="mt-2"
                  onClick={() => setCounterOffer(prev => ({ ...prev, received: true }))}
                >
                  Simulate Counter-Offer
                </Button>
              </div>
            ) : (
              <div className="space-y-4 bg-orange-50 p-4 rounded">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium">Counter-Offer Amount ($)</label>
                    <input
                      type="number"
                      min="0"
                      value={counterOffer.amount}
                      onChange={(e) => {
                        const value = Math.max(0, parseFloat(e.target.value) || 0);
                        setCounterOffer(prev => ({
                          ...prev,
                          amount: value
                        }));
                      }}
                      className="w-full mt-1 p-2 border rounded"
                      placeholder="Proposed amount"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Response Deadline</label>
                    <input
                      type="datetime-local"
                      value={counterOffer.deadline}
                      onChange={(e) => setCounterOffer(prev => ({
                        ...prev,
                        deadline: e.target.value
                      }))}
                      className="w-full mt-1 p-2 border rounded"
                    />
                  </div>
                  <div className="flex items-end gap-2">
                    <Button 
                      variant="default" 
                      className="bg-green-600 hover:bg-green-700"
                      onClick={() => {
                        setContractConfig(prev => ({ ...prev, proposedPrice: counterOffer.amount }));
                        toast({ title: "Counter-Offer Approved", description: "Contract price updated" });
                      }}
                    >
                      Approve
                    </Button>
                    <Button 
                      variant="destructive"
                      onClick={() => {
                        setCounterOffer({ received: false, amount: 0, deadline: '', notes: '' });
                        toast({ title: "Counter-Offer Declined", description: "Original terms maintained" });
                      }}
                    >
                      Decline
                    </Button>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Notes</label>
                  <textarea
                    value={counterOffer.notes}
                    onChange={(e) => setCounterOffer(prev => ({
                      ...prev,
                      notes: e.target.value
                    }))}
                    className="w-full mt-1 p-2 border rounded"
                    rows={2}
                    placeholder="Negotiation notes and reasoning"
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Contract Generation and Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Contract Generation & Preview
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Preview and Generate contracts before proceeding to signatures
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Button 
                  className="w-full flex items-center gap-2" 
                  onClick={() => generateContractPreview('booking')}
                  disabled={false}
                >
                  <FileText className="h-4 w-4" />
                  Preview Booking Agreement
                </Button>
                {contractPreview.bookingAgreement && (
                  <div className="p-3 bg-gray-50 rounded border max-h-40 overflow-y-auto">
                    <h4 className="font-medium text-sm mb-2">Booking Agreement Preview:</h4>
                    <div className="text-xs text-gray-700 whitespace-pre-line">
                      {contractPreview.bookingAgreement.substring(0, 500)}...
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="mt-2"
                      onClick={() => {
                        // Download full preview
                        const blob = new Blob([contractPreview.bookingAgreement!], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'booking-agreement-preview.txt';
                        a.click();
                        URL.revokeObjectURL(url);
                      }}
                    >
                      <Download className="h-3 w-3 mr-1" />
                      Download Full Preview
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="space-y-2">
                <Button 
                  className="w-full flex items-center gap-2" 
                  onClick={() => generateContractPreview('performance')}
                  disabled={assignedTalent.length === 0}
                >
                  <FileText className="h-4 w-4" />
                  Preview Performance Contracts
                </Button>
                {contractPreview.performanceContract && (
                  <div className="p-3 bg-gray-50 rounded border max-h-40 overflow-y-auto">
                    <h4 className="font-medium text-sm mb-2">Performance Contract Preview:</h4>
                    <div className="text-xs text-gray-700 whitespace-pre-line">
                      {contractPreview.performanceContract.substring(0, 500)}...
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="mt-2"
                      onClick={() => {
                        // Download full preview
                        const blob = new Blob([contractPreview.performanceContract!], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'performance-contract-preview.txt';
                        a.click();
                        URL.revokeObjectURL(url);
                      }}
                    >
                      <Download className="h-3 w-3 mr-1" />
                      Download Full Preview
                    </Button>
                  </div>
                )}
              </div>
            </div>

            {/* Contract Confirmation */}
            <div className="mt-6 p-4 bg-blue-50 rounded border border-blue-200">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  id="contractConfirmation"
                  className="mt-1"
                  checked={stepConfirmations[currentStep] || false}
                  onChange={(e) => setStepConfirmations((prev: Record<number, boolean>) => ({
                    ...prev,
                    [currentStep]: e.target.checked
                  }))}
                />
                <label htmlFor="contractConfirmation" className="text-sm">
                  <span className="font-medium">I confirm that:</span>
                  <ul className="mt-1 space-y-1 text-muted-foreground">
                    <li>• Contract terms and pricing have been reviewed and approved</li>
                    <li>• Counter-offers (if any) have been properly handled</li>
                    <li>• All assigned talent and contract previews are accurate</li>
                    <li>• Ready to proceed to Technical Rider Creation</li>
                  </ul>
                </label>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Step 3: Technical Rider Creation - Original Technical Rider Code with Templates
  const [technicalStep, setTechnicalStep] = useState(1);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [stagePlot, setStagePlot] = useState({
    stageWidth: 32,
    stageDepth: 24,
    performers: [
      { id: 1, name: 'Lead Vocals', position: { x: 16, y: 4 }, instrument: 'vocals', musician: '' },
      { id: 2, name: 'Guitar', position: { x: 8, y: 8 }, instrument: 'guitar', musician: '' },
      { id: 3, name: 'Bass', position: { x: 24, y: 8 }, instrument: 'bass', musician: '' },
      { id: 4, name: 'Drums', position: { x: 16, y: 16 }, instrument: 'drums', musician: '' },
      { id: 5, name: 'Keyboards', position: { x: 4, y: 12 }, instrument: 'keyboard', musician: '' }
    ],
    monitors: [
      { id: 1, position: { x: 14, y: 2 }, mix: 'Vocal Mix' },
      { id: 2, position: { x: 18, y: 2 }, mix: 'Vocal Mix' },
      { id: 3, position: { x: 6, y: 6 }, mix: 'Guitar Mix' },
      { id: 4, position: { x: 26, y: 6 }, mix: 'Bass Mix' },
      { id: 5, position: { x: 2, y: 10 }, mix: 'Keys Mix' }
    ],
    lighting: true,
    videoRecording: false,
    photographyArea: true,
    template: ''
  });

  const stageTemplates = {
    'solo-acoustic': {
      name: 'Solo Acoustic',
      performers: [
        { id: 1, name: 'Lead Vocals', position: { x: 16, y: 4 }, instrument: 'vocals', musician: '' },
        { id: 2, name: 'Acoustic Guitar', position: { x: 16, y: 8 }, instrument: 'guitar', musician: '' }
      ],
      monitors: [
        { id: 1, position: { x: 14, y: 2 }, mix: 'Vocal/Guitar Mix' },
        { id: 2, position: { x: 18, y: 2 }, mix: 'Vocal/Guitar Mix' }
      ]
    },
    'duo': {
      name: 'Duo Setup',
      performers: [
        { id: 1, name: 'Lead Vocals', position: { x: 12, y: 4 }, instrument: 'vocals', musician: '' },
        { id: 2, name: 'Guitar', position: { x: 8, y: 8 }, instrument: 'guitar', musician: '' },
        { id: 3, name: 'Keyboard/Vocals', position: { x: 20, y: 8 }, instrument: 'keyboard', musician: '' }
      ],
      monitors: [
        { id: 1, position: { x: 10, y: 2 }, mix: 'Vocal Mix' },
        { id: 2, position: { x: 18, y: 6 }, mix: 'Keys Mix' }
      ]
    },
    'full-band': {
      name: 'Full Band',
      performers: [
        { id: 1, name: 'Lead Vocals', position: { x: 16, y: 4 }, instrument: 'vocals', musician: '' },
        { id: 2, name: 'Guitar', position: { x: 8, y: 8 }, instrument: 'guitar', musician: '' },
        { id: 3, name: 'Bass', position: { x: 24, y: 8 }, instrument: 'bass', musician: '' },
        { id: 4, name: 'Drums', position: { x: 16, y: 16 }, instrument: 'drums', musician: '' },
        { id: 5, name: 'Keyboards', position: { x: 4, y: 12 }, instrument: 'keyboard', musician: '' }
      ],
      monitors: [
        { id: 1, position: { x: 14, y: 2 }, mix: 'Vocal Mix' },
        { id: 2, position: { x: 18, y: 2 }, mix: 'Vocal Mix' },
        { id: 3, position: { x: 6, y: 6 }, mix: 'Guitar Mix' },
        { id: 4, position: { x: 26, y: 6 }, mix: 'Bass Mix' },
        { id: 5, position: { x: 2, y: 10 }, mix: 'Keys Mix' }
      ]
    }
  };

  const [mixerConfig, setMixerConfig] = useState({
    inputs: [
      { channel: 1, source: 'Lead Vocal', mic: 'SM58', location: 'Center Stage', notes: 'Main vocal microphone', musician: '' },
      { channel: 2, source: 'Backup Vocal 1', mic: 'SM57', location: 'Stage Left', notes: 'Harmony vocals', musician: '' },
      { channel: 3, source: 'Backup Vocal 2', mic: 'SM57', location: 'Stage Right', notes: 'Harmony vocals', musician: '' },
      { channel: 4, source: 'Acoustic Guitar', mic: 'DI + SM81', location: 'Stage Left', notes: 'Direct input + condenser mic', musician: '' },
      { channel: 5, source: 'Electric Guitar', mic: 'SM57', location: 'Guitar Amp', notes: 'Close mic on amp', musician: '' },
      { channel: 6, source: 'Bass Guitar', mic: 'DI', location: 'Bass Amp', notes: 'Direct input from bass', musician: '' },
      { channel: 7, source: 'Kick Drum', mic: 'Beta 52', location: 'Drum Kit', notes: 'Inside kick drum', musician: '' },
      { channel: 8, source: 'Snare Drum', mic: 'SM57', location: 'Drum Kit', notes: 'Top of snare', musician: '' },
      { channel: 9, source: 'Hi-Hat', mic: 'SM81', location: 'Drum Kit', notes: 'Condenser mic above hi-hat', musician: '' },
      { channel: 10, source: 'Overhead L', mic: 'SM81', location: 'Drum Kit', notes: 'Left overhead cymbal mic', musician: '' },
      { channel: 11, source: 'Overhead R', mic: 'SM81', location: 'Drum Kit', notes: 'Right overhead cymbal mic', musician: '' },
      { channel: 12, source: 'Keyboard', mic: 'DI (Stereo)', location: 'Stage Left', notes: 'Stereo direct input', musician: '' }
    ],
    monitors: [
      { mix: 1, name: 'Lead Vocal Mix', sends: 'Vocal, Drums, Bass, Keys' },
      { mix: 2, name: 'Guitar Mix', sends: 'Guitar, Drums, Bass, Vocal' },
      { mix: 3, name: 'Bass Mix', sends: 'Bass, Drums, Vocal, Guitar' },
      { mix: 4, name: 'Drums Mix', sends: 'Drums, Bass, Guitar, Vocal' },
      { mix: 5, name: 'Keys Mix', sends: 'Keys, Vocal, Drums, Bass' }
    ],
    effects: [
      { name: 'Vocal Reverb', type: 'Hall Reverb', settings: 'Medium decay, warm tone' },
      { name: 'Vocal Delay', type: 'Digital Delay', settings: '1/8 note, 15% feedback' },
      { name: 'Drum Compression', type: 'Compressor', settings: 'Fast attack, medium release' },
      { name: 'Master EQ', type: 'Graphic EQ', settings: 'House curve adjustment' }
    ]
  });

  const [setlist, setSetlist] = useState({
    songs: [
      { id: 1, title: 'Opening Song', key: 'G', duration: '3:45', transition: 'Direct', notes: 'High energy opener, crowd interaction', chords: 'G-D-Em-C' },
      { id: 2, title: 'Fan Favorite #1', key: 'C', duration: '4:12', transition: 'Guitar intro', notes: 'Audience participation, clap along', chords: 'C-Am-F-G' },
      { id: 3, title: 'Ballad', key: 'Em', duration: '5:30', transition: 'Acoustic', notes: 'Stripped down, intimate moment', chords: 'Em-C-G-D' },
      { id: 4, title: 'Dance Track', key: 'A', duration: '3:55', transition: 'Build up', notes: 'Get the crowd moving, lights flash', chords: 'A-D-E-A' },
      { id: 5, title: 'Cover Song', key: 'D', duration: '4:20', transition: 'Medley', notes: 'Popular cover, sing-along moment', chords: 'D-A-Bm-G' },
      { id: 6, title: 'New Single', key: 'F', duration: '3:38', transition: 'Direct', notes: 'Promote new release, energy boost', chords: 'F-C-Dm-Bb' },
      { id: 7, title: 'Instrumental Break', key: 'Bb', duration: '2:45', transition: 'Solo intro', notes: 'Showcase musicians, guitar/drum solos', chords: 'Bb-F-Gm-Eb' },
      { id: 8, title: 'Emotional Peak', key: 'Am', duration: '4:55', transition: 'Slow build', notes: 'Powerful vocals, emotional connection', chords: 'Am-F-C-G' },
      { id: 9, title: 'Party Anthem', key: 'E', duration: '3:25', transition: 'Immediate', notes: 'High energy, crowd jumping', chords: 'E-A-B-E' },
      { id: 10, title: 'Regional Hit', key: 'G', duration: '4:05', transition: 'Call back', notes: 'Local crowd favorite, cultural moment', chords: 'G-Em-C-D' },
      { id: 11, title: 'Closing Song', key: 'C', duration: '5:15', transition: 'Epic build', notes: 'Big finish, confetti, thank you speech', chords: 'C-G-Am-F' }
    ],
    timing: {
      mainSet: '38:33',
      encore: '7:40',
      totalShow: '~54:00'
    },
    notes: 'Energy flow: High → Mixed → Emotional peak → Party finish. Include 2-3 crowd interaction moments.',
    specialRequirements: 'Confetti cannons for final song, backup wireless mics available, towels for performers'
  });

  // Chord progression generator
  const generateChords = (key: string) => {
    const chordProgressions = {
      'C': ['C-Am-F-G', 'C-F-G-C', 'Am-F-C-G'],
      'G': ['G-D-Em-C', 'G-C-D-G', 'Em-C-G-D'],
      'D': ['D-A-Bm-G', 'D-G-A-D', 'Bm-G-D-A'],
      'A': ['A-D-E-A', 'A-F#m-D-E', 'F#m-D-A-E'],
      'E': ['E-A-B-E', 'E-C#m-A-B', 'C#m-A-E-B'],
      'Em': ['Em-C-G-D', 'Em-Am-B-Em', 'C-G-Em-D'],
      'Am': ['Am-F-C-G', 'Am-Dm-G-Am', 'F-C-Am-G'],
      'F': ['F-C-Dm-Bb', 'F-Bb-C-F', 'Dm-Bb-F-C'],
      'Bb': ['Bb-F-Gm-Eb', 'Bb-Eb-F-Bb', 'Gm-Eb-Bb-F']
    };
    const progressions = chordProgressions[key as keyof typeof chordProgressions] || ['C-Am-F-G'];
    return progressions[Math.floor(Math.random() * progressions.length)];
  };

  const getInstrumentColor = (instrument: string) => {
    const colors = {
      vocals: '#FF6B6B',
      guitar: '#4ECDC4', 
      bass: '#45B7D1',
      drums: '#96CEB4',
      keyboard: '#FFEAA7'
    };
    return colors[instrument as keyof typeof colors] || '#DDD';
  };

  // Original Technical Rider Render Function with Templates and Musician Assignment
  const renderTechnicalRider = () => {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-semibold mb-2">Technical Rider Creation</h3>
            <p className="text-muted-foreground">Complete technical requirements with templates and musician assignments</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={saveWorkflow} disabled={saving}>
              {saving ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              {saving ? 'Saving...' : 'Save'}
            </Button>
            <Button variant="outline" size="sm" onClick={generatePDF}>
              <Download className="h-4 w-4 mr-2" />
              Generate PDF
            </Button>
          </div>
        </div>

        <Tabs value={technicalStep.toString()} onValueChange={(value) => setTechnicalStep(parseInt(value))}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="1">Stage Plot</TabsTrigger>
            <TabsTrigger value="2">Mixer & Patch</TabsTrigger>
            <TabsTrigger value="3">Setlist</TabsTrigger>
            <TabsTrigger value="4">Complete Rider</TabsTrigger>
          </TabsList>

          <TabsContent value="1" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Enhanced Stage Plot Designer
                </CardTitle>
                <CardDescription>
                  Access the advanced stage plot designer with movable drag-and-drop icons and talent assignments
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {/* Enhanced Stage Plot Designer */}
                    <Card className="border-dashed">
                      <CardContent className="p-4">
                        <div className="text-center space-y-2">
                          <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-lg mx-auto flex items-center justify-center">
                            <Settings className="h-6 w-6 text-white" />
                          </div>
                          <h4 className="font-semibold">Stage Plot Designer</h4>
                          <p className="text-sm text-muted-foreground">
                            Drag-and-drop movable icons, talent assignments, equipment management
                          </p>
                          <Button 
                            className="w-full" 
                            onClick={() => setStagePlotModalOpen(true)}
                          >
                            <Settings className="h-4 w-4 mr-2" />
                            Open Stage Plot
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Enhanced 32-Port Mixer */}
                    <Card className="border-dashed">
                      <CardContent className="p-4">
                        <div className="text-center space-y-2">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg mx-auto flex items-center justify-center">
                            <Volume2 className="h-6 w-6 text-white" />
                          </div>
                          <h4 className="font-semibold">Mixer & Patch</h4>
                          <p className="text-sm text-muted-foreground">
                            Professional mixer configuration with talent-to-channel assignments
                          </p>
                          <Button 
                            className="w-full" 
                            onClick={() => setMixerModalOpen(true)}
                          >
                            <Volume2 className="h-4 w-4 mr-2" />
                            Open Mixer & Patch
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Enhanced Setlist Manager */}
                    <Card className="border-dashed">
                      <CardContent className="p-4">
                        <div className="text-center space-y-2">
                          <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg mx-auto flex items-center justify-center">
                            <Music className="h-6 w-6 text-white" />
                          </div>
                          <h4 className="font-semibold">Setlist Manager</h4>
                          <p className="text-sm text-muted-foreground">
                            YouTube integration, AI optimization, chord chart generation
                          </p>
                          <Button 
                            className="w-full" 
                            onClick={() => setSetlistModalOpen(true)}
                          >
                            <Music className="h-4 w-4 mr-2" />
                            <span>Setlist Manager</span>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Complete System Access */}
                  <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="h-5 w-5 text-primary" />
                      <h4 className="font-semibold">Complete Enhanced Technical Rider System</h4>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Access the full enhanced technical rider designer with all three components integrated. 
                      All data is interconnected - stage plot assignments flow to mixer configuration and setlist management.
                    </p>
                    <Button 
                      size="lg" 
                      className="w-full md:w-auto"
                      onClick={() => setTechnicalRiderModalOpen(true)}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Open Complete Technical Rider Designer
                    </Button>
                  </div>

                  {/* Legacy Template Selection (Optional) */}
                  <details className="border rounded-lg p-4">
                    <summary className="cursor-pointer font-medium text-sm">
                      Legacy Template Selection (Optional)
                    </summary>
                    <div className="mt-4 space-y-4">
                      <div>
                        <Label>Stage Template</Label>
                        <Select value={selectedTemplate} onValueChange={(value) => {
                          setSelectedTemplate(value);
                          if (value && stageTemplates[value as keyof typeof stageTemplates]) {
                            const template = stageTemplates[value as keyof typeof stageTemplates];
                            setStagePlot(prev => ({
                              ...prev,
                              performers: template.performers,
                              monitors: template.monitors,
                              template: value
                            }));
                          }
                        }}>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose a stage template" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="solo-acoustic">Solo Acoustic</SelectItem>
                            <SelectItem value="duo">Duo Setup</SelectItem>
                            <SelectItem value="full-band">Full Band</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Stage Width (feet)</Label>
                      <Input type="number" value={stagePlot.stageWidth} onChange={(e) => 
                        setStagePlot({...stagePlot, stageWidth: parseInt(e.target.value)})
                      } />
                    </div>
                    <div>
                      <Label>Stage Depth (feet)</Label>
                      <Input type="number" value={stagePlot.stageDepth} onChange={(e) => 
                        setStagePlot({...stagePlot, stageDepth: parseInt(e.target.value)})
                      } />
                    </div>
                  </div>

                  {/* Template Control Buttons */}
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => {
                      if (selectedTemplate) {
                        const template = stageTemplates[selectedTemplate as keyof typeof stageTemplates];
                        setStagePlot(prev => ({
                          ...prev,
                          performers: template.performers,
                          monitors: template.monitors
                        }));
                        toast({ title: "Template Loaded", description: `${template.name} template applied` });
                      }
                    }}>Load Template</Button>
                    <Button size="sm" variant="outline" onClick={() => {
                      setStagePlot(prev => ({
                        ...prev,
                        performers: [],
                        monitors: [],
                        template: ''
                      }));
                      setSelectedTemplate('');
                      toast({ title: "Stage Reset", description: "Stage plot cleared" });
                    }}>Reset</Button>
                    <Button size="sm" variant="outline" onClick={() => {
                      setSelectedTemplate('');
                      toast({ title: "Template Unselected", description: "Template selection cleared" });
                    }}>Unselect</Button>
                  </div>

                  {/* Stage plot visualization */}
                  <div className="border rounded-lg p-4 bg-gray-50">
                    <div 
                      className="bg-white border-2 border-gray-300 relative mx-auto"
                      style={{ 
                        width: `${Math.min(stagePlot.stageWidth * 8, 400)}px`, 
                        height: `${Math.min(stagePlot.stageDepth * 8, 300)}px` 
                      }}
                    >
                      {/* Performers */}
                      {stagePlot.performers.map((performer: any) => (
                        <div
                          key={performer.id}
                          className="absolute w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-bold text-white cursor-move"
                          style={{
                            backgroundColor: getInstrumentColor(performer.instrument),
                            left: `${(performer.position.x / stagePlot.stageWidth) * 100}%`,
                            top: `${(performer.position.y / stagePlot.stageDepth) * 100}%`,
                            transform: 'translate(-50%, -50%)'
                          }}
                          title={performer.name}
                        >
                          {performer.name[0]}
                        </div>
                      ))}

                      {/* Monitors */}
                      {stagePlot.monitors.map((monitor: any) => (
                        <div
                          key={monitor.id}
                          className="absolute w-4 h-4 bg-gray-600 border rounded flex items-center justify-center"
                          style={{
                            left: `${(monitor.position.x / stagePlot.stageWidth) * 100}%`,
                            top: `${(monitor.position.y / stagePlot.stageDepth) * 100}%`,
                            transform: 'translate(-50%, -50%)'
                          }}
                          title={monitor.mix}
                        >
                          <Volume2 className="h-2 w-2 text-white" />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Legend */}
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-sm">
                    {Object.entries({
                      vocals: 'Vocals',
                      guitar: 'Guitar', 
                      bass: 'Bass',
                      drums: 'Drums',
                      keyboard: 'Keyboard'
                    }).map(([key, label]) => (
                      <div key={key} className="flex items-center gap-2">
                        <div 
                          className="w-4 h-4 rounded-full border" 
                          style={{ backgroundColor: getInstrumentColor(key) }}
                        />
                        <span>{label}</span>
                      </div>
                    ))}
                  </div>

                  {/* Musician Assignment for Stage Positions */}
                  <Card className="mt-4">
                    <CardHeader>
                      <CardTitle className="text-sm">Musician Assignment</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {stagePlot.performers.map((performer: any, index: number) => (
                          <div key={performer.id} className="grid grid-cols-2 gap-2 items-center">
                            <Label className="text-sm">{performer.name}</Label>
                            <Select 
                              value={performer.musician} 
                              onValueChange={(value) => {
                                setStagePlot(prev => ({
                                  ...prev,
                                  performers: prev.performers.map(p => 
                                    p.id === performer.id ? { ...p, musician: value } : p
                                  )
                                }));
                              }}
                            >
                              <SelectTrigger className="text-xs">
                                <SelectValue placeholder="Assign musician" />
                              </SelectTrigger>
                              <SelectContent>
                                {assignedTalent.filter(t => t.type.includes('Artist') || t.type.includes('Musician')).map(talent => (
                                  <SelectItem key={talent.userId} value={talent.name}>
                                    {talent.name} ({talent.role})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="lighting" 
                        checked={stagePlot.lighting} 
                        onCheckedChange={(checked) => setStagePlot({...stagePlot, lighting: checked === true})} 
                      />
                      <label htmlFor="lighting">Stage Lighting</label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="video" 
                        checked={stagePlot.videoRecording} 
                        onCheckedChange={(checked) => setStagePlot({...stagePlot, videoRecording: checked === true})} 
                      />
                      <label htmlFor="video">Video Recording</label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="photo" 
                        checked={stagePlot.photographyArea} 
                        onCheckedChange={(checked) => setStagePlot({...stagePlot, photographyArea: checked === true})} 
                      />
                      <label htmlFor="photo">Photography Area</label>
                    </div>
                  </div>
                    </div>
                  </details>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="2" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Volume2 className="h-5 w-5" />
                  Mixer & Patch List
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Input Patch List with Musician Assignment */}
                  <div>
                    <h4 className="font-semibold mb-3">Input Patch List</h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm border-collapse border">
                        <thead>
                          <tr className="bg-gray-50">
                            <th className="border p-2 text-left">Ch</th>
                            <th className="border p-2 text-left">Source</th>
                            <th className="border p-2 text-left">Microphone</th>
                            <th className="border p-2 text-left">Location</th>
                            <th className="border p-2 text-left">Musician</th>
                            <th className="border p-2 text-left">Notes</th>
                          </tr>
                        </thead>
                        <tbody>
                          {mixerConfig.inputs.map((input: any) => (
                            <tr key={input.channel}>
                              <td className="border p-2 font-mono">{input.channel}</td>
                              <td className="border p-2">{input.source}</td>
                              <td className="border p-2 font-mono">{input.mic}</td>
                              <td className="border p-2">{input.location}</td>
                              <td className="border p-2">
                                <Select 
                                  value={input.musician} 
                                  onValueChange={(value) => {
                                    setMixerConfig(prev => ({
                                      ...prev,
                                      inputs: prev.inputs.map(inp => 
                                        inp.channel === input.channel ? { ...inp, musician: value } : inp
                                      )
                                    }));
                                  }}
                                >
                                  <SelectTrigger className="text-xs h-6 border-0">
                                    <SelectValue placeholder="Assign" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {assignedTalent.filter(t => t.type.includes('Artist') || t.type.includes('Musician')).map(talent => (
                                      <SelectItem key={talent.userId} value={talent.name}>
                                        {talent.name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </td>
                              <td className="border p-2 text-xs">{input.notes}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Monitor Mixes */}
                  <div>
                    <h4 className="font-semibold mb-3">Monitor Mix Configuration</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {mixerConfig.monitors.map((monitor: any) => (
                        <Card key={monitor.mix}>
                          <CardContent className="pt-4">
                            <h5 className="font-medium mb-2">Mix {monitor.mix}: {monitor.name}</h5>
                            <p className="text-sm text-muted-foreground">{monitor.sends}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>

                  {/* Effects Processing */}
                  <div>
                    <h4 className="font-semibold mb-3">Effects & Processing</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {mixerConfig.effects.map((effect: any, index: number) => (
                        <Card key={index}>
                          <CardContent className="pt-4">
                            <h5 className="font-medium mb-1">{effect.name}</h5>
                            <p className="text-sm text-blue-600 mb-2">{effect.type}</p>
                            <p className="text-xs text-muted-foreground">{effect.settings}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="3" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Music className="h-5 w-5" />
                  Performance Setlist
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Setlist table with Chord Generator */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm border-collapse border">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="border p-2 text-left">#</th>
                          <th className="border p-2 text-left">Song Title</th>
                          <th className="border p-2 text-left">Key</th>
                          <th className="border p-2 text-left">Chords</th>
                          <th className="border p-2 text-left">Duration</th>
                          <th className="border p-2 text-left">Transition</th>
                          <th className="border p-2 text-left">Notes</th>
                          <th className="border p-2 text-left">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {setlist.songs.map((song: any) => (
                          <tr key={song.id}>
                            <td className="border p-2 font-mono">{song.id}</td>
                            <td className="border p-2 font-medium">{song.title}</td>
                            <td className="border p-2 font-mono">{song.key}</td>
                            <td className="border p-2 font-mono text-xs">{song.chords}</td>
                            <td className="border p-2 font-mono">{song.duration}</td>
                            <td className="border p-2">{song.transition}</td>
                            <td className="border p-2 text-xs">{song.notes}</td>
                            <td className="border p-2">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                onClick={() => {
                                  const newChords = generateChords(song.key);
                                  setSetlist(prev => ({
                                    ...prev,
                                    songs: prev.songs.map(s => 
                                      s.id === song.id ? { ...s, chords: newChords } : s
                                    )
                                  }));
                                  toast({ 
                                    title: "Chords Generated", 
                                    description: `New chord progression for ${song.title}: ${newChords}` 
                                  });
                                }}
                                className="text-xs h-6"
                              >
                                Generate
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Timing summary */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="pt-4 text-center">
                        <div className="text-2xl font-bold text-blue-600">{setlist.timing.mainSet}</div>
                        <div className="text-sm text-muted-foreground">Main Set</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-4 text-center">
                        <div className="text-2xl font-bold text-green-600">{setlist.timing.encore}</div>
                        <div className="text-sm text-muted-foreground">Encore</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-4 text-center">
                        <div className="text-2xl font-bold text-purple-600">{setlist.timing.totalShow}</div>
                        <div className="text-sm text-muted-foreground">Total Show Time</div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Performance notes */}
                  <div>
                    <h4 className="font-semibold mb-3">Performance Notes</h4>
                    <div className="space-y-2">
                      <p className="text-sm"><strong>Flow:</strong> {setlist.notes}</p>
                      <p className="text-sm"><strong>Special Requirements:</strong> {setlist.specialRequirements}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="4" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Complete Technical Rider
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-sm">
                  <div className="text-center">
                    <h3 className="text-lg font-bold">TECHNICAL RIDER</h3>
                    <p className="text-muted-foreground">{booking?.eventName} - {booking?.eventDate}</p>
                  </div>

                  <Separator />

                  <div>
                    <h4 className="font-semibold mb-2">Stage Requirements</h4>
                    <p>Stage Size: {stagePlot.stageWidth}' × {stagePlot.stageDepth}'</p>
                    <p>Performers: {stagePlot.performers.length} positions</p>
                    <p>Monitor wedges: {stagePlot.monitors.length} required</p>
                    <p>Additional: {stagePlot.lighting ? 'Professional lighting required' : 'Basic lighting acceptable'}</p>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Audio Requirements</h4>
                    <p>Input channels required: {mixerConfig.inputs.length}</p>
                    <p>Monitor mixes: {mixerConfig.monitors.length}</p>
                    <p>Effects processing: {mixerConfig.effects.length} units</p>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Performance Details</h4>
                    <p>Set duration: {setlist.timing.mainSet} + {setlist.timing.encore} encore</p>
                    <p>Total songs: {setlist.songs.length}</p>
                    <p>Special requirements: {setlist.specialRequirements}</p>
                  </div>

                  {/* Technical Rider Confirmation */}
                  <div className="mt-6 p-4 bg-blue-50 rounded border border-blue-200">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        id="technicalRiderConfirmation"
                        className="mt-1"
                        checked={technicalConfirmed}
                        onChange={(e) => setTechnicalConfirmed(e.target.checked)}
                      />
                      <label htmlFor="technicalRiderConfirmation" className="text-sm">
                        <span className="font-medium">I confirm that:</span>
                        <ul className="mt-1 space-y-1 text-muted-foreground">
                          <li>• Stage plot design and equipment placement has been reviewed</li>
                          <li>• Mixer configuration and patch list are accurate</li>
                          <li>• Performance setlist and timing are finalized</li>
                          <li>• All technical requirements are properly documented</li>
                          <li>• Ready to proceed to Signature Collection</li>
                        </ul>
                      </label>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button className="w-full" onClick={async () => {
                      try {
                        const response = await apiRequest(`/api/bookings/${booking?.id}/technical-rider`, {
                          method: 'POST',
                          body: {
                            assignedTalent,
                            stagePlot: {
                              stageWidth: stagePlot.stageWidth,
                              stageDepth: stagePlot.stageDepth,
                              performers: stagePlot.performers,
                              monitors: stagePlot.monitors,
                              lighting: stagePlot.lighting
                            },
                            mixerConfig: {
                              inputs: mixerConfig.inputs,
                              monitors: mixerConfig.monitors,
                              effects: mixerConfig.effects
                            },
                            setlist: {
                              songs: setlist.songs,
                              timing: setlist.timing,
                              notes: setlist.notes,
                              specialRequirements: setlist.specialRequirements
                            }
                          }
                        });

                        if (response.ok) {
                          const blob = await response.blob();
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `technical-rider-${booking?.id}-${Date.now()}.pdf`;
                          a.click();
                          window.URL.revokeObjectURL(url);
                          toast({ title: "Technical Rider", description: "Complete technical rider PDF downloaded successfully" });
                        } else {
                          throw new Error('Technical rider generation failed');
                        }
                      } catch (error) {
                        console.error('Technical rider error:', error);
                        toast({ title: "Download Error", description: "Failed to generate technical rider PDF", variant: "destructive" });
                      }
                    }}>
                      <Download className="h-4 w-4 mr-2" />
                      Download Complete Technical Rider PDF
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    );
  };

  // Step 4: Signature Collection
  const renderSignatureCollection = () => {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PenTool className="h-5 w-5" />
              Signature Collection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button className="flex items-center gap-2" onClick={async () => {
                  try {
                    await updateBookingMutation.mutateAsync({
                      signatures: [
                        ...(booking?.signatures || []),
                        {
                          type: 'client',
                          signedBy: booking?.bookerName || booking?.clientName || 'Client',
                          signedAt: new Date().toISOString(),
                          documentType: 'booking_agreement'
                        }
                      ]
                    });
                    toast({ title: "Signature Collected", description: "Client signature collected and stored" });
                  } catch (error) {
                    toast({ title: "Error", description: "Failed to collect client signature", variant: "destructive" });
                  }
                }}>
                  <PenTool className="h-4 w-4" />
                  Collect Client Signature
                </Button>
                <Button className="flex items-center gap-2" onClick={async () => {
                  try {
                    const primaryArtist = assignedTalent.find(t => t.isMainBookedTalent) || assignedTalent[0];
                    await updateBookingMutation.mutateAsync({
                      signatures: [
                        ...(booking?.signatures || []),
                        {
                          type: 'artist',
                          signedBy: primaryArtist?.name || 'Primary Artist',
                          signedAt: new Date().toISOString(),
                          documentType: 'performance_agreement'
                        }
                      ]
                    });
                    toast({ title: "Signature Collected", description: "Artist signature collected and stored" });
                  } catch (error) {
                    toast({ title: "Error", description: "Failed to collect artist signature", variant: "destructive" });
                  }
                }}>
                  <PenTool className="h-4 w-4" />
                  Collect Artist Signature
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Step 5: Payment Processing
  const renderPaymentProcessing = () => {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Payment Processing
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button className="flex items-center gap-2" onClick={async () => {
                  try {
                    const totalAmount = contractConfig.totalBookingPrice || calculateTotalBookingPrice();
                    await updateBookingMutation.mutateAsync({
                      payments: [
                        ...(booking?.payments || []),
                        {
                          amount: totalAmount,
                          method: 'platform_payment',
                          status: 'completed',
                          processedAt: new Date().toISOString(),
                          transactionId: `TXN-${Date.now()}`,
                          paidBy: booking?.bookerName || booking?.clientName || 'Client'
                        }
                      ]
                    });
                    toast({ title: "Payment Processed", description: `Payment of $${totalAmount} processed successfully` });
                  } catch (error) {
                    toast({ title: "Payment Error", description: "Failed to process payment", variant: "destructive" });
                  }
                }}>
                  <CreditCard className="h-4 w-4" />
                  Process Payment
                </Button>
                <Button className="flex items-center gap-2" onClick={async () => {
                  try {
                    const response = await apiRequest(`/api/bookings/${booking?.id}/generate-receipt`, {
                      method: 'POST',
                      body: {
                        totalAmount: contractConfig.totalBookingPrice || calculateTotalBookingPrice(),
                        payments: booking?.payments || [],
                        clientName: booking?.bookerName || booking?.clientName || 'Client',
                        eventDate: booking?.eventDate,
                        eventName: booking?.eventName
                      }
                    });

                    if (response.ok) {
                      const blob = await response.blob();
                      const url = window.URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `receipt-${booking?.id}-${Date.now()}.pdf`;
                      a.click();
                      window.URL.revokeObjectURL(url);
                      toast({ title: "Receipt Generated", description: "Receipt downloaded successfully" });
                    } else {
                      throw new Error('Receipt generation failed');
                    }
                  } catch (error) {
                    toast({ title: "Receipt Error", description: "Failed to generate receipt", variant: "destructive" });
                  }
                }}>
                  <Receipt className="h-4 w-4" />
                  Generate Receipt
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Step 6: Feedback (Optional)
  const renderFeedback = () => {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5" />
              AI Career Enhancement Feedback
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-muted-foreground mb-4">
                This optional step provides AI-powered career enhancement feedback for managed talent assigned to the booking, 
                with priority given to the main booked talent.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button className="flex items-center gap-2" onClick={() => {
                  toast({ title: "AI Feedback", description: "Career enhancement analysis generated for main talent" });
                }}>
                  <Star className="h-4 w-4" />
                  Generate AI Feedback
                </Button>
                <Button variant="outline" className="flex items-center gap-2" onClick={() => {
                  toast({ title: "Feedback", description: "Feedback step skipped" });
                }}>
                  <ArrowRight className="h-4 w-4" />
                  Skip This Step
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Step 6: Finalization
  const renderFinalization = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Workflow Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Completion Status</Label>
                <div className="flex items-center gap-2 mt-2">
                  <Progress value={getProgressPercentage()} className="flex-1" />
                  <span className="text-sm font-medium">{Math.round(getProgressPercentage())}%</span>
                </div>
              </div>
              <div>
                <Label>Next Actions</Label>
                <p className="text-sm text-muted-foreground mt-2">
                  All contracts generated and ready for client delivery
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Final Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <Button className="w-full" onClick={() => {
              updateBookingMutation.mutate({ status: 'completed' });
              toast({ title: "Completed", description: "Booking workflow completed successfully!" });
            }}>
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Complete Workflow
            </Button>
            <Button variant="outline" className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Download All Documents
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return renderTalentAssignment();
      case 2:
        return renderContractGeneration();
      case 3:
        return renderTechnicalRider();
      case 4:
        return renderSignatureCollection();
      case 5:
        return renderPaymentProcessing();
      case 6:
        return renderFeedback();
      default:
        return <div>Invalid step</div>;
    }
  };

  // Check access permissions
  const hasWorkflowAccess = () => {
    if (userRole === 'superadmin') return true;
    if (userRole === 'admin') {
      // Check if this admin is assigned to the booking
      return booking?.assignedAdmin?.userId === booking?.currentUserId;
    }
    return false;
  };

  if (isLoading || bookingLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading workflow...</span>
      </div>
    );
  }

  if (!hasWorkflowAccess()) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">
                You don't have permission to access this booking workflow.
              </p>
              <p className="text-sm text-muted-foreground">
                Only the assigned admin for this booking or a superadmin can proceed with workflow management.
              </p>
              {booking?.assignedAdmin && (
                <div className="mt-4 p-3 bg-blue-50 rounded border">
                  <p className="text-sm font-medium">Assigned Admin:</p>
                  <p className="text-sm text-muted-foreground">{booking.assignedAdmin.fullName}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Workflow Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Comprehensive Booking Workflow</span>
            <Badge variant="outline">
              Step {currentStep} of {workflowSteps.length}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Overall Progress</span>
              <span className="text-sm text-muted-foreground">
                {Math.round(getProgressPercentage())}% Complete
              </span>
            </div>
            <Progress value={getProgressPercentage()} className="w-full" />
          </div>

          {/* Step Indicators */}
          <div className="flex items-center justify-between">
            {workflowSteps.map((step, index) => (
              <div key={step.id} className="flex flex-col items-center">
                <div 
                  className={`
                    w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium
                    transition-all duration-300 cursor-pointer hover:scale-110 ${
                      step.status === 'completed' 
                        ? 'bg-green-500 text-white hover:bg-green-600' 
                        : step.isActive 
                          ? 'bg-primary text-primary-foreground hover:bg-primary/80' 
                          : 'bg-muted text-muted-foreground hover:bg-muted/80'
                    }
                  `}
                  onClick={() => handleStepClick(index + 1)}
                  title={
                    userRole === 'superadmin' 
                      ? `Click to jump to ${step.title}` 
                      : (userRole === 'admin' || userRole === 'assigned_admin') && technicalConfirmed
                        ? `Click to jump to ${step.title}`
                        : (userRole === 'admin' || userRole === 'assigned_admin') && !technicalConfirmed
                          ? `Complete Technical Rider to enable navigation to ${step.title}`
                          : `Click to go to ${step.title} (previous steps only)`
                  }
                >
                  {step.status === 'completed' ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : (
                    step.icon
                  )}
                </div>
                <span className={`mt-2 text-xs text-center ${
                  step.isActive ? 'font-medium' : 'text-muted-foreground'
                }`}>
                  {step.title}
                </span>
                {index < workflowSteps.length - 1 && (
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Current Step Content */}
      <Card>
        <CardHeader>
          <CardTitle>{workflowSteps[currentStep - 1]?.title}</CardTitle>
          <p className="text-muted-foreground">
            {workflowSteps[currentStep - 1]?.description}
          </p>
        </CardHeader>
        <CardContent>
          {renderStepContent()}
        </CardContent>
      </Card>

      {/* Navigation */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={goToPreviousStep}
              disabled={currentStep === 1}
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
            
            <div className="flex gap-2">
              {saving && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Saving...
                </div>
              )}
              
              <Button 
                onClick={async () => {
                  // Send email notification for step completion
                  try {
                    await apiRequest(`/api/bookings/${bookingId}/workflow/notify`, {
                      method: 'POST',
                      body: {
                        type: currentStep === 6 ? 'completed' : 'step_completed',
                        step: currentStep,
                        stepName: workflowSteps[currentStep - 1]?.title,
                        progress: Math.round((currentStep / workflowSteps.length) * 100)
                      }
                    });
                  } catch (error) {
                    console.log('Email notification failed:', error);
                  }
                  
                  // Progress to next step or complete
                  progressToNextStep();
                }}
                disabled={
                  currentStep === 6 || 
                  (currentStep === 2 && !stepConfirmations[currentStep]) ||
                  (currentStep === 3 && !technicalConfirmed) ||
                  (!workflowSteps[currentStep - 1]?.canProgress && currentStep !== 2 && currentStep !== 3)
                }
              >
                {currentStep === 6 ? 'Complete Workflow' : 'Next Step'}
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Modal Components */}
      <EnhancedStagePlotDesigner
        isOpen={stagePlotModalOpen}
        onClose={() => setStagePlotModalOpen(false)}
        bookingId={bookingId}
        assignedTalent={assignedTalent}
        onSave={(data: any) => {
          toast({ title: "Stage Plot Saved", description: "Stage plot configuration saved successfully" });
        }}
      />

      <Enhanced32PortMixer
        isOpen={mixerModalOpen}
        onClose={() => setMixerModalOpen(false)}
        bookingId={bookingId}
        assignedTalent={assignedTalent}
        onSave={(data: any) => {
          toast({ title: "Mixer Configuration Saved", description: "Mixer & patch configuration saved successfully" });
        }}
      />

      <EnhancedSetlistManager
        isOpen={setlistModalOpen}
        onClose={() => setSetlistModalOpen(false)}
        bookingId={bookingId}
        assignedTalent={assignedTalent}
        eventDetails={{
          eventName: booking?.eventName,
          eventType: booking?.eventType,
          venueName: booking?.venueName
        }}
        onSave={(data: any) => {
          toast({ title: "Setlist Saved", description: "Setlist configuration saved successfully" });
        }}
      />

      <Dialog open={technicalRiderModalOpen} onOpenChange={setTechnicalRiderModalOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Complete Technical Rider Designer</DialogTitle>
          </DialogHeader>
          <div className="p-4 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layout className="h-5 w-5" />
                  Stage Plot Designer
                </CardTitle>
              </CardHeader>
              <CardContent>
                <EnhancedStagePlotDesigner
                  isOpen={true}
                  onClose={() => {}}
                  bookingId={bookingId}
                  assignedTalent={assignedTalent}
                  onSave={(data: any) => console.log("Stage plot saved:", data)}
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Volume2 className="h-5 w-5" />
                  Mixer & Patch Configuration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Enhanced32PortMixer
                  isOpen={true}
                  onClose={() => {}}
                  bookingId={bookingId}
                  assignedTalent={assignedTalent}
                  onSave={(data: any) => console.log("Mixer saved:", data)}
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Music className="h-5 w-5" />
                  Setlist Manager
                </CardTitle>
              </CardHeader>
              <CardContent>
                <EnhancedSetlistManager
                  isOpen={true}
                  onClose={() => {}}
                  bookingId={bookingId}
                  assignedTalent={assignedTalent}
                  eventDetails={{
                    eventName: booking?.eventName,
                    eventType: booking?.eventType,
                    venueName: booking?.venueName
                  }}
                  onSave={(data: any) => console.log("Setlist saved:", data)}
                />
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}