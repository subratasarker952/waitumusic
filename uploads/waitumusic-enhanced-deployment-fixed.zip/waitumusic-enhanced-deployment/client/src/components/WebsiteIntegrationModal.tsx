import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Globe, Link, QrCode, Download, Copy, Eye, MousePointer, Code, ExternalLink } from "lucide-react";
import type { WebsiteIntegration, InsertWebsiteIntegration } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface WebsiteIntegrationModalProps {
  children: React.ReactNode;
  artistId?: number;
  artistName?: string;
}

export default function WebsiteIntegrationModal({ children, artistId, artistName }: WebsiteIntegrationModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("create");
  const [open, setOpen] = useState(false);

  // Website Integrations for this artist
  const { data: integrations, isLoading: integrationsLoading } = useQuery<WebsiteIntegration[]>({
    queryKey: ["/api/website-integrations", artistId],
    enabled: open && !!artistId,
  });

  const createIntegrationMutation = useMutation({
    mutationFn: (data: InsertWebsiteIntegration) => 
      apiRequest("/api/website-integrations", { method: "POST", body: data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/website-integrations"] });
      toast({ title: "All-links page created successfully" });
      setNewIntegration({
        slug: "",
        isActive: true,
        accessLevel: "public",
        socialLinks: [],
        musicLinks: [],
        bookingLinks: [],
        storeLinks: [],
        customLinks: [],
      });
    },
    onError: () => {
      toast({ title: "Failed to create all-links page", variant: "destructive" });
    },
  });

  const [newIntegration, setNewIntegration] = useState<Partial<InsertWebsiteIntegration>>({
    slug: "",
    isActive: true,
    accessLevel: "public",
    socialLinks: [],
    musicLinks: [],
    bookingLinks: [],
    storeLinks: [],
    customLinks: [],
  });

  const handleCreateIntegration = () => {
    if (!newIntegration.slug) {
      toast({ title: "Please provide a unique slug for your all-links page", variant: "destructive" });
      return;
    }
    createIntegrationMutation.mutate(newIntegration as InsertWebsiteIntegration);
  };

  const [linkType, setLinkType] = useState("");
  const [linkTitle, setLinkTitle] = useState("");
  const [linkUrl, setLinkUrl] = useState("");

  const addLink = () => {
    if (!linkType || !linkTitle || !linkUrl) {
      toast({ title: "Please fill in all link fields", variant: "destructive" });
      return;
    }

    const newLink = { title: linkTitle, url: linkUrl, icon: linkType };
    const categoryKey = `${linkType}Links` as keyof typeof newIntegration;
    const currentLinks = (newIntegration[categoryKey] as any[]) || [];
    
    setNewIntegration(prev => ({
      ...prev,
      [categoryKey]: [...currentLinks, newLink]
    }));

    // Reset form
    setLinkTitle("");
    setLinkUrl("");
  };

  const generateEmbedCode = (integration: WebsiteIntegration) => {
    return `<iframe src="https://www.waitumusic.com/${integration.slug}" width="100%" height="600" frameborder="0" style="border-radius: 12px; background: transparent;"></iframe>`;
  };

  const generateQRCodeUrl = (integration: WebsiteIntegration) => {
    return `https://api.qrserver.com/v1/create-qr-code/?size=300x300&format=png&bgcolor=00000000&data=https://www.waitumusic.com/${integration.slug}`;
  };

  const downloadQRCode = async (integration: WebsiteIntegration) => {
    try {
      const qrUrl = generateQRCodeUrl(integration);
      const response = await fetch(qrUrl);
      const blob = await response.blob();
      
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${integration.slug}-qr-code.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({ title: "QR code downloaded successfully" });
    } catch (error) {
      toast({ title: "Failed to download QR code", variant: "destructive" });
    }
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({ title: `${type} copied to clipboard` });
    }).catch(() => {
      toast({ title: `Failed to copy ${type}`, variant: "destructive" });
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Globe className="h-6 w-6 text-emerald-600" />
            <span>Website Integration - {artistName}</span>
          </DialogTitle>
          <DialogDescription>
            Create and manage your all-links pages with QR codes and embeddable widgets
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="create" className="flex items-center space-x-2">
              <Link className="h-4 w-4" />
              <span>Create All-Links</span>
            </TabsTrigger>
            <TabsTrigger value="existing" className="flex items-center space-x-2">
              <Globe className="h-4 w-4" />
              <span>Manage Pages</span>
            </TabsTrigger>
            <TabsTrigger value="embed" className="flex items-center space-x-2">
              <Code className="h-4 w-4" />
              <span>Embed & QR</span>
            </TabsTrigger>
          </TabsList>

          {/* Create New All-Links Page Tab */}
          <TabsContent value="create" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Link className="h-5 w-5 text-blue-500" />
                  <span>Create New All-Links Page</span>
                </CardTitle>
                <CardDescription>
                  Build a beautiful landing page that showcases all your important links
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Basic Settings */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Basic Settings</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="slug">Page Slug</Label>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-500">www.waitumusic.com/</span>
                        <Input
                          id="slug"
                          placeholder="your-name"
                          value={newIntegration.slug || ""}
                          onChange={(e) => setNewIntegration(prev => ({ ...prev, slug: e.target.value }))}
                        />
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={!!newIntegration.isActive}
                        onCheckedChange={(checked) => setNewIntegration(prev => ({ ...prev, isActive: checked }))}
                      />
                      <Label>Active</Label>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Links Management */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Add Links</h3>
                  <div className="grid md:grid-cols-4 gap-4">
                    <div>
                      <Label>Link Category</Label>
                      <Select value={linkType} onValueChange={setLinkType}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="social">Social Media</SelectItem>
                          <SelectItem value="music">Music Platforms</SelectItem>
                          <SelectItem value="booking">Booking</SelectItem>
                          <SelectItem value="store">Store</SelectItem>
                          <SelectItem value="custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Link Title</Label>
                      <Input
                        placeholder="e.g., Follow on Instagram"
                        value={linkTitle}
                        onChange={(e) => setLinkTitle(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>URL</Label>
                      <Input
                        placeholder="https://..."
                        value={linkUrl}
                        onChange={(e) => setLinkUrl(e.target.value)}
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={addLink} className="w-full">
                        Add Link
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Preview Added Links */}
                {((Array.isArray(newIntegration.socialLinks) && newIntegration.socialLinks.length > 0) || 
                  (Array.isArray(newIntegration.musicLinks) && newIntegration.musicLinks.length > 0) || 
                  (Array.isArray(newIntegration.bookingLinks) && newIntegration.bookingLinks.length > 0) || 
                  (Array.isArray(newIntegration.storeLinks) && newIntegration.storeLinks.length > 0) || 
                  (Array.isArray(newIntegration.customLinks) && newIntegration.customLinks.length > 0)) && (
                  <>
                    <Separator />
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Added Links Preview</h3>
                      <div className="space-y-2">
                        {['social', 'music', 'booking', 'store', 'custom'].map(category => {
                          const categoryKey = `${category}Links` as keyof typeof newIntegration;
                          const links = newIntegration[categoryKey] as any[];
                          if (!links?.length) return null;

                          return (
                            <div key={category}>
                              <h4 className="font-medium capitalize mb-2">{category} Links</h4>
                              <div className="space-y-1">
                                {links.map((link: any, index: number) => (
                                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded">
                                    <div>
                                      <span className="font-medium">{link.title}</span>
                                      <span className="text-sm text-gray-500 ml-2">{link.url}</span>
                                    </div>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => {
                                        const updatedLinks = links.filter((_, i) => i !== index);
                                        setNewIntegration(prev => ({ ...prev, [categoryKey]: updatedLinks }));
                                      }}
                                    >
                                      Remove
                                    </Button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}

                <Separator />

                <Button 
                  onClick={handleCreateIntegration}
                  disabled={createIntegrationMutation.isPending}
                  className="w-full"
                >
                  {createIntegrationMutation.isPending ? "Creating..." : "Create All-Links Page"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Existing Pages Tab */}
          <TabsContent value="existing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Globe className="h-5 w-5 text-emerald-500" />
                  <span>Your All-Links Pages</span>
                </CardTitle>
                <CardDescription>
                  Manage your existing all-links pages
                </CardDescription>
              </CardHeader>
              <CardContent>
                {integrationsLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto"></div>
                    <p className="mt-2 text-gray-600 dark:text-gray-300">Loading your pages...</p>
                  </div>
                ) : integrations?.length === 0 ? (
                  <div className="text-center py-8">
                    <Link className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-300">No all-links pages created yet. Start by creating your first one!</p>
                    <Button className="mt-4" onClick={() => setActiveTab("create")}>
                      Create Your First All-Links Page
                    </Button>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {integrations?.map((integration) => (
                      <Card key={integration.id} className="border-l-4 border-l-emerald-500">
                        <CardContent className="pt-4">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h4 className="font-semibold text-lg">/{integration.slug}</h4>
                                <Badge variant={integration.isActive ? "default" : "secondary"}>
                                  {integration.isActive ? "Active" : "Inactive"}
                                </Badge>
                              </div>
                              <p className="text-gray-600 dark:text-gray-300 text-sm mb-3">
                                www.waitumusic.com/{integration.slug}
                              </p>
                              <div className="flex items-center space-x-4 text-sm text-gray-500">
                                <div className="flex items-center space-x-1">
                                  <Eye className="h-4 w-4" />
                                  <span>{integration.viewCount || 0} views</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <MousePointer className="h-4 w-4" />
                                  <span>{integration.clickCount || 0} clicks</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => downloadQRCode(integration)}
                              >
                                <QrCode className="h-4 w-4 mr-2" />
                                QR Code
                              </Button>
                              <Button variant="outline" size="sm">
                                <ExternalLink className="h-4 w-4 mr-2" />
                                Visit
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Embed & QR Tab */}
          <TabsContent value="embed" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Code className="h-5 w-5 text-purple-500" />
                  <span>Embed Code & QR Codes</span>
                </CardTitle>
                <CardDescription>
                  Get embed codes and download QR codes for your all-links pages
                </CardDescription>
              </CardHeader>
              <CardContent>
                {integrations?.length === 0 ? (
                  <div className="text-center py-8">
                    <Code className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-300">Create an all-links page first to get embed codes and QR codes.</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {integrations?.map((integration) => (
                      <Card key={integration.id} className="border-l-4 border-l-purple-500">
                        <CardContent className="pt-4 space-y-4">
                          <h4 className="font-semibold text-lg">/{integration.slug}</h4>
                          
                          {/* Embed Code */}
                          <div>
                            <Label className="text-sm font-medium">Embed Code</Label>
                            <div className="flex items-center space-x-2 mt-1">
                              <Textarea
                                value={generateEmbedCode(integration)}
                                readOnly
                                className="font-mono text-sm"
                                rows={3}
                              />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => copyToClipboard(generateEmbedCode(integration), "Embed code")}
                              >
                                <Copy className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          {/* QR Code */}
                          <div>
                            <Label className="text-sm font-medium">QR Code</Label>
                            <div className="flex items-center space-x-4 mt-2">
                              <img
                                src={generateQRCodeUrl(integration)}
                                alt={`QR Code for ${integration.slug}`}
                                className="w-24 h-24 border rounded"
                              />
                              <div className="space-y-2">
                                <p className="text-sm text-gray-600 dark:text-gray-300">
                                  Transparent PNG QR code linking to: www.waitumusic.com/{integration.slug}
                                </p>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => downloadQRCode(integration)}
                                >
                                  <Download className="h-4 w-4 mr-2" />
                                  Download PNG
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}