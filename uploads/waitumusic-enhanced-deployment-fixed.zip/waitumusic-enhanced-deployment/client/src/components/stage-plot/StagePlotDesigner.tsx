import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Save, Download, Upload, RotateCcw, RotateCw, Trash2, Grid3X3, Music, Eraser, Users, Edit3, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';

interface StageItem {
  id: string;
  type: 'instrument' | 'equipment' | 'performer';
  name: string;
  displayName?: string; // Editable display name for legend
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  color: string;
  icon: string;
  assignedUserId?: number; // For performers assigned from booking
  letterCode?: string; // Auto-generated letter code for legend
}

interface StagePlot {
  id?: string;
  name: string;
  items: StageItem[];
  stageWidth: number;
  stageHeight: number;
  createdAt?: string;
  modifiedAt?: string;
}

const STAGE_ITEMS = {
  instruments: [
    { name: 'Grand Piano', width: 120, height: 80, color: '#8B4513', icon: '🎹' },
    { name: 'Upright Piano', width: 60, height: 40, color: '#8B4513', icon: '🎹' },
    { name: 'Drum Kit', width: 100, height: 100, color: '#2C5F2D', icon: '🥁' },
    { name: 'Bass Guitar Amp', width: 40, height: 60, color: '#1E40AF', icon: '🔊' },
    { name: 'Guitar Amp', width: 35, height: 55, color: '#DC2626', icon: '🔊' },
    { name: 'Keyboard Stand', width: 50, height: 30, color: '#6B7280', icon: '🎹' },
    { name: 'Microphone Stand', width: 15, height: 15, color: '#374151', icon: '🎤' },
    { name: 'Music Stand', width: 20, height: 15, color: '#6B7280', icon: '🎼' },
  ],
  equipment: [
    { name: 'Monitor Speaker', width: 30, height: 25, color: '#111827', icon: '🔊' },
    { name: 'Main Speaker', width: 40, height: 60, color: '#111827', icon: '🔊' },
    { name: 'Mixing Console', width: 80, height: 50, color: '#374151', icon: '🎚️' },
    { name: 'Power Amp Rack', width: 60, height: 40, color: '#1F2937', icon: '⚡' },
    { name: 'DI Box', width: 20, height: 15, color: '#6B7280', icon: '📦' },
    { name: 'Cable Management', width: 25, height: 25, color: '#9CA3AF', icon: '🔌' },
  ],
  performers: [
    { name: 'Lead Vocalist', width: 30, height: 30, color: '#DC2626', icon: '👤' },
    { name: 'Background Vocalist', width: 25, height: 25, color: '#F59E0B', icon: '👤' },
    { name: 'Guitarist', width: 30, height: 30, color: '#059669', icon: '👤' },
    { name: 'Bassist', width: 30, height: 30, color: '#1E40AF', icon: '👤' },
    { name: 'Drummer', width: 30, height: 30, color: '#7C2D12', icon: '👤' },
    { name: 'Keyboardist', width: 30, height: 30, color: '#7C3AED', icon: '👤' },
  ]
};

interface StagePlotDesignerProps {
  bookingId?: number;
  onSave?: (stagePlot: StagePlot) => void;
  onLoad?: (stagePlot: StagePlot) => void;
  initialPlot?: StagePlot;
  userRole?: string;
  canEdit?: boolean;
  assignedUsers?: Array<{
    id: number;
    name: string;
    role: string;
    instruments?: string[];
    specializations?: string[];
  }>;
}

export default function StagePlotDesigner({
  bookingId,
  onSave,
  onLoad,
  initialPlot,
  userRole = 'fan',
  assignedUsers = [],
  canEdit = true
}: StagePlotDesignerProps) {
  const [stagePlot, setStagePlot] = useState<StagePlot>(
    initialPlot || {
      name: 'New Stage Plot',
      items: [],
      stageWidth: 800,
      stageHeight: 600
    }
  );
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [draggedItem, setDraggedItem] = useState<StageItem | null>(null);
  const [showGrid, setShowGrid] = useState(true);
  const [savedPlots, setSavedPlots] = useState<StagePlot[]>([]);
  const [templateName, setTemplateName] = useState('');
  const [isMobile, setIsMobile] = useState(false);
  
  const canvasRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const canManage = canEdit && (userRole === 'superadmin' || userRole === 'admin' || 
    userRole === 'managed_artist' || userRole === 'managed_musician');

  // Generate performer colors from assigned users
  const performerColors = [
    '#DC2626', '#F59E0B', '#059669', '#1E40AF', '#7C2D12', '#7C3AED',
    '#E11D48', '#0EA5E9', '#10B981', '#8B5CF6', '#F97316', '#06B6D4'
  ];

  // Generate assigned performers from booking users
  const assignedPerformers = assignedUsers.map((user, index) => {
    const primaryInstrument = user.instruments?.[0] || user.specializations?.[0] || 'Performer';
    return {
      name: `${user.name} (${primaryInstrument})`,
      width: 30,
      height: 30,
      color: performerColors[index % performerColors.length],
      icon: '👤',
      assignedUserId: user.id
    };
  });

  // Generate letter codes for legend
  const generateLetterCode = (index: number): string => {
    return String.fromCharCode(65 + (index % 26)); // A, B, C, ...
  };

  // Mobile detection and saved plots loading
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    const loadSavedPlots = async () => {
      try {
        const response = await apiRequest('/api/stage-plots');
        if (response.ok) {
          const plots = await response.json();
          setSavedPlots(plots);
        }
      } catch (error) {
        console.error('Failed to load stage plots:', error);
      }
    };
    
    loadSavedPlots();
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleDragStart = (e: React.DragEvent, itemType: string, itemName: string) => {
    const itemTemplate = Object.values(STAGE_ITEMS).flat().find(item => item.name === itemName);
    if (itemTemplate) {
      // Generate index for letter code based on current items count
      const currentItemIndex = stagePlot.items.length;
      
      const newItem: StageItem = {
        id: `${Date.now()}-${Math.random()}`,
        type: itemType as 'instrument' | 'equipment' | 'performer',
        name: itemName,
        x: 0,
        y: 0,
        width: itemTemplate.width,
        height: itemTemplate.height,
        rotation: 0,
        color: itemTemplate.color,
        icon: itemTemplate.icon,
        assignedUserId: undefined, // Will be set if this is a performer item
        letterCode: generateLetterCode(currentItemIndex)
      };
      setDraggedItem(newItem);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedItem || !canvasRef.current || !canManage) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newItem = {
      ...draggedItem,
      x: Math.max(0, Math.min(x - draggedItem.width / 2, stagePlot.stageWidth - draggedItem.width)),
      y: Math.max(0, Math.min(y - draggedItem.height / 2, stagePlot.stageHeight - draggedItem.height))
    };

    setStagePlot(prev => ({
      ...prev,
      items: [...prev.items, newItem]
    }));
    setDraggedItem(null);
  };

  const handleItemDrag = (itemId: string, newX: number, newY: number) => {
    if (!canManage) return;
    
    setStagePlot(prev => ({
      ...prev,
      items: prev.items.map(item =>
        item.id === itemId
          ? {
              ...item,
              x: Math.max(0, Math.min(newX, prev.stageWidth - item.width)),
              y: Math.max(0, Math.min(newY, prev.stageHeight - item.height))
            }
          : item
      )
    }));
  };

  const handleItemRotate = (itemId: string, direction: 'clockwise' | 'counterclockwise' = 'clockwise') => {
    if (!canManage) return;
    
    setStagePlot(prev => ({
      ...prev,
      items: prev.items.map(item =>
        item.id === itemId
          ? { ...item, rotation: direction === 'clockwise' 
              ? (item.rotation + 45) % 360 
              : (item.rotation - 45 + 360) % 360 }
          : item
      )
    }));
  };

  // Mobile directional controls
  const handleMobileMove = (itemId: string, direction: 'up' | 'down' | 'left' | 'right') => {
    if (!canManage) return;
    
    const moveDistance = 10;
    
    setStagePlot(prev => ({
      ...prev,
      items: prev.items.map(item => {
        if (item.id === itemId) {
          let newX = item.x;
          let newY = item.y;
          
          switch (direction) {
            case 'up':
              newY = Math.max(0, item.y - moveDistance);
              break;
            case 'down':
              newY = Math.min(prev.stageHeight - item.height, item.y + moveDistance);
              break;
            case 'left':
              newX = Math.max(0, item.x - moveDistance);
              break;
            case 'right':
              newX = Math.min(prev.stageWidth - item.width, item.x + moveDistance);
              break;
          }
          
          return { ...item, x: newX, y: newY };
        }
        return item;
      })
    }));
  };

  const handleItemDelete = (itemId: string) => {
    if (!canManage) return;
    
    const item = stagePlot.items.find(i => i.id === itemId);
    const itemName = item ? `${item.name}${item.letterCode ? ` (${item.letterCode})` : ''}` : 'this item';
    
    if (confirm(`Are you sure you want to remove "${itemName}" from the stage plot?`)) {
      setStagePlot(prev => ({
        ...prev,
        items: prev.items.filter(item => item.id !== itemId)
      }));
      setSelectedItem(null);
      
      toast({
        title: "Item Removed",
        description: `"${itemName}" has been removed from the stage plot`
      });
    }
  };

  const handleSavePlot = async () => {
    if (!canManage || !templateName.trim()) {
      toast({
        title: "Save Failed",
        description: "Please enter a template name",
        variant: "destructive"
      });
      return;
    }

    try {
      const plotToSave = {
        ...stagePlot,
        name: templateName,
        modifiedAt: new Date().toISOString()
      };

      // Check if name already exists and append number
      let finalName = templateName;
      let counter = 1;
      while (savedPlots.some(plot => plot.name === finalName)) {
        finalName = `${templateName}-${counter}`;
        counter++;
      }
      plotToSave.name = finalName;

      const response = await apiRequest('/api/stage-plots', {
        method: 'POST',
        body: JSON.stringify(plotToSave)
      });

      if (response.ok) {
        const saved = await response.json();
        setSavedPlots(prev => [...prev, saved]);
        setTemplateName('');
        toast({
          title: "Stage Plot Saved",
          description: `Template saved as "${finalName}"`
        });
      }
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Failed to save stage plot template",
        variant: "destructive"
      });
    }
  };

  const handleLoadPlot = (plot: StagePlot) => {
    const loadedPlot = {
      ...plot,
      id: undefined // Remove ID so it becomes a new plot when saved
    };
    setStagePlot(loadedPlot);
    setSelectedItem(null);
    
    // Notify parent about load action
    if (onLoad) {
      onLoad(loadedPlot);
    }
    
    toast({
      title: "Template Loaded",
      description: `Loaded "${plot.name}" - modify and save with new name`
    });
  };

  const clearStageLayout = () => {
    if (window.confirm('Are you sure you want to clear the entire stage layout? This action cannot be undone.')) {
      setStagePlot(prev => ({
        ...prev,
        items: []
      }));
      setSelectedItem(null);
      toast({
        title: "Stage Cleared",
        description: "All items have been removed from the stage"
      });
    }
  };

  const deletePlot = async (plot: any) => {
    const confirmed = window.confirm(
      `Are you sure you want to delete the stage plot template "${plot.name}"? This action cannot be undone.`
    );
    
    if (!confirmed) return;

    try {
      const response = await apiRequest(`/api/stage-plots/${plot.id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setSavedPlots(prev => prev.filter(p => p.id !== plot.id));
        toast({
          title: "Template Deleted",
          description: `Stage plot template "${plot.name}" has been deleted`
        });
      } else {
        throw new Error('Failed to delete template');
      }
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: "Failed to delete stage plot template",
        variant: "destructive"
      });
    }
  };

  const updateItemLabel = (itemId: string, newLabel: string) => {
    setStagePlot(prev => ({
      ...prev,
      items: prev.items.map(item =>
        item.id === itemId ? { ...item, displayName: newLabel } : item
      )
    }));
    setEditingLabel(null);
    setLabelEditValue('');
  };

  const startEditingLabel = (itemId: string, currentName: string) => {
    setEditingLabel(itemId);
    setLabelEditValue(currentName);
  };

  const handleExportPNG = async () => {
    try {
      // Create canvas for export
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      canvas.width = stagePlot.stageWidth;
      canvas.height = stagePlot.stageHeight;

      // Draw stage background
      ctx.fillStyle = '#f3f4f6';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw stage border
      ctx.strokeStyle = '#374151';
      ctx.lineWidth = 2;
      ctx.strokeRect(0, 0, canvas.width, canvas.height);

      // Draw grid if enabled
      if (showGrid) {
        ctx.strokeStyle = '#e5e7eb';
        ctx.lineWidth = 0.5;
        for (let x = 0; x <= canvas.width; x += 20) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, canvas.height);
          ctx.stroke();
        }
        for (let y = 0; y <= canvas.height; y += 20) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(canvas.width, y);
          ctx.stroke();
        }
      }

      // Draw stage items with letter codes
      stagePlot.items.forEach(item => {
        ctx.save();
        ctx.translate(item.x + item.width / 2, item.y + item.height / 2);
        ctx.rotate(item.rotation * Math.PI / 180);
        ctx.fillStyle = item.color;
        ctx.fillRect(-item.width / 2, -item.height / 2, item.width, item.height);
        
        // Add letter code
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 16px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(item.letterCode || '', 0, 5);
        ctx.restore();
      });

      // Convert to blob and download
      canvas.toBlob(blob => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${stagePlot.name || 'stage-plot'}.png`;
          a.click();
          URL.revokeObjectURL(url);
          
          toast({
            title: "Stage Plot Exported",
            description: "PNG image downloaded successfully"
          });
        }
      }, 'image/png');
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export stage plot image",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Music className="h-5 w-5" />
            Stage Plot Designer
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
            {/* Item Palette - Original Size */}
            <div className="space-y-3">
              <div>
                <Label className="text-sm font-semibold">Instruments</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {STAGE_ITEMS.instruments.map(item => (
                    <div
                      key={item.name}
                      draggable={canManage}
                      onDragStart={(e) => handleDragStart(e, 'instrument', item.name)}
                      className={`p-2 border rounded cursor-move text-center text-xs ${
                        canManage ? 'hover:bg-gray-50' : 'opacity-60 cursor-not-allowed'
                      }`}
                      style={{ backgroundColor: `${item.color}20` }}
                    >
                      <div className="text-lg">{item.icon}</div>
                      <div className="truncate">{item.name}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-xs font-medium">Equipment</Label>
                <div className="grid grid-cols-3 gap-1 mt-2">
                  {STAGE_ITEMS.equipment.map(item => (
                    <div
                      key={item.name}
                      draggable={canManage}
                      onDragStart={(e) => handleDragStart(e, 'equipment', item.name)}
                      className={`p-1 border rounded cursor-move text-center text-xs ${
                        canManage ? 'hover:bg-gray-50' : 'opacity-60 cursor-not-allowed'
                      }`}
                      style={{ backgroundColor: `${item.color}20` }}
                    >
                      <div className="text-sm">{item.icon}</div>
                      <div className="truncate text-xs">{item.name}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-xs font-medium">Performers</Label>
                <div className="grid grid-cols-3 gap-1 mt-2">
                  {STAGE_ITEMS.performers.map(item => (
                    <div
                      key={item.name}
                      draggable={canManage}
                      onDragStart={(e) => handleDragStart(e, 'performer', item.name)}
                      className={`p-1 border rounded cursor-move text-center text-xs ${
                        canManage ? 'hover:bg-gray-50' : 'opacity-60 cursor-not-allowed'
                      }`}
                      style={{ backgroundColor: `${item.color}20` }}
                    >
                      <div className="text-sm">{item.icon}</div>
                      <div className="truncate text-xs">{item.name}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Stage Canvas - Much Wider */}
            <div className="lg:col-span-3">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <Label className="text-sm font-semibold">Stage Layout</Label>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowGrid(!showGrid)}
                    >
                      <Grid3X3 className="h-4 w-4" />
                    </Button>
                    {canManage && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleExportPNG}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>

                <div
                  ref={canvasRef}
                  className="relative border-2 border-gray-300 bg-gray-50 overflow-hidden"
                  style={{ width: `${Math.min(stagePlot.stageWidth, 600)}px`, height: `${Math.min(stagePlot.stageHeight, 400)}px` }}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleDrop}
                >
                  {/* Grid */}
                  {showGrid && (
                    <div className="absolute inset-0 opacity-20">
                      <svg width="100%" height="100%">
                        <defs>
                          <pattern
                            id="grid"
                            width="20"
                            height="20"
                            patternUnits="userSpaceOnUse"
                          >
                            <path
                              d="M 20 0 L 0 0 0 20"
                              fill="none"
                              stroke="#374151"
                              strokeWidth="0.5"
                            />
                          </pattern>
                        </defs>
                        <rect width="100%" height="100%" fill="url(#grid)" />
                      </svg>
                    </div>
                  )}

                  {/* Stage Items */}
                  {stagePlot.items.map(item => (
                    <div
                      key={item.id}
                      className={`absolute cursor-pointer border-2 rounded flex items-center justify-center text-xs font-semibold text-white ${
                        selectedItem === item.id ? 'border-blue-500' : 'border-gray-400'
                      } ${canManage ? 'hover:border-blue-400' : ''}`}
                      style={{
                        left: item.x,
                        top: item.y,
                        width: item.width,
                        height: item.height,
                        backgroundColor: item.color,
                        transform: `rotate(${item.rotation}deg)`,
                        fontSize: Math.min(item.width, item.height) / 8 + 'px'
                      }}
                      onClick={() => canManage && setSelectedItem(item.id)}
                      onMouseDown={(e) => {
                        if (!canManage || isMobile) return;
                        e.preventDefault();
                        const startX = e.clientX - item.x;
                        const startY = e.clientY - item.y;

                        const handleMouseMove = (moveE: MouseEvent) => {
                          const newX = Math.max(0, Math.min(stagePlot.stageWidth - item.width, moveE.clientX - startX));
                          const newY = Math.max(0, Math.min(stagePlot.stageHeight - item.height, moveE.clientY - startY));
                          
                          setStagePlot(prev => ({
                            ...prev,
                            items: prev.items.map(stageItem =>
                              stageItem.id === item.id ? { ...stageItem, x: newX, y: newY } : stageItem
                            )
                          }));
                        };

                        const handleMouseUp = () => {
                          document.removeEventListener('mousemove', handleMouseMove);
                          document.removeEventListener('mouseup', handleMouseUp);
                        };

                        document.addEventListener('mousemove', handleMouseMove);
                        document.addEventListener('mouseup', handleMouseUp);
                      }}
                      onTouchStart={(e) => {
                        if (!canManage || !isMobile) return;
                        e.preventDefault();
                        
                        // Long press timer for selection
                        const longPressTimer = setTimeout(() => {
                          setSelectedItem(item.id);
                          // Provide haptic feedback if available
                          if (navigator.vibrate) {
                            navigator.vibrate(50);
                          }
                        }, 500);

                        const handleTouchEnd = () => {
                          clearTimeout(longPressTimer);
                          document.removeEventListener('touchend', handleTouchEnd);
                        };

                        document.addEventListener('touchend', handleTouchEnd);
                      }}
                    >
                      <div className="text-center">
                        <div className="text-lg">{item.icon}</div>
                        <div className="truncate">{item.name}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Legend Area - Only show items on canvas */}
                {stagePlot.items.length > 0 && (
                  <div className="mt-4">
                    <Label className="text-sm font-medium mb-2 block">Legend - Items on Stage</Label>
                    <div className="flex flex-wrap gap-3 text-xs">
                      {[...new Set(stagePlot.items.map(item => item.name))].map(itemName => {
                        const stageItem = stagePlot.items.find(item => item.name === itemName);
                        if (!stageItem) return null;
                        
                        return (
                          <div key={itemName} className="flex items-center gap-2">
                            <div 
                              className="w-4 h-4 rounded border flex items-center justify-center text-xs"
                              style={{ backgroundColor: stageItem.color }}
                            >
                              <span className="text-white">{stageItem.icon}</span>
                            </div>
                            <span className="truncate">{itemName}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Clear Stage Layout Button - Below legend */}
                {canManage && stagePlot.items.length > 0 && (
                  <div className="mt-4">
                    <Button
                      onClick={clearStageLayout}
                      variant="destructive"
                      size="sm"
                    >
                      <Eraser className="h-4 w-4 mr-2" />
                      Clear Stage Layout
                    </Button>
                  </div>
                )}

                {selectedItem && canManage && (
                  <div className="mt-4 p-4 border rounded-lg bg-gray-50">
                    <Label className="text-sm font-medium mb-3 block">
                      Selected Item Controls
                    </Label>
                    
                    {/* Mobile and Desktop Directional Controls */}
                    <div className="space-y-4">
                      {/* Movement Controls */}
                      <div>
                        <Label className="text-xs text-gray-600 mb-2 block">Movement</Label>
                        <div className="grid grid-cols-3 gap-1 w-fit mx-auto">
                          <div></div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleMobileMove(selectedItem, 'up')}
                            className="h-10 w-10 p-0"
                          >
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <div></div>
                          
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleMobileMove(selectedItem, 'left')}
                            className="h-10 w-10 p-0"
                          >
                            <ArrowLeft className="h-4 w-4" />
                          </Button>
                          <div className="flex items-center justify-center text-xs text-gray-500">
                            Move
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleMobileMove(selectedItem, 'right')}
                            className="h-10 w-10 p-0"
                          >
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                          
                          <div></div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleMobileMove(selectedItem, 'down')}
                            className="h-10 w-10 p-0"
                          >
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                          <div></div>
                        </div>
                      </div>

                      {/* Rotation Controls */}
                      <div>
                        <Label className="text-xs text-gray-600 mb-2 block">Rotation</Label>
                        <div className="flex gap-2 justify-center">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleItemRotate(selectedItem, 'counterclockwise')}
                            className="flex items-center gap-1"
                          >
                            <RotateCcw className="h-4 w-4" />
                            <span className="text-xs">CCW</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleItemRotate(selectedItem, 'clockwise')}
                            className="flex items-center gap-1"
                          >
                            <RotateCw className="h-4 w-4" />
                            <span className="text-xs">CW</span>
                          </Button>
                        </div>
                      </div>

                      {/* Delete Control */}
                      <div className="pt-2 border-t">
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleItemDelete(selectedItem)}
                          className="w-full flex items-center gap-2"
                        >
                          <Trash2 className="h-4 w-4" />
                          Delete Item
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Templates & Controls - Much Narrower */}
            <div className="lg:col-span-1 space-y-2">
              {canManage && (
                <div>
                  <Label className="text-xs font-medium">Save Template</Label>
                  <div className="space-y-2 mt-1">
                    <Input
                      value={templateName}
                      onChange={(e) => setTemplateName(e.target.value)}
                      placeholder="Template name"
                      className="h-8 text-sm"
                    />
                    <Button
                      onClick={handleSavePlot}
                      disabled={!templateName.trim()}
                      className="w-full h-7 text-xs px-2"
                    >
                      <Save className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              )}

              <div>
                <Label className="text-xs font-medium">Load Template</Label>
                <div className="space-y-1 mt-1">
                  {savedPlots.map(plot => (
                    <div key={plot.id} className="flex gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 justify-start h-7 text-xs px-1"
                        onClick={() => handleLoadPlot(plot)}
                      >
                        <Upload className="h-3 w-3" />
                        <span className="truncate ml-1">{plot.name}</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deletePlot(plot)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 h-7 w-7 p-0"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                  {savedPlots.length === 0 && (
                    <p className="text-xs text-gray-500">No saved templates</p>
                  )}
                </div>
              </div>


            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}