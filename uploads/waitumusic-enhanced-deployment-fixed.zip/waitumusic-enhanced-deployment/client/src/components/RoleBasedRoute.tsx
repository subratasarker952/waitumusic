import { ReactNode } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';

interface RoleBasedRouteProps {
  children: ReactNode;
  allowedRoles: string[];
  fallback?: ReactNode;
}

export default function RoleBasedRoute({ 
  children, 
  allowedRoles, 
  fallback 
}: RoleBasedRouteProps) {
  const { user, role, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return fallback || (
      <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="flex mb-4 gap-2">
              <AlertCircle className="h-8 w-8 text-red-500" />
              <h1 className="text-2xl font-bold text-gray-900">Authentication Required</h1>
            </div>
            <p className="mt-4 text-sm text-gray-600">
              Please log in to access this page.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Debug logging for role issues (development only)
  if (process.env.NODE_ENV === 'development') {
    console.log('RoleBasedRoute Debug:', { 
      user, 
      role, 
      roleType: typeof role, 
      roleName: role?.name || role,
      allowedRoles,
      hasAccess: role ? allowedRoles.includes(role.name || role) : false
    });
  }

  const userRole = role?.name || role;
  
  if (role && !allowedRoles.includes(userRole)) {
    return fallback || (
      <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="flex mb-4 gap-2">
              <AlertCircle className="h-8 w-8 text-orange-500" />
              <h1 className="text-2xl font-bold text-gray-900">Access Denied</h1>
            </div>
            <p className="mt-4 text-sm text-gray-600">
              You don't have permission to access this page.
            </p>
            {process.env.NODE_ENV === 'development' && (
              <div className="mt-4 p-2 bg-gray-100 rounded text-xs">
                <p>Debug Info:</p>
                <p>Your role: {userRole}</p>
                <p>Required roles: {allowedRoles.join(', ')}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
}
