import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Brain, Target, TrendingUp, Users, Calendar, BarChart3, Zap, Globe, Crown } from "lucide-react";
import type { SocialMediaCampaign, InsertSocialMediaCampaign, CareerForecasting, CompetitiveIntelligence } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/contexts/AuthContext";

export default function AICompanion() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("campaigns");

  // Check if user is admin or superadmin
  const isAdminOrSuperadmin = user?.roleId === 1 || user?.roleId === 2;

  // Social Media Campaigns
  const { data: campaigns, isLoading: campaignsLoading } = useQuery<SocialMediaCampaign[]>({
    queryKey: ["/api/social-media-campaigns"],
  });

  // Career Forecasting
  const { data: forecasting, isLoading: forecastingLoading } = useQuery<CareerForecasting[]>({
    queryKey: ["/api/career-forecasting"],
  });

  // Competitive Intelligence
  const { data: intelligence, isLoading: intelligenceLoading } = useQuery<CompetitiveIntelligence[]>({
    queryKey: ["/api/competitive-intelligence"],
  });

  const createCampaignMutation = useMutation({
    mutationFn: (data: InsertSocialMediaCampaign) => 
      apiRequest("/api/social-media-campaigns", { method: "POST", body: data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/social-media-campaigns"] });
      toast({ title: "Campaign created successfully" });
    },
    onError: () => {
      toast({ title: "Failed to create campaign", variant: "destructive" });
    },
  });

  const [newCampaign, setNewCampaign] = useState<Partial<InsertSocialMediaCampaign>>({
    campaignName: "",
    objectives: [],
    platforms: ["Instagram", "Twitter", "TikTok", "YouTube", "Facebook", "LinkedIn"], // Default all selected
    status: "draft",
  });

  const [campaignType, setCampaignType] = useState("");

  const handleCreateCampaign = () => {
    if (!newCampaign.campaignName || !campaignType) {
      toast({ title: "Please fill in required fields", variant: "destructive" });
      return;
    }
    
    const campaignData: Partial<InsertSocialMediaCampaign> = {
      campaignName: newCampaign.campaignName,
      objectives: [campaignType],
      platforms: newCampaign.platforms || ["Instagram", "Twitter", "TikTok", "YouTube", "Facebook", "LinkedIn"],
      status: newCampaign.status || "draft",
      targetAudience: campaignType === "Brand Partnership" ? {
        demographics: { ageRange: "18-35", interests: ["music", "entertainment"] }
      } : undefined,
      campaignStrategy: {
        contentPillars: ["music", "engagement", "growth"],
        contentTypes: ["posts", "stories", "reels"]
      }
    };
    
    console.log('Sending campaign data:', campaignData);
    createCampaignMutation.mutate(campaignData as InsertSocialMediaCampaign);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-4">
              AI Companion Suite
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Leverage artificial intelligence to supercharge your music career with data-driven insights, 
              automated campaigns, and strategic forecasting.
            </p>
          </div>

          {/* Feature Overview Cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="border-purple-200 dark:border-purple-800">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Brain className="h-6 w-6 text-purple-600" />
                  <CardTitle>Smart Campaigns</CardTitle>
                </div>
                <CardDescription>
                  AI-powered social media campaign management with automated scheduling and optimization
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-blue-200 dark:border-blue-800">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-6 w-6 text-blue-600" />
                  <CardTitle>Career Forecasting</CardTitle>
                </div>
                <CardDescription>
                  Predict future opportunities and plan strategic career moves based on market analysis
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-indigo-200 dark:border-indigo-800">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Target className="h-6 w-6 text-indigo-600" />
                  <CardTitle>Market Intelligence</CardTitle>
                </div>
                <CardDescription>
                  Competitive analysis and market insights to position yourself ahead of the competition
                </CardDescription>
              </CardHeader>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="campaigns" className="flex items-center space-x-2">
                <Brain className="h-4 w-4" />
                <span>Campaigns</span>
              </TabsTrigger>
              <TabsTrigger value="forecasting" className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4" />
                <span>Forecasting</span>
              </TabsTrigger>
              <TabsTrigger value="intelligence" className="flex items-center space-x-2">
                <Target className="h-4 w-4" />
                <span>Intelligence</span>
              </TabsTrigger>
              <TabsTrigger value="insights" className="flex items-center space-x-2">
                <BarChart3 className="h-4 w-4" />
                <span>Insights</span>
              </TabsTrigger>
            </TabsList>

            {/* Social Media Campaigns Tab */}
            <TabsContent value="campaigns" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Zap className="h-5 w-5 text-yellow-500" />
                    <span>AI-Powered Social Media Campaigns</span>
                  </CardTitle>
                  <CardDescription>
                    Create and manage intelligent social media campaigns that adapt to your audience
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Create New Campaign Form */}
                  <div className="space-y-4 mb-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="campaignName">Campaign Name</Label>
                        <Input
                          id="campaignName"
                          placeholder="Enter campaign name..."
                          value={newCampaign.campaignName || ""}
                          onChange={(e) => setNewCampaign(prev => ({ ...prev, campaignName: e.target.value }))}
                        />
                      </div>
                      <div>
                        <Label htmlFor="campaignType">Campaign Type</Label>
                        {isAdminOrSuperadmin && (
                          <div className="flex items-center gap-2 mb-2">
                            <Crown className="h-4 w-4 text-amber-500" />
                            <span className="text-sm text-amber-600 dark:text-amber-400">
                              Admin/Superadmin - Create Custom Campaign Types
                            </span>
                          </div>
                        )}
                        <Select
                          value={campaignType}
                          onValueChange={setCampaignType}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select campaign type..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="album_release">Album Release</SelectItem>
                            <SelectItem value="tour_promotion">Tour Promotion</SelectItem>
                            <SelectItem value="brand_awareness">Brand Awareness</SelectItem>
                            <SelectItem value="fan_engagement">Fan Engagement</SelectItem>
                            <SelectItem value="collaboration">Collaboration</SelectItem>
                            {isAdminOrSuperadmin && (
                              <>
                                <SelectItem value="artist_development">Artist Development</SelectItem>
                                <SelectItem value="platform_growth">Platform Growth</SelectItem>
                                <SelectItem value="market_expansion">Market Expansion</SelectItem>
                                <SelectItem value="cross_promotion">Cross Promotion</SelectItem>
                                <SelectItem value="talent_acquisition">Talent Acquisition</SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                        {!isAdminOrSuperadmin && (
                          <p className="text-sm text-muted-foreground mt-1">
                            Additional campaign types available for admins
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="platforms">Target Platforms</Label>
                      <p className="text-sm text-muted-foreground mb-2">
                        Click to select/deselect platforms. All platforms are selected by default.
                      </p>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {["Instagram", "Twitter", "TikTok", "YouTube", "Facebook", "LinkedIn"].map((platform) => (
                          <Badge
                            key={platform}
                            variant={
                              (newCampaign.platforms as string[] || []).includes(platform) 
                                ? "default" 
                                : "outline"
                            }
                            className="cursor-pointer transition-colors"
                            onClick={() => {
                              const platforms = (newCampaign.platforms as string[]) || [];
                              const updated = platforms.includes(platform)
                                ? platforms.filter(p => p !== platform)
                                : [...platforms, platform];
                              setNewCampaign(prev => ({ ...prev, platforms: updated }));
                            }}
                          >
                            {platform}
                            {(newCampaign.platforms as string[] || []).includes(platform) && " ✓"}
                          </Badge>
                        ))}
                      </div>
                      <div className="mt-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const allPlatforms = ["Instagram", "Twitter", "TikTok", "YouTube", "Facebook", "LinkedIn"];
                            const currentPlatforms = (newCampaign.platforms as string[]) || [];
                            const allSelected = allPlatforms.every(p => currentPlatforms.includes(p));
                            setNewCampaign(prev => ({ 
                              ...prev, 
                              platforms: allSelected ? [] : allPlatforms 
                            }));
                          }}
                        >
                          {(newCampaign.platforms as string[] || []).length === 6 ? "Deselect All" : "Select All"}
                        </Button>
                      </div>
                    </div>

                    <Button 
                      onClick={handleCreateCampaign}
                      disabled={createCampaignMutation.isPending}
                      className="w-full md:w-auto"
                    >
                      {createCampaignMutation.isPending ? "Creating..." : "Create Campaign"}
                    </Button>
                  </div>

                  <Separator className="my-6" />

                  {/* Existing Campaigns */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center space-x-2">
                      <Calendar className="h-5 w-5" />
                      <span>Active Campaigns</span>
                    </h3>
                    {campaignsLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div>
                        <p className="mt-2 text-gray-600 dark:text-gray-300">Loading campaigns...</p>
                      </div>
                    ) : campaigns?.length === 0 ? (
                      <div className="text-center py-8">
                        <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600 dark:text-gray-300">No campaigns yet. Create your first AI-powered campaign above!</p>
                      </div>
                    ) : (
                      <div className="grid gap-4">
                        {campaigns?.map((campaign) => (
                          <Card key={campaign.id} className="border-l-4 border-l-purple-500">
                            <CardContent className="pt-4">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h4 className="font-semibold text-lg">{campaign.campaignName}</h4>
                                  <p className="text-gray-600 dark:text-gray-300">
                                    {campaign.objectives && Array.isArray(campaign.objectives) 
                                      ? campaign.objectives.join(', ') 
                                      : 'Campaign objectives'}
                                  </p>
                                  <div className="flex space-x-2 mt-2">
                                    {Array.isArray(campaign.platforms) && campaign.platforms.map((platform: string) => (
                                      <Badge key={platform} variant="secondary">{platform}</Badge>
                                    ))}
                                  </div>
                                </div>
                                <Badge variant={campaign.status === 'active' ? 'default' : 'outline'}>
                                  {campaign.status}
                                </Badge>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Career Forecasting Tab */}
            <TabsContent value="forecasting" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-green-500" />
                    <span>Career Forecasting & Strategic Planning</span>
                  </CardTitle>
                  <CardDescription>
                    AI-driven insights to predict and plan your career trajectory
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {forecastingLoading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
                      <p className="mt-2 text-gray-600 dark:text-gray-300">Analyzing career data...</p>
                    </div>
                  ) : forecasting?.length === 0 ? (
                    <div className="text-center py-8">
                      <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 dark:text-gray-300">No forecasting data available yet. Our AI is learning your patterns...</p>
                      <Button className="mt-4">Generate First Forecast</Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {forecasting?.map((forecast) => (
                        <Card key={forecast.id} className="border-l-4 border-l-green-500">
                          <CardContent className="pt-4">
                            <h4 className="font-semibold text-lg">{forecast.forecastPeriod}</h4>
                            <p className="text-gray-600 dark:text-gray-300">
                              Confidence Score: {forecast.confidenceScore}%
                            </p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Competitive Intelligence Tab */}
            <TabsContent value="intelligence" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5 text-red-500" />
                    <span>Market Intelligence & Competitive Analysis</span>
                  </CardTitle>
                  <CardDescription>
                    Stay ahead of the competition with AI-powered market insights
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {intelligenceLoading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mx-auto"></div>
                      <p className="mt-2 text-gray-600 dark:text-gray-300">Gathering market intelligence...</p>
                    </div>
                  ) : intelligence?.length === 0 ? (
                    <div className="text-center py-8">
                      <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 dark:text-gray-300">No competitive analysis available yet. Let our AI scout the market for you...</p>
                      <Button className="mt-4">Start Market Analysis</Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {intelligence?.map((intel) => (
                        <Card key={intel.id} className="border-l-4 border-l-red-500">
                          <CardContent className="pt-4">
                            <h4 className="font-semibold text-lg">
                              Market Analysis - {intel.region}
                            </h4>
                            <p className="text-gray-600 dark:text-gray-300">
                              Analysis Type: {intel.analysisType}
                            </p>
                            <Badge variant="outline" className="mt-2">{intel.region}</Badge>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* AI Insights Tab */}
            <TabsContent value="insights" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-blue-500" />
                    <span>AI-Generated Insights & Recommendations</span>
                  </CardTitle>
                  <CardDescription>
                    Personalized recommendations based on your performance data and market trends
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-300">
                      AI insights are being generated based on your activity. Check back soon for personalized recommendations!
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}