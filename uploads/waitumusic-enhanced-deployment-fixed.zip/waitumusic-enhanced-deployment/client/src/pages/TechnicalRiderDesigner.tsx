import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Mic, Speaker, Music, Settings, Download, Upload, Save, Eye } from 'lucide-react';

interface StageElement {
  id: string;
  type: 'instrument' | 'mic' | 'speaker' | 'monitor' | 'equipment';
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
}

interface MixerChannel {
  channel: number;
  instrument: string;
  inputType: string;
  phantom: boolean;
  gain: string;
  eq: { high: string; mid: string; low: string };
  aux: string[];
  assigned: boolean;
}

interface SetlistItem {
  id: string;
  songTitle: string;
  artist: string;
  key: string;
  tempo: string;
  duration: string;
  notes: string;
  transitions: string;
}

export default function TechnicalRiderDesigner() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedTool, setSelectedTool] = useState<string>('select');
  const [stageElements, setStageElements] = useState<StageElement[]>([]);
  const [mixerChannels, setMixerChannels] = useState<MixerChannel[]>([]);
  const [setlist, setSetlist] = useState<SetlistItem[]>([]);
  const [stageSize, setStageSize] = useState({ width: '40', height: '30' });
  const [bookingId, setBookingId] = useState<number>(1);
  
  // Initialize mixer channels (32 channels)
  useEffect(() => {
    const channels: MixerChannel[] = [];
    for (let i = 1; i <= 32; i++) {
      channels.push({
        channel: i,
        instrument: '',
        inputType: 'XLR',
        phantom: false,
        gain: '0dB',
        eq: { high: '0dB', mid: '0dB', low: '0dB' },
        aux: ['0', '0', '0', '0'],
        assigned: false
      });
    }
    setMixerChannels(channels);
  }, []);

  // Canvas drawing functions
  const drawStage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw stage outline
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.strokeRect(20, 20, parseInt(stageSize.width) * 10, parseInt(stageSize.height) * 10);

    // Draw stage elements
    stageElements.forEach((element) => {
      ctx.fillStyle = element.color;
      ctx.fillRect(element.x, element.y, element.width, element.height);
      
      // Add label
      ctx.fillStyle = '#000';
      ctx.font = '12px Arial';
      ctx.fillText(element.name, element.x + 2, element.y + 15);
    });
  };

  useEffect(() => {
    drawStage();
  }, [stageElements, stageSize]);

  // Add stage element
  const addStageElement = (type: StageElement['type']) => {
    const newElement: StageElement = {
      id: Date.now().toString(),
      type,
      name: type.charAt(0).toUpperCase() + type.slice(1),
      x: 50 + Math.random() * 200,
      y: 50 + Math.random() * 150,
      width: type === 'mic' ? 20 : type === 'speaker' ? 40 : 60,
      height: type === 'mic' ? 20 : type === 'speaker' ? 30 : 40,
      color: type === 'instrument' ? '#8B4513' : type === 'mic' ? '#FF6B6B' : type === 'speaker' ? '#4ECDC4' : '#45B7D1'
    };
    setStageElements([...stageElements, newElement]);
  };

  // Update mixer channel
  const updateMixerChannel = (index: number, field: keyof MixerChannel, value: any) => {
    const updated = [...mixerChannels];
    if (field === 'eq') {
      updated[index].eq = { ...updated[index].eq, ...value };
    } else if (field === 'aux') {
      updated[index].aux = value;
    } else {
      (updated[index] as any)[field] = value;
    }
    setMixerChannels(updated);
  };

  // Add setlist item
  const addSetlistItem = () => {
    const newItem: SetlistItem = {
      id: Date.now().toString(),
      songTitle: '',
      artist: '',
      key: 'C',
      tempo: '120 BPM',
      duration: '3:30',
      notes: '',
      transitions: ''
    };
    setSetlist([...setlist, newItem]);
  };

  // Update setlist item
  const updateSetlistItem = (id: string, field: keyof SetlistItem, value: string) => {
    setSetlist(setlist.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  // Save technical rider
  const saveTechnicalRider = async () => {
    try {
      const riderData = {
        bookingId,
        stageName: `Stage Design - ${new Date().toLocaleDateString()}`,
        stage_dimensions: { width: stageSize.width, height: stageSize.height },
        stage_layout: stageElements,
        mixer_configuration: mixerChannels.filter(ch => ch.assigned),
        setlist_data: setlist,
        created_by: 24 // Current user ID
      };

      const response = await fetch('/api/technical-rider/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(riderData)
      });

      if (response.ok) {
        alert('Technical rider saved successfully!');
      } else {
        alert('Failed to save technical rider');
      }
    } catch (error) {
      console.error('Error saving technical rider:', error);
      alert('Error saving technical rider');
    }
  };

  // Generate technical rider document
  const generateTechnicalRider = () => {
    const assignedChannels = mixerChannels.filter(ch => ch.assigned);
    const totalEquipment = stageElements.length;
    const totalDuration = setlist.reduce((total, item) => {
      const minutes = parseInt(item.duration.split(':')[0] || '0');
      const seconds = parseInt(item.duration.split(':')[1] || '0');
      return total + (minutes * 60) + seconds;
    }, 0);

    const riderText = `
TECHNICAL RIDER - WAI'TUMUSIC PERFORMANCE

Date: ${new Date().toLocaleDateString()}
Booking ID: ${bookingId}

STAGE SPECIFICATIONS:
- Stage Size: ${stageSize.width}ft x ${stageSize.height}ft
- Total Equipment Items: ${totalEquipment}
- Stage Layout: Custom design with positioned equipment

AUDIO REQUIREMENTS:
- Mixer Channels Required: ${assignedChannels.length} of 32
- Input Requirements:
${assignedChannels.map(ch => `  Channel ${ch.channel}: ${ch.instrument} (${ch.inputType}${ch.phantom ? ' +48V' : ''})`).join('\n')}

SETLIST INFORMATION:
- Total Songs: ${setlist.length}
- Estimated Duration: ${Math.floor(totalDuration / 60)}:${(totalDuration % 60).toString().padStart(2, '0')}
- Song List:
${setlist.map((song, idx) => `  ${idx + 1}. ${song.songTitle || 'Untitled'} - ${song.artist || 'TBA'} (${song.key}, ${song.tempo})`).join('\n')}

EQUIPMENT PLACEMENT:
${stageElements.map(el => `- ${el.name} (${el.type}): Position ${el.x},${el.y}`).join('\n')}

Generated by Wai'tuMusic Technical Rider Designer
Contact: technical@waitumusic.com
    `;

    // Create downloadable document
    const blob = new Blob([riderText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `technical-rider-booking-${bookingId}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-gray-900">
            Technical Rider Designer
          </h1>
          <p className="text-xl text-gray-600">
            Complete technical rider creation system with stage plot, mixer configuration, and setlist management
          </p>
          <div className="flex justify-center space-x-4">
            <Button onClick={saveTechnicalRider} className="bg-green-600 hover:bg-green-700">
              <Save className="w-4 h-4 mr-2" />
              Save Rider
            </Button>
            <Button onClick={generateTechnicalRider} variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Download Document
            </Button>
          </div>
        </div>

        {/* Main Technical Rider Interface */}
        <Tabs defaultValue="stageplot" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="stageplot">Stage Plot Designer</TabsTrigger>
            <TabsTrigger value="mixer">Mixer & Patch</TabsTrigger>
            <TabsTrigger value="setlist">Setlist Builder</TabsTrigger>
            <TabsTrigger value="overview">Technical Rider Overview</TabsTrigger>
          </TabsList>

          {/* Stage Plot Designer */}
          <TabsContent value="stageplot" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="w-5 h-5 mr-2" />
                  Stage Plot Designer
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-3 gap-6">
                  {/* Stage Configuration */}
                  <div className="space-y-4">
                    <h3 className="font-semibold">Stage Configuration</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium">Stage Width (ft)</label>
                        <Input
                          type="number"
                          value={stageSize.width}
                          onChange={(e) => setStageSize({...stageSize, width: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Stage Height (ft)</label>
                        <Input
                          type="number"
                          value={stageSize.height}
                          onChange={(e) => setStageSize({...stageSize, height: e.target.value})}
                        />
                      </div>
                    </div>

                    <h3 className="font-semibold mt-6">Add Equipment</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addStageElement('instrument')}
                      >
                        <Music className="w-4 h-4 mr-1" />
                        Instrument
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addStageElement('mic')}
                      >
                        <Mic className="w-4 h-4 mr-1" />
                        Microphone
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addStageElement('speaker')}
                      >
                        <Speaker className="w-4 h-4 mr-1" />
                        Speaker
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addStageElement('equipment')}
                      >
                        <Settings className="w-4 h-4 mr-1" />
                        Equipment
                      </Button>
                    </div>

                    <div className="mt-4">
                      <h4 className="font-medium mb-2">Equipment List</h4>
                      <div className="space-y-1 max-h-40 overflow-y-auto">
                        {stageElements.map((element) => (
                          <div key={element.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span className="text-sm">{element.name}</span>
                            <Badge variant="outline">{element.type}</Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Stage Canvas */}
                  <div className="lg:col-span-2">
                    <div className="border-2 border-gray-300 rounded-lg p-4 bg-white">
                      <h3 className="font-semibold mb-4">Stage Layout</h3>
                      <canvas
                        ref={canvasRef}
                        width={600}
                        height={400}
                        className="border border-gray-200 cursor-crosshair"
                        style={{ width: '100%', maxWidth: '600px' }}
                      />
                      <div className="mt-2 text-sm text-gray-600">
                        Click "Add Equipment" buttons to place items on stage. Items appear randomly and can be repositioned.
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mixer & Patch */}
          <TabsContent value="mixer" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>32-Channel Mixer Configuration</CardTitle>
                <p className="text-sm text-gray-600">Configure input channels and routing for your performance</p>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[1200px] text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Ch</th>
                        <th className="text-left p-2">Instrument</th>
                        <th className="text-left p-2">Input</th>
                        <th className="text-left p-2">+48V</th>
                        <th className="text-left p-2">Gain</th>
                        <th className="text-left p-2">High</th>
                        <th className="text-left p-2">Mid</th>
                        <th className="text-left p-2">Low</th>
                        <th className="text-left p-2">Aux 1</th>
                        <th className="text-left p-2">Aux 2</th>
                        <th className="text-left p-2">Assigned</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mixerChannels.slice(0, 16).map((channel, index) => (
                        <tr key={channel.channel} className="border-b">
                          <td className="p-2 font-medium">{channel.channel}</td>
                          <td className="p-2">
                            <Input
                              value={channel.instrument}
                              onChange={(e) => updateMixerChannel(index, 'instrument', e.target.value)}
                              placeholder="Instrument name"
                              className="w-32"
                            />
                          </td>
                          <td className="p-2">
                            <select
                              value={channel.inputType}
                              onChange={(e) => updateMixerChannel(index, 'inputType', e.target.value)}
                              className="w-20 p-1 border rounded"
                            >
                              <option value="XLR">XLR</option>
                              <option value="TRS">TRS</option>
                              <option value="RCA">RCA</option>
                              <option value="DI">DI</option>
                            </select>
                          </td>
                          <td className="p-2">
                            <input
                              type="checkbox"
                              checked={channel.phantom}
                              onChange={(e) => updateMixerChannel(index, 'phantom', e.target.checked)}
                            />
                          </td>
                          <td className="p-2">
                            <Input
                              value={channel.gain}
                              onChange={(e) => updateMixerChannel(index, 'gain', e.target.value)}
                              className="w-16"
                              placeholder="0dB"
                            />
                          </td>
                          <td className="p-2">
                            <Input
                              value={channel.eq.high}
                              onChange={(e) => updateMixerChannel(index, 'eq', { high: e.target.value })}
                              className="w-16"
                              placeholder="0dB"
                            />
                          </td>
                          <td className="p-2">
                            <Input
                              value={channel.eq.mid}
                              onChange={(e) => updateMixerChannel(index, 'eq', { mid: e.target.value })}
                              className="w-16"
                              placeholder="0dB"
                            />
                          </td>
                          <td className="p-2">
                            <Input
                              value={channel.eq.low}
                              onChange={(e) => updateMixerChannel(index, 'eq', { low: e.target.value })}
                              className="w-16"
                              placeholder="0dB"
                            />
                          </td>
                          <td className="p-2">
                            <Input
                              value={channel.aux[0]}
                              onChange={(e) => {
                                const newAux = [...channel.aux];
                                newAux[0] = e.target.value;
                                updateMixerChannel(index, 'aux', newAux);
                              }}
                              className="w-12"
                              placeholder="0"
                            />
                          </td>
                          <td className="p-2">
                            <Input
                              value={channel.aux[1]}
                              onChange={(e) => {
                                const newAux = [...channel.aux];
                                newAux[1] = e.target.value;
                                updateMixerChannel(index, 'aux', newAux);
                              }}
                              className="w-12"
                              placeholder="0"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="checkbox"
                              checked={channel.assigned}
                              onChange={(e) => updateMixerChannel(index, 'assigned', e.target.checked)}
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Channels 17-32:</strong> Available for expansion. Only showing first 16 channels for interface simplicity.
                    Full 32-channel configuration is saved in the technical rider.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Setlist Builder */}
          <TabsContent value="setlist" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center">
                    <Music className="w-5 h-5 mr-2" />
                    Setlist Builder
                  </span>
                  <Button onClick={addSetlistItem} size="sm">
                    Add Song
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {setlist.map((item, index) => (
                    <Card key={item.id} className="p-4">
                      <div className="grid md:grid-cols-6 gap-4">
                        <div>
                          <label className="text-xs font-medium text-gray-600">Song #{index + 1}</label>
                          <Input
                            value={item.songTitle}
                            onChange={(e) => updateSetlistItem(item.id, 'songTitle', e.target.value)}
                            placeholder="Song title"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-gray-600">Artist</label>
                          <Input
                            value={item.artist}
                            onChange={(e) => updateSetlistItem(item.id, 'artist', e.target.value)}
                            placeholder="Artist name"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-gray-600">Key</label>
                          <select
                            value={item.key}
                            onChange={(e) => updateSetlistItem(item.id, 'key', e.target.value)}
                            className="w-full p-2 border rounded"
                          >
                            {['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'].map(key => (
                              <option key={key} value={key}>{key}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="text-xs font-medium text-gray-600">Tempo</label>
                          <Input
                            value={item.tempo}
                            onChange={(e) => updateSetlistItem(item.id, 'tempo', e.target.value)}
                            placeholder="120 BPM"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-gray-600">Duration</label>
                          <Input
                            value={item.duration}
                            onChange={(e) => updateSetlistItem(item.id, 'duration', e.target.value)}
                            placeholder="3:30"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-gray-600">Notes</label>
                          <Input
                            value={item.notes}
                            onChange={(e) => updateSetlistItem(item.id, 'notes', e.target.value)}
                            placeholder="Performance notes"
                          />
                        </div>
                      </div>
                    </Card>
                  ))}

                  {setlist.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <Music className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <p>No songs in setlist. Click "Add Song" to get started.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Technical Rider Overview */}
          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="w-5 h-5 mr-2" />
                  Technical Rider Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <Card className="p-4">
                    <h3 className="font-semibold text-green-600 mb-2">Stage Configuration</h3>
                    <div className="space-y-2 text-sm">
                      <p>Stage Size: {stageSize.width}ft × {stageSize.height}ft</p>
                      <p>Equipment Items: {stageElements.length}</p>
                      <div className="space-y-1">
                        {stageElements.slice(0, 5).map((el, idx) => (
                          <p key={idx} className="text-xs text-gray-600">• {el.name} ({el.type})</p>
                        ))}
                        {stageElements.length > 5 && (
                          <p className="text-xs text-gray-500">+ {stageElements.length - 5} more items</p>
                        )}
                      </div>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <h3 className="font-semibold text-blue-600 mb-2">Audio Setup</h3>
                    <div className="space-y-2 text-sm">
                      <p>Assigned Channels: {mixerChannels.filter(ch => ch.assigned).length}/32</p>
                      <p>Phantom Power: {mixerChannels.filter(ch => ch.phantom).length} channels</p>
                      <div className="space-y-1">
                        {mixerChannels.filter(ch => ch.assigned).slice(0, 5).map((ch, idx) => (
                          <p key={idx} className="text-xs text-gray-600">
                            • Ch {ch.channel}: {ch.instrument || 'Unnamed'}
                          </p>
                        ))}
                      </div>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <h3 className="font-semibold text-purple-600 mb-2">Performance Details</h3>
                    <div className="space-y-2 text-sm">
                      <p>Songs: {setlist.length}</p>
                      <p>Est. Duration: {Math.floor(setlist.reduce((total, item) => {
                        const [mins, secs] = item.duration.split(':').map(n => parseInt(n) || 0);
                        return total + (mins * 60) + secs;
                      }, 0) / 60)}:{((setlist.reduce((total, item) => {
                        const [mins, secs] = item.duration.split(':').map(n => parseInt(n) || 0);
                        return total + (mins * 60) + secs;
                      }, 0) % 60)).toString().padStart(2, '0')}</p>
                      <div className="space-y-1">
                        {setlist.slice(0, 3).map((song, idx) => (
                          <p key={idx} className="text-xs text-gray-600">
                            {idx + 1}. {song.songTitle || 'Untitled'} ({song.key})
                          </p>
                        ))}
                        {setlist.length > 3 && (
                          <p className="text-xs text-gray-500">+ {setlist.length - 3} more songs</p>
                        )}
                      </div>
                    </div>
                  </Card>
                </div>

                <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">Technical Rider Status</h4>
                  <div className="grid md:grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full mr-2 ${stageElements.length > 0 ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                      <span>Stage Plot {stageElements.length > 0 ? 'Complete' : 'Incomplete'}</span>
                    </div>
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full mr-2 ${mixerChannels.some(ch => ch.assigned) ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                      <span>Mixer Config {mixerChannels.some(ch => ch.assigned) ? 'Complete' : 'Incomplete'}</span>
                    </div>
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full mr-2 ${setlist.length > 0 ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                      <span>Setlist {setlist.length > 0 ? 'Complete' : 'Incomplete'}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}