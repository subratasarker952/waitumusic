import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import UnifiedDashboard from '@/components/UnifiedDashboard';
import AuthRequiredWrapper from '@/components/auth/AuthRequiredWrapper';

function DashboardContent() {
  const { user } = useAuth();

  // Fetch dashboard statistics
  const { data: stats, isLoading: statsLoading, error: statsError } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    enabled: !!user,
    retry: 1,
    retryOnMount: false
  });

  const isAdminRole = user && [1, 2].includes(user.roleId);

  // Fetch bookings based on user role
  const { data: allBookings, isLoading: allBookingsLoading, error: allBookingsError } = useQuery({
    queryKey: ['/api/bookings/all'],
    enabled: !!user && !!isAdminRole,
    retry: 1
  });

  // Fetch user's own bookings
  const { data: userBookings, isLoading: userBookingsLoading, error: userBookingsError } = useQuery({
    queryKey: ['/api/bookings/user'],
    enabled: !!user && !isAdminRole,
    retry: 1
  });

  // Check loading states
  const shouldLoadStats = statsLoading;
  const shouldLoadAdminBookings = isAdminRole && allBookingsLoading;
  const shouldLoadUserBookings = !isAdminRole && userBookingsLoading;

  // Show error message with more details for debugging
  if (statsError || allBookingsError || userBookingsError) {
    console.error('Dashboard errors:', { statsError, allBookingsError, userBookingsError });
    
    // Report error to OppHub learning system
    if (statsError || allBookingsError || userBookingsError) {
      const errorMsg = statsError?.message || allBookingsError?.message || userBookingsError?.message || 'Dashboard loading error';
      fetch('/api/opphub/report-error', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: `Dashboard Error: ${errorMsg}`,
          context: 'dashboard_loading_failure'
        })
      }).catch(console.error);
    }
    
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="text-red-600 mb-4">Dashboard Error</div>
          <p className="text-gray-600 mb-4">Something went wrong loading the dashboard. Please refresh the page.</p>
          {process.env.NODE_ENV === 'development' && (
            <div className="text-xs text-gray-500 mt-4 p-2 bg-gray-100 rounded">
              <p>Stats Error: {statsError?.message || 'None'}</p>
              <p>Admin Bookings Error: {allBookingsError?.message || 'None'}</p>  
              <p>User Bookings Error: {userBookingsError?.message || 'None'}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (shouldLoadStats || shouldLoadAdminBookings || shouldLoadUserBookings) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-pulse">Loading dashboard...</div>
        </div>
      </div>
    );
  }

  const bookings = Array.isArray(allBookings) ? allBookings : Array.isArray(userBookings) ? userBookings : [];

  return (
    <div className="container mx-auto px-4 py-8">
      <UnifiedDashboard stats={stats} bookings={bookings} user={user} />
    </div>
  );
}

export default function Dashboard() {
  return (
    <AuthRequiredWrapper message="Please log in to access your dashboard">
      <DashboardContent />
    </AuthRequiredWrapper>
  );
}