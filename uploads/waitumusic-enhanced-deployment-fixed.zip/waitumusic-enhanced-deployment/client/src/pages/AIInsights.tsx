import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import AICareerWidget from '@/components/AICareerWidget';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, TrendingUp, Target, Lightbulb } from 'lucide-react';

export default function AIInsights() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              AI Career Insights
            </CardTitle>
            <CardDescription>
              Please log in to access personalized career recommendations and insights.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Our AI-powered system analyzes your profile, activity, and industry trends to provide 
              tailored career guidance and actionable recommendations.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-6">
      <div className="text-center space-y-4 mb-8">
        <h1 className="text-4xl font-bold flex items-center justify-center gap-3">
          <Brain className="h-8 w-8 text-blue-600" />
          AI Career Insights
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Get personalized career recommendations powered by intelligent analysis of your profile, 
          activity patterns, and industry trends.
        </p>
      </div>

      {/* Feature Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Target className="h-5 w-5 text-green-600" />
              Smart Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Receive actionable recommendations tailored to your role, experience level, and career goals.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              Industry Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Stay informed about industry trends and market opportunities relevant to your career.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Lightbulb className="h-5 w-5 text-amber-600" />
              Growth Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Understand your strengths and identify areas for improvement with detailed analysis.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main AI Widget */}
      <AICareerWidget />
    </div>
  );
}