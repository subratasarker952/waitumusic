import React from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { CartProvider } from "@/contexts/CartContext";
import { ModalSystemProvider } from "@/components/ModalProvider";
import TestComponent from "@/components/TestComponent";

import Layout from "@/components/Layout";
import RoleBasedRoute from "@/components/RoleBasedRoute";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Dashboard from "@/pages/Dashboard";
import Artists from "@/pages/Artists";
import ArtistDetail from "@/pages/ArtistDetail";
import Booking from "@/pages/BookingPage";
import Services from "@/pages/Services";
import Consultation from "@/pages/Consultation";
import Collaboration from "@/pages/Collaboration";
import About from "@/pages/About";
import Contact from "@/pages/Contact";
import TechnicalRiderDesigner from "@/pages/TechnicalRiderDesigner";
import Cart from "@/pages/Cart";
import Store from "@/pages/Store";
import AdminPanel from "@/pages/AdminPanel";
import Recommendations from "@/pages/Recommendations";
import AIInsights from "@/pages/AIInsights";
import BookingWorkflowTest from "@/pages/BookingWorkflowTest";
import CareerRecommendations from "@/pages/CareerRecommendations";
import ManagementApplicationWalkthrough from "@/pages/ManagementApplicationWalkthrough";
import EnhancedProfileTest from "@/pages/EnhancedProfileTest";
import MusicianRateManagement from "@/pages/MusicianRateManagement";
import AICompanion from "@/pages/AICompanion";
import ComprehensiveWorkflow from "@/pages/ComprehensiveWorkflow";
import Users from "@/pages/Users";
import OppHubPage from "@/pages/OppHubPage";
import PRORegistrationPage from "@/pages/PRORegistrationPage";
import OppHubStrategicDashboard from "@/components/OppHubStrategicDashboard";
import OppHubHealthDashboard from "@/components/monitoring/OppHubHealthDashboard";
import NotFound from "@/pages/not-found";
import { SplitsheetDemoPage } from "@/components/SplitsheetDemoPage";
import EnhancedSplitsheetPage from "@/pages/EnhancedSplitsheetPage";
import Revenue from "@/pages/Revenue";
import ModalSystemTest from "@/pages/ModalSystemTest";
import OpportunityMatching from "@/pages/OpportunityMatching";
import PlatformAuditDashboard from "@/components/PlatformAuditDashboard";
import TechnicalGuidanceDemo from "@/components/TechnicalGuidanceDemo";
import OfflineBookingAccess from "@/components/OfflineBookingAccess";
import ComeSeeTvIntegrationDashboard from "@/components/ComeSeeTvIntegrationDashboard";
import DataIntegrityDemo from "@/pages/DataIntegrityDemo";
import AlbumUploadComplete from "@/pages/AlbumUploadComplete";

// Management System Components
import MerchandiseManager from "@/components/MerchandiseManager";
import NewsletterManager from "@/components/NewsletterManager";
import SplitsheetManager from "@/components/SplitsheetManager";
import ContractManager from "@/components/ContractManager";
import TechnicalRiderManager from "@/components/TechnicalRiderManager";
import ISRCManager from "@/components/ISRCManager";
import { ComprehensiveSystemAnalyzer } from "@/components/ComprehensiveSystemAnalyzer";
import SystemManagement from "@/pages/SystemManagement";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/artists" component={Artists} />
        <Route path="/artists/:id" component={ArtistDetail} />
        <Route path="/booking" component={Booking} />
        <Route path="/services" component={Services} />
        <Route path="/consultation" component={Consultation} />
        <Route path="/collaboration" component={Collaboration} />
        <Route path="/about" component={About} />
        <Route path="/contact" component={Contact} />
        <Route path="/cart" component={Cart} />
        <Route path="/store" component={Store} />
        
        <Route path="/opphub">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician', 'managed_professional', 'professional', 'fan'
          ]}>
            <OppHubPage />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/opphub-strategic">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <OppHubStrategicDashboard />
          </RoleBasedRoute>
        </Route>
        
        {/* Protected Routes */}
        <Route path="/dashboard">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician', 'managed_professional', 'professional', 'fan'
          ]}>
            <Dashboard />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/recommendations">
          <RoleBasedRoute allowedRoles={['fan']}>
            <Recommendations />
          </RoleBasedRoute>
        </Route>
        

        
        <Route path="/admin">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <AdminPanel />
          </RoleBasedRoute>
        </Route>

        <Route path="/ai-companion">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician']}>
            <AICompanion />
          </RoleBasedRoute>
        </Route>

        {/* Management System Routes */}
        <Route path="/merchandise-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician', 'managed_professional']}>
            <MerchandiseManager />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/newsletter-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician', 'managed_professional']}>
            <NewsletterManager />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/splitsheet-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician', 'managed_professional']}>
            <SplitsheetManager />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/contract-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician', 'managed_professional']}>
            <ContractManager />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/technical-rider-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician', 'managed_professional']}>
            <TechnicalRiderManager />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/isrc-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician', 'managed_professional']}>
            <ISRCManager />
          </RoleBasedRoute>
        </Route>

        <Route path="/opportunity-matching">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician', 'managed_professional', 'professional'
          ]}>
            <OpportunityMatching />
          </RoleBasedRoute>
        </Route>

        <Route path="/health-monitor">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <OppHubHealthDashboard />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/platform-audit">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <PlatformAuditDashboard />
          </RoleBasedRoute>
        </Route>


        
        <Route path="/booking-workflow-test">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <BookingWorkflowTest />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/comprehensive-workflow">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <ComprehensiveWorkflow />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/technical-guidance-demo">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <TechnicalGuidanceDemo />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/technical-rider-designer">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician']}>
            <TechnicalRiderDesigner />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/technical-rider">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician']}>
            <TechnicalRiderDesigner />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/management-walkthrough">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <ManagementApplicationWalkthrough />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/enhanced-profile-test">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <EnhancedProfileTest />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/admin/contracts">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <AdminPanel />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/admin/bookings">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <AdminPanel />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/musician-rates">
          <RoleBasedRoute allowedRoles={['musician', 'managed_musician', 'superadmin', 'admin']}>
            <MusicianRateManagement />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/users">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <Users />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/revenue" component={Revenue} />
        
        <Route path="/pro-registration">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician', 'managed_professional', 'professional'
          ]}>
            <PRORegistrationPage />
          </RoleBasedRoute>
        </Route>
        
        <Route path="/splitsheet">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician', 'managed_professional', 'professional'
          ]}>
            <EnhancedSplitsheetPage />
          </RoleBasedRoute>
        </Route>

        <Route path="/merchandise-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'artist']}>
            <MerchandiseManager />
          </RoleBasedRoute>
        </Route>

        <Route path="/splitsheet-manager">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician', 'managed_professional', 'professional'
          ]}>
            <SplitsheetManager />
          </RoleBasedRoute>
        </Route>

        <Route path="/contract-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <ContractManager />
          </RoleBasedRoute>
        </Route>

        <Route path="/technical-rider-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin', 'managed_artist', 'managed_musician']}>
            <TechnicalRiderManager />
          </RoleBasedRoute>
        </Route>

        <Route path="/isrc-manager">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician'
          ]}>
            <ISRCManager />
          </RoleBasedRoute>
        </Route>

        <Route path="/newsletter-manager">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <NewsletterManager />
          </RoleBasedRoute>
        </Route>

        <Route path="/system-management">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <SystemManagement />
          </RoleBasedRoute>
        </Route>
        
        {/* Keep legacy routes for backward compatibility */}
        <Route path="/enhanced-splitsheet">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician', 'managed_professional', 'professional'
          ]}>
            <EnhancedSplitsheetPage />
          </RoleBasedRoute>
        </Route>
        <Route path="/splitsheet-demo" component={SplitsheetDemoPage} />
        
        <Route path="/modal-system-test">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <ModalSystemTest />
          </RoleBasedRoute>
        </Route>

        <Route path="/comeseetv-integration">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <ComeSeeTvIntegrationDashboard />
          </RoleBasedRoute>
        </Route>

        <Route path="/data-integrity-demo">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <DataIntegrityDemo />
          </RoleBasedRoute>
        </Route>

        <Route path="/album-upload-complete/:albumId">
          <RoleBasedRoute allowedRoles={[
            'superadmin', 'admin', 'managed_artist', 'artist', 
            'managed_musician', 'musician'
          ]}>
            <AlbumUploadComplete />
          </RoleBasedRoute>
        </Route>

        <Route path="/system-analyzer">
          <RoleBasedRoute allowedRoles={['superadmin', 'admin']}>
            <ComprehensiveSystemAnalyzer />
          </RoleBasedRoute>
        </Route>
        
        {/* Test route for debugging React rendering */}
        <Route path="/test-react" component={TestComponent} />
        
        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  try {
    // Fixed: Add CartProvider back - Navigation component needs useCart hook
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AuthProvider>
            <CartProvider>
              <ModalSystemProvider>
                <Router />
                <Toaster />
              </ModalSystemProvider>
            </CartProvider>
          </AuthProvider>
        </TooltipProvider>
      </QueryClientProvider>
    );
  } catch (error) {
    console.error("App component error:", error);
    return (
      <div style={{ padding: '20px', color: 'red' }}>
        <h2>App Component Error</h2>
        <p>Error: {error instanceof Error ? error.message : 'Unknown error'}</p>
      </div>
    );
  }
}

export default App;
