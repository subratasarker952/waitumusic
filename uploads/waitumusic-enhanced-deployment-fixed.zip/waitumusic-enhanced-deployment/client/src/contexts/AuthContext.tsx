import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface User {
  id: number;
  email: string;
  fullName: string;
  roleId: number;
}

interface UserProfile {
  userId: number;
  bio?: string;
  avatarUrl?: string;
  coverImageUrl?: string;
  socialLinks?: any;
  websiteUrl?: string;
  phoneNumber?: string;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  roleData: any;
  role: any;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: any) => Promise<boolean>;
  logout: () => void;
  refreshProfile: () => Promise<void>;
  getToken: () => string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export { AuthContext };

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [roleData, setRoleData] = useState<any>(null);
  const [role, setRole] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      setIsLoading(false);
      return;
    }

    try {
      const data = await apiRequest('/api/user/profile');
      setUser(data.user);
      setProfile(data.profile);
      setRoleData(data.roleData);
      setRole(data.role || data.user?.role);
    } catch (error) {
      // Clear invalid token and redirect to login
      localStorage.removeItem('token');
      setUser(null);
      setProfile(null);
      setRoleData(null);
      setRole(null);
      console.error('Auth check failed:', error);
      // Report authentication error to OppHub learning system
      fetch('/api/opphub/report-error', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: `Authentication Error: ${error}`,
          context: 'authentication_failure'
        })
      }).catch(console.error);
      
      localStorage.removeItem('token');
      setUser(null);
      setProfile(null);
      setRoleData(null);
      setRole(null);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const data = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: { email, password }
      });

      localStorage.setItem('token', data.token);
      setUser(data.user);
      await refreshProfile();
      toast({
        title: "Login successful",
        description: `Welcome back, ${data.user.fullName}!`,
      });
      return true;
    } catch (error: any) {
      console.error('Login error:', error);
      toast({
        title: "Login failed", 
        description: error.message?.includes('401') ? "Invalid email or password" : "Unable to connect to server. Please try again.",
        variant: "destructive",
      });
      return false;
    }
  };

  const register = async (userData: any): Promise<boolean> => {
    try {
      const data = await apiRequest('/api/auth/register', {
        method: 'POST',
        body: userData,
      });

      localStorage.setItem('token', data.token);
      setUser(data.user);
      await refreshProfile();
      toast({
          title: "Registration successful",
          description: "Welcome to Wai'tuMusic!",
        });
        return true;
    } catch (error: any) {
      console.error('Registration error:', error);
      toast({
        title: "Registration failed",
        description: error.message?.includes('400') ? "Registration failed - user may already exist" : "Unable to connect to server",
        variant: "destructive",
      });
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
    setProfile(null);
    setRoleData(null);
    setRole(null);
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    });
  };

  const refreshProfile = async () => {
    const token = localStorage.getItem('token');
    if (!token) return;

    try {
      const data = await apiRequest('/api/user/profile');
      setProfile(data.profile);
      setRoleData(data.roleData);
      setRole(data.role || data.user?.role);
    } catch (error) {
      console.error('Profile refresh failed:', error);
    }
  };

  const getToken = () => {
    return localStorage.getItem('token');
  };

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      roleData,
      role,
      isLoading,
      login,
      register,
      logout,
      refreshProfile,
      getToken
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
