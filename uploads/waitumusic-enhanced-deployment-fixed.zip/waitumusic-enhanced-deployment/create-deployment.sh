#!/bin/bash

# WaituMusic Platform Deployment Package Creator
# This script creates a deployment package for production servers

set -e

echo "Creating WaituMusic Platform deployment package..."

# Configuration
DEPLOY_DIR="waitumusic-deploy"
PACKAGE_NAME="waitumusic-platform-deploy.tar.gz"

# Clean previous deployment directory
rm -rf "$DEPLOY_DIR"
rm -f "$PACKAGE_NAME"

# Create deployment directory
mkdir -p "$DEPLOY_DIR"

echo "Copying essential files..."

# Copy package.json for production
cp deploy/package.json "$DEPLOY_DIR/"

# Copy server files
cp -r server "$DEPLOY_DIR/"

# Copy client source files (will be built on server)
mkdir -p "$DEPLOY_DIR/client/src"
cp -r client/src/* "$DEPLOY_DIR/client/src/"

# Copy build configuration files
cp vite.config.ts "$DEPLOY_DIR/"
cp tsconfig.json "$DEPLOY_DIR/"
cp tsconfig.server.json "$DEPLOY_DIR/" 2>/dev/null || echo "tsconfig.server.json not found, skipping"
cp tailwind.config.ts "$DEPLOY_DIR/"
cp postcss.config.js "$DEPLOY_DIR/"
cp components.json "$DEPLOY_DIR/"

# Copy database configuration
cp drizzle.config.ts "$DEPLOY_DIR/"

# Copy shared files
cp -r shared "$DEPLOY_DIR/"

# Copy client public assets and index.html
mkdir -p "$DEPLOY_DIR/client/public"
if [ -d "client/public" ]; then
    cp -r client/public/* "$DEPLOY_DIR/client/public/"
fi

# Create index.html if it doesn't exist
if [ ! -f "$DEPLOY_DIR/client/public/index.html" ]; then
    cat > "$DEPLOY_DIR/client/public/index.html" << 'EOF'
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>WaituMusic Platform</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
EOF
fi

# Copy essential directories
mkdir -p "$DEPLOY_DIR/uploads"
mkdir -p "$DEPLOY_DIR/invoices"
mkdir -p "$DEPLOY_DIR/tmp"

# Create production environment template
cat > "$DEPLOY_DIR/.env.example" << 'EOF'
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/waitumusic_db
PGHOST=localhost
PGPORT=5432
PGDATABASE=waitumusic_db
PGUSER=waitumusic_user
PGPASSWORD=your_secure_password

# Application Configuration
NODE_ENV=production
PORT=5000
DOMAIN=your-domain.com

# Security (generate new secrets for production)
JWT_SECRET=your_jwt_secret_here
SESSION_SECRET=your_session_secret_here

# Demo Mode
DEMO_MODE_ENABLED=false

# Email Configuration
SMTP_HOST=localhost
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
FROM_EMAIL=noreply@your-domain.com

# File Upload Configuration
MAX_FILE_SIZE=50MB
UPLOAD_PATH=/path/to/uploads
EOF

# Create production TypeScript config for server
cat > "$DEPLOY_DIR/tsconfig.server.json" << 'EOF'
{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "outDir": "./dist/server",
    "rootDir": "./server",
    "module": "CommonJS",
    "target": "ES2020",
    "moduleResolution": "node",
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "declaration": false,
    "sourceMap": false
  },
  "include": [
    "server/**/*"
  ],
  "exclude": [
    "node_modules",
    "dist",
    "client"
  ]
}
EOF

# Create README for deployment
cat > "$DEPLOY_DIR/README.md" << 'EOF'
# WaituMusic Platform - Production Deployment

This package contains the WaituMusic Platform ready for production deployment on AlmaLinux 9 with CyberPanel/OpenLiteSpeed.

## Quick Installation

1. Run the installer as root:
```bash
sudo chmod +x install.sh
sudo ./install.sh your-domain.com
```

2. Configure your domain DNS to point to this server
3. Set up SSL certificate in CyberPanel
4. Access your platform at http://your-domain.com

## Manual Installation

If you prefer to install manually, see the detailed instructions in the installer script.

## Default Credentials

- **Superadmin**: superadmin@waitumusic.com / secret123
- **Admin**: admin@waitumusic.com / secret123

**Important**: Change these passwords immediately after installation!

## Support

For support and documentation, visit: https://github.com/waitumusic/platform
EOF

# Copy installer script
cp deploy/install.sh "$DEPLOY_DIR/"
chmod +x "$DEPLOY_DIR/install.sh"

# Remove development-only files and directories
rm -rf "$DEPLOY_DIR/server/**/*.ts" 2>/dev/null || true
find "$DEPLOY_DIR" -name "*.ts" -not -path "*/client/*" -delete 2>/dev/null || true

echo "Creating deployment package..."

# Create tar.gz package
tar -czf "$PACKAGE_NAME" "$DEPLOY_DIR"

echo "Deployment package created: $PACKAGE_NAME"
echo "Package size: $(du -h $PACKAGE_NAME | cut -f1)"
echo "Contents: $(tar -tzf $PACKAGE_NAME | wc -l) files"

echo ""
echo "To deploy:"
echo "1. Copy $PACKAGE_NAME to your AlmaLinux 9 server"
echo "2. Extract: tar -xzf $PACKAGE_NAME"
echo "3. Run: cd $DEPLOY_DIR && sudo ./install.sh your-domain.com"

# Cleanup
rm -rf "$DEPLOY_DIR"

echo "Deployment package ready!"