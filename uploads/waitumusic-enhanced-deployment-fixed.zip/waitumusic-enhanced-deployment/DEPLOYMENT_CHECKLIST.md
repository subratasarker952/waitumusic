# WaituMusic Production Deployment Checklist

## Pre-Deployment Requirements

### Server Requirements
- [ ] AlmaLinux 9 server with root access
- [ ] CyberPanel installed and configured
- [ ] Domain name (waitumusic.com) pointing to server
- [ ] PostgreSQL database server available
- [ ] At least 4GB RAM and 20GB disk space

### External Services
- [ ] PostgreSQL database created (waitumusic_prod)
- [ ] SendGrid account and API key for email
- [ ] Stripe account for payment processing (optional)
- [ ] SSL certificate ready (Let's Encrypt via CyberPanel)

## Deployment Steps

### 1. Upload and Extract Files
```bash
# Upload deploywaitumusic.tar.gz to server
scp deploywaitumusic.tar.gz root@your-server:/tmp/

# Extract on server
cd /tmp
tar -xzf deploywaitumusic.tar.gz
cd deploy
```

### 2. Run Installation Script
```bash
chmod +x install.sh
sudo ./install.sh
```

### 3. Configure Environment Variables
```bash
cd /home/waitumusic.com/public_html
nano .env
```

Required environment variables:
- [ ] `DATABASE_URL` - PostgreSQL connection string
- [ ] `SESSION_SECRET` - Secure random string (32+ characters)
- [ ] `JWT_SECRET` - Secure random string (32+ characters)
- [ ] `SENDGRID_API_KEY` - For email functionality
- [ ] `FROM_EMAIL` - noreply@waitumusic.com
- [ ] `STRIPE_SECRET_KEY` - For payment processing (optional)

### 4. Database Setup
```bash
# Push database schema
npm run db:push

# Verify database connection
curl http://localhost:3000/api/demo-mode
```

### 5. SSL Certificate Configuration
- [ ] Go to CyberPanel → SSL → Issue SSL
- [ ] Select waitumusic.com and www.waitumusic.com
- [ ] Choose Let's Encrypt
- [ ] Issue certificate

### 6. Web Server Configuration

#### CyberPanel (OpenLiteSpeed)
- [ ] Create website: waitumusic.com
- [ ] Set document root: `/home/waitumusic.com/public_html/dist`
- [ ] Configure reverse proxy for `/api/` → `http://127.0.0.1:3000`

#### Nginx (Alternative)
```bash
sudo cp nginx.conf /etc/nginx/conf.d/waitumusic.com.conf
sudo nginx -t
sudo systemctl restart nginx
```

### 7. Firewall Configuration
```bash
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --permanent --add-port=80/tcp
sudo firewall-cmd --permanent --add-port=443/tcp
sudo firewall-cmd --reload
```

### 8. Start Application
```bash
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup systemd
```

## Post-Deployment Verification

### Health Checks
- [ ] Application status: `pm2 status`
- [ ] API health: `curl http://localhost:3000/api/demo-mode`
- [ ] Database: `curl http://localhost:3000/api/artists`
- [ ] SSL: `curl https://www.waitumusic.com/api/demo-mode`

### Functionality Tests
- [ ] Homepage loads: https://www.waitumusic.com
- [ ] Login system works with demo accounts
- [ ] Artist catalog displays (Princess Trinidad, Lí-Lí Octave)
- [ ] API endpoints respond correctly
- [ ] Database queries execute successfully

### Performance Tests
- [ ] Page load times < 3 seconds
- [ ] API response times < 500ms
- [ ] PM2 memory usage reasonable
- [ ] No error logs in PM2 or application logs

## Security Checklist

### Environment Security
- [ ] All default passwords changed
- [ ] Environment variables secured
- [ ] Database access restricted
- [ ] Firewall properly configured

### SSL and HTTPS
- [ ] SSL certificate valid and auto-renewing
- [ ] HTTP redirects to HTTPS
- [ ] HSTS headers configured
- [ ] Security headers present

### Application Security
- [ ] Demo mode disabled in production (`DEMO_MODE_ENABLED=false`)
- [ ] CORS configured for production domain
- [ ] Rate limiting enabled
- [ ] File upload restrictions in place

## Monitoring Setup

### Log Monitoring
- [ ] PM2 logs accessible: `pm2 logs waitumusic-production`
- [ ] Application logs: `/home/waitumusic.com/logs/`
- [ ] Nginx/OpenLiteSpeed logs configured
- [ ] Error tracking setup

### Performance Monitoring
- [ ] PM2 monitoring: `pm2 monit`
- [ ] Server resource monitoring
- [ ] Database performance monitoring
- [ ] API response time monitoring

## Backup and Recovery

### Backup Setup
- [ ] Database backup script configured
- [ ] File backup for uploads directory
- [ ] Configuration backup (environment variables)
- [ ] Automated backup schedule

### Recovery Plan
- [ ] Database restore procedure tested
- [ ] Application rollback procedure documented
- [ ] Configuration recovery plan
- [ ] Emergency contact information

## Production Optimization

### Performance Tuning
- [ ] PM2 cluster mode configured
- [ ] Database connection pooling optimized
- [ ] Static file caching configured
- [ ] Gzip compression enabled

### SEO and Analytics
- [ ] Google Analytics setup (optional)
- [ ] SEO meta tags configured
- [ ] Sitemap generated
- [ ] Robots.txt configured

## Troubleshooting Commands

### PM2 Management
```bash
pm2 status                           # Check status
pm2 logs waitumusic-production       # View logs
pm2 restart waitumusic-production    # Restart app
pm2 reload waitumusic-production     # Reload without downtime
pm2 stop waitumusic-production       # Stop app
```

### Health Checks
```bash
curl http://localhost:3000/api/demo-mode     # API health
curl http://localhost:3000/api/artists       # Database health
netstat -tlnp | grep :3000                   # Port check
systemctl status pm2-root                    # PM2 service status
```

### Database Operations
```bash
npm run db:push          # Update schema
npm run db:studio        # Open database studio
psql $DATABASE_URL       # Direct database access
```

## Support Resources

### Documentation
- Application logs: `/home/waitumusic.com/logs/`
- PM2 logs: `pm2 logs waitumusic-production`
- System logs: `journalctl -u pm2-root`

### Common Issues
1. **Port 3000 in use**: `sudo netstat -tlnp | grep :3000` and kill process
2. **Database connection**: Check DATABASE_URL and PostgreSQL status
3. **SSL issues**: Renew certificate through CyberPanel
4. **Application crashes**: Check PM2 logs and restart

### Emergency Procedures
1. **Application down**: `pm2 restart waitumusic-production`
2. **Database issues**: Check connection and run `npm run db:push`
3. **SSL expired**: Renew through CyberPanel
4. **High memory usage**: `pm2 reload waitumusic-production`

## Deployment Complete

Once all items are checked, WaituMusic is successfully deployed and ready for production use at https://www.waitumusic.com.

**Final verification**: All systems operational, SSL secure, application responsive, and monitoring active.